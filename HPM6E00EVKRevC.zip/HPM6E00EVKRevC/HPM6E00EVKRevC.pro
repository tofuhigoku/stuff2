{
  "board": {
    "3dviewports": [],
    "design_settings": {
      "defaults": {
        "board_outline_line_width": 0.09999999999999999,
        "copper_line_width": 0.19999999999999998,
        "copper_text_italic": false,
        "copper_text_size_h": 1.5,
        "copper_text_size_v": 1.5,
        "copper_text_thickness": 0.3,
        "copper_text_upright": false,
        "courtyard_line_width": 0.049999999999999996,
        "dimension_precision": 4,
        "dimension_units": 3,
        "dimensions": {
          "arrow_length": 1270000,
          "extension_offset": 500000,
          "keep_text_aligned": true,
          "suppress_zeroes": false,
          "text_position": 0,
          "units_format": 1
        },
        "fab_line_width": 0.09999999999999999,
        "fab_text_italic": false,
        "fab_text_size_h": 1.0,
        "fab_text_size_v": 1.0,
        "fab_text_thickness": 0.15,
        "fab_text_upright": false,
        "other_line_width": 0.15,
        "other_text_italic": false,
        "other_text_size_h": 1.0,
        "other_text_size_v": 1.0,
        "other_text_thickness": 0.15,
        "other_text_upright": false,
        "pads": {
          "drill": 1.0,
          "height": 1.7,
          "width": 1.7
        },
        "silk_line_width": 0.09999999999999999,
        "silk_text_italic": false,
        "silk_text_size_h": 0.6,
        "silk_text_size_v": 0.75,
        "silk_text_thickness": 0.1016,
        "silk_text_upright": false,
        "zones": {
          "45_degree_only": false,
          "min_clearance": 0.0
        }
      },
      "diff_pair_dimensions": [
        {
          "gap": 0.0,
          "via_gap": 0.0,
          "width": 0.0
        },
        {
          "gap": 0.1524,
          "via_gap": 0.1524,
          "width": 0.1016
        },
        {
          "gap": 2.4384,
          "via_gap": 2.032,
          "width": 0.1016
        },
        {
          "gap": 0.254,
          "via_gap": 0.2032,
          "width": 0.2032
        }
      ],
      "drc_exclusions": [],
      "meta": {
        "version": 2
      },
      "rule_severities": {
        "annular_width": "error",
        "clearance": "error",
        "connection_width": "ignore",
        "copper_edge_clearance": "error",
        "copper_sliver": "error",
        "courtyards_overlap": "ignore",
        "diff_pair_gap_out_of_range": "error",
        "diff_pair_uncoupled_length_too_long": "error",
        "drill_out_of_range": "error",
        "duplicate_footprints": "error",
        "extra_footprint": "error",
        "footprint": "error",
        "footprint_type_mismatch": "ignore",
        "hole_clearance": "error",
        "hole_near_hole": "error",
        "invalid_outline": "error",
        "isolated_copper": "error",
        "item_on_disabled_layer": "error",
        "items_not_allowed": "error",
        "length_out_of_range": "error",
        "lib_footprint_issues": "ignore",
        "lib_footprint_mismatch": "ignore",
        "malformed_courtyard": "error",
        "microvia_drill_out_of_range": "error",
        "missing_courtyard": "ignore",
        "missing_footprint": "error",
        "net_conflict": "error",
        "npth_inside_courtyard": "ignore",
        "padstack": "error",
        "pth_inside_courtyard": "ignore",
        "shorting_items": "error",
        "silk_edge_clearance": "ignore",
        "silk_over_copper": "ignore",
        "silk_overlap": "ignore",
        "skew_out_of_range": "error",
        "solder_mask_bridge": "error",
        "starved_thermal": "error",
        "text_height": "ignore",
        "text_thickness": "ignore",
        "through_hole_pad_without_hole": "error",
        "too_many_vias": "error",
        "track_dangling": "error",
        "track_width": "error",
        "tracks_crossing": "error",
        "unconnected_items": "error",
        "unresolved_variable": "error",
        "via_dangling": "error",
        "zones_intersect": "error"
      },
      "rules": {
        "allow_blind_buried_vias": false,
        "allow_microvias": false,
        "max_error": 0.005,
        "min_clearance": 0.1016,
        "min_connection": 0.1016,
        "min_copper_edge_clearance": 0.15239999999999998,
        "min_hole_clearance": 0.15239999999999998,
        "min_hole_to_hole": 0.15239999999999998,
        "min_microvia_diameter": 0.4064,
        "min_microvia_drill": 0.1016,
        "min_resolved_spokes": 1,
        "min_silk_clearance": 0.0,
        "min_text_height": 0.508,
        "min_text_thickness": 0.0508,
        "min_through_hole_diameter": 0.15239999999999998,
        "min_track_width": 0.1016,
        "min_via_annular_width": 0.0508,
        "min_via_diameter": 0.254,
        "solder_mask_clearance": 0.0,
        "solder_mask_min_width": 0.0,
        "solder_mask_to_copper_clearance": 0.0,
        "use_height_for_length_calcs": true
      },
      "teardrop_options": [
        {
          "td_allow_use_two_tracks": false,
          "td_curve_segcount": 5,
          "td_on_pad_in_zone": false,
          "td_onpadsmd": false,
          "td_onroundshapesonly": false,
          "td_ontrackend": false,
          "td_onviapad": false
        }
      ],
      "teardrop_parameters": [
        {
          "td_curve_segcount": 0,
          "td_height_ratio": 1.0,
          "td_length_ratio": 0.5,
          "td_maxheight": 2.0,
          "td_maxlen": 1.0,
          "td_target_name": "td_round_shape",
          "td_width_to_size_filter_ratio": 0.9
        },
        {
          "td_curve_segcount": 0,
          "td_height_ratio": 1.0,
          "td_length_ratio": 0.5,
          "td_maxheight": 2.0,
          "td_maxlen": 1.0,
          "td_target_name": "td_rect_shape",
          "td_width_to_size_filter_ratio": 0.9
        },
        {
          "td_curve_segcount": 0,
          "td_height_ratio": 1.0,
          "td_length_ratio": 0.5,
          "td_maxheight": 2.0,
          "td_maxlen": 1.0,
          "td_target_name": "td_track_end",
          "td_width_to_size_filter_ratio": 0.9
        }
      ],
      "track_widths": [
        0.0,
        0.1016,
        0.1524,
        0.2032,
        0.254,
        0.3,
        0.381,
        0.508,
        0.762,
        1.016,
        1.27
      ],
      "via_dimensions": [
        {
          "diameter": 0.0,
          "drill": 0.0
        },
        {
          "diameter": 0.4064,
          "drill": 0.254
        }
      ],
      "zones_allow_external_fillets": false,
      "zones_use_no_outline": true
    },
    "layer_presets": [
      {
        "activeLayer": -2,
        "layers": [
          0,
          37,
          44
        ],
        "name": "top",
        "renderLayers": [
          125,
          126,
          127,
          128,
          129,
          130,
          133,
          134,
          135,
          136,
          137,
          138,
          139,
          140,
          141,
          142,
          143,
          144,
          145,
          146,
          147,
          148,
          149,
          150,
          151,
          152,
          153,
          154,
          155,
          157,
          158,
          159,
          160,
          161
        ]
      }
    ],
    "viewports": []
  },
  "boards": [],
  "cvpcb": {
    "equivalence_files": []
  },
  "erc": {
    "erc_exclusions": [],
    "meta": {
      "version": 0
    },
    "pin_map": [
      [
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        2
      ],
      [
        0,
        2,
        0,
        1,
        0,
        0,
        1,
        0,
        2,
        2,
        2,
        2
      ],
      [
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        1,
        0,
        1,
        2
      ],
      [
        0,
        1,
        0,
        0,
        0,
        0,
        1,
        1,
        2,
        1,
        1,
        2
      ],
      [
        0,
        0,
        0,
        0,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        2
      ],
      [
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        0,
        2
      ],
      [
        1,
        1,
        1,
        1,
        1,
        0,
        1,
        1,
        1,
        1,
        1,
        2
      ],
      [
        0,
        0,
        0,
        1,
        0,
        0,
        1,
        0,
        0,
        0,
        0,
        2
      ],
      [
        0,
        2,
        1,
        2,
        0,
        0,
        1,
        0,
        2,
        2,
        2,
        2
      ],
      [
        0,
        2,
        0,
        1,
        0,
        0,
        1,
        0,
        2,
        0,
        0,
        2
      ],
      [
        0,
        2,
        1,
        1,
        0,
        0,
        1,
        0,
        2,
        0,
        0,
        2
      ],
      [
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2,
        2
      ]
    ],
    "rule_severities": {
      "bus_definition_conflict": "error",
      "bus_entry_needed": "error",
      "bus_to_bus_conflict": "error",
      "bus_to_net_conflict": "error",
      "conflicting_netclasses": "error",
      "different_unit_footprint": "error",
      "different_unit_net": "error",
      "duplicate_reference": "error",
      "duplicate_sheet_names": "error",
      "endpoint_off_grid": "ignore",
      "extra_units": "error",
      "global_label_dangling": "error",
      "hier_label_mismatch": "error",
      "label_dangling": "ignore",
      "lib_symbol_issues": "warning",
      "missing_bidi_pin": "error",
      "missing_input_pin": "error",
      "missing_power_pin": "error",
      "missing_unit": "error",
      "multiple_net_names": "error",
      "net_not_bus_member": "error",
      "no_connect_connected": "error",
      "no_connect_dangling": "ignore",
      "pin_not_connected": "ignore",
      "pin_not_driven": "ignore",
      "pin_to_pin": "ignore",
      "power_pin_not_driven": "ignore",
      "similar_labels": "error",
      "simulation_model_issue": "ignore",
      "unannotated": "error",
      "unit_value_mismatch": "error",
      "unresolved_variable": "error",
      "wire_dangling": "error"
    }
  },
  "libraries": {
    "pinned_footprint_libs": [],
    "pinned_symbol_libs": []
  },
  "meta": {
    "filename": "HPM6E00EVKRevC.kicad_pro",
    "version": 1
  },
  "net_settings": {
    "classes": [
      {
        "bus_width": 12,
        "clearance": 0.1016,
        "diff_pair_gap": 0.2032,
        "diff_pair_via_gap": 0.25,
        "diff_pair_width": 0.1016,
        "line_style": 0,
        "microvia_diameter": 0.3,
        "microvia_drill": 0.1,
        "name": "Default",
        "pcb_color": "rgba(0, 0, 0, 0.000)",
        "schematic_color": "rgba(0, 0, 0, 0.000)",
        "track_width": 0.1016,
        "via_diameter": 0.4064,
        "via_drill": 0.254,
        "wire_width": 6
      },
      {
        "bus_width": 12,
        "clearance": 0.1016,
        "diff_pair_gap": 0.2032,
        "diff_pair_via_gap": 0.25,
        "diff_pair_width": 0.1016,
        "line_style": 0,
        "microvia_diameter": 0.3,
        "microvia_drill": 0.1,
        "name": "MII",
        "pcb_color": "rgba(0, 0, 0, 0.000)",
        "schematic_color": "rgba(0, 0, 0, 0.000)",
        "track_width": 0.1016,
        "via_diameter": 0.4064,
        "via_drill": 0.254,
        "wire_width": 6
      },
      {
        "bus_width": 12,
        "clearance": 0.1016,
        "diff_pair_gap": 0.127,
        "diff_pair_via_gap": 0.25,
        "diff_pair_width": 0.1016,
        "line_style": 0,
        "microvia_diameter": 0.3,
        "microvia_drill": 0.1,
        "name": "USB",
        "pcb_color": "rgba(0, 0, 0, 0.000)",
        "schematic_color": "rgba(0, 0, 0, 0.000)",
        "track_width": 0.1016,
        "via_diameter": 0.4064,
        "via_drill": 0.254,
        "wire_width": 6
      }
    ],
    "meta": {
      "version": 3
    },
    "net_colors": null,
    "netclass_assignments": null,
    "netclass_patterns": [
      {
        "netclass": "MII",
        "pattern": "/HPM6E00 EVK MAINENTRY/PA19"
      }
    ]
  },
  "pcbnew": {
    "last_paths": {
      "gencad": "",
      "idf": "",
      "netlist": "./",
      "specctra_dsn": "",
      "step": "",
      "vrml": ""
    },
    "page_layout_descr_file": ""
  },
  "schematic": {
    "annotate_start_num": 0,
    "drawing": {
      "dashed_lines_dash_length_ratio": 12.0,
      "dashed_lines_gap_length_ratio": 3.0,
      "default_line_thickness": 6.0,
      "default_text_size": 50.0,
      "field_names": [],
      "intersheets_ref_own_page": false,
      "intersheets_ref_prefix": "",
      "intersheets_ref_short": false,
      "intersheets_ref_show": false,
      "intersheets_ref_suffix": "",
      "junction_size_choice": 3,
      "label_size_ratio": 0.375,
      "pin_symbol_size": 25.0,
      "text_offset_ratio": 0.15
    },
    "legacy_lib_dir": "",
    "legacy_lib_list": [],
    "meta": {
      "version": 1
    },
    "net_format_name": "",
    "ngspice": {
      "fix_include_paths": true,
      "fix_passive_vals": false,
      "meta": {
        "version": 0
      },
      "model_mode": 0,
      "workbook_filename": ""
    },
    "page_layout_descr_file": "LOGO1.kicad_wks",
    "plot_directory": "./",
    "spice_adjust_passive_values": false,
    "spice_current_sheet_as_root": false,
    "spice_external_command": "spice \"%I\"",
    "spice_model_current_sheet_as_root": true,
    "spice_save_all_currents": false,
    "spice_save_all_voltages": false,
    "subpart_first_id": 65,
    "subpart_id_separator": 0
  },
  "sheets": [
    [
      "beb44ed8-7622-45cf-bbfb-b2d5b9d8c208",
      ""
    ],
    [
      "f1049d94-3709-48ef-97b5-91120e738f00",
      "HPM6E00 EVK MAINENTRY"
    ],
    [
      "25fbddd4-121b-45bc-9d5c-b1a29b271505",
      "MCU_POWER"
    ],
    [
      "64c6c979-a234-4d9b-ab9c-77c628dd08ef",
      "MCU_PA&JTAG"
    ],
    [
      "fe001727-b9b6-48f9-9091-47c87be6eeea",
      "MCU_PB&FLASH"
    ],
    [
      "ec7061b6-00a7-4ff1-9a25-a121ab0e2b02",
      "MCU_PC&PD"
    ],
    [
      "80972795-ef8c-4d10-a412-3b571d8c109e",
      "MCU_PE"
    ],
    [
      "e7136f12-2387-4abd-a480-0f0bcb9cd2e4",
      "MCU_PF"
    ],
    [
      "461aadfd-1dc7-48b2-9324-43aebd74c5e7",
      "MCU_PY&PZ"
    ],
    [
      "ec6a6f6f-ae47-4a68-be51-cbf014b7338a",
      "MCU_USB&OSC"
    ],
    [
      "26258b01-d699-48f1-bf49-060b9aea75c9",
      "POWER"
    ],
    [
      "00ec6331-320c-41ca-90b3-2a365d4e193d",
      "ETHERCAT_A"
    ],
    [
      "3a910f40-0a09-4108-80d6-1fa75b40b1af",
      "ETHERCAT_B"
    ],
    [
      "21a69ad3-d4bc-4ca6-8758-48254c4665b1",
      "ETH_RGMII"
    ],
    [
      "2dda6564-240e-411c-87a3-0164d71f620d",
      "MOTOR_IF"
    ],
    [
      "a7954fe4-ba93-4956-94e3-ae1db24a196c",
      "RASPBERRY-PI_IF"
    ],
    [
      "4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505",
      "PPI&FEMC_IF"
    ],
    [
      "b8432231-9443-4f8c-b065-03c77811eba6",
      "PDM&DAO"
    ],
    [
      "fd9440a8-6c85-4683-8354-fd761d502aa0",
      "AUDIO_CODEC"
    ],
    [
      "d039d08c-645b-4ed7-9c2b-76bd2108cc2f",
      "ADC&CAN"
    ],
    [
      "9f4b65b3-3be8-46c5-9cef-7a140a88b39d",
      "DEBUG_FT2232"
    ],
    [
      "ede36aad-ac34-4d4f-8b81-cc1b3553ddbb",
      "MISC"
    ]
  ],
  "text_variables": {}
}
