(kicad_sch (version 20230121) (generator eeschema)

  (uuid 31be0534-3b8d-4e19-9cd1-4848291a63e7)

  (paper "A3")

  (title_block
    (title "HPM6E00EVKRevC")
    (date "2024-09-29")
    (rev "C")
    (comment 1 "AUDIO_CODEC")
  )

  (lib_symbols
    (symbol "00_HPM_power:+5V" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "+5V" (at 0 3.556 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "power-flag" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"+5V\"" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "+5V_0_1"
        (polyline
          (pts
            (xy -0.762 1.27)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 0)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 2.54)
            (xy 0.762 1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "+5V_1_1"
        (pin power_in line (at 0 0 90) (length 0) hide
          (name "+5V" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "00_HPM_power:GND" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "GND" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "power-flag" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"GND\" , ground" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "GND_0_1"
        (polyline
          (pts
            (xy 0 0)
            (xy 0 -1.27)
            (xy 1.27 -1.27)
            (xy 0 -2.54)
            (xy -1.27 -1.27)
            (xy 0 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "GND_1_1"
        (pin power_in line (at 0 0 270) (length 0) hide
          (name "GND" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "00_HPM_power:VAUD_3.3V" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "VAUD_3.3V" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "power-flag" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"VDD\"" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "VAUD_3.3V_0_1"
        (polyline
          (pts
            (xy -0.762 1.27)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 0)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 2.54)
            (xy 0.762 1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "VAUD_3.3V_1_1"
        (pin power_in line (at 0 0 90) (length 0) hide
          (name "VAUD_3.3V" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
          (alternate "VANA" power_in line)
        )
      )
    )
    (symbol "01-HPM-Peripheral:TestPoint-0.5mm" (pin_numbers hide) (pin_names (offset 0.762) hide) (in_bom yes) (on_board yes)
      (property "Reference" "TP" (at -2.54 -1.27 0)
        (effects (font (size 1.27 1.27)) (justify left) hide)
      )
      (property "Value" "0.5mm" (at -1.27 5.08 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "01_HPM_Peripheral:TestPoint_Pad_D0.5mm" (at 5.08 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 5.08 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "test point tp" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "test point" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "Pin* Test*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "TestPoint-0.5mm_0_1"
        (circle (center 0 3.302) (radius 0.762)
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "TestPoint-0.5mm_1_1"
        (pin passive line (at 0 0 90) (length 2.54)
          (name "1" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:0Ω_0603" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 5.08 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "0Ω" (at 1.27 7.62 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 2.54 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0603WAF0000T5E" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 1.27 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "0Ω_0603_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "0Ω_0603_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:10K_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "10K" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402WGF1002TCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "10K_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "10K_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:1K_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "1K" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402WGF1001TCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "1K_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "1K_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:2.49K_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "2.49K" (at 0 10.16 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "RC0402FR-072K7L" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "YAGEO(国巨)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "2.49K_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "2.49K_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:33Ω_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "33Ω" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402WGF330JTCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "33Ω_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "33Ω_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:5.1K_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "5.1K" (at 0 7.62 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402WGF5101TCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "5.1K_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "5.1K_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:0.1uF,16V_0402" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at -1.27 10.16 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "0.1uF,16V" (at -5.08 12.7 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 2.54 -13.97 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "CL05B104KO5NNNC" (at 1.27 -16.51 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "SAMSUNG(三星)" (at 0 -11.43 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "0.1uF,16V_0402_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "0.1uF,16V_0402_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:10uF,10V_0402" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at -3.81 15.24 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "10uF,10V" (at -3.81 10.16 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "CL05A106MP5NUNC" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" " SAMSUNG(三星)" (at 0 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "10uF,10V_0402_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "10uF,10V_0402_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:10uF,16V_0603" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0.635 2.54 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "10uF,16V" (at 0.635 -2.54 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0603_1608Metric" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "CL10A106KO8NQNC" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" " SAMSUNG(三星)" (at 0 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0603" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "10uF,16V_0603_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "10uF,16V_0603_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:18pF,50V_0402" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0.635 2.54 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "18pF,50V" (at 0.635 -2.54 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 3.81 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" " CC0402JRNPO9BN180" (at 2.54 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" " YAGEO(国巨)" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "18pF,50V_0402_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "18pF,50V_0402_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:220pF,50V_0402" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at -5.08 13.97 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "220pF,50V" (at -5.08 8.89 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 3.81 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402B221K500NT" (at 2.54 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" " YAGEO(国巨)" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "220pF,50V_0402_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "220pF,50V_0402_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:4.7uF,16V_0603" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0.635 2.54 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "4.7uF,16V" (at 0.635 -2.54 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0603_1608Metric" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "CL10A475KO8NNNC" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" " SAMSUNG(三星)" (at 0 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0603" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "4.7uF,16V_0603_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "4.7uF,16V_0603_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:钽电容_100uF, 6.3V" (pin_numbers hide) (pin_names (offset 1.016) hide) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0 4.572 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "100uF, 6.3V" (at 12.7 2.54 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "03_HPM_Capacitance:CASE-B_3528" (at -1.27 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at -1.27 -11.43 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "TAJB107K006RNJ" (at 0 -10.668 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" " Kyocera AVX" (at -1.27 -13.97 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "ki_description" "钽电容" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "钽电容_100uF, 6.3V_1_1"
        (polyline
          (pts
            (xy -0.508 0)
            (xy -1.27 0)
          )
          (stroke (width 0.1524) (type solid))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -0.508 2.032)
            (xy -0.508 -2.032)
          )
          (stroke (width 0.1524) (type solid))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0.508 2.032)
            (xy 0.508 -2.032)
          )
          (stroke (width 0.1524) (type solid))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.27 0)
            (xy 0.508 0)
          )
          (stroke (width 0.1524) (type solid))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 2.032 1.524)
            (xy 2.032 0.508)
          )
          (stroke (width 0.1524) (type solid))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 2.54 1.016)
            (xy 1.524 1.016)
          )
          (stroke (width 0.1524) (type solid))
          (fill (type none))
        )
        (pin input line (at 3.81 0 180) (length 2.54)
          (name "1" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -3.81 0 0) (length 2.54)
          (name "2" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "05_HPM_Connector_KF2EDGR:KF2EDGR_3.81_2P" (pin_names (offset 1.016) hide) (in_bom yes) (on_board yes)
      (property "Reference" "J" (at 1.27 2.54 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "KF2EDGR_3.81_2P" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Footprint" "05_HPM_Connector_KF2EDGR:PhoenixContact_MC_1,5_2-G-3.81_1x02_P3.81mm_Horizontal" (at -2.54 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 1.27 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "" (at -2.54 -13.97 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "BOOMELE(博穆精密)" (at -2.54 -11.43 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 1.27 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "connector" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "插拔式接线端子,弯针" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "Connector*:*_1x??_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "KF2EDGR_3.81_2P_1_1"
        (rectangle (start 0 -3.683) (end 1.27 -3.937)
          (stroke (width 0.1524) (type default))
          (fill (type none))
        )
        (rectangle (start 0 -1.143) (end 1.27 -1.397)
          (stroke (width 0.1524) (type default))
          (fill (type none))
        )
        (rectangle (start 0 0) (end 2.54 -5.08)
          (stroke (width 0.254) (type default))
          (fill (type background))
        )
        (pin passive line (at -3.81 -1.27 0) (length 3.81)
          (name "Pin_1" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at -3.81 -3.81 0) (length 3.81)
          (name "Pin_2" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "07_HPM_Inductance:磁珠-600Ω@100MHz_1.3A_0603" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "FB" (at -2.54 1.27 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "600Ω@100MHz_1.3A" (at -6.35 -3.81 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 2.54 -5.715 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 2.54 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "BLM18KG601SN1D" (at 3.81 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "muRata(村田)" (at 1.27 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "BLM18KG601SN1D" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "Inductor_* L_* *Ferrite*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "磁珠-600Ω@100MHz_1.3A_0603_0_1"
        (polyline
          (pts
            (xy 1.27 0)
            (xy 1.7526 0)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 3.429 0)
            (xy 3.8354 0)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 2.8194 1.8288)
            (xy 4.0386 1.1176)
            (xy 2.3368 -1.8288)
            (xy 1.1176 -1.1176)
            (xy 2.8194 1.8288)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "磁珠-600Ω@100MHz_1.3A_0603_1_1"
        (pin passive line (at 5.08 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "13_HPM_Audio:Microphone" (pin_names (offset 0.0254) hide) (in_bom yes) (on_board yes)
      (property "Reference" "P" (at -3.81 -3.81 0)
        (effects (font (size 1.27 1.27)) (justify right))
      )
      (property "Value" "Microphone" (at 5.08 -10.16 0)
        (effects (font (size 1.27 1.27)) (justify right))
      )
      (property "Footprint" "10_HPM_Audio:MIC-SMD_BD4.0_B4013AM423-008" (at -1.27 -19.05 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 -2.54 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "B4013AM423-008" (at 0 -12.7 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "Goertek(歌尔)" (at 0 -15.24 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "咪头/麦克风" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "Microphone_0_1"
        (polyline
          (pts
            (xy -2.54 2.54)
            (xy -2.54 -2.54)
          )
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.27 -3.81)
            (xy 1.778 -3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.524 -3.556)
            (xy 1.524 -4.064)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (circle (center 0 0) (radius 2.54)
          (stroke (width 0.254) (type default))
          (fill (type background))
        )
      )
      (symbol "Microphone_1_1"
        (pin passive line (at 0 -5.08 90) (length 2.54)
          (name "+" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 5.08 270) (length 2.54)
          (name "-" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "13_HPM_Audio:PJ-316A-6A" (in_bom yes) (on_board yes)
      (property "Reference" "J" (at -7.62 8.89 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "PJ-316A-6A" (at -5.08 8.89 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "10_HPM_Audio:SMD_PJ-316A-6A" (at 2.54 -17.78 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "PJ-316A-6A" (at 2.54 -15.24 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "韩国韩荣" (at 0 -12.7 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "音频连接器" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "PJ-316A-6A_0_1"
        (rectangle (start -7.62 7.62) (end 11.43 -8.89)
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -7.62 -7.62)
            (xy 6.35 -7.62)
            (xy 6.35 -3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -7.62 2.54)
            (xy -3.81 2.54)
            (xy -3.81 3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -7.62 -5.08)
            (xy 1.27 -5.08)
            (xy 2.54 -6.35)
            (xy 3.81 -5.08)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -7.62 -2.54)
            (xy -1.27 -2.54)
            (xy 0 -3.81)
            (xy 1.27 -2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -7.62 5.08)
            (xy -1.27 5.08)
            (xy 0 3.81)
            (xy 1.27 5.08)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -3.81 5.08)
            (xy -5.08 3.81)
            (xy -2.54 3.81)
            (xy -3.81 5.08)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -7.62 0)
            (xy -3.81 0)
            (xy -3.81 -1.27)
            (xy -5.08 -1.27)
            (xy -3.81 -2.54)
            (xy -2.54 -1.27)
            (xy -3.81 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (rectangle (start 5.08 2.54) (end 7.62 -3.81)
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "PJ-316A-6A_1_1"
        (pin power_in line (at -10.16 -7.62 0) (length 2.54)
          (name "" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin power_in line (at -10.16 5.08 0) (length 2.54)
          (name "" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 -2.54 0) (length 2.54)
          (name "" (effects (font (size 1.27 1.27))))
          (number "3" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 -5.08 0) (length 2.54)
          (name "" (effects (font (size 1.27 1.27))))
          (number "4" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 2.54 0) (length 2.54)
          (name "" (effects (font (size 1.27 1.27))))
          (number "5" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 0 0) (length 2.54)
          (name "" (effects (font (size 1.27 1.27))))
          (number "6" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "13_HPM_Audio:WM8960CGEFL/RV" (in_bom yes) (on_board yes)
      (property "Reference" "U" (at 3.81 1.27 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "WM8960CGEFL{slash}RV" (at 12.7 1.27 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "10_HPM_Audio:QFN-32" (at 15.24 -69.85 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "WM8960CGEFL/RV" (at 15.24 -67.31 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "Cirrus Logic(凌云)" (at 13.97 -64.77 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "音频接口芯片" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "WM8960CGEFL/RV_0_1"
        (rectangle (start 0 0) (end 26.67 -63.5)
          (stroke (width 0) (type default))
          (fill (type background))
        )
      )
      (symbol "WM8960CGEFL/RV_1_1"
        (pin free line (at 29.21 -22.86 180) (length 2.54)
          (name "MICBIAS" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -5.08 0) (length 2.54)
          (name "DBVDD" (effects (font (size 1.27 1.27))))
          (number "10" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -33.02 0) (length 2.54)
          (name "MCLK" (effects (font (size 1.27 1.27))))
          (number "11" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -25.4 0) (length 2.54)
          (name "BCLK" (effects (font (size 1.27 1.27))))
          (number "12" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -22.86 0) (length 2.54)
          (name "DACLRC" (effects (font (size 1.27 1.27))))
          (number "13" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -30.48 0) (length 2.54)
          (name "DACDAT" (effects (font (size 1.27 1.27))))
          (number "14" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -20.32 0) (length 2.54)
          (name "ADCLRC/GPIO1" (effects (font (size 1.27 1.27))))
          (number "15" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -27.94 0) (length 2.54)
          (name "ADCDAT" (effects (font (size 1.27 1.27))))
          (number "16" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -57.15 0) (length 2.54)
          (name "SCLK" (effects (font (size 1.27 1.27))))
          (number "17" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -59.69 0) (length 2.54)
          (name "SDIN" (effects (font (size 1.27 1.27))))
          (number "18" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -58.42 180) (length 2.54)
          (name "SPK_RN" (effects (font (size 1.27 1.27))))
          (number "19" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -40.64 0) (length 2.54)
          (name "LINPUT3/JD2" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -10.16 180) (length 2.54)
          (name "SPKGND2" (effects (font (size 1.27 1.27))))
          (number "20" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -10.16 0) (length 2.54)
          (name "SPKVDD1" (effects (font (size 1.27 1.27))))
          (number "21" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -55.88 180) (length 2.54)
          (name "SPK_RP" (effects (font (size 1.27 1.27))))
          (number "22" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -50.8 180) (length 2.54)
          (name "SPK_LN" (effects (font (size 1.27 1.27))))
          (number "23" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -7.62 180) (length 2.54)
          (name "SPKGND1" (effects (font (size 1.27 1.27))))
          (number "24" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -48.26 180) (length 2.54)
          (name "SPK_LP" (effects (font (size 1.27 1.27))))
          (number "25" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -12.7 0) (length 2.54)
          (name "SPKVDD2" (effects (font (size 1.27 1.27))))
          (number "26" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -20.32 180) (length 2.54)
          (name "VMID" (effects (font (size 1.27 1.27))))
          (number "27" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -5.08 180) (length 2.54)
          (name "AGND" (effects (font (size 1.27 1.27))))
          (number "28" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -35.56 180) (length 2.54)
          (name "HP_R" (effects (font (size 1.27 1.27))))
          (number "29" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -43.18 0) (length 2.54)
          (name "LINPUT2" (effects (font (size 1.27 1.27))))
          (number "3" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -40.64 180) (length 2.54)
          (name "OUT3" (effects (font (size 1.27 1.27))))
          (number "30" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -30.48 180) (length 2.54)
          (name "HP_L" (effects (font (size 1.27 1.27))))
          (number "31" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -7.62 0) (length 2.54)
          (name "AVDD" (effects (font (size 1.27 1.27))))
          (number "32" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -60.96 180) (length 2.54)
          (name "GND_PADDLE" (effects (font (size 1.27 1.27))))
          (number "33" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -45.72 0) (length 2.54)
          (name "LINPUT1" (effects (font (size 1.27 1.27))))
          (number "4" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -53.34 0) (length 2.54)
          (name "RINPUT1" (effects (font (size 1.27 1.27))))
          (number "5" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -50.8 0) (length 2.54)
          (name "RINPUT2" (effects (font (size 1.27 1.27))))
          (number "6" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -48.26 0) (length 2.54)
          (name "RINPUT3/JD3" (effects (font (size 1.27 1.27))))
          (number "7" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at -2.54 -2.54 0) (length 2.54)
          (name "DCVDD" (effects (font (size 1.27 1.27))))
          (number "8" (effects (font (size 1.27 1.27))))
        )
        (pin free line (at 29.21 -2.54 180) (length 2.54)
          (name "DGND" (effects (font (size 1.27 1.27))))
          (number "9" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "99_HPM:270nF,50V_0603" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0 10.16 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "0.1uF,50V" (at -3.81 12.7 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 3.81 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" " 0603B274K500NT" (at 2.54 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "FH(风华)" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "270nF,50V_0603_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "270nF,50V_0603_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "power:+3.3V" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "+3.3V" (at 0 3.556 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "global power" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"+3.3V\"" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "+3.3V_0_1"
        (polyline
          (pts
            (xy -0.762 1.27)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 0)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 2.54)
            (xy 0.762 1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "+3.3V_1_1"
        (pin power_in line (at 0 0 90) (length 0) hide
          (name "+3.3V" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
  )

  (junction (at 87.63 71.12) (diameter 0) (color 0 0 0 0)
    (uuid 18bca215-6a81-441d-9691-58a8942f4619)
  )
  (junction (at 278.13 132.08) (diameter 0) (color 0 0 0 0)
    (uuid 1de463af-0e2e-4507-9acf-937edd0cecf9)
  )
  (junction (at 170.18 66.04) (diameter 0) (color 0 0 0 0)
    (uuid 2569dfc9-cbbb-4153-beed-d0739b5fda76)
  )
  (junction (at 219.075 91.44) (diameter 0) (color 0 0 0 0)
    (uuid 29525e94-8ad8-40f6-9f36-93a1f4dc055a)
  )
  (junction (at 120.65 60.96) (diameter 0) (color 0 0 0 0)
    (uuid 29cff131-d4f3-48ad-9ffb-dd59e0529f98)
  )
  (junction (at 120.65 58.42) (diameter 0) (color 0 0 0 0)
    (uuid 2da63c06-ab35-4bdc-959f-67879ff42885)
  )
  (junction (at 170.18 63.5) (diameter 0) (color 0 0 0 0)
    (uuid 303d7880-692d-412f-8356-e2393bbfb9b2)
  )
  (junction (at 252.095 86.36) (diameter 0) (color 0 0 0 0)
    (uuid 361679c9-aceb-4fa9-bf4b-fc13898aaec9)
  )
  (junction (at 109.22 113.03) (diameter 0) (color 0 0 0 0)
    (uuid 38ff3d17-d745-4f2c-a794-711a168c2115)
  )
  (junction (at 71.12 54.61) (diameter 0) (color 0 0 0 0)
    (uuid 3ddcb190-da51-4532-877e-5fb499b352dc)
  )
  (junction (at 294.005 107.95) (diameter 0) (color 0 0 0 0)
    (uuid 4321dfda-87bc-4215-bb70-20c0292bc279)
  )
  (junction (at 255.27 118.11) (diameter 0) (color 0 0 0 0)
    (uuid 4996e9ff-423e-4b18-962a-b93429cf1286)
  )
  (junction (at 290.83 142.24) (diameter 0) (color 0 0 0 0)
    (uuid 5f2c01f6-55ec-4d7e-b9d5-e8973ed1f3bb)
  )
  (junction (at 73.66 63.5) (diameter 0) (color 0 0 0 0)
    (uuid 60818263-46de-467a-be71-03b6367e7622)
  )
  (junction (at 71.12 46.99) (diameter 0) (color 0 0 0 0)
    (uuid 64185fd6-3bec-47e5-9fb1-ab80891dd559)
  )
  (junction (at 106.68 115.57) (diameter 0) (color 0 0 0 0)
    (uuid 6ddd01fd-fbb4-406b-b3ec-b889c4390ee9)
  )
  (junction (at 219.075 93.98) (diameter 0) (color 0 0 0 0)
    (uuid 6ee1c29d-b896-4b83-a924-2ad081b5b553)
  )
  (junction (at 87.63 63.5) (diameter 0) (color 0 0 0 0)
    (uuid 6f641669-3b64-45a5-a633-c5a466a3e622)
  )
  (junction (at 255.27 125.73) (diameter 0) (color 0 0 0 0)
    (uuid 7550f9b5-104a-4168-b53e-d474667c286b)
  )
  (junction (at 101.6 54.61) (diameter 0) (color 0 0 0 0)
    (uuid 8d3e6ad9-c73b-466d-a20e-e81affce698a)
  )
  (junction (at 96.52 182.88) (diameter 0) (color 0 0 0 0)
    (uuid 959fe8f2-be61-4396-99d0-a3aba4a694dc)
  )
  (junction (at 57.15 46.99) (diameter 0) (color 0 0 0 0)
    (uuid 99fc8d65-8dc9-4f92-abee-ec26d68336e8)
  )
  (junction (at 111.125 66.04) (diameter 0) (color 0 0 0 0)
    (uuid 9f5ca59a-5ba5-43ba-a4f7-15933efe93dc)
  )
  (junction (at 83.185 121.92) (diameter 0) (color 0 0 0 0)
    (uuid a01a96ee-a43d-4897-b160-34aca004c682)
  )
  (junction (at 278.13 142.24) (diameter 0) (color 0 0 0 0)
    (uuid a16ac61c-2336-4989-99be-7bcf52f10ef9)
  )
  (junction (at 219.075 106.68) (diameter 0) (color 0 0 0 0)
    (uuid a5e9fe4d-f7c3-4951-b29d-e94b12718008)
  )
  (junction (at 272.415 83.82) (diameter 0) (color 0 0 0 0)
    (uuid b0c39a8a-f64d-426e-95f0-46d84348a3d8)
  )
  (junction (at 101.6 63.5) (diameter 0) (color 0 0 0 0)
    (uuid b9d53d54-29f0-4c66-b7d1-b57bc0771f75)
  )
  (junction (at 295.91 96.52) (diameter 0) (color 0 0 0 0)
    (uuid bb7e5cad-0d96-40a1-8fbd-66f41d2a5a55)
  )
  (junction (at 86.36 54.61) (diameter 0) (color 0 0 0 0)
    (uuid be08803f-6f37-4782-87d2-0ffb58d07372)
  )
  (junction (at 96.52 193.04) (diameter 0) (color 0 0 0 0)
    (uuid d0af8b61-5974-45ad-addd-6213a50e5099)
  )
  (junction (at 101.6 71.12) (diameter 0) (color 0 0 0 0)
    (uuid d17b94af-237e-4bc7-b35c-d97fa6fd7152)
  )
  (junction (at 170.18 60.96) (diameter 0) (color 0 0 0 0)
    (uuid e3129174-f6da-408d-97b2-b3840e0ff11b)
  )
  (junction (at 252.095 93.98) (diameter 0) (color 0 0 0 0)
    (uuid eab05669-f171-4c7f-81a0-012bb5ff4a2d)
  )
  (junction (at 86.36 46.99) (diameter 0) (color 0 0 0 0)
    (uuid efb54b1d-0c63-48c3-9325-b6282f78adbc)
  )
  (junction (at 252.095 106.68) (diameter 0) (color 0 0 0 0)
    (uuid f110555c-13ce-4f89-aa81-a7371deabf10)
  )
  (junction (at 101.6 46.99) (diameter 0) (color 0 0 0 0)
    (uuid f15ea8c4-29fe-4dd2-a262-757cefb3c2e7)
  )
  (junction (at 272.415 88.9) (diameter 0) (color 0 0 0 0)
    (uuid f8ab3ff2-7a39-4d95-b925-806e4f74fdd6)
  )

  (no_connect (at 166.37 96.52) (uuid bd9f38da-6bb8-4e50-a1d3-3624cfdfea77))
  (no_connect (at 328.295 91.44) (uuid d54dc4ef-1984-4a1e-81bf-4653b5ffc4fe))

  (wire (pts (xy 272.415 88.9) (xy 328.295 88.9))
    (stroke (width 0.15) (type default))
    (uuid 0140549e-0151-4d2d-9bed-54f2fc78958b)
  )
  (wire (pts (xy 73.66 63.5) (xy 87.63 63.5))
    (stroke (width 0.15) (type default))
    (uuid 03374b05-fa2a-467b-8bdf-2c4e0b59592d)
  )
  (wire (pts (xy 278.13 142.24) (xy 278.13 143.51))
    (stroke (width 0.15) (type default))
    (uuid 049538ca-0394-4190-b025-f666eca77d14)
  )
  (wire (pts (xy 189.865 86.36) (xy 166.37 86.36))
    (stroke (width 0.15) (type default))
    (uuid 0ac8320d-8eec-4a69-a87f-c00c39fabdbc)
  )
  (wire (pts (xy 166.37 58.42) (xy 170.18 58.42))
    (stroke (width 0.15) (type default))
    (uuid 0b13b05c-4ec9-40d8-a023-ead3a4f2b039)
  )
  (wire (pts (xy 96.52 115.57) (xy 106.68 115.57))
    (stroke (width 0.15) (type default))
    (uuid 0b346b13-c1d6-4e3d-acc2-073ad832f783)
  )
  (wire (pts (xy 220.98 66.04) (xy 220.98 78.74))
    (stroke (width 0.15) (type default))
    (uuid 0cd50a3d-7a31-451c-abfe-1b32a860d132)
  )
  (wire (pts (xy 55.245 63.5) (xy 73.66 63.5))
    (stroke (width 0.15) (type default))
    (uuid 0d7a381a-d1d4-4fea-afef-366cbcf9e91f)
  )
  (wire (pts (xy 166.37 114.3) (xy 195.58 114.3))
    (stroke (width 0.15) (type default))
    (uuid 12250b30-be41-41f5-b3b6-ded0e33ef32c)
  )
  (wire (pts (xy 166.37 66.04) (xy 170.18 66.04))
    (stroke (width 0.15) (type default))
    (uuid 14c4f9b6-977c-473b-85da-36ae35668df8)
  )
  (wire (pts (xy 116.84 193.04) (xy 133.35 193.04))
    (stroke (width 0.15) (type default))
    (uuid 14d1ca59-b7e0-418e-8da4-9e0b862137fc)
  )
  (wire (pts (xy 50.8 46.99) (xy 57.15 46.99))
    (stroke (width 0) (type default))
    (uuid 169f0531-bd3f-4e3c-b433-bc09e46ddeb5)
  )
  (wire (pts (xy 272.415 83.82) (xy 272.415 88.9))
    (stroke (width 0.15) (type default))
    (uuid 17848b66-ecc8-4744-a799-0694cb87fb22)
  )
  (wire (pts (xy 316.23 107.95) (xy 308.61 107.95))
    (stroke (width 0) (type default))
    (uuid 1b286a29-f5ee-4cb4-b2e2-94aadee59ed9)
  )
  (wire (pts (xy 227.33 181.61) (xy 227.33 179.07))
    (stroke (width 0) (type default))
    (uuid 1cc0c22a-d0cf-416d-bd64-4c6bf95116d7)
  )
  (wire (pts (xy 86.36 46.99) (xy 101.6 46.99))
    (stroke (width 0) (type default))
    (uuid 1d7af234-5d56-4dcb-9a5a-c4dfe907412e)
  )
  (wire (pts (xy 99.06 121.92) (xy 106.68 121.92))
    (stroke (width 0) (type default))
    (uuid 1eb38f52-f838-4867-b82c-e5b66baf44d3)
  )
  (wire (pts (xy 96.52 182.88) (xy 109.22 182.88))
    (stroke (width 0.15) (type default))
    (uuid 1f595337-719b-4d9e-80fa-86988697dc7e)
  )
  (wire (pts (xy 255.27 118.11) (xy 270.51 118.11))
    (stroke (width 0) (type default))
    (uuid 1fb0d3a2-6118-451e-8304-521f40579a6f)
  )
  (wire (pts (xy 208.915 106.68) (xy 219.075 106.68))
    (stroke (width 0.15) (type default))
    (uuid 23eb9e66-6f51-4308-9740-248b4b0042b4)
  )
  (wire (pts (xy 111.125 66.04) (xy 111.125 68.58))
    (stroke (width 0) (type default))
    (uuid 24a1aea3-2b74-4b4a-8fd2-b005ea5545c6)
  )
  (wire (pts (xy 71.12 54.61) (xy 86.36 54.61))
    (stroke (width 0) (type default))
    (uuid 254e5f4e-9bc2-4c10-8584-fe39c2de5045)
  )
  (wire (pts (xy 278.13 123.19) (xy 278.13 118.11))
    (stroke (width 0.15) (type default))
    (uuid 264e4cb5-1eaf-4a66-8a16-2ab3903d6f20)
  )
  (wire (pts (xy 166.37 111.76) (xy 195.58 111.76))
    (stroke (width 0.15) (type default))
    (uuid 28295d5f-f8d9-4365-86eb-784674a34200)
  )
  (wire (pts (xy 278.13 91.44) (xy 278.13 93.98))
    (stroke (width 0.15) (type default))
    (uuid 2e558d7b-6c46-446a-8909-1b4e9c0b5176)
  )
  (wire (pts (xy 120.65 63.5) (xy 120.65 60.96))
    (stroke (width 0.15) (type default))
    (uuid 2f49704d-98db-45aa-ac8e-eaf48bd3b6f3)
  )
  (wire (pts (xy 241.935 104.14) (xy 241.935 106.68))
    (stroke (width 0.15) (type default))
    (uuid 2fe0a37b-d71f-4399-b56f-961e2938cdfb)
  )
  (wire (pts (xy 82.55 193.04) (xy 96.52 193.04))
    (stroke (width 0.15) (type default))
    (uuid 311a332c-e856-430b-af9e-ff288f385114)
  )
  (wire (pts (xy 41.275 46.99) (xy 43.18 46.99))
    (stroke (width 0) (type default))
    (uuid 3acbd2de-28ef-48b6-a26f-3fd88a4b98f7)
  )
  (wire (pts (xy 232.41 66.04) (xy 220.98 66.04))
    (stroke (width 0.15) (type default))
    (uuid 3c2f7920-8f8e-4373-bb29-f5206ecf46cf)
  )
  (wire (pts (xy 117.475 86.36) (xy 134.62 86.36))
    (stroke (width 0.15) (type default))
    (uuid 3fbd8d5d-a154-4e05-8cc4-b1d3f906b06c)
  )
  (wire (pts (xy 213.36 176.53) (xy 180.34 176.53))
    (stroke (width 0) (type default))
    (uuid 40024479-1ecb-4ccc-9bd6-acddf1196760)
  )
  (wire (pts (xy 97.79 88.9) (xy 109.855 88.9))
    (stroke (width 0.15) (type default))
    (uuid 40230e7b-5e85-4596-8ef2-4ec259785337)
  )
  (wire (pts (xy 278.13 142.24) (xy 290.83 142.24))
    (stroke (width 0) (type default))
    (uuid 44568c14-ec9f-44af-a094-03c924b9c087)
  )
  (wire (pts (xy 173.99 176.53) (xy 227.33 176.53))
    (stroke (width 0.15) (type default))
    (uuid 44c15265-5f8f-4a9a-b9f5-48af45949dd2)
  )
  (wire (pts (xy 219.075 106.68) (xy 219.075 104.14))
    (stroke (width 0.15) (type default))
    (uuid 480cb02a-652c-4883-b4ed-952f09a53fd1)
  )
  (wire (pts (xy 208.915 93.98) (xy 219.075 93.98))
    (stroke (width 0.15) (type default))
    (uuid 48bac5e9-52c2-47f5-a060-7369980a84f3)
  )
  (wire (pts (xy 213.36 193.04) (xy 184.15 193.04))
    (stroke (width 0) (type default))
    (uuid 495f4867-2215-42f4-aab7-cae4295a04be)
  )
  (wire (pts (xy 57.15 54.61) (xy 71.12 54.61))
    (stroke (width 0) (type default))
    (uuid 4c6ccc6e-6f67-445d-a3c0-be88cd86c6ea)
  )
  (wire (pts (xy 96.52 201.93) (xy 96.52 204.47))
    (stroke (width 0.15) (type default))
    (uuid 4d224d51-da18-43f9-92c1-48ded8e33145)
  )
  (wire (pts (xy 166.37 76.2) (xy 184.15 76.2))
    (stroke (width 0.15) (type default))
    (uuid 4eb72ef9-4ba0-4b49-81ff-28398c08afb7)
  )
  (wire (pts (xy 91.44 101.6) (xy 134.62 101.6))
    (stroke (width 0.15) (type default))
    (uuid 4ebb255e-0c97-4872-924b-5ace9446462b)
  )
  (wire (pts (xy 151.13 198.12) (xy 170.18 198.12))
    (stroke (width 0.15) (type default))
    (uuid 5110413d-0d2e-420a-a11a-5de28d104245)
  )
  (wire (pts (xy 57.15 46.99) (xy 71.12 46.99))
    (stroke (width 0) (type default))
    (uuid 541e3f6c-c528-4b33-9a5a-9ea21bc029bc)
  )
  (wire (pts (xy 151.13 193.04) (xy 170.18 193.04))
    (stroke (width 0.15) (type default))
    (uuid 552010d9-de73-4821-9342-6708155ad9d6)
  )
  (wire (pts (xy 219.075 93.98) (xy 219.075 91.44))
    (stroke (width 0.15) (type default))
    (uuid 55488c32-fec6-49c6-89b7-0d939c3afe0d)
  )
  (wire (pts (xy 208.915 104.14) (xy 208.915 106.68))
    (stroke (width 0.15) (type default))
    (uuid 580e7ced-cddb-45c8-b4ca-055c7a81bed6)
  )
  (wire (pts (xy 269.24 132.08) (xy 278.13 132.08))
    (stroke (width 0.15) (type default))
    (uuid 58b944e8-6844-4861-b991-0d4e19bc1994)
  )
  (wire (pts (xy 96.52 180.34) (xy 96.52 182.88))
    (stroke (width 0.15) (type default))
    (uuid 5e26cf42-ba02-4029-8e34-85136c01ba92)
  )
  (wire (pts (xy 120.65 58.42) (xy 120.65 46.99))
    (stroke (width 0.15) (type default))
    (uuid 5eba47c3-8a4d-4763-a45c-dee9113827b7)
  )
  (wire (pts (xy 241.935 93.98) (xy 241.935 96.52))
    (stroke (width 0.15) (type default))
    (uuid 6007bf72-f016-457d-8ede-1410933ad055)
  )
  (wire (pts (xy 99.06 127) (xy 109.22 127))
    (stroke (width 0) (type default))
    (uuid 611842f1-3d51-4041-bece-1e4b105924dd)
  )
  (wire (pts (xy 166.37 60.96) (xy 170.18 60.96))
    (stroke (width 0.15) (type default))
    (uuid 61303652-2d4a-49db-bd3e-e27f0e38d222)
  )
  (wire (pts (xy 120.65 58.42) (xy 134.62 58.42))
    (stroke (width 0) (type default))
    (uuid 62a20b00-deb9-4a18-b829-090e4c260966)
  )
  (wire (pts (xy 101.6 63.5) (xy 111.125 63.5))
    (stroke (width 0.15) (type default))
    (uuid 6304a34d-3bc1-405b-abb4-bce17b244285)
  )
  (wire (pts (xy 200.66 76.2) (xy 191.77 76.2))
    (stroke (width 0.15) (type default))
    (uuid 6582a852-6d9d-4c9c-b5e4-6a1690a1640e)
  )
  (wire (pts (xy 189.865 91.44) (xy 166.37 91.44))
    (stroke (width 0.15) (type default))
    (uuid 6642445b-f6a0-410a-8cdb-d6bd110d3e2a)
  )
  (wire (pts (xy 45.085 62.23) (xy 45.085 63.5))
    (stroke (width 0.15) (type default))
    (uuid 68d60eb1-4618-49df-827a-c96b3d2a9ae6)
  )
  (wire (pts (xy 83.185 127) (xy 91.44 127))
    (stroke (width 0) (type default))
    (uuid 6974d70a-252d-454d-9253-37570d6a9c90)
  )
  (wire (pts (xy 252.095 106.68) (xy 252.095 107.95))
    (stroke (width 0.15) (type default))
    (uuid 6a8864a7-842b-4f33-b779-c14f4b795f47)
  )
  (wire (pts (xy 87.63 71.12) (xy 101.6 71.12))
    (stroke (width 0.15) (type default))
    (uuid 6af18a47-baf1-4bfc-8e10-66a56c7db9fe)
  )
  (wire (pts (xy 96.52 168.91) (xy 96.52 172.72))
    (stroke (width 0.15) (type default))
    (uuid 6d1efa9d-6115-45fc-9212-aec6bdba6853)
  )
  (wire (pts (xy 111.125 66.04) (xy 134.62 66.04))
    (stroke (width 0) (type default))
    (uuid 6d330c39-e0b8-4006-8810-5bf79e5a4150)
  )
  (wire (pts (xy 96.52 193.04) (xy 96.52 194.31))
    (stroke (width 0.15) (type default))
    (uuid 6f8052bb-9f64-4a91-b288-199b27b8cb8a)
  )
  (wire (pts (xy 91.44 106.68) (xy 134.62 106.68))
    (stroke (width 0.15) (type default))
    (uuid 70a156d6-c6b3-4d5e-b3da-d0dfc5239027)
  )
  (wire (pts (xy 47.625 63.5) (xy 45.085 63.5))
    (stroke (width 0.15) (type default))
    (uuid 732473b5-6800-44f1-beec-12ef86e31c52)
  )
  (wire (pts (xy 269.24 142.24) (xy 278.13 142.24))
    (stroke (width 0.15) (type default))
    (uuid 77308971-6219-4a5d-81b0-77a9ed8bf493)
  )
  (wire (pts (xy 252.095 106.68) (xy 252.095 104.14))
    (stroke (width 0.15) (type default))
    (uuid 7c79b751-4eae-4813-93aa-d3b9d2da0e5e)
  )
  (wire (pts (xy 252.095 93.98) (xy 252.095 96.52))
    (stroke (width 0.15) (type default))
    (uuid 7fbfe7f9-1bbd-4b3f-9f92-668c90ba5cb4)
  )
  (wire (pts (xy 83.185 121.92) (xy 83.185 127))
    (stroke (width 0) (type default))
    (uuid 8036888f-df9b-48f8-b008-6dbe684652d5)
  )
  (wire (pts (xy 82.55 182.88) (xy 96.52 182.88))
    (stroke (width 0.15) (type default))
    (uuid 82e33aaf-1d45-40ea-9047-20828e458e07)
  )
  (wire (pts (xy 170.18 66.04) (xy 170.18 67.31))
    (stroke (width 0.15) (type default))
    (uuid 83738dd6-5fb6-47c0-acc6-3ed3ed5bc989)
  )
  (wire (pts (xy 294.005 121.92) (xy 294.005 142.24))
    (stroke (width 0) (type default))
    (uuid 85508972-028f-49de-8870-e59f468dc63d)
  )
  (wire (pts (xy 71.12 46.99) (xy 86.36 46.99))
    (stroke (width 0) (type default))
    (uuid 85e257c7-52d8-4bcf-8138-f18ed140c1c8)
  )
  (wire (pts (xy 166.37 63.5) (xy 170.18 63.5))
    (stroke (width 0.15) (type default))
    (uuid 8638fe5e-2a84-4059-92dd-948ae9ef0ee5)
  )
  (wire (pts (xy 272.415 88.9) (xy 272.415 96.52))
    (stroke (width 0.15) (type default))
    (uuid 86fdab29-1054-416f-8888-955b587e8d41)
  )
  (wire (pts (xy 91.44 104.14) (xy 134.62 104.14))
    (stroke (width 0.15) (type default))
    (uuid 87f4839e-44dc-432e-9840-4d291d7cd77c)
  )
  (wire (pts (xy 219.075 106.68) (xy 219.075 107.95))
    (stroke (width 0.15) (type default))
    (uuid 88001e1f-e105-4bb6-8ef9-c68f2321c18c)
  )
  (wire (pts (xy 290.83 121.92) (xy 290.83 142.24))
    (stroke (width 0) (type default))
    (uuid 8868fce6-f11c-497f-86ad-5188105ccdd8)
  )
  (wire (pts (xy 120.65 46.99) (xy 101.6 46.99))
    (stroke (width 0.15) (type default))
    (uuid 8e451358-7cde-4140-a6db-7e711390b89c)
  )
  (wire (pts (xy 101.6 72.39) (xy 101.6 71.12))
    (stroke (width 0) (type default))
    (uuid 8ec4127e-2dc7-45ee-b54e-15f7aaeeb6b8)
  )
  (wire (pts (xy 91.44 96.52) (xy 134.62 96.52))
    (stroke (width 0.15) (type default))
    (uuid 9018b04f-9de8-4c58-a76e-4019af1cef0f)
  )
  (wire (pts (xy 166.37 116.84) (xy 170.18 116.84))
    (stroke (width 0.15) (type default))
    (uuid 934c5c2f-3f22-4829-9c07-1b1a5544c690)
  )
  (wire (pts (xy 106.68 115.57) (xy 106.68 121.92))
    (stroke (width 0) (type default))
    (uuid 940a3c26-7c0a-425a-896b-d894efc68fdf)
  )
  (wire (pts (xy 170.18 60.96) (xy 170.18 63.5))
    (stroke (width 0.15) (type default))
    (uuid 94c11fb9-2620-4cb5-a810-038c78763cd7)
  )
  (wire (pts (xy 272.415 72.39) (xy 272.415 73.66))
    (stroke (width 0.15) (type default))
    (uuid 951b61f6-4a85-4756-8dae-b32b515f671c)
  )
  (wire (pts (xy 197.485 91.44) (xy 219.075 91.44))
    (stroke (width 0.15) (type default))
    (uuid 95f02dc4-86a9-4295-8c87-11bb98269d2f)
  )
  (wire (pts (xy 86.36 54.61) (xy 101.6 54.61))
    (stroke (width 0) (type default))
    (uuid 9907daf4-6e39-441e-b486-2b8a7055307d)
  )
  (wire (pts (xy 116.84 182.88) (xy 133.35 182.88))
    (stroke (width 0.15) (type default))
    (uuid 9923762d-a0d5-418d-b858-c7a41d8e81ad)
  )
  (wire (pts (xy 246.38 142.24) (xy 261.62 142.24))
    (stroke (width 0.15) (type default))
    (uuid 9a2c3b7a-7273-492b-bfdd-d47389903d56)
  )
  (wire (pts (xy 272.415 107.95) (xy 272.415 104.14))
    (stroke (width 0) (type default))
    (uuid 9aa77a6b-59ba-4004-9687-838716301a59)
  )
  (wire (pts (xy 295.91 91.44) (xy 295.91 96.52))
    (stroke (width 0) (type default))
    (uuid 9b042847-78fa-452a-a522-f8dfffcc66c0)
  )
  (wire (pts (xy 87.63 63.5) (xy 101.6 63.5))
    (stroke (width 0.15) (type default))
    (uuid 9bfa7721-8168-4cdc-9cbd-9337097bf309)
  )
  (wire (pts (xy 73.66 71.12) (xy 87.63 71.12))
    (stroke (width 0.15) (type default))
    (uuid 9ca176f6-e28b-49ec-a212-8ab20cb72449)
  )
  (wire (pts (xy 213.36 198.12) (xy 184.15 198.12))
    (stroke (width 0) (type default))
    (uuid 9cce1aea-0980-4b70-b73b-3da9b0cb697e)
  )
  (wire (pts (xy 197.485 86.36) (xy 252.095 86.36))
    (stroke (width 0.15) (type default))
    (uuid 9e87a374-4c38-48be-b8c5-375592018061)
  )
  (wire (pts (xy 294.005 99.06) (xy 328.295 99.06))
    (stroke (width 0) (type default))
    (uuid 9eef7c56-edb2-4801-ac5e-d2c32dfcb619)
  )
  (wire (pts (xy 290.83 96.52) (xy 295.91 96.52))
    (stroke (width 0) (type default))
    (uuid a024dd42-d206-4cf9-bceb-6bf942d0f9e8)
  )
  (wire (pts (xy 120.65 58.42) (xy 134.62 58.42))
    (stroke (width 0.15) (type default))
    (uuid a2b8ab3d-2cd2-4396-953a-402d07db787c)
  )
  (wire (pts (xy 272.415 81.28) (xy 272.415 83.82))
    (stroke (width 0.15) (type default))
    (uuid a5ae1aa1-96b1-4695-a1c5-c501d6d9d809)
  )
  (wire (pts (xy 278.13 140.97) (xy 278.13 142.24))
    (stroke (width 0.15) (type default))
    (uuid aabbba02-6cc3-45d4-842b-f59570383afe)
  )
  (wire (pts (xy 97.79 78.74) (xy 109.855 78.74))
    (stroke (width 0.15) (type default))
    (uuid aadc978c-c993-4bff-ab64-09b86e949888)
  )
  (wire (pts (xy 294.005 99.06) (xy 294.005 107.95))
    (stroke (width 0) (type default))
    (uuid ad7fad84-30b7-47ba-85bd-8e55a4e7935e)
  )
  (wire (pts (xy 226.06 198.12) (xy 226.06 195.58))
    (stroke (width 0.15) (type default))
    (uuid af513a1e-ecd7-4d60-a68a-8835a3c756b4)
  )
  (wire (pts (xy 83.185 121.92) (xy 91.44 121.92))
    (stroke (width 0) (type default))
    (uuid b1c9c36b-01d1-47d1-a0cd-a7cc8e33783d)
  )
  (wire (pts (xy 278.13 130.81) (xy 278.13 132.08))
    (stroke (width 0.15) (type default))
    (uuid b1d62fe2-a950-41d6-ab68-4fdedb0234ec)
  )
  (wire (pts (xy 109.22 113.03) (xy 109.22 127))
    (stroke (width 0) (type default))
    (uuid b266fad6-d7d8-440e-925e-6c2e5e7303dc)
  )
  (wire (pts (xy 166.37 106.68) (xy 195.58 106.68))
    (stroke (width 0.15) (type default))
    (uuid b33a5744-f721-4f78-a9ae-4e567ce94f42)
  )
  (wire (pts (xy 129.54 76.2) (xy 134.62 76.2))
    (stroke (width 0.15) (type default))
    (uuid b4067c72-ce31-48a4-a64b-a771bb1c715d)
  )
  (wire (pts (xy 241.935 93.98) (xy 252.095 93.98))
    (stroke (width 0.15) (type default))
    (uuid b46747b8-7a2b-472e-8732-737ac7dba596)
  )
  (wire (pts (xy 117.475 83.82) (xy 134.62 83.82))
    (stroke (width 0.15) (type default))
    (uuid b4cb2e22-7589-4215-80b0-811eb48fc48e)
  )
  (wire (pts (xy 252.095 86.36) (xy 328.295 86.36))
    (stroke (width 0.15) (type default))
    (uuid b7806887-29f0-4e8e-9eab-c923c9642db2)
  )
  (wire (pts (xy 300.99 107.95) (xy 294.005 107.95))
    (stroke (width 0) (type default))
    (uuid b7d78f33-d53c-476d-ad69-224879dfb817)
  )
  (wire (pts (xy 290.83 96.52) (xy 290.83 114.3))
    (stroke (width 0) (type default))
    (uuid bc0e9773-93a5-42e7-99de-661ae22910fe)
  )
  (wire (pts (xy 91.44 109.22) (xy 134.62 109.22))
    (stroke (width 0.15) (type default))
    (uuid bd2751be-e441-41b2-b06f-574fc8711130)
  )
  (wire (pts (xy 101.6 55.88) (xy 101.6 54.61))
    (stroke (width 0) (type default))
    (uuid bd63d208-d596-43c0-acae-a79584d591c3)
  )
  (wire (pts (xy 111.125 68.58) (xy 134.62 68.58))
    (stroke (width 0) (type default))
    (uuid bdd8f95f-9ee1-4efc-9c73-5f8cec406a00)
  )
  (wire (pts (xy 219.075 96.52) (xy 219.075 93.98))
    (stroke (width 0.15) (type default))
    (uuid c1bdc650-16bb-4abd-99fc-15a55b901caf)
  )
  (wire (pts (xy 208.915 96.52) (xy 208.915 93.98))
    (stroke (width 0.15) (type default))
    (uuid c274db25-6fa2-4ec0-9406-187fe367e276)
  )
  (wire (pts (xy 246.38 132.08) (xy 261.62 132.08))
    (stroke (width 0.15) (type default))
    (uuid c3cafc7a-7d95-4933-ae46-52f9c249d221)
  )
  (wire (pts (xy 120.65 60.96) (xy 134.62 60.96))
    (stroke (width 0) (type default))
    (uuid c436f6f2-88be-4e84-a1f1-29f405aa5691)
  )
  (wire (pts (xy 303.53 91.44) (xy 312.42 91.44))
    (stroke (width 0) (type default))
    (uuid c70c1dc8-c577-45b7-a015-3ef02ae0cb97)
  )
  (wire (pts (xy 278.13 93.98) (xy 328.295 93.98))
    (stroke (width 0.15) (type default))
    (uuid c749d765-1f30-4c60-8965-8797c7ec5e43)
  )
  (wire (pts (xy 149.86 181.61) (xy 168.91 181.61))
    (stroke (width 0.15) (type default))
    (uuid c9038a7a-7f12-44d0-be51-780291deac3d)
  )
  (wire (pts (xy 252.095 93.98) (xy 252.095 86.36))
    (stroke (width 0.15) (type default))
    (uuid cb734cf7-fd02-4bf5-bc25-f12a8e2802fe)
  )
  (wire (pts (xy 117.475 81.28) (xy 134.62 81.28))
    (stroke (width 0.15) (type default))
    (uuid cc331730-9f15-4677-9fa3-eb9f31f5ba3c)
  )
  (wire (pts (xy 278.13 132.08) (xy 278.13 133.35))
    (stroke (width 0.15) (type default))
    (uuid ce538dc6-29ec-4e39-8f0d-fe963e6883bd)
  )
  (wire (pts (xy 120.65 63.5) (xy 134.62 63.5))
    (stroke (width 0.15) (type default))
    (uuid cefbfb37-e324-47ad-9822-acedcd470a8a)
  )
  (wire (pts (xy 170.18 116.84) (xy 170.18 117.475))
    (stroke (width 0.15) (type default))
    (uuid cf60f389-32d2-4284-8f1e-911864daac2e)
  )
  (wire (pts (xy 97.79 81.28) (xy 109.855 81.28))
    (stroke (width 0.15) (type default))
    (uuid cf9da151-ce0d-4395-b018-b73561594797)
  )
  (wire (pts (xy 97.79 86.36) (xy 109.855 86.36))
    (stroke (width 0.15) (type default))
    (uuid d22c1c0d-8908-417a-8f35-9c5558cb5813)
  )
  (wire (pts (xy 166.37 104.14) (xy 195.58 104.14))
    (stroke (width 0.15) (type default))
    (uuid d368bcec-f82f-46fb-9dcb-ae30a4e0a9a6)
  )
  (wire (pts (xy 149.86 176.53) (xy 168.91 176.53))
    (stroke (width 0.15) (type default))
    (uuid d831a50f-4513-4b0e-8f64-3405b2547af9)
  )
  (wire (pts (xy 294.005 107.95) (xy 294.005 114.3))
    (stroke (width 0) (type default))
    (uuid d8406834-f5f9-4fa1-9ea0-e8fb670bd67a)
  )
  (wire (pts (xy 295.91 96.52) (xy 328.295 96.52))
    (stroke (width 0) (type default))
    (uuid d8b71d28-0d93-47ce-b06d-dfda4f264bc1)
  )
  (wire (pts (xy 175.26 193.04) (xy 226.06 193.04))
    (stroke (width 0.15) (type default))
    (uuid daf181a1-942c-45c5-9341-7a3d6bb38fed)
  )
  (wire (pts (xy 120.65 60.96) (xy 120.65 58.42))
    (stroke (width 0.15) (type default))
    (uuid db2ab345-531d-4d8b-a84c-6484f0d6bc71)
  )
  (wire (pts (xy 120.65 60.96) (xy 134.62 60.96))
    (stroke (width 0.15) (type default))
    (uuid dbe72fdf-6d5b-4232-871b-792f81a2f6cc)
  )
  (wire (pts (xy 247.65 125.73) (xy 255.27 125.73))
    (stroke (width 0.15) (type default))
    (uuid dd149b9e-b77c-4eed-933e-68e03a3d1bd0)
  )
  (wire (pts (xy 96.52 113.03) (xy 109.22 113.03))
    (stroke (width 0.15) (type default))
    (uuid dda74cff-7d01-4c3f-b794-3c038a28d9cc)
  )
  (wire (pts (xy 105.41 168.91) (xy 96.52 168.91))
    (stroke (width 0.15) (type default))
    (uuid df428edc-009e-4cf8-987d-3aebd9875588)
  )
  (wire (pts (xy 219.075 91.44) (xy 278.13 91.44))
    (stroke (width 0.15) (type default))
    (uuid e197100f-b4db-4c9d-b5df-26c60e608c6e)
  )
  (wire (pts (xy 97.79 83.82) (xy 109.855 83.82))
    (stroke (width 0.15) (type default))
    (uuid e27adbcf-541d-47ec-ae5f-831bb1a4bf96)
  )
  (wire (pts (xy 241.935 106.68) (xy 252.095 106.68))
    (stroke (width 0.15) (type default))
    (uuid e36979fe-15db-4bb3-a019-ca3c53ce0193)
  )
  (wire (pts (xy 111.125 63.5) (xy 111.125 66.04))
    (stroke (width 0.15) (type default))
    (uuid e653c0a6-9dcf-4ac0-9d14-13d848767224)
  )
  (wire (pts (xy 117.475 88.9) (xy 134.62 88.9))
    (stroke (width 0.15) (type default))
    (uuid e670368d-7886-4d3f-990c-252638fc20a8)
  )
  (wire (pts (xy 170.18 58.42) (xy 170.18 60.96))
    (stroke (width 0.15) (type default))
    (uuid e7314b81-ec8d-4dfd-a0e3-59a9c62deecf)
  )
  (wire (pts (xy 270.51 118.11) (xy 278.13 118.11))
    (stroke (width 0.15) (type default))
    (uuid e80c172b-c373-42a6-86e6-47718e8ef836)
  )
  (wire (pts (xy 109.22 113.03) (xy 134.62 113.03))
    (stroke (width 0.15) (type default))
    (uuid e814d8a4-71da-482f-9f74-1bc4252d96ab)
  )
  (wire (pts (xy 290.83 142.24) (xy 294.005 142.24))
    (stroke (width 0) (type default))
    (uuid e83b83c1-65c9-4db0-8cd2-9fe5fedc1624)
  )
  (wire (pts (xy 73.66 63.5) (xy 87.63 63.5))
    (stroke (width 0) (type default))
    (uuid e91a981a-5462-45c8-aa91-bb99b0ad2f55)
  )
  (wire (pts (xy 166.37 78.74) (xy 220.98 78.74))
    (stroke (width 0.15) (type default))
    (uuid e9db9839-437c-49d7-a4a1-d5f96486c99c)
  )
  (wire (pts (xy 96.52 193.04) (xy 109.22 193.04))
    (stroke (width 0.15) (type default))
    (uuid eadfc7ce-8e8d-43fa-9269-705b51f57a38)
  )
  (wire (pts (xy 170.18 63.5) (xy 170.18 66.04))
    (stroke (width 0.15) (type default))
    (uuid eb862b97-b8b2-4523-b140-5aaee2c6bd34)
  )
  (wire (pts (xy 232.41 75.565) (xy 232.41 73.66))
    (stroke (width 0.15) (type default))
    (uuid ebe0514c-dc37-41e8-830e-9afa87e8f03d)
  )
  (wire (pts (xy 175.26 198.12) (xy 226.06 198.12))
    (stroke (width 0.15) (type default))
    (uuid ef6a8431-9254-428b-9216-dd58799f5606)
  )
  (wire (pts (xy 106.68 115.57) (xy 134.62 115.57))
    (stroke (width 0.15) (type default))
    (uuid efff8d31-7ff4-448a-969b-4bfa0521251b)
  )
  (wire (pts (xy 173.99 181.61) (xy 227.33 181.61))
    (stroke (width 0) (type default))
    (uuid f05aea49-dc9b-4faf-a0e1-2f4c1fa3f07e)
  )
  (wire (pts (xy 247.65 118.11) (xy 255.27 118.11))
    (stroke (width 0) (type default))
    (uuid f1a930cf-1c34-49b0-9368-72aa44bb38cb)
  )
  (wire (pts (xy 117.475 78.74) (xy 134.62 78.74))
    (stroke (width 0.15) (type default))
    (uuid f470c3c9-eeb7-4729-a2c4-57eac865f8e3)
  )
  (wire (pts (xy 263.525 83.82) (xy 272.415 83.82))
    (stroke (width 0.15) (type default))
    (uuid f838551b-85cd-49c3-92c4-7fcbbc813941)
  )

  (image (at 298.45 195.58) (scale 1.75347)
    (uuid ef18a83c-f83f-47fa-8386-96531c5fbca7)
    (data
      iVBORw0KGgoAAAANSUhEUgAAAgEAAAGMCAIAAADMQuatAAAAA3NCSVQICAjb4U/gAAAACXBIWXMA
      AA50AAAOdAFrJLPWAAAgAElEQVR4nOx9d3xUVdr/uXdKZjLplQBpQICEREzoILKC9IhlEYTVBfYV
      C4LYXgugwqLygrLLUlREQBTRpYqogIDSV5oGEmkJISEFkpA2mWT6vb8/vr/zfE5mkoiAcdWcP/gM
      kzvnnvOc5zy9SKqqspbRMlpGy2gZf8gh/9oLaBkto2W0jJbxq40WHtAyWkbLaBl/3KH9JSZtzL4k
      SdLP+vk1Pv+zViLO+XPX+ZN2sxtZcNNLbZ7hsYafC4eb9fy1jGsB1428V/wtnm/+A/pvQImW8bsf
      v2E9gG5IE6S55c60jJbRMlpGE+MX0QNukPL+XDEN/23sVx7fX6Ooe90L+z2NmxUvcN16VWPz3ODC
      ruXnf7Szbhl/2PGL8IBmGzdOpJpgHi3jv220xLC1jJZx08dvmwe0jP+qceOOHMzQwpVbRstotvEb
      9gfc+GiRK3+hcd2AlSSphQG0jJbRnOP3rwc0be3xFjxbrEMto2X8KuNmxRN6XOGW69z0+G3zgMaC
      9mi0SPq/rdH0gbaw5+sbv0Rs7n/zuInB5X+E8YvYghrEOVVVVVV1OBwe33g/rKqqoiiKoqgNDcaY
      oig4XbfbjZ/QYSuK4na78ZjL5XI6nS6XC++12Wwul4sxhjVIkuR0OmVZVhSFFtP0vuh1qqo6nU7a
      qcLHjbAcqf4Q4dPEtNiRoigulwsbcTgceJ5Wi7XhAfwVT+K3rP55eUfcOp1OSZIwGz5jTpq5sfWL
      A7vA6eDV+EaSJMwgSRLOBYfrPZUkSbIsSw0N8S20HvyE9Dy8F7iBdwEB3G632+2ml9rtdppBnIr+
      S0eDyenQ6YPHTsU/EczpSUJXGh4T0vo9ttYgeMWl4u0AqcvlcjgcTqdTVVWXy0XAb2I2ccv4IebE
      NwQ0+gltlobL5cIz3leDHgY0CIfdbjcOxWaz0XFgHhFcdI7ee8cbCVai0OCx3xbpkIbUPLAgtNZo
      NHSQuNKy3CgfakIeVFVVo9Hgv4qiyLJM1xJkhaiD2+3GS/EwXgdS6OPj43A49Ho9zexyubRabWOX
      TZZlsA28mt7iQQd/Hmiuee8eMjLeiyVptVq32y3Lstvt1ul0jDG73e7j48MYczqdOp0OF0Oj0RBN
      wU4BHA+670HmMJvRaGSMud1um81mNBrxjLhZp9NJJ+K9chw9LjkOC9BTFEWr1YoUUKfTNciTaDHe
      A4ycAIIPeBi7w2cR08DCARn8HJDU6XQgcFqtFpwD/2q1WvxcRABWHwfoA70I4KXHAAQAlv7E6pMq
      cYg/x/rFQxGxggYILkCKU2aMAaVlWbZarYwxo9Hocrk0Gk0TuEpLon3ZbDYfHx+XywVwabVaJggB
      wDqHw4FpAQEPfizOT/91Op3ioQOH6dVEImw2m8FggDCHV2g0GpwXzpdgjgUDdPQWEdotw2M0Bw/w
      QFm73a7T6YiIgISx+gRI8rIJiJ+J8Im0nq46rhlRN7oVJLrq9XrCJMaJi0gCGmNLLpeLcF2v12Ny
      ojLeZPFmAa2xAejh1Vqt1uFwALDiddJoNHRvcdkgWBkMBtoI6VUexEhkqPjG6XSCZZJkiouKC9bY
      mmkSgMvjr2AeIt30BiZOuQmZgHkxCWIMOFDMD+EDZAVcEKIxvQviAtgVlkpYQYshAgeiLG6QCboI
      JmdcCxEpPr1OFEEa5MTiBQFNF0HdoMxBPIZejQOCIqjX66+FAdACwPMIeqqq4goQBOgnhHWEFY29
      At9DTBFRFL91uVzASUI2KG24tsBwHApmI8GCGJ7NZtNoNHTlCWI3627+zkaz6gH//5X8qlitVr1e
      T1flGn+O/+Jcgd900kAgjUZDgj+oPywYJLngGUwCEQ9YSxejaTWZ8J6UBhG3flEeoHo5uxRFsVgs
      RqMRV4KYn7cMSDdWtHUQTBpbtniZPTQt4riMk4CmJ6EFe8j7ACnpMaJA4AGKJmiKSLYYl08hLTJO
      +rERvN3hcGi1WvAeQIyIHR2x3W4XSQlhHdAJk3sfE8kTxNhAOvEw6BqeIRmiwcNlAjUX6b5IeRsE
      BW0faABiChrKBD2m6XmYIDtD+tbr9QRGkWGTYtegGOE9sGtS19xut8vl8vHxIRTFe0mGI5SzWq1G
      o9HjjbRIUnxJwXU4HFBeW6h/00Mze/bsZngNCTW4e7jwOp2OLr/0cwbRMlI8CYHoA0mOwHhZlqur
      qxctWrR9+3aj0RgXF0dqJgl0mBYY09jAdkSpx5suNwM8mSBM+fr6arXakpKSXbt2+fr6hoSE0I7I
      2gNZMi8vr6qqKigoiHGCyBqnKeKu7Xb7F198sX79+pqamujoaBhG6FcE5ybOS+JGEpwaLrkozNLP
      PV59LYPVVxSwGAy73S5JEhBA4gwAapAsyzt27HjnnXeqqqrat2+Pb6xWK20N2xSpOd5FGNUgn5a4
      PkGSuMRZkSzLMDFJ3H5IZI7VxxwwMAgruCPsp2ynxEoZ5+6YQZblY8eOzZ07d+/evcnJyYGBgSR3
      S14shz7QkmAZw/fYuCRwXFE+IKWcbkeDd8Hj1HAW+KAKAxBbv3790qVLFUXp2LEjwGW32+mai3qq
      Vqutra3dsGHDjh07QkJCgoODZcFm2zS3+4OPX6pmnPfxS5Jks9mg5dXU1FRWVsK0IgkqvCQQ2QZn
      pgeAMZBNgDRutzsgICAyMpLsy5gZnmGj0eh0OhcuXHj16tVbbrkFog2JacBCsro2ti+IV6CqwDCy
      SLJmpP7ienQ6HexaH3zwwaxZs+65555169aRRQsLgxB39uzZcePGWa3WzZs3JyUlMX5MDQqzTOBz
      eGbHjh3Lly+fPHlyeno6bixZllwuF2y1jUGAXkTePwAZhJJAygStgn57LVD1JqPAB1VVYcIWiQUO
      Dt9s3br1vffeGz9+/JgxYyCd+Pr6Io4AFgnGLd2ETsRm6I0eKgsor06ng0LjvRERzeiYpPr8GP8l
      d4XIwDx4D01LtFgStB9Q2z179qxaterWW2998cUXmSDleMCQPosiEY5Go9FcuXJl7969ISEhPj4+
      hDOkmuh0OpglSQdtDK8YY5D6y8rKVFXt3r17RESEw+EwGAzAZDIMuFyuLVu2/Pvf/46KikpPTwc0
      9Hq9zE3BjNvHIFhUVlb+85//PHHiRHx8fIcOHfR6vYfzpkUhaHA0U70gHKper4d30e12T5s27dtv
      vw0MDIQy2ODzjQ2It3T9tFqtVqtt27btsmXLwsLCoOeKkqmPj4+qqsHBwXq93t/fv0OHDvgespLZ
      bJ43b97p06cjIyPtdjuZI7yHqqp1dXUjR44cN26cxAXbm8gAGqN9Iu4qPDpFEmRnjUYzZMiQL774
      YsuWLUuWLHnmmWdoErKMvffeexkZGePHj09ISABrxPZBGcVdiJ9xXhqNpl27dlqttlWrVlJ9E/PG
      jRu3bt1qMBgwW2P7AqGPi4ubMmVKREQEXgEOajabFyxYcPLkyTZt2uBh0UssjsbYs4+PD1k8IPub
      zeaKiorJkyePHTtWtPUxxsD7ccSpqamMsYCAAJn7e/V6PTjokiVLTp8+TbQS1AdCqKqq0dHR48eP
      79SpE21QJM1Wq3XXrl2VlZW+vr5klSIZGf/6+vo6HI7k5OTS0tLCwkJIEpDfiSu4XC7YowwGA3jS
      oEGDYMLyuCBEiz00Wq1Wazabjx49qtFoxo0bFxkZSeywaR8pTPBQ1nHi586dGzdunMFggBcX1we7
      8/Pzg2CO6DtRBWlsfszQpk2br776Kjw83GAwiGZbhDZUVlYeOXJEp9Pdf//9ooeGTJeSEFOAK3/1
      6lWNRpOamgqDGylwTVg7W0Zz5AcQvsqyDJdUaGioTqerq6vz9/dPTEwkEzANPN+EqMK4FKnX60tL
      S0+dOgWuQB5aMoYywTiAnwBfceskSXI6nUeOHNm5c+dPbgS3Ny4ujnmFaniss3kQDuvBllNTUxcv
      Xjxw4MB58+Z179799ttvZwJR2Lhx4z//+c8hQ4asXLkSgi251Ih4EXjFD7CxMi5wkWkb1FCn0+Xm
      5n766adS4w5b8S29evV6+umnGWO1tbUmk4nEvTNnznzxxRdkP2lwm02DQvwtiJfb7U5PTxdpIqiS
      h29WlmWid1BSQTr37Nnz9ddfBwQEBAUFIVTRYDDU1dUxxkpLS7t06TJhwgQPVYBQV6fTLVu27Kuv
      voIbU+SsTDAW+fv7r1mz5ssvv3zvvfcoHgmsgnw22JfBYLDZbL169erXrx9MebQF8ewkwTVKMM/J
      ydm/f39YWNjw4cPpHPG6xtgAIMA46QSrNhqNt99+u8lkInMTIX9eXt758+f9/f179+4NxYt5CTHe
      r3A4HBEREf7+/hqNBlAiDw1mvnjxYl5e3uDBgxMSEggUZIUjDYnYam5ubn5+/ogRI9q1a8e4rZjC
      AsUr3zQu/dFGc/AAuiSim659+/ayLE+aNGn27Nk4S+ABBTIyIVCMInzoOsH+4HQ6fXx8Tp48eccd
      d/j4+MAFRK8QdV6IvQgJhSRI18xkMj333HNDhw41Go0kb3p7CLA8t9vds2dPu90O6wckR0WIHGfX
      qxN4S3bihHTlcD+3bt168uTJ0NBQouD+/v4WiyU2NvbkyZOvv/76mTNnTCZTbW2tLMtms/mDDz5g
      jMXExKxfv762tpYxBiOSy+WqqakZMGDAbbfdhqALAhrJVnq9nsBInIP85+np6f7+/gaDgZx1jPtg
      RcMOjqxVq1aIR4LxjXE288gjj9x+++3wD5lMpn379q1cuTIpKemxxx7z8/Oz2WzACoIMGdOhAn78
      8cdff/31sGHDxo4da7FYVG4k7NWrFwX/eCttquCcZEKsl8p1VlVVn3766TFjxlRXVys8/OnkyZOP
      PvqoqJQQDSIoWa3WXr166XS6oKAgEvBBnfV6vUajuXr16saNG+12e0JCwpAhQ7Kzs48ePerr63v7
      7beHhYXBKkWha5Ikfffdd5mZmV26dPHz88NLyfMvcWcME7gaE8xKW7Zsqa6ufuihh7p06SLip0gf
      Rd8ANgJ7C14EfpCcnLxu3bpWrVoRSHELNBrNvHnzZsyYMWrUqBUrVkDII58fq88jRWOXzWaz2+2A
      MzHLEydOrFmz5vLlywaDAYh6+vTpiRMn0qZwhadMmdKlS5clS5acOXMGwUVhYWHZ2dmMsUuXLk2c
      ONHHxwcqlM1mw1//8pe/3HbbbVL9GK2WwZo5T5juocJTloj5M4EuiI4ykkegvxMOAdVAGugO08Pg
      DR50EwKsVquFBEpI7+PjM3DgwDvvvJPUZJH0N7YXl8slSRJsjs2AUkRxAJzPP/981apVwcHBfn5+
      NTU1uGYBAQEOh8NkMh08ePCHH36orKz08/MzGo0Wi6WmpiYqKmrr1q3btm0j9dlut6uqWlNTM3/+
      /D59+uAegqXhnoDi40rDpgRVXeEBRW63+5ZbbrnllluYQApZfdu3aBDAYVGQiVardblcJpNp8ODB
      gwcPJpkuOjp6zZo14eHhTzzxBInwHvFj4tEUFxfv2bOnZ8+eEydOFIFGcSZkT6eTwgb9/f0p2hIa
      D0UBIb7wlltu6dSpExF3fA8ttkFDB1ZoNBqnT58eEBBgsVj8/f2tVivoFB7Q6XR79+7dtGlTWlpa
      dHR0QkJCmzZt7rnnnoSEhAULFsTGxipC2gdgMmXKlDNnznTr1o1oq6jm5ufnHz9+nCw8Go2mrq4O
      eH7x4sW1a9cCbXbu3FldXS3K6RohbwbLA+/p3r077OkQAnBSer0+KipKFbJqMIPD4SgqKpJlGX51
      YktizCvxSMZdIJIk+fn5+fr6gg6QfnblypWdO3cWFBQwxpxOp6+vr9vtXr9+vV6v1+v1FosFEv3Q
      oUPj4+MPHTq0b98+eBfga2SM5eTkXLx40e1242LiV6GhoX/6059EHGhxFNNoVh5ABEIR0sRAWfLy
      8mDYgTggCv50ZjQJ1Lry8vK4uLiIiAir1QoipfCsS9xnVVXPnz9vsVh8fHzgccJLc3NzodLW1ta2
      bt06PDwcUiqZ1yn6mMQ34iISdwxCk4DhUmkkp+wmDtJ8AZP77ruvQ4cOAQEBBoMB4lhdXZ1erzca
      jQ6Hw8fHp7Ky8r333svKyhozZkzfvn1NJhNYRV1dncxjXQDG2traXr16iS5ZOOjy8vLOnTvXvn17
      CFNFRUWKopjN5vPnz+t0OtiCOnToIPonKPCcjODEgxUe7i3xqHPi6KDvjPswVVVFvAAEVZKdRZOu
      aF1RVbW6utrtdiMBCnMipQgfyDytKEp+fn54eDgmhxWRMWa32wEcm83mcDj8/f39/f1pPUyIsld5
      wnmDTiOVD6ikLpcL85B6KvGks9LSUlVVu3XrBv9qQkICIrsoTN7tdoNYY1WZmZkulys2NpYQD/QL
      /2ZkZEydOhXKCrQH0pOAzIyx9957b8mSJfRbnU5ntVqxO8gxBFWj0bhmzZr4+HhaiZuniEO49vX1
      xX4xW0VFxdGjRxVFSU5OlgQ3APmZSPCHzIGbyBjDuZC8hdNMTk5+9913g4ODf/zxx2nTpgUEBLz7
      7rtxcXGFhYVarRZ3rba2FgFOc+bMsVqtOp0uMDCwtLR04sSJdrt98eLFffv2LS0tBTIjbKGysjI5
      OZlxYYJx7URt3Mn0xxnNzQMkHl0ngt5ms82bN++rr74ymUwkfSiKYjAYwsPDa2trq6qqiJrgJ5Ik
      FRYWrlmzZvTo0b6+vjU1NaGhoWIgHeSXt99+e+PGjYGBgYqi+Pr6ms1mq9X61FNPmUwm5D0uXLhw
      2LBhIPG4cooQbEP6MgkyCg9whAZD8X/NAzfa/ogRI4YPH04yMlimeJ3cbvfx48dPnz49duzYgQMH
      0rJJD9MIEeLEklUeCc4Y27Nnz6OPPgr/OePVHTZu3PjVV19B+vvb3/42c+ZMCkEB3DAVBFjRREYU
      k6xnEs+/ZUKYOeAMGRw2a3gL5fqBjIQJ+J4M3LDO+fj4YAugOFA6tVptTU3NjBkzCgsLESOg1+sv
      Xboky/LOnTvJiKTVap999tn09HSwK4UXS8DuoIxia2KxEHFgCxS4QjlQFKfLGMvOzoYgTJuKi4vL
      yMjIz8+Pj4/X1A9FPXfu3NGjRwMDA9u2bcuEiEw6R1mWS0pKIiIihg8fjvgcvMVms8myHBQUpNFo
      qqurXS4XRASNV2a42+329fWtrKzcunWrxWIhRgLEg0SFJYEB4LJAKiorK8vNzQ0ODo6Pj2ec8Yg2
      H5XnrJBvifIrcYlUnmzodrvbt2/fvn17xlhBQYHVau3bt296errT6QQFZwIRV1W1b9++ZJPMy8uz
      2WydOnUaPXp0cHBwYmIi3VM6GhwiXShcnBaFoFl5AMHaG4+DgoJCQ0Mh8YEWa7XaysrKvXv3Ipyf
      7iThFq6QwkOh6bDFt+h0OoTPk/0RWm1QUFBlZSVYDhPivhnPNSMiIvNIZCArlo0ABrIge2zTwx5y
      40NUorEGSFtmsxn3ysMhgVRJm82mKIrdbmc8rUnhoRfYi8PhsNvtgYGB5HchhzlAZzKZDAYDVI3s
      7GzIj0FBQYqi+Pj4UDgNWSfIZccEZwxIMwz3BB8iAW4hiZe+hJaG8wJRE+HABB4A2ZDx1CcQLNEE
      RE5sSZIsFsulS5fy8/ORmeh2u0tKShRFsVqt586dY4zZbDbIE2QxoGh0wEepX+aE1fdXkxkEfzp2
      7Njq1auHDRsG1zRwD06XCxcuqKoaGxsLcuzv79+1a9eDBw/m5+djYSBPgNiFCxdcLlfXrl3BA6Cz
      aoSMB51OB2XizTffDA8Pt1qtyLqCgA/o4ezsdjsiOFVVRRQsqQI6ne78+fOnTp06e/as6NSReA4N
      YaOYqyzL8o8//lheXj5o0KC4uDhvYYWOifCEpgXdx1SSJMG6i19BgnG5XJDPyAslhmJD33XzrPIf
      f/zRbDbfdddd/v7+dEdw7pQ+ho2TBqARch3+yKNZeYAHFaCbbDQa58yZM3fuXInXcQOl/v777/v3
      79+tW7cPPvigffv2VqsVxWqAOlVVVb6+viDuRqMRLiCJZ8kD6WfMmDFr1izc+c2bN//lL38JCgpa
      u3Zt9+7dq6qqIO+UlZXpdDpIeZQQBOqpqqrJZJJlGVdXluW6ujqdTldVVaXT6cLDw8UwfNoafbhZ
      bEAVMnIhgRoMhgsXLsybN+/q1at0QwA9BFCbzeaMjAyDwfDaa6998MEHIP2Mx4oQHWnXrt2UKVNi
      Y2NJLII12Wg0jhgx4k9/+lOrVq1kWb5w4cKdd95ZW1v76KOPzpw50+l0Wq1Wu91eXFwcGhqKtytC
      zS/GCSI5zB0OB6BttVodDkfr1q2JU0o8+JJxsmKz2RhjWVlZkyZNYlxsFGHrIUwcPXqU8QhRWXD8
      SkLdGLfbHRgYuGTJksjISFgdCwsLH3nkEcTLvvzyyzhuq9UaERHBuN5D8JcbyoCjNYgnhT9pNJrD
      hw+/++67n332GTgBScEWi+XgwYOMsc6dO+MsdDpdfHy8JElFRUWMMxjiqV9//bUsy/379w8JCSFG
      TtY2iQdBMcbgMUbsNdE7SO4gr0aj0dfXl+gg9CHSIKEuk2pIeEX7IiGJ8XgqnU536NAhxlhBQcH8
      +fMlnjjCuJm3rq4OGwdDCg0Nvf/++yHpM687Qs6Y0tLS3bt3GwyGPn36SJK0f//+9evXd+3aFZG+
      4ASYVuK24gMHDjDGevToQVoCeQfxJIAJJCSduEUJYM1fO9qD6xISwHIK8YQeM5lMjDFfX19CbvIb
      K4oSGRnJ+BmTTYBxQZ4x5nQ6g4KCCMmOHz/udrurq6srKysZY/jTp59+umDBAshi8KRRYBKuXGVl
      JVgOpH673W4yma5cuTJ69GhENDUD0EhaQZAiLjyUpNzcXA0vcUPXEjCx2Wyqqp44ceK7777T1C9V
      hpvvdrsHDRoERYEJpRSgioWEhISFheFPNTU1CIs0m80gGQEBAceOHXv88ccBZDjktVqt1WpVVTU8
      PNzHx6e6utrhcJDZxMfHB/Ds3r370qVLETtPYiNBkg60vLx8x44dbl4JEoZdIkYkcYOviJoEKfgK
      935jGUajMS0tjWTPwsLC4uJixpjL5YqKiqK3EyeTZZkC/Bmv/0OCS2MMHoBljI0bN+706dMrVqyY
      OnXq2rVre/fuDeDn5ubm5OQkJSWlpKTQPLDY5OfnWywWPz8/bBbx0zt27FAUJTU1ldRBMoAoPJ2Y
      MQb+DQXRzWveEbfQepXkIiZB80j1HTn0vOrlS8e/er2+urr6/PnzkiTl5eUtXLhQFeICcEZgtxAv
      nE5nWlramDFjSFAQbZjk8WKMZWdnHzt2LC0tDenBubm577zzzuDBgydPnoz1HDlypKioyN/fH89b
      rdZvvvkGwtmRI0esVivMdzhKmHZlWQ4LC0tNTSUWy7zI0R9z/Dr9A0R/gCg7aHiUN1DWbrcj34e8
      UjqdDu4+ygCUZdlisUD5JU+yKKpoeObhsWPHgHyvvPJKWlpaWFiYqqrFxcVnz55FIrHE3ZXAY/iQ
      UYoHNgEsDCpIdXV1c6KRyi2zABfSiz7++GPsGs/A4FtbWwuDxosvvnjgwIH58+cPHz4cRZJJ6IOd
      3WKx+Pr6IjOL3HS4tGQUwq4///zziooKxtjq1auTk5MfeughVVXr6urOnTtXV1dnMBhwzRhjcBsC
      dBqNhjg6vdpisWi1WrgWxcvPOCXCqSmK0r9//zfeeAPsX8MTO1h9hzDkwXnz5r3//vtQBEWIwZ+M
      fymqnazhBw4cgE94w4YNffv2nTBhAkgnuUZUVQWaiXSf7CTuhlIZ8CQ4Ynh4+OzZs4uLi7/66qvn
      n39+xYoVoGiZmZmMscTERFjVsJ2uXbv6+fllZmZWVVX5+fkpvNpVZmZmQUFBXFxcz549GRfPQehF
      dijxOtgUjQMfuEfuFfkkMAOc/4wxhBXABisJ2QkevFnmKdZ0xc6dO3fy5MmIiIi///3vCQkJ8JYb
      jUaE8+KluKRffvnl0qVLAwMDEVyEuyzzgAuNUDRQVdVTp06pqnrfffcFBAQwxsLCwsDCsWWdTrdg
      wYItW7YQMsDP4XK55syZIxa/gd+CbFnTpk3r2rWrhtevlXhk1B9cFWgmHiDVjxokoi8JpWZUIZcH
      mAqpnMQQUTkV0whE9x0Z+0ikxYdTp05lZGQEBgba7fYjR45Mnz599erVer1+6NCht956K+yhtACt
      VltcXDxhwgSDwfDBBx9ERkaC0gHPDAZDQUFBfHy8KgS9eUuFjcmJPwmiBn9OFBnZVbD59OrVizWS
      XWyz2aKjo1VVTU5ORoqNx4R0HICbXq+3Wq0gGSpP6yVnZlZWFsTMsrKy2bNnJyQk9O7du127dps2
      bUIMIgV0wZKzaNGizZs3P/vss//zP/9TWVlJ/nZwL0T4sfoWBsYtPCoPK3S73d27dxerUIimA/Ez
      2BgFGqk8a5cKC5NLVuIupZqamg0bNgQEBOj1+vLy8hkzZvj5+Y0ePdrNi29DoaHnxffSslUvcx+g
      CsZcV1fXqlWrlStXPvjgg99+++3kyZM/+eSTqKiovXv3MsZuu+02/ARwjo2N7dy58+nTpy9dutS2
      bVsy969cuVJV1d69e+M0VcEqKBqj6BJhQr1ef/z48QULFoAla7VaxCkhgBLOCUVRYmNj586dC28t
      rqQspFwRVkuCt4yoMNTio0ePlpSU9OvXb+LEiWINdo8DYoxlZGQwxtLS0oBjMBKSosaEpEuHw7F/
      /35ZlpOSksByMDP+xSIHDBigqmrr1q1dLldAQMCBAweOHDnSq1evHj16QJ6D54MJxkabzdatWzfx
      QpFOzP7Y41e2BWHgnCAhUtyxoih1dXUQfCSeesMYMxqNCGuDTkCJi2KSJ2ReEpEYY5s2bTIajamp
      qTk5OXfcccfq1asDAgLeeeedLl26dOnShfCV/EjwvwUHB3ft2hUGYnHxt956K+OSpke9+18IaCp3
      cyHQUP5OCDYAACAASURBVCzM4M1sIGdBhqWGOQpvIUCXjdWvDQnLG8RMivbRarVHjhw5derUoEGD
      Tp8+3b1791OnTj3xxBOffPJJx44d27RpQ2xbK3QjWLdunUajiY6ORmipUj8qidYjmh3E7dTV1UmS
      hOBxt1DzjtXHH6KJFouFbOKMUx+yk0AJgC9Ur9dDRN27d+/x48fvvvvu77//Pikp6fLly88//3xS
      UlJSUhK8xEA2WBvEuGFxeJ8UfW+1WmF5j4yMXLFixV133XX48OGZM2fOmTNn9+7dJpNp0KBBKi8O
      gRclJSWdOHHi/Pnz3bt3B70rKyvbvXs3Y+yee+4hP7DSeNkDN0/NU1W1oqJix44dNTU1pMdQqA89
      n5aW9ve//x08Dzye/trgK0TAAqonT55kjCG5hAndcmid4Kl2u72goMDtduNakdlHZO0kveXk5Bw4
      cKB79+59+vRhgsWfnmGMTZs2bfr06YRRL7/88pEjR6ZMmfLXv/6VNRT7r/KKAHDLUyQIRRn9kcev
      kB8gDrozTqfz9ddff/fddymow8fHp66uTlXVY8eOderUSeaFMK1Wq8ViSUxM3L17d+vWrRm3IFNF
      XzdPLaYIBKvVunXr1qFDh2ZkZFRXV0+bNs3f3/8f//hH586dp06dCls/wrFJKlFVlYIoyFrKuOWK
      3LOUs+Mh9fxcJaDpQdgvy3JBQcHbb79dUlKi8l5m3kCG/23nzp1Op3Pp0qUfffQRZqAFg4PCZoqr
      mJKSMmnSJCjdCo/yxEX69ttvLRZL27ZtMzIyBg4c+MADDzzwwAOvvfbakiVL/P39KeyH1DVVVdGy
      jaw9JE3DhEIGYtEkKA5YCSQhf1BUAWmbRDuCg4Ol+kFNJKqL5iaNRgOjB2PsH//4R48ePRITE7du
      3XrvvfcOGTLk7rvvnjx58vr169u0aaPhXUoCAgIU3s9LFIqZV04c0T7G419hyfT19Y2Li3vnnXcm
      TZq0Zs2aCxcuFBQUJCYmJicnw6KCQFiDwdCvX79Vq1YdOHCAMt127dp18eLF+Pj4UaNGQctpGs2I
      iAPgNTU1t99++8KFC2NjY6urq2VZxh0JCwvbvXv32LFjq6urkeBNklaDBq4GX6eq6oULF7755htJ
      kgYMGMC44UgV8vnpJ1ar9ezZs4wxpDiIsPLQYiVJevvtt69cudK1a1ckvun1+p07d8qyXFRU9OWX
      XxoMhsLCwoSEhD59+mCG8vLy7777TpKkpKQkcWZyjVBhSnAjscS01JI23Mw8QGo8EgsRyhERERKP
      RcOB5eXlybIcERGBAPDAwMC6urrKysrWrVsj9hGUAgoBEwy+RMvcbvehQ4dOnTr1wgsv/PDDD0iS
      evzxx5ctWzZjxow+ffpA7MrKytq/f/+IESNQDogkbkjTdXV1Bw8erK2tHTJkCOQ7lVtFNfVrKN4U
      6u8xCeGrJEnFxcXr1q0rLCwMCAigRDaPn4Mcw/b63XffuXnulcxjHMEJiC7X1NT07t17+PDh4eHh
      Gp4mBjZQWVm5ZcuW/v37d+7cee3atXa7/b777rv33ns/+uijrl27Pvvss4yx0tLSPXv2xMfHo1YX
      GRwAJYfDkZWVdf78+QEDBrRu3VpRFCpK0SADUHlfh6qqqoyMDKp4IdUv7IrJfXx8fHx8fvzxR6V+
      ETQq009yn0gdDh8+vHfv3ieeeKJjx46Kotjt9qFDh06cOHHVqlWvvPLK0qVLibuAjYlEjY5eEQKZ
      WH3TB7AOa4Mqc9ttt82fP/9///d/Dx48KEkS6ndCMqVLcdttt8XExBw4cCArKwvkbOXKlbIsP/LI
      I6h6C2Rj9dmPCDeZR0ZotVp4Yvz8/BISEvz9/cPDw0VciomJkXk9OFa/NmpjhyIJNVfw5fHjxy9e
      vNi2bVsoTyLq0grBusrLy0+fPh0SEhIZGel9XwiAsiybzeby8nLG2O7du3ft2qUIBQL+85//pKen
      4xAnT57cu3dv/Pz8+fN79uzp06dPYmKiGBFAgwlxrhSdRdLJH5wBsF/FJ+whTag8oWbKlCkPP/ww
      BflIknT8+PHBgwenpaWtWrUqLi7OZrOdOnUqNjYWZv2QkBAYK0wmE8wFoiZLqqUsy4sXL27Tpg3u
      IUxMnTt3fvnll7dt20Z3+PPPP3/11VeRQQY0hTUgMDCQMZaXl/fUU08VFBRs2rRpyJAhTOio1YRu
      fiOQEQelKCuK0qFDh/nz56uqGhMTExgYSFKVCFJkgV6+fNntdkdERISEhFDBS3K5gwfA4p+VlRUc
      HNyxY0eQbIQMAoZffvnlsWPHJk6cGBgY6HQ6zWazTqebPHnypUuXaFXl5eUPPvjg4MGDt23bJvEw
      FdBW8BvoIk8//fSbb75JrkI4TknBEiGAHR07diw9Pd1ms+G4RZ6hqip8nvAJV1dXq0ICh4u3e2M8
      RlDlxenw/RtvvKHVasePH3/lyhXGGAKonnnmma1bt65Zs2bcuHEpKSlINPWwcTPBANXYkancZE/0
      C8C/77778vPzn3vuOVVVKbWFipqoqtqmTZtBgwatXr16165dycnJ69ev37t3b0RExEMPPaTwuC/W
      ZMwxcBLeF2JRSAFBOovJZCJ9gpCB7H5ka2pwcpW3q2M8QBmOjVGjRrVu3Vo0LdL9BadUVTUvL6+i
      oiItLY3S3MSDFvlrQEDArFmzkpOTLRZLQEAAjAE//vjjxo0bu3bt+uc//1mW5YqKiuTkZJXn7uzb
      t48xlpycXFZWJvGel+T1dTgcYWFhoaGh6KgMAQ68gW7uzdXaf3OjuXlAg+BG7mVoaCjZH4BMcXFx
      sFqEhob6+vqWlJT83//9nyzLH3/8cVRUFIkk5eXliEZgjMHfRSEHOp3u4MGD27Zte/DBB2NiYior
      K0k6ePTRRydMmNCqVSvGmNVq/fHHH1VVbdeuHTlCISMjGDQhIeHPf/7za6+9tmHDhn79+hHXkXmk
      xC8KNAqJURQlLCxs/PjxrH7hRvFhfHP27NmnnnqKMbZu3bro6GhFSMYRTVsY3bt3xwdI6IzH4Tgc
      jqVLl7Zu3frOO+/cu3cviW/Dhg3r0qULIkfdbndWVpaqql27doV0T0WcIGZqNJoxY8Zs2LBh06ZN
      Tz31VJs2bcAnqIQOrZkuJMhQZGTkiBEjEArlFLoiixQE8N+/fz8VjmU8VVXluaCwH8qyDIL+ySef
      bN++ffDgwX379l2xYgX5Kjp27Pjwww8XFRUlJSVVVlY6nU60IvGALeMkzIN8iESNdA53/fxnin9/
      77337rjjDqPRaDKZ0B6LMWY0Gu+5554PPvjg6NGjWVlZ6J3y5JNPtmnTRhVKQ3u8URyUcyu6i7Br
      jUaD3HiXy4XYU5VH0DOhyXuDOiVNJbrcL1269NVXXzHG7rjjDpjXWH2aTjRao9GcPXvWarXGx8fj
      ujFBSlN4BCexny5dusBQRiz/4MGDGzZs6Nix44wZMxgnDlCMLly48NFHHwHPP/vsMwqKxbnj35Ej
      R7744ouIjGDcV6EKXvQ/+Piv8AnLXr33QPVAskmOi4yM7Nu375w5c2bNmvXWW29BQdbpdKgMQ+F6
      IN+QZ2tra//1r39ptdr7778fCgfVM0G/LQrZ3rNnzy233ALLJrk3yamg0+n+9re/bdmy5dNPP73v
      vvuGDRsm8fYD5EH95QZdGI1QKYyU2QZtUJWVlYcPH/bz80PxRa1QcI3oo/i8m+dbyryvskaj+eST
      T44dO/bwww+3b9/+888/Z4yRihATE0PHBHWqb9++IP3oNyDxXseMseHDh0+cOHHZsmVr1qx54YUX
      SFCVG8q2pf0mJSUtWrQoICCAXM0N3lhVVWfMmJGZmUmEjPgcNgJ+gzlzc3Nfe+01RVHmzJmjCJXv
      sACYtoKCgvLz80tLS2NiYsRwAA99xUOdFbdAVIYEBcbYmTNnli1bptfrQ0JCtm/f/uabb7722mvE
      tzBDz549b7311s2bN1+9evXAgQPt2rX761//qnJ/psTTwRrDN5G7U1QMgi/JW4tYW3jdCWIa3iOT
      cKzB+UVF5MiRI2azuVu3bujIRPyYAELo5Ha7c3JyGGNRUVFaoVaPCEPiLgpPxRA5KNVtZUIUA4S8
      0tLS6OjopKSk2tpacDgElUDkLysrO3HixIYNGwYNGpSQkAD9GDlGP6lU/XHGf4tPGFIelTrB99TR
      CZhhMBhmzpyZmZn59ttvJyUlPfHEE6SZivHjuHiIW9i2bdvmzZt79OgxatQoVt9b4Ob9LNE/4OrV
      q5MmTQoJCSGriyLkGbhcrvj4+AceeAAWpKFDh5LEp72Gfsg3OMSb73K5/vOf/xw4cAAVL7ARRSjc
      xhgzGo0nTpzQ6/WtWrXasWPHsWPHqqurxSItjEdAwZVy5cqVnj17wvFIBpPLly/PmzdPq9VOmDCB
      LiS8KZRRDDV/y5YtnTt3HjBgAK4xriLMSiTrPfjgg2vXrv3www8feeSRwMBACnL3QA+JRzcynjCo
      1C9t5P2wJEkQ88k2hQckIQ8Ik+Tm5r766qtnzpyZMmVKjx49ZJ6QDF7ucDhQml9V1ezsbLfbTSnQ
      jLNYUQWhQyd6Jwmub9IOiR1++OGH58+fv/feeydOnDhu3LjXX389JSVl7Nix8FRDc42MjJw+ffqk
      SZN2795tNBrnzZuHhGqJG2EYp9dNDNJstFotfBISd48TQMAJRM8K+DE8GU3MjF9ZLJbdu3fX1NQo
      irJt2zaTyUQcXQzJUxQF/iGkOqNcPOM8knBb5YNCLdy8qDV2LXMfr8q7ZdCXrVu3XrVqlb+/P+LI
      wcZkWYbdf+HChT/88ENcXNyAAQNIQCFu3Zgm/UcbzcQDSFYliUkSmgvSwCmSMddoNIJy4Rtcs9mz
      Z585c+abb755+OGHySIPqZ+oGzjKmTNnnn32WVmWX3jhBcpJIYynLii1tbWbNm0yGAwjRowgWgNs
      JjoFXBw6dOg777yzadOmxx57TEzylHgwEtGpm45eRHG0Wu3evXtnz54dFBTk6+uLXHyFD9T11Wg0
      qISRk5Mzc+ZMZERTNikt1c2LapSVlY0ZM+aee+5hgiF77ty5OTk5Dz/8cL9+/RjXJABw2DQA840b
      N1qt1oEDBwYGBkL1RuENVVUp/8jHx6dnz56DBg3avHnzhg0bkF0sCzlooo2F9ku8nPGgQ9nLM4wZ
      UCJGFIFdLldNTY1Wq4XnHD/ZunXr2rVrExISZs2aRQSaSCoVIWCM5eXlMcZSU1NhW9AKxQFVIWmW
      cf0JHmAmREB5FInbtWvX4sWLZVmeNm3agAEDXn755RkzZrz00ku33nprhw4dyMwF+2dYWFhZWVmf
      Pn3uu+8+xsu4uuo3wCEoEQaK/6q8BuKlS5f27dsXFRWFICWgSlBQUGZmplrfm63Wd7d42Nwojgtw
      y8zMPHLkiCRJMM/C9U1sAKgoSZLdbg8KCqqpqamqqmrXrl3Xrl0ZN2wCRCACcAdSVB5dUi3vc4dD
      wX8rKiqysrIuX77crl27tLQ0mItpF6Jz+/Llyxs2bJAk6fHHH2/Tpo0iRFVJQsbDH5wBsGbuI8bq
      xwK7eVdxtBdGcTd6DL4+VDKoqqpCmSCn0xkbGztnzhwkJZWXl6O7oUajAYlXeDUV0Din03nfffeN
      HDlSxxsngXhBZ8Rjhw8f3rNnT79+/dLS0ogwSYIZl5aN/lzr16/fv38/iuZTU2LSSNz1q2Y2yAZ+
      Ltqp3HSLLQwYMOD1118nyo4kSYmbcUJDQy9cuLB48eKrV6/iXRMnTkxJSYGL2+12W61WCG4URFtY
      WIgkCVVVqdlnaWmpv7//888/rwph7MS/QfXsdvvatWvdbvekSZPoKhIJwOJxLWVZHj169ObNmzdt
      2vToo48ywQJD15LIOrF88t0ReOkxKIhIgygpKWGMZWRkLF68uLq6+urVqyUlJXV1dePHjx87dizj
      t71Tp04pKSkvvfQSUlUZV7CooB7llF29elWW5Y4dO4I2kfjMeE9pfAbP2Lp16w8//HDvvfeCxkEU
      pWw7VVUvX748f/58q9X6P//zP3/6058URZkyZcq2bduOHj360ksvrV69GnEHMH5+9NFHZWVljLGz
      Z88eP368d+/e6KZC/gy1IdMfrY3IN9D4xIkTEydORPU93DtISBpeKhyMgW4lldomUKu8f4AkmD21
      Wu2kSZOioqIURUHldrIlSjwTReL1+/bv37927dqgoKDo6GgmlCShw6VmEhIvPS3xkE1FUSwWy4UL
      FyRJOnbs2OTJk3NycjIyMlwu18KFC3v06AGaIPPmoC5eclyr1W7ZsuXYsWMDBgx48MEHyebWMrxH
      89mCCJkYVyoRd6Eoyp49e1577TVI5aQ7m0wms9nMGDt+/Pj48eP9/f0VRbHZbFT//ZVXXunevfvy
      5cv9/PyAzR6h+p06dXrzzTdjYmIo1xSEA8wGF7i2thZlBsaNG4dwOpEkkSkDW5Akafjw4Rs3bly/
      fv2ECRNQTk4rlJEBWiPihewnN0sbUHkN3n79+vXr188jTFASHANr164tLy/v06dPamrqkiVLysvL
      x48f7+0KZoKdBMZ9sFJ8M3HixCFDhsCTBsYJyY4JATbvvPNOVlZWeno6vMoELtG1SD72wYMHR0dH
      79mz5+jRo7179yZjvST0QIewif60WJIkSWazuaamprq62mKxVFdXl5aWXrp0KTc39/LlyygGfvHi
      RcYYuj8yzip8fX3vuusuSQgA79u377vvvpuWlkZsjCpkMEGEr6ys/O677xRFod44TNBRJMEWBCAc
      OXLkzTff1Gq1ycnJwAeJuyIg7b799tsHDx6MiYl54oknGGNQXF599dXhw4ejbwFWWF1d/fLLL69c
      ubJTp06tWrXat2/fc889t3nz5oiICGhUTq9uRR6niUViO61atZo6dSpCucDJQJHxE8QIRUdHk9VU
      y+sLuXiLdrLJwPxCRFlRlJSUlNTUVBLeG0NXhedqfPjhh2FhYWFhYaKVTOb9GODPw/PV1dVnzpyp
      qqoqLy/Pzs4+c+YMalOrqpqdnV1cXBwRETFs2LC0tLQBAwa4eB+nsrKy77//Pjk5uU2bNoB8VVXV
      6tWrGWOPPfYYsli8zYktA+MX5wEkRzN+2UjLo4MpKSkpKioymUySJDkcDqr+odVqe/bsiYSAiooK
      UFukR+l0uurqalS3hypK5eQwCfJuxo8fL/H6X6AvoHEkWq5cufKzzz7r16/fn//8ZyZ4nOiqMyFS
      RVXVQYMGJSUlZWRkHDt2bODAgRBkiKWpvHYF9n6zcI6ovJiKhT58Es+NYtzbcfDgwVdeeUWv18+c
      ObN///6FhYUrVqwICgqaO3cuBUfX1dURw8OyoZIzbixyu90DBw7ElzreMwsPS9yIl5eX969//UtR
      lGeeeUblRXIAN6V+NpPMnfD33nvv4sWL165d27NnTxyKLMt1dXVICLfZbJWVlbW1tdu3b2eMFRQU
      vPbaa+Xl5ZmZmUVFRTU1NXa7HaXrwJ7hEQkKCgIipaamDh48OCIiws/PLyQkxGAwJCYmMs6EFEXx
      9/fv27evypsgykLqLz0my3JmZuaJEyciIiISExPJqMK4ZR8DKwcnCAgIEPOZSZXEN++//z4ifJ5/
      /vnU1FQIziaTqU+fPitWrEhOTkZJnPz8/DfeeGPlypUGg+HNN99MS0sbP378/v37X3rppUWLFkHa
      EO1RquDh97hoQInOnTvPmTNHx3swULk9svmAqVNXHyaEO9PMhFeknJHqoNFoKIqMzlrUUQhRT58+
      zRjr3bs3vUsS6rnC2EvSodlsfuONN3bs2IF3+fn5BQQEAFdvv/32v//97zExMb6+vlQvEpxj1apV
      s2bN6tev39KlS9Eyc82aNd9///3o0aNHjx7NeFVw9Rf22/1GR3P3kiRRkdDF7Xbff//9ffr0MZlM
      OqHpM1WwIt0fSgOYBKz5uHsIfSEBB00IJEmyWq1iCyrFq/HLjh07Fi1a5OfnN3369ODgYA8vpXjN
      JG4IjoiI6NOnz+nTp7/44gt4QemeSJJUWFh45swZjUYTFBSUkpIiRqnfLAAqPOUVnE/mPcSx0z17
      9kyfPv3ixYsvv/wyHNeLFi3Kzc1duHBhcXHxW2+9hVwhZOqCEYLXKry+GIlLyCClhGFV8CdLknT5
      8uVnnnkmLy9vxowZ/fv3l3gjaElIuiFqRXd+5MiRixcv3r17d3V1dXBwMIpUf/PNNytWrCguLnY4
      HMXFxSjfryhKbm7uvHnzTCZTUFCQn59fu3bt0Lg4LCwsNjY2JiYmPDw8KioqMjLylVdeWb58+Z13
      3vnGG294iMYk6cvcX42OCNgU6AKUGzK4HT58WFGUoUOHIpCRTp+Okgb+ZLVagRiMF0wGcXS73e+/
      //5LL71UXV397LPPPvLII+BVKPfk5+f30EMPAfLZ2dnTpk3btWuXXq9ftmzZXXfdpSjK66+//sAD
      D6xatYox9tZbb6HNA72XNRSqRFTe7XaDQZImSpZPxgUdBKSiLBIJZ/BOU09gos6kAUDBgriA2F+q
      xuyN54qilJaWHj16VKfToe6pwv3V9IDMS3HAK4BmIQMGDEhISOjcuXNKSkqHDh3Onj171113hYWF
      9e/fn64bTtNkMrlcrqSkpA4dOuzbt2/06NH//ve//fz85s2bp9PpHnvsMUogbTEHNTZ+cR4goqYq
      xOTiM9ArMDAQkZqESWKaD+NHrhEqzzAhqgGcA5IOyiSAHgHLwUvIW0WRAzab7d///vfFixenTp16
      //33My74iE5pD5wGg7njjjuWL19+5swZVAIABuMWffvttzNmzDCbzcOHD1+0aBGIiMck12Eaou2T
      JE5eB8Zbq9fV1W3ZsmXmzJn5+fn333//tGnTQKHatm27bNmyv/71rx9//PHJkydXrFiBBEvwVMZd
      bS7eL1P0Z4qlkMBpyIf/7bffbtu27ZZbbpkyZYq2fj814ou0eOIKKSkpAQEB58+f/+GHHwYOHAj5
      7uzZsyhr0aFDh44dO7Zt27Zt27aRkZGIMe3QoUN0dLTBYPD39/fz80MGslzf9474KDpimYdmSrys
      DS2MwhAoyIrVj7QpKCjYuHEjY2zo0KFkqgKl9hB1yRZXV1cHWZuQBCB9++23X3nlFYvFMnr0aHih
      yQWt4eW+GWO7d+9+7rnncnJyIiIiFi1aNG7cOMxz2223LV++/O677/7www/tdvvSpUtB0zW89Det
      xJvyYtduoUwC43GiWIPC4+JgIMI34IhOpxNl5gi8jFchhROOPMOq0IEVrxbNZfiQnZ194sSJgICA
      +Ph4Vt+wBgZDch54TGho6KxZs/z9/aEeYb8XL15UeEVxF++axxgDN2WMDR8+PCUl5dFHH921a9fo
      0aNDQkJKSkqeeOKJQYMGMcZQR50uacvwGM0HFJy0i/drxNmLl1AWgnZAfchUTXgvC4F3hE8IRkSt
      CCZYM/R6fW1tLaLBFCHgB4/5+Pgg43fChAmiVku2IPIH0B0DLejRo8esWbN69OhBOYegpyAHyM6t
      rq5usJiPuIBrH8TtxGtPxgfkwS1fvhzdwx955JFZs2ZB3kcd6T59+nz22WfPPPPM7t27R44cOWbM
      mMmTJ6elpTGhc4uY80zEjkI4CCzkbunateuTTz7Zq1cvqrwv2nmJRtP1BvENDAycPXu2yWTq0aMH
      4yFD6enp7dq1a9OmTXR0tI+PD5KfQXlJ6GP1DWsEB1H8RHUpCnZCWBeEDArSx782mw31mRFUSl5r
      RVE2b978/fffp6amglNqNBrknZKKg5cSNZckCZ2cIyMjsU1Jkqqrq99+++358+dbLJY777xz3rx5
      iDqlyhDQEqqrqxcvXvyPf/zDbDa3a9duyZIlI0aMoIN2uVwjR478+OOPx48f//HHH5vN5oULFyYk
      JJBapgpOIBG1FF7ChAlWF4gvUPvEKyYJcVZutxtGJ2KQMi8+oeEpxGIJTxEfGsPzvLw8u92enp6O
      utkanueBOan+KJlnJUlCThy5IhRFgdcEQQ04EVi3GHdsKIoSFxe3devWxx9//IMPPmCMtW3b9rnn
      niOFTK0fzdUyxNEcPIAwFQ2ggQdIE92wYUNOTg5SmVTeCx6hKZTkQi5WokokoEHQKy0trauri4iI
      UAXPFW67R6EYSEbUPmncuHGjR48mQU/llRKYVyS4yuMutFptfHz83Llz6U/kWmCMhYSEBAYGVlVV
      eQe/sxuIQqNrRv5nkK2LFy8ePHhwx44dn3zyCWMsJiZm9uzZVHGMmiKoqpqSkvLll18uXLhw7ty5
      y5cv//DDD8eMGTNkyJDbbrsN0RqMy1wkR2t5+xEmXF3aRdeuXRcsWKAI8VfwOqpeNWeIjiPI8skn
      n9TwFA2QocTExMTERBE4pIoRLycguHjXdYVHiyqKQo5liXs1YXMH4yFNET+XJAnR8UzISsF/jx8/
      /tZbbzHGJk6c2L59ezcvYC4eBF5nt9uRW1BRUXHgwAGHw5GQkEDw2bBhw5w5c5xO56hRoxYvXhwb
      G6sICRw4xC+++GLGjBmnT5+WJGnEiBGzZ8/u0aOHKoQbYbaxY8fabLZnnnlm27ZtWVlZCxYsuPfe
      e70Rgwm3jLQ3UnpIM2CCAmSxWL799tvIyMioqCiDwRAYGHjhwgV0TCJ5i0w0V65c+fTTT+G/FW19
      kuAqo1XRkhRF2bp1K2OsrKzs3XffRSAZ4r9x/eGTuP/++9u2bQtOIEp7dKzwFBISig1coQrgHA0G
      w+rVq4ODgxctWmSxWHbu3IkINMaLCrewgQZH8/UPYEKBLTIQZWdn5+TkeIgSjSm54mz0DD0P7ATe
      k4GS9AmyFVA0COMsAZqvJEmbNm1atmyZyWQKDAwsLi6urKyMiYkh5UOUbZnAAGjxdrt92LBhu3fv
      Xrx4cUFBAd0NVYiZY1x0+lnQIwETzo+vv/76q6++ysvLy8rKQhyhTqd79NFHp02bBkqkCA2Q8Rmk
      S2x+iwAAIABJREFU86WXXkpPT1+4cOGmTZvWrFmzZs2a8PDwxMTE9u3b9+/ff+TIkWFhYaRpkbwp
      CQUY6OCo0A3WdvXq1alTp165cgWxH9u3b5dlmcKxSP4V4SCeNatPRCjtTnS9ivhDkYgqT0+VJAnW
      GIlnyYE0EBAwM1FAkiqIoJw+ffrZZ58tLCwcOHDghAkTxBWSWQxiSqtWrc6dOzdy5Mg2bdrk5OTk
      5eWlp6ej3CE0m6FDhwKYCxcuDAgIIC0ERrNz5849+eSTCGEKCAh4+umnn3/+eSxe5aETRA3tdvuE
      CRNCQkIefPDBixcvgsGPHj1a4U1mNDyVXawRpPIoe43QMlcjVBXV6XQBAQFvvfXWoUOHUFHK7XZX
      VFSUl5ffcsstCLqnVzDGamtr582bh4I87BpuqMfYt28fqvpg0CT4cMcdd7Rt2xYSGJiuzCtS4DF4
      XFTBsSSeCKlxcLe8+eabKJf74osvBgQEwLbWQv2bGM1qIIMwgtNFeM/06dMfe+wxVr9JN2vEaC4i
      nJsXQNbpdMePH3/ooYdKSkrgHHbzasaQMkgswpe1tbUIOQUVw7+o2RISEpKVlYVOk4yxoKCgYcOG
      waZP8UI0FZ4RNW4ES6SmpsbGxhYWFtLzHhL0dQzS5UGalyxZcvjwYbC65OTkiRMnjho1qkOHDkTx
      aVVSfWeMoigpKSmrVq168cUX161b98knn1y8ePHAgQP79u2rrq5GAQyxWRtxPqfTiaRQgBQiPOqD
      glWEhoZevXoVbXJx0KNGjUJsJZX+Z/V59o0MD0iWl5crilJYWOgWiqEq9YsLeQyVNx4gW8SJEycO
      HjwYEhIyY8YMGKMBdpAkGJpMJlNiYuLdd9+9bt26M2fOnD17VqPRDBw48Pnnn8dPZFl2OByxsbGf
      fvop413VIPOSJ8BgMJSXl2s0moceemjatGlpaWmUZUJHRkcJ3pCenr59+/apU6fqdDqUFKXEBVVV
      LRYLvNzodKThxR4avETiGD16dEFBQW1t7aVLl2AIuvXWW6dPn45EByAbgnlqamq6desWGhrq7+/v
      6+tLmhwxm591fCqPDKyoqCgpKaHyt2IWiKhNWiwWp9NZXl4O5k2FYMXdwcOByZcsWeJ0OpcvX/7q
      q6+Gh4ffeeedlB/3s9b5BxnNygMIO81mMwx5sbGxHTt29L6oopjf4FCE8DuHwxEfH4/AQYW3KCKd
      ETZBSZKuXLni5+fn4+NjsVgkHkYNYwJuWt++fTdt2lRSUlJeXh4SEtKxY8eUlBTcf2SoeQQ/0LLd
      vAanTqc7dOjQ119/3b1795CQEOZlU7pu0NGmAgMDH3vssYCAgJ49e6anp3fq1Al+abwIKo7Irgie
      Kg8XkWW5U6dOs2fPfuGFF44ePbp169acnJyJEye2atXKzbtowapD/gbIy2FhYU6nE/wSPjp6qVar
      XbZsGSpYyLIcERGRmpqKCcVw2+uGgAdRExkbY6xjx459+vRBZBdMeQqPQGMCFtFvSTpGljXR2ffe
      ey8wMBCORICU9EiKIAoLC5s/f/7jjz9+6dIlVGKIi4tDAwOz2RwQEKBygwyJ0m6eCwli3bZt2/ff
      fz87OxvhyCo3M4prI2aAjBaDwdC3b99169Y5nc6kpCT0UGJcze3evfvChQvDwsLIguSxZfEeidg4
      derUyZMno60bIBYeHo450WcUhjKdTte1a9fPPvuMooSJv3obPK9xuHizJhB0sp16CIJ4GOb+uLg4
      s9kcEhJCvU49BCytUIZ2wYIFV65cKSoqQsGP617nH2Fc/7W8vkHYk5WVVVNT07Fjx/DwcBARXDZS
      /1kjPEDizX4J4y0Wy8mTJ318fDp16oQSY5IQ6ALrEJ7MzMw0m80dO3aE5k6IKAleB1Y/8YoM0LQA
      b4hJ3OdssViefvrpH374Yfny5d26dYM1VuLu5SZmaHqIijnBR+KxsIADPJMexhN6qSIE46pCYRbi
      FuSUYzxOnFyCePXFixdLSkpiYmJQ+FPhUX3gGRQgSEwRvBnWOWrv48HsG+Px1wIf8RnI0ZicEs3o
      BD1ep/Ch1+tzc3Pz8/PhkZZ43QINL4pALnF6hRihIAtFnJT6xS8RpgVLFAGQSJXKM+R1Oh3EC1HL
      pEUyXvmKdDvMRj5qLMOjnIaGR0JLggroDWe1fuYjqy/QEJKIm5IbKbbcRJpY08dHk2AGm82GI6BA
      VdpIXV2dzWYzGo1wBZNG5TEnITn01LKyMpfLFRERofDK20pDaZIto1l5AC4SoZTHTVOFoA7WkCbr
      cZ8J6SnjCbZ+2ExwmfEA+AHKKoB/yELNZyKpuGBU5QaiN4y5ohuKliGK9pjEbrefPXvWZDK1a9dO
      lFA85Jqfi4WUQcN4LA2AqQgN1IDlCHWnXDAatFT4Pyk+hAI8sEjyAeCN9CtigSpv9qAKVfJpkWRE
      wltkHixPBPoGxTFRD2D14QluRJUvNRoNuXlEoZgkR4XX7sdv4emFAwMcggw4HqcsZuThX+AVQrDQ
      qBLMD2HKFEqk8rbG6OWLV9OOGoQMElxwagaDATUvyd4l16+2y3hxQ8aTMTFIf/WAJHF9YksEK/h+
      CVYqH6KVSW3cznbtRwnUdfNqSyg7QZmGDap9klDHwmNCNy+eiBhWoAFZhq1WK2mu17fm3+toVh7g
      4bMikY3soWr9CrSNDUpgQZiBhle+xQHj/jPGkEXFuC9O5cEGJMfJPD9F5iXktLzVIpAMHEXkTB6D
      8MnjNuItVO/3xvUAt1DbmSRBq9WKPHiJ50JTWSSPGQBz0eRKtAw5d4oQuEIUVhYC7SmVTAy7cvOK
      QyRhgQfQdWWC1n8T7x4BUFRuiBPAb0E9YyXBKISFgcPh6ImrEQZiU+TqoKKe5I1UeVIVHTpmUIQ0
      DphrIE9QhgrjuheeJ0xTG7eriEFxEi/HDerGhIvg4n2t6UTYT/kDFF7bClSV8kXorwpv+A7aCtVQ
      aqjx1nXQEMINQJJayzFBZhJHTU0NornAZbVNFusVg8dkHjmmEZrb/NzV/r5Hs/IAMeeecVn7/6+j
      kTr4jQ04JCXBKEEqJEnfkPXEVyCKEcIU484AjdBmHZRRkiS73Y6bJgm5BRje4jwwjCZBgKkoWIk/
      vA4sVAUTgSxkUeCvpBlQSKXHCkWazvgpiElAIhHxoPLk92NCcSHiSaCJJEGLmoT3gXpjWmNwEJ9s
      8BmPqSReq1LmwTBEHL1/rnIjg3jcxDjJtqbwDgSEP7QdoiwkUnjIrR7mETovPEBFPlQe6NKYpVHi
      gU8KL4ogZi9K9e08jX3TIIRZQ0glYoso78tCKX/vS9r0WxobBHDSYptABifvDErQuBaFUozPJmmv
      hQd4j+b2B+DsxUsiynR0Qt6I5XE3xHtIt0jEV/H+iNIWE2gZYT/jHIKoJMUqqPVtrN47EvVTN6+C
      QjTI4zF2XdFB4nWV6tt5PW5F08ZZkXmo9c0pIkFkQg16D7uc6LoUX0cWIW+rqwdxuRY4kN3ZY4jz
      NLg1D/xp4ryYkA8BKxZtXxSBCSvI/i7OKRIyMa2ddiFKJ6RGkBztQa89INMgyxGRmY7S+5iYF4lv
      AtSk0nlssMHPDbKK6xveMzRxy0gF8cDMBqcVJSTGdTtK9m7hAR6jWXnAtbzrGk/Ig6Bc32iCpvys
      VTUtt167/PuT4xoPqwn22WzjWuBwjY/9pCrQGPyvRc+49uE9mwevuhaVpcGHr309LfTr546f1Clb
      xm+7gMaveKi/CmFtGU2Ma6H+v9wbW0bL+I2O3yoPkG4g2Lxl/M5G81P/ltEyfjfjt8oDxNEM/MDD
      6PRrsR+PnV7Lxm9kqTdiS7kWM11jRv+f6xP+uePm2ojEn1+7Fe4GzZgt4xpHi7D4k6NZecC1IP01
      Wo1vymjCr+W9jGbApOvwTDSN4jfL8H19w+Pt1z7tjbDbm+hzuo5BjvprfPgXWkbLEEcLr216/Db0
      gJ+Mcrvpb/yvEh+ajqXxXuovIfv/WkMS8hV+IeZ0c8d/D9q0jJZxLeO3Wkaj5aa1jJbRMlrGjY/f
      Kg/AaGZO4BFcrPLRnGv4yfHftp6W0TJaxn/zuAk8ADm3+JcJdVToS2pA6DG8qRVVLKAcHyTpeJs7
      JCGlS7QV4GFkt0tCqXpxTkUoIeuRviSuX+ItR0TSL4aEU64KLU/x6qchZvp4LInAQt+Iu6b/KkIN
      5MbSo8S/yrzXpjiJx94lofoKbYpA53GIrH5hXvq5CFsRaKLRhrYjTsWE2hUilBRe88sDJcTZGnwL
      AUpEGMZLWXj83MOyRPDx+Aa/Fd/emKeKfktXoLFBCxM3Qt/Q6wjIkpAJ6A0l79cpQu0mccH0wQM/
      sXKaR1VV4KT4Ou9/Ga861eDb6UmPD+LwnrOxBTe4O/EZEQgeP/dAOe+ZPQDoQcFUoe15g8//bsaN
      1vBivIAfJY7KvAYsVVCgKg500h7HyThBpJRFJtAdmlDlBRcxCVVoES8hvkS5UI+i/3iLqqpiPqQH
      4lK7D4kXn2GMoUiLB30UX0drpiLJHmRd5TVeMD+VaqFKDNThj3ZNVIzKECGrnjVEC9xCA0UmVONQ
      hYRJsYyzwouOiYnQYkl6MRUTvJayW1FvQ+adWwgHJEnS8C6edMrUx4p+TuCVePdmOgtaqgg9bApr
      EC+hxCuO0Tx4BVW7k3jHLuIE7vpNj6n+AbZDb1d5YSXMSS+VeF0dOm6Jl2mSeGZ40/eFEoaprIiI
      IUyohUnygQgZ+iwJxS3oNhHTYvWLh3tILcyLA9HGATG6YqIkQfwJC6P+LQQx782KvI3uPsGNfoLH
      xNxp+pK+UXlFYQKdWNxUfCORAg/sFbcDaYx54ZtGaGFG1UREKnEtBSp+i+OGdgWgO51OyAWq0OYJ
      +ER1AUWCRZgk8ZKNODbUvncLtX81QidYeh0uHhEaiZfMxDk5HA4RaegZ/JdKEtJLqWOlWC8ekzBO
      N4mciTUgCYnxDBWyJlAQXXY4HICAoih4jFQHWSjSSVQbtTYJL+12OyBDnVFVoZc33Rms2YPK4Hsi
      2SLSq0IPENwTFDLD0RDYqbYHXorlAUouPgAcWgkxQirCLMJcURTUQ8YPqTgPvpS4ege8UrlmA5hI
      fIiV0bAGlIoTbz7JqsTgqRQEqacAJvWtpIpsWKqb1xkkDYl4Ic2JKqFYJCoV0iK974vCS/URVQIc
      sB4sGFsgIivxKug0IXBDvGgyr2cnca3R+5J6UGGSPFwuFyDPeA1UqnxFOxUpI8lzzEu7pRXiKol3
      hABCl9RDmiF0lRpRdj3gKTIzwB//Am2YIE1SDRWSIehwCQeIUFCReam+8ufNmX5P40Y5G64Brigg
      brPZQLvdvN+baJ0AxuM86PKgyCK+VBvSEtxuN7ENhfehBb46HI66ujqcsSjVUsNIxuU1UWwhVEYB
      TtAjUbQkuowiwDabDT/HPRfvMBUuFWFCFMrNy0zSlgmfgK+k/tfV1VGXLipWimWgAh0TLGCKMEgU
      xcwoworJJUmi7mOqYDDR8AbxpC2JciVuAq4Hfoja7gAakU7wVNTUBKyIwDkcDrpdJIDTyXpQJbHi
      KYkIQB6Zt4bHRqT66gJYnVh4igRhlCBWuTZAaEBMBUev8hLKJN5KvByeqqpoziUJCqjFYmFCZzRJ
      KKdKpyBinThYfcqFDzLvaE+yBTozM05J6dAVRUFTdXSJwAqJPRMGir0zpfqmJLwdyCDW0xVrpEtc
      +2SCAE7sH/MQvyewi5qxxBUL+rl4c1XeyAhgFLV/MCTxsoM/0U1BR0nwWmI/mE3lVdBR/ZRQV4Q8
      CgOTmqjh3adFaiM2MgM2gm4QbWG/x6GZPXv2df+YCAdVx8VhkJimCjZW/JVaEdHhKbyWups31gAp
      pAMjzUCUhqh6FJEhhXctB28ATXE4HOgaZjAYiBjRHSYDAul6Go2GitNmZmZKklRcXCxJkp+fHzWx
      I/wTZdjKykoUCqaymrRgoubgFgovekVWF3q1SEnJnoObSeUVRQYDgguOiOdtNhsmIT5RWVlJMzPB
      Dk6CmyzL6G8FPgoI6PX67OzsoqKioKCgy5cvR0REkDJHFfSYoD8p3LpFy6NybETHqeKxRqNBKXyR
      SIk9F0EC6urq8vPzg4ODQSXBGOj+S1zRBHzQ6xEkAPQCReQxFfq/k1qp0WhKS0uLiooCAwOhQGDl
      VVVVtbW1fn5+xDUBH5yv0WiklkRoIkbMz6MUaGMCIwGNPgD/HQ7HuXPn0COFSJKGt9nCFSDcVgTD
      GjEY+hXhD52yzWazWCxuoZsbkWmQOWxKEVp64I01NTWSJKErA3YnilmMm/hkXl6bCR4yi8VSU1Mj
      yzJRA4JnRUWF0WjESeFEmKA1svoiGq0Z1xxbA+GWhTZBiqIUFhb6+vrq9Xr0CSDFiDFmsViuXLni
      crnQGQ0vqq2tpVroUK1oMSRfilxN+f3Wm7uh/ABiADqdzsX7dlVWVp49e9ZsNmu12oiIiC5dujCO
      7gD9jz/+GBcXFxERQZwDVFKn01VUVJw6dap3794ajeY///nPlStXWrVqVVtbGxwcDMSCkBsaGpqS
      kuJwOH744Qe73U723JiYmLCwMJPJRM2p0Xh94MCBBoMhPz8/NzdXwxtS45jbtGkTHR2t0+mqqqp2
      7tx5++23R0ZGyrJsNptXrFgxadKk3Nxcg8EwcuRIhZdNtlgsfn5+brfbYrHYbLbS0tLvvvuutLQU
      7Rghzvv5+dXW1hJXIBNNTk5OUVGR2WzW6/UpKSlt27YFGS0pKTl16pSfnx8am+C2S9w+1qVLl9DQ
      0AsXLvj7+0dERKBGPyQsWZZPnz5tMBg6dOhALArfa7XaK1eu7N+/v3v37u3bty8vL8/MzAR/Jb0k
      NDQ0KSnJz8+vrq7um2++iYuLS05ONplMqqp+/PHH7dq102q1X3/99fTp04mygGzl5+cXFhYyL7Mv
      Wqkwxurq6vz9/cPDw2NiYoxGY25ubkZGxoABA0JDQ10ul8lkqq2tNRqNgM+uXbtKSkrGjBlDFFmW
      5UuXLu3evfuRRx5hjB05cuT06dMAu8S7FAwdOjQwMFCSpFOnTp08eVJVVV9fXyiFQUFBtbW1mA0c
      qH379t26dUMNekVRvv/++8zMzOeff564mkaj+eKLL7RaLbqQM95PWKPRlJSU7N27d+zYsWAVGRkZ
      //znPydNmtS5c2er1dq2bVuDwQB1FjvyGCQ/Eh0hggjaV1FRsWrVqgceeKBbt27E26ihBemFGo0m
      Nze3rKwM1lej0UjEl+x4kAkSEhLCw8MZFyCOHj0aExOTlJTkdrv379/PGNNqtRaLJTAwsFevXgAU
      WCZ0voqKiu+++66oqGjkyJGJiYngu1SCH8IQda8DdTabzaqq1tTUFBUVlZSUZGZmXrp06ZlnnunQ
      oQPpTLIs5+TkbNy48YUXXtBoNFVVVXv37gU+uN3u2NjY9u3bowKrw+EoKCgwm80kmlRWVkZFRdXV
      1YEhkWEwOjo6NDRUVdVdu3aFh4ePGjVKkqTc3Nzi4mKj0WixWCwWS1ZW1rlz59LT09PT0yEiZGZm
      5ubmotcbjBDh4eFRUVHoroyTioyMvOOOO4g7EgMQJdHfx7ghHiDq2hDh9+3bt2HDhtra2h49epw/
      f762tjYxMXHcuHFRUVEQ9A4dOjRt2rSnnnrq8ccfJ4mDGP7mzZvnzp27du3afv36ZWVlbdmyBU0f
      L1++bDab0UlVVdURI0Z06tQpLy/v5Zdf9vX1DQoKwnV1OBxdunR5+OGHW7VqRX3EXLxViMPhgFCM
      62e1Wv38/CIiIrAXl8t1+PDhc+fOTZs2LTAw8PDhwyaTKTU1lTG2Z8+evn37BgcH40moLxcvXjx5
      8uShQ4dyc3Mfe+yx5ORkl8u1du1alPIPCAi4cuVKVFTUkCFD8CubzbZu3bovvvgiNjY2Pj7+0qVL
      77///j333POXv/xFq9WWl5evWbOGMWYwGBwOx4ULF9q0aRMREWE2m8PCwiIiIoxG47Zt21q1ajVm
      zBiqpa7VanHTfH19165d6+fnR3qAwvsbozcTYwwMGLYsUjjQ9BzwKS4u/uabb/72t78lJyefPXu2
      trb23nvvZYw5HI6ioqKYmBg6KdD68vJyEiEl7oC12+2qqp45c+bQoUOjRo0KCgqCIFlXV7d79+4e
      PXoEBQVt3749MTGxffv2jLOQ/fv35+XljRo1ykPeBMt3u93FxcXV1dVt27bFXkpLS7OzszGboigG
      gyE8PBxi4BtvvNGpU6exY8dWVVXBbAKPSGBgIOhpcXHx6dOnP/zwQ51Od/LkyaqqqqCgILPZrCjK
      tm3bgoODo6KibDZbdHR0YmIiVmK322tqasCcKioqvv7664CAgLKysgMHDhQWFs6cOTMhIcHFWxm7
      G+rhQ0PiXYIhtUD6uXr1amFhIdREjUZz9uzZrKwsQNtkMpWVlY0bNw6IAd5w8ODB/Pz8u+++G2Iv
      6HJ2dnZBQUFCQkJwcHB0dLRGaJN3+fJltLyvrKxcsWJFQkJCampqTU3NRx99lJaWRh2ESkpKMjIy
      MjMzc3Jy0tLSunbtGhgY+NFHH4WFhcEppdfrdTpd//79/fz8JEm6evXqgQMHSkpKfH197XZ7ZWXl
      9u3b27VrFx4eHhsbm5iYGBISouFdd/4fe98dH1WZtv2cM5PMZCaTSe9t0gMpEAIkBEILndBFBUTF
      RURsWHHfXXZ1hdUFXF2UVWyLikiHUENLAoQAIZAE0nub1EkmUzOTmTnfH9d3nt+BLd/7vbr77vrz
      /OFPksmc9jx3ue7rvm6Y0f7+/tLSUsT7paWl27Zt27hxo7Ozc3V1dW9vb3R0NJ6h0Wisra1tbm4G
      Xme1Wr28vPbt26dWq7OyspRKpdFohPt0d3f38PAQi8Xp6ekff/xxd3f32rVr79279/3334eGhmJh
      p6SkpKSkxMfHw7k6OTm5u7snJCS8/fbbgIJXrFjh5eWlVCoR3jEM093dXVZWNmbMGLgoh0Cq+ifm
      AMgP9AHUMcI55+Xlvfvuu5mZmXimHMc1NDT85je/6e3t3bx5M0Iko9HY2tpaUlLS19fn7e2NMZAA
      OnQ63cWLF1tbW/v6+liWnTNnDuJ3h8Px0Ucf1dXVvfHGG3K5fGhoyM3NTSKRqNVqlmVffvnl+Ph4
      o9HIsmxZWdnevXsPHTr09NNPm0ymu3fvVldX19XVWa3WlJSUuLi4yMhI9v4xsCw/P8DLy2vdunXv
      vPNOSUlJVlbWzp07XV1dP//8887OzjNnzvT29mLc9rRp0xITE2EOkpKSWlpaOjo65s6dSwi5fv16
      fX39nDlzEMaWlpZWVlZOnjwZhnL37t179+59/fXXJ0+ejP189OjRr776SqfTbdiwITY29t1337Va
      rb6+vuXl5U8++eR//dd/YSIx0qnh4eHW1lY67oouyv379w8PD3d1dRUUFMybNw/mgBDS39/f0NDQ
      1tZ269YtkUiUkJAwatSoGTNmsPysNLgQilbJ5fJHHnnkD3/4Q25ubkJCwoEDB4qLi0+fPt3Z2Xn9
      +nUYXKPRmJSUNGnSJKlUGh8fHxUVhTCNJvtCC15WVjZ16tSwsDAaRikUCuAwpaWlp06d2r59O/Ie
      sViM/EahUODD7e3tjY2NdXV11dXVubm5bm5uJpNp8uTJo0ePhm/QarV6vZ7wIXZMTExsbKzdbgfm
      M3HixLFjx3KCuiUrmI4Am9jQ0LB69erW1laWZd3d3eF3xWLxyJEjUWGiIIBarS4tLW1tba2vrw8K
      Cjp27JiLi8u2bdsIIbW1tb6+voGBgYSHQZBiCveIEESmWRRcps1m6+3tNRgMhYWFHMeZTKaGhoaQ
      kJDGxsbW1tbU1FQ3N7eKioo9e/bMmjULE4/j4uISEhI0Go3JZMrKysLYToZhJBJJcXExx3ELFy6U
      y+VYGzqdTqPRaLVajUZTX1/v7+8PF7ho0aLs7Oz29va9e/ciEsJKcHV1DQsLAzC7ePHioKCg1tbW
      77///o033nB1dXVxcVGr1Xfu3ImPj4dHcXZ2dnd3t1gsLi4uvr6+zc3Ner1+48aNMTExdJopxQb7
      +vr6+voaGxuxNgICAgYHB7u7u6dNm+bp6elwOBCA43F5eHhMnDhx9OjR8AFYZidOnBgxYsSzzz47
      MDAAgM7hcHh7exNCrFZrXFzc0qVLS0tLh4aGZs6cmZSU5OrqevHiRY7jHnroIeFmt1qtAQEBLi4u
      gIycnZ19fHxCQkJ8fHwiIiIQ73d1deXk5Gi1Wi8vL/b+ATs/+4AHDwrK6/X6gwcPJiUlvfzyy4gs
      WJZNSUnZunXr448/npmZOWfOHI7jXFxc4uPjzWbzuXPnVqxYgQG/QLTPnj1rt9uTk5Oxi/z8/PBz
      hmGAsahUKkp+IITAn8fGxnp5eXl5eRFCgoODOzo68vLyHn30UavVajQaOzo6tFqt1WrV6XSDg4PY
      MFKpFIVr4KFyuRzwy4gRIzZt2qRSqT755JPq6uqNGzfiV6GhoVgcYrFYLpcTvorl5OSkUCj0en1f
      X5/RaOzq6goLC0tNTYWtUavV+fn5CA+7urr279+/bt26pUuX4rlxHPfYY48NDw93dnYODAy4u7uH
      hobiocXExCiVyqCgoICAACJgJri6ulIGC+Lx4eHhW7duPfPMM2q1+uDBg/PmzUPQDQzEYDA0Nja2
      tbUlJiYODAx0dnbKZDL6tBmGQVKFnWyz2dzc3NasWWM0GouKik6dOpWVlYWah5ubGwI0i8WiUCiQ
      gjg5OTk5ORUWFgLIpnjutGnTPDw8RCKRi4sLQCEK8uKCOY574YUX3nzzzS1btmzZsoXekYeHB0Wx
      HA6HXq9vbGzs7u5mWRbwTnV1NQbAubq6NjQ0dHR04Ns4nuICe40i0N27d1EOIYR4eHjAFQHKDwwM
      TElJiYiIWLJkiZOTk4eHx/DwcHJyssViCQkJycrKGjFiBJBMQgjMQXV1dUdHR1VVVW5ubnUN3Y+m
      AAAgAElEQVR19YQJExobG69du1ZbWzt//vzLly+HhobGxcUJJ9lRY0GrF9Qb0UoJIaS7u7umpqao
      qMjd3b2hoeH8+fMzZ85kGCYgIGDChAlisTg4OPjjjz+mdVdqrAcGBvLy8rA+DQYDQgeLxSKVSmF/
      TSYTy7JwJzU1NWazWalUhoeHi0QiV1dXZBiIToQFTyxyhmHq6+ttNhsi8czMTPw2KCiopaUF92Wz
      2VxcXDIyMnBtMpnMz89PJpOFh4dLJBLUElxdXTFTjxDS19dXVVVVU1PT399fW1ur0+lsNpuHh4dC
      oSCEyGQyIFEMX5RWKBS4Tqyfzz//vK+v76233mIYRqlU0kwLc1URG02YMCE1NbWpqam/vx8RSXt7
      u9lsvnLlyvDw8NDQUGBgYExMjEwmu3fvXnFxsUajwcdyc3OTkpIQQhEessODcgh6BYSv9ad0/FAs
      iFaBampq2tvbf/3rX9PUkhBisVgSExPHjRt37dq1WbNmAdMPCwtLTk6+fv36/Pnz3dzckGOaTKaL
      Fy9OmjQJ+D6tC+EsyIJpNYxWtOg+RzjJMIyfn59er+/v74+Ojvb39y8vL6+qqtq0aZOLi8s333xD
      +DqY1WpVKBQuLi79/f2TJ09GxM2ybFJS0vHjxy9dujR//vxHH33U3d0dQHlmZibFgvDJxsbG/v7+
      CxcuDA4OlpSUGAwGkUgklUpFAoo3itUcx128eNHPz2/ZsmWEENSsCCHOzs6PPfaYTqcDoOEQEP7s
      AjYtNV4szwahFeADBw6o1erFixdXVVUdPny4pqYmNjYWT8/b23vq1Kksy+7Zs0cikUybNm337t2w
      OwBVZTIZVnN4ePjUqVOx3CMiImpqarZt2xYUFPTYY4/FxcUNDw8XFBSMGDEiKCgI90ULaCaT6cyZ
      M97e3vHx8VKptLu7+8MPPwQCQAQ9ChT3oKCqQqHYsGHDiy++uHv37qefftpqtVosFnw/AnZ/f/+Q
      kJDLly/X19cHBgYmJiZ+9tlnx44dy83NlcvlQCFg7Gg8CF9y7949hCPl5eVGo5HjuJs3b6pUqhde
      eAErDcvp2rVrc+fObW9v12g0s2fPLigoGBgYuHv3bmlp6ahRo6qrq/G1GRkZAQEBAMTFYvHUqVN7
      e3tRl7ZarZcvX3Z2dg4MDKyurm5qalKpVBioSev2eKeUzmDnx5bRVEwsFickJHh5eZ09e3b69OnZ
      2dm/+93vWlpaXF1d3d3dadlAxDOS6V6z2WwmkwkgnkajUSgUvb294NUIT8EwzJQpU65cufLll1/G
      xMRkZ2d3dXW5uLigiEILD3itIpEIWWNtbW1FRYVCoQAgiaAHFyORSEAZwMXX19ffuXMHlQnUb/r7
      +w8dOuTq6gr8xM3NbfTo0cHBwcPDw5GRkUFBQTU1Nd3d3SqVKjU19ciRI4AKOb43jeG5njAIhBCE
      EVevXt25c2dcXJzRaPz+++9HjRoVFxeHjQ+cAE9YKpWi7NfV1QXGgclk0mg0Op3OxcUFQSGeoU6n
      k8lkERERWJO+vr56vd5ut3d0dGBp1dXVdXZ2Us+NR4R//mOs7z/x+KFYEHWMTU1NSqUyOjoaOw0M
      LcBtWVlZBw4c4HhupUKhmD179vbt269duzZ79mw80MuXL/f39y9atKigoGBoaMhx/1Rbcn83LF4D
      LWQRQmACDAbDxYsX4+LiIiIicHkajaavr2/37t0bN25cvnw57FF+fr5Wq01LS0OVAmEsx/PYWltb
      N27cuHfv3ueffz41NbWurq61tbWgoEAsFqtUqjVr1iA/nThx4vDw8NmzZ7VabXR0dHh4+M2bN6ur
      q4UPh/Bl89LS0rCwMBQkAVLTFSyTybCjyP3NX5yA1Ud/iCVLvWNBQUFGRoZIJEpMTIyMjDxy5Mim
      TZuwbcBUaWpqksvlFy5cSExMzM7OxtlLSkrOnj27du1aHx8fWpilb7O1tXXWrFkGg+H3v/99VFSU
      Xq+vrKyMjo52c3Pz9fVdsGAB8hWOJ4yOHTt2woQJHMfpdLpPP/0UaAwCdrwaEd9KZjKZsCpYlh05
      cuSrr74K0A+x4YwZMx4woMDoc3JyIiIiVCrVY489Nm3aNISfjY2NFy9epI+achMKCwtTUlLWrFkz
      PDxsMBg8PT3b2tpQQMYnwSD87rvvnn32WZPJVFNTk5KS4uvrK5VK8/PzFy5cGB8fT3g/jbKnVCoN
      Dg4OCQkxm83e3t4xMTGurq7jxo0bNWqUSCSaNm2ar6/vjRs3HPxYdmq4YbUJz5Kk4Qt8PJaxRCKx
      Wq0qlWrSpEkikWhgYAA0gY6ODvollKTkcDgwDZsQEhMTM3fuXJpwOxwOX1/fkpISfCdwbdxyd3d3
      T0/PtWvXli5dqlQqUT8j/BhqmkhZLJbY2NikpKTPP/88JyfHw8NjxYoVtbW1Q0ND1IvD+lMankwm
      CwgIwFYFjI6kGSkgikZubm7IGoeHhxUKRVdXV1NT07lz51JTUyUSCcIFLBij0UhZ/Hq9Hhmn3W6/
      c+fOBx98sGLFCtSB+/r63n777WeeeSYzM5PGf62trYcPH25vb3/ooYcyMzPj4uKw+6RS6eDg4Lx5
      82gIRenLDocDJf2uri7ULZqbmwFFiMVik8kUGBiIBcAIeN6U2/ZTOn4ELAj7tqenJyoqCnYZ6B4i
      CEKIRCJpbm62Wq2I3axWa2Ji4siRI3NycqZPnw7zffr06ZSUlJCQkMHBQcJTP+lZGP7AP2mMWVtb
      +5e//AUrCSZALBZv2rQJsMPNmzcHBgZefvnlxsbG/fv3P/vss4WFhWPGjAkMDJRIJIGBge3t7YmJ
      iQzfcIg9tnz5cj8/v6NHj0okkqCgIFDrQkJCJBJJQEAAbhY7jWVZnU7n5OS0d+/ep556ivDdA0Bj
      QOwB4EiDfZZvMkLaLuKJ+RTwobf5QMqJyJGm7QzDVFZWdnd3b9q0iRDCsuzKlSt37drV29sLhFQi
      kQwMDLS0tMycOVOlUp09e/a//uu/rl27JpFIxowZU11dDdxZpVIhGaedNcnJyVOnTj1y5AjqwD09
      PYGBgf7+/u7u7kqlEuk55bnCfdLgFIEwcHmOb+Qm/OZxdnZG6Ar/NHv2bNi1hoYGQgjcNoJZqVT6
      9ddfW63WN998s7W1dcuWLenp6TExMUCfJRKJv78/igccTyZ2dnbu7Ozs6Oj4xS9+gUfn6emJhw92
      KaWl9/X1JSYmlpeXm0ymxsZGHx+fhQsX9vT09Pf3jxo1KjY2FjgJXp/JZJLL5U1NTV999VVVVdW6
      desUCoVCocApVCoVVoJMJmNZlno4lifmEp6ZQ2MXoBY0VDebzTk5OV5eXsgnXFxcVCpVTU2N7f6u
      Y6Elwnf29PRcvnwZT1Wn03l4eFRVVaEMTviQiBDS29tbUVGxZMkSZ2fnP/7xj2vWrLHZbEDeEdFj
      K4GN5nA4TCZTZ2dncHAwAK7Q0FBk2LgXSozGNQQGBqIWgqt1c3Pz8fEZP348JV/BBSKLAnJotVqX
      Ll0qEom++OILX19f2H2xWAzvQjcCra4fPnz4o48++uUvfzlmzJht27b5+Pg899xzLMtu3bq1vb19
      xYoV+LDVao2Pj7969eq33347efLkgYGB27dvS6XSa9euWSwWHx8fvV4fFBQUFxfn5ORksVjc3Nyq
      q6vd3d1TU1M/+eSToqIiWmpasGCBv78/x3EWiwUWDOwS4Yv7Afby3/H4oT6AFkwkEkl3dzdd+rSf
      COEDqrhYyjA3s2fP/v3vf4/i+82bN7u7u5944glhkZbyzcn97SoM35gjEokkEolcLlcqlQgfli9f
      Pm7cOASqyFXDwsKCg4MzMzMJIQ6H47333vv0009hvk0m0969excvXjx+/HiW75JtbW0tLCx89NFH
      Y2JiUNI0mUxXr17NyMhwc3NjGEav1yP9FIvF3333nUgkys7OnjRp0ubNm2fOnKlUKgkhcADYVHgO
      lKtq47UTEMHRBggimMaOB0thH/yT4bn8HN9lc/To0ZqamuLi4pqaGoZh2tvbi4qKCgsLFy9ejMd+
      8+ZNZ2dnhUIxadIkGIVDhw5NmDAhKCgI2fqVK1fu3Lnz2GOP0ZWtVqvPnz8PxwyCkNVqvX79emxs
      rI+PD26Hen3sDV9fX5anmdL6MCwRbQ7AjdM+D6lUCgath4eHyWS6fft2YmKiv78/lodEImlpabl5
      82ZWVhYhZNWqVaWlpR0dHbW1tbW1tSggdXZ2VldXT5w4EY8FD/nWrVssy06fPh3xOGJtOHKO7wXj
      OM7d3f2tt95yOBxHjx4NCQlZuXIlIaS6utpisRw6dAiW1Gq1LliwADTZr7766uuvv5ZIJKtWrWJZ
      tqioyNvbOyQkpL+/v6enBzVzrDRwmmkxmbZrsXwPFHX5DE/8N5vNZWVlI0eO5DiupqbGy8srODgY
      JRZ4O1o5IAIhI5vNptPptFotKlvDw8NGo1Gv1yP8IoTgD1mWPXXqlLu7u6enZ1RUFP7EZrPBfYLH
      AaAcjhm0vc7OzmXLlnl4eHz33XfTp09XKpUc39xD26yQYd+5cwdtMagVtbS0qNXqY8eOeXt7m81m
      mUym1WqDgoLS09NB28vPz/fw8HBxcVm5cuWtW7fQefPXrg55Rm1t7SeffFJYWLhjx4709PTGxkaa
      rzz77LNhYWEff/zxvXv3XnrpJW9v77i4uJEjR8L0OxyOGzdu5OXlzZ49OyYmxmw2m83mmpqaqqoq
      lUqFIFUkEhUXF0+bNi0jI2N4ePjkyZNg2bq4uHh5eWGD478IZWig89MrBpAf7gMoXhEbG7tnz57W
      1taRI0eCKE0bZ0pKSkaMGEGDApFIpNfrk5OTIyIicnJyUlNTjx8/HhwcPGrUKJr5En5j06BYmAcw
      fI0+LCxs2bJloaGhRND0hKjw4MGDFRUVkydPNhgMAQEBbm5uhw4diouLCwoK6unpGRoa8vb2jo6O
      LikpAaoDK/nxxx+npKTI5fLi4uLz58/Hxsb29PS0t7fn5uY6HI6EhIRVq1bhk/n5+a2trRMmTCgr
      K5syZUp/fz/DMMCLYe4BleCC4+Pj7927J2ylwRktFktra2tQUBCycub+gwiyAeod8SuTyXTlyhWF
      QrFv3z44GKvV6ufnl5eXN3fuXIlEUl1dffz48XHjxoF5FRgYmJ+f39XVNXfuXJTHXV1dR44cefDg
      wSVLloCaJZVKb9y4cffu3YceemhwcHDbtm3h4eHd3d14pyzLBgcHL1y4MDg4GI9aLpe3tra+9dZb
      oI1aLJaKigpAw4QQCjFR4Esul6NJ5/Lly3/+85+ffPLJrKyso0ePFhYWbtiwgZpFhmH+/Oc/h4SE
      TJkyZc+ePY8++mhwcPCBAwfq6uoAXtlsNoPBYOOVqfBUOY7Lzc09d+7cO++8g25ekUhkNps1Gs3C
      hQthO2gJFAyC9PT069ev37hxg2GYhISETz/91G63e3p67tu374svvliyZImDL9Fv2LChr68vPj6+
      pKSkp6fHycnpo48+unjxYnR0tFgsbm9v12q1dXV1EyZMsPGCS7T3hfC+kLKw8FqRvshkskWLFh0/
      fnz79u21tbWLFi2y2WwajQYBPsdzr+ku43itjrCwsKVLl4r5DkpCSHh4eFVVFZpvzWazl5fX7du3
      z5w58+STT+IC5s2bd+PGjdjYWBC0EIqJxWIKlDU2Nubm5mZlZVmt1oyMjOjo6JqaGrRYEr5cTO0g
      +uZ6e3sp6IQ2naGhoc7OTuA5APRQzdq1a5fD4Zg9e/a3337r6+u7aNGibdu2+fv7Ez5vJgKlpr6+
      vh07dgwODu7bty8sLAxpvUgkMhgMPj4+Nptt3rx5rq6uX3zxRWFh4aJFixAtCVuFxo8fT2nZHMf5
      +fndunULJCiGYYaGhtLT01evXs2y7NSpU729vdvb23t6egAAUjKrsDmAVux+emXhH6E/AAs0JiYm
      PDz84sWLI0aMQJBL+QCXL19ev349ETT+YUFnZGTs378/Jyenr69v8eLF2DxguBMBoYKejp4LPxwa
      GjKbzZRYQmknCFGDg4NjY2NlMtnt27eRiHzzzTcbNmxwOByoarq6umZmZu7YsaOsrCwpKYkQcunS
      JaPRiPATua2npyf49dg2crkcpq2ysvJ3v/vdH/7wB61WW1xc7HA4lixZkp+fj3Z2XKGLi4uI7zpe
      sGDBiRMnCgoKZsyYgXvBZZ88efLw4cNvv/12ZGSkSCD0xv0dfRIsRIZhjh49SgjZt29fVFSUg6ed
      lJWVPf7447du3UpLS+M4bunSpVFRUadOndLpdIGBgefOnUtMTHRxcWlvb8efpKWlnTlz5sSJEw8/
      /LBUKm1ubj516tTq1asBxQJFYVl2YGDAYrEEBgaCmIRtgFvDPkG5VS6Xb9myJSIiglbd7bw8i4jv
      rcvPz798+XJnZ+f8+fNnz5598+bNAwcOeHh4HD16dOXKlWAc6vX6+fPnJycnq9VqPCWj0ahUKh96
      6KG0tDS8697e3vPnz9OaEx7O8uXLR48e3dvbK5PJUB5EPxTgbyC5LMsaDIbz58+3tLTk5eUZDIa+
      vr5JkybJZDK9Xu/t7Y0GojVr1sTFxcGsZGRkVFZWXr16FRjmRx99RAjJycm5dOmSq6vrjBkzIiIi
      9Ho9FgZNXuGWaBLgEAi02fl+eHQRLlq0aOLEiatWrert7X3hhRfEYjECAuEWoAI7FosFfXAmk6mi
      osLhcOj1+vb2dqPReO/evXPnzoHg+NJLLyEte/HFF0ePHp2TkwNcvqqqSiaTIQvEBaMHMDg4OCIi
      4sMPP/Tx8Zk0adLJkycdDseoUaPkcvmxY8cIH4LQ0JjjOH9//6VLl9KCB8Mwzc3NFy5ceOSRR6RS
      qZAihYayxMTEuLg4jUYDn223281mM/pvYGolEkl/f39ZWdno0aPd3d1feeUVNG8KLQYnUNabOHHi
      mDFj4PNYgY4eNnhPT09PT09fX59EIlEqlZWVlXaBKtfw8HBhYSHIrAzDdHR0rF27Ni4u7u7duyAa
      EUI6OjqAdyH7wQv9Idby3/b4EeaI4dH7+vrOnj17165dgYGBdHHo9frNmzd7eXnNmTOH8OEPklaO
      42bMmJGXl7du3bqVK1fOnj2bVrewyBBSEZ4XRGXU8CuUayhgIhKIKACbBsJTWlqK4G7z5s0hISEI
      DRDOcBwXFBTk4+NTU1OTnJys1+s//fTTqVOnhoaGmkym2NjY7Ozs8PBwrVZ74cKFuXPnIobFHpbJ
      ZL///e/HjBlz4sQJEd/jbrfb+/v7a2pqWJZ1dXVtaWlBoDc8PIwy9e9+97u4uDhkLXa7vampac+e
      PUFBQaGhoRRDQO5v50XfYEcogY/wtZBjx46NHDkyNDRU6IaTkpLi4+OPHDmCIC4+Pl6tVqNed+TI
      kbq6ul27dtFcG4F/cHDwzZs3V6xYwXHcF1984e7uPnHiRI7jvLy8Nm7cOGLECKPRWFJSEhcX5+vr
      S7EIWhQZPXp0VlYWbQIg/LYHyABDQLfl+fPngbNt2bJFJpMdP34cRZqEhIRXX321srJy27ZtEonE
      xcWFogd4LCzf0kFNgFgstlgs1ODifzIzM6dNm0Y/yXFceHh4ZWUlUCwqKoeGLKVSOXLkSKVS+dpr
      r+FrT506VVhYGBQUBMwaDozC6xaLBTiyw+FobW29evXq5s2bOzo6Pv3009dffx2JBdLf+vr6hoaG
      lJQUHx8fulYplM/xIj8A9FieRhwQEODu7v6Xv/xl/fr1CoWis7Ozvb3dxcVlcHCQ4/mRnZ2dx48f
      7+vrAyzW0NAQGhrq4+Pj7u7u5+cXEhIybdq07OzsoKCgyMhIu90+duxYQojNZoPnYBjm+vXrMTEx
      wILsvHLt4cOHx4wZM2LEiPnz56ekpJhMJpDccN7+/n61Wo2erK6ursHBQYCiyLYBTMFpwatZLBb4
      GJrLAqGaMmWKSCRqaWkBJjwwMFBUVPTee+8RQcmkp6enuLgY4gIxMTFY/PSFov2e8AC9SCRCGQb/
      bG9vLy4uHhwcZBgmOTm5vLz84MGDhHcYg4ODo0aNoiVolmWTkpKys7MdDodCoTh//jxWkUKhoH6i
      qKjIYDCsXr0aSNcPt5P/tscP5QXBQuE9ZWdnazSar7/+Oi8vD/SA69evS6XSd99919vbG/QMVAut
      VquLi4uTk9O4ceP27NkzadIkIcoMbgk1bYQPo6BjQxFVo9HY3d1NeNUaxKTUJeDaQFDRarWhoaHz
      5s0jhCBEZRjGYrEolcrly5fjXo4dO+bs7Ix/ymSy1tbWnJyc9PT0srKyiooKhmF8fX1NJpO3t3di
      YmJ4eHhYWBjHcQaDwWKx0CSxrKwMYY6Hh8eVK1ewZGE3t2zZ8tprr61atWr69OloeiouLh43btzz
      zz+Px0JlEvCFVDYLsTAal7AV8/PzKysr0VWLrYgnw7LsuHHjvvjii3Xr1sXExBBCOI5DE4BSqXzu
      ued8fHzsvCAadtecOXMaGxsJIbdv3+7t7V26dClO19ra2tjYqNfrUSAZOXJkZGQkkoPk5GSUkd3d
      3QGmo+sCRRrwrKCigdeBh+Pq6rpp06bx48dHRETU1dXt3r27pqbmqaeemj17NiHk17/+9TvvvLNj
      x47XX38d3h2VYb1eLxKJ5HJ5S0vL6dOni4qKYJp7enq0Wu2UKVNwdrBd4TZQMEBCWVpaSmMOSAK4
      ubmFhoauX79eLBbn5+f39PTQNbZixYq+vr7t27e//fbbYMoKw3CO4xA4FxQUfPPNN5MnT547d67N
      ZtuxY8cbb7zx4osvJiYmAoUvKyv7wx/+8MEHH8D3wItw97cLwLyCLXP8+PHvvvvuySefnD59+s6d
      O69du+bt7V1aWopVqtFo+vv78SQlEkl8fDzHcYsXL/b29kahFfAFy7KVlZW3b9/OzMxEsEIEytsI
      p27fvq1Wq6G9wfL9z1arFc+HEIIkFZxaKuOo1WoPHTqETLqlpcXGi8fBf2CT9vf3e3p64tvo6qL7
      UZjNSyQSkD6RXsTFxeHnMMFGoxH9H8z9is0cL71uMplojY2KqaDf+4MPPpgyZYrBYFi2bNnatWvX
      rVuHZeni4oJWCZvNVl9f7+fnB8URCIoAhmIYBilOZ2cnyGxGo1GtVgcGBuJ2kBk4BEpNP6XjR6gH
      YPNzHOfm5rZ+/fpp06adOnUK4NqiRYumTJkC64mG8pSUFHd3d7lcDnw2MzPz22+/RdwHJ/HSSy+N
      HDmS4bUS8dAXLlwIjR2APzAE48eP37x5s0KhoBpznGAeCKUkIgZcs2YNy7J379796KOP9Hr98uXL
      AYOOGjWKEDI0NJSZmTl27Fi0LGKHoK2RYZjw8HCj0VhTU4M8HVYeq19Ykfbx8Zk/f/7MmTNBRlap
      VM3NzZDNMRgMwcHBe/fuzc/PP3bsWGdnZ1BQ0PPPP48uYhA0OZ7zGhAQ8Ktf/So8PNwh0FJGHy86
      GwMCAt5+++2JEyfC8yH8hM946KGHwsPDQQ/lOE4qlaIwM23aNLi9jz/+OD8/f+zYsaiMhYWFRUVF
      cRwXGhr63HPPRUdHIwvx9PSsrKysqqoSi8VRUVFyuRwkS09Pz/DwcITDhEe0OF5DtKOjY//+/QEB
      AWVlZaAhEl60NTo6OiIiQiQSHTx4cNeuXUlJSe+//35UVBTubuTIkb/85S//9Kc/5ebmZmdnw2aB
      eI7VhW4juEAIYNC0w2g05uTkDAwMABqCjZBIJFqttqenx9PTc+/evQggsrKywBrEojKbzVCag/OQ
      SqWvv/56eHj46dOnMzMzoa7DsmxZWRlIYj09Pbt3766vr1+8ePHcuXNxJRs3bvzmm2/eeeed8ePH
      v/zyy4SQcePGPfzww+hoQXWaCHwAJQ7hjLW1tefOnVu1atX8+fMZhnnllVfEYvHhw4djY2PT0tLA
      s8jLy8P+QvcsNUN0eWDlwLVQCTa6d2w2m1Kp7Ovru3TpUlZW1qhRo/DufHx8RCLR+vXrVSrVvHnz
      OL7bn2VZpVKJTF0ikSxcuHDlypUeHh5DQ0N6vb6goMAumK4DqPDbb7+trKzs6+uLi4tTKpU0TSf3
      C+ThYqRSaUNDw6VLl958803kiwzDeHl57d+/32QyZWdn00SZEcw2QCmbEYgh4ofwu4ODgzNnznz0
      0UfxQsvKyhoaGrAvqPvX6XQKheKhhx5SKBS4F0RshBDsR39/f4vFsmnTJrlcPjw8LJfLly1bxgo0
      smgm+hM7fpzJ6Uj2sYCEP4ebBUxPufxiXkCNNqzS1lZsYJghiifY7p/lQpM1O6/qjlOI+KkDQhy2
      t7e3vb09OjoaNC+dTofWnnHjximVSgoRDA0NgeaI7xweHq6vrw8JCQGKSqMYGpjgfqVSaUdHR1dX
      V0pKCoALs9msUCgo3Q0ouYiXTMGXCIkQ8F4iXnKH4ZX1GF6ii4ZyFBX5v6+NfwLwAVQzwIkX68YG
      MBgM1dXV4eHhCoUCz7CwsLCtrS09PV2lUlFhXsKLl1GbAhfu5eXl4GnvhBAE13BXDsGAEQcvOdnV
      1VVSUoLnExUVFRsbS7meIIxC0gAgO21ppuqt7e3tIpEIdEO8u5aWlpSUFIvFgk4o8GvxCvr7+1Gz
      QXyHhwD3DzAKEaKzs7NWq8WriYiIAGgDQ9nf32+xWGi7AxaSVqu9ePHi2LFjw8LCCCHoT25oaEhI
      SJBKpUVFRSNGjIiPj4dDxUuRSCQFBQW9vb3Lli1zOBxGo7GwsDAhISE4OJjaDsKHujSGxel0Op3Z
      bEZp1GAwYPFAdw/rHHcXFhbm4uJCtwnLCw1Rlo5IJAJPKSoqCguJRt8Oh6OlpQVF2sjISFhSvPf6
      +vq7d++OGTMGJFcKm/T19YE/zbJsT08PNLWwqgcHB8H9F/FCe5Bu7O7udnJyio+PDw8Ppw0ZeBes
      oElCo9HU1tZGR0fX1taOHz+eel+TyVRWVqbT6dLT093c3ODSWMHkIq1WW1NTk5SUhLI04/EAACAA
      SURBVKVOf4VHOjg4SBukERYMDg4ODAzQ9YwAVCKRREdHcxynVqt7enpQjeA4Dm3hCHQgPgjdvcjI
      SOxrRCTUXv1Aa/nvdvxQH0CNOEywTqdzc3NDBESZIQicKV5BOQlCIp3QlHM8k48W1ugPadVezOsG
      Ez4XEb4h6gkIb7JhE6knR2AoTPHQbkoTWBE/QAprnWaguHJcBoBd+nPqnAhPBsUyRZWbqvTAalCm
      oJ1XmSZ8Y52N10CH/6N66BQVdXFxoQk+TufgJWjAyYOxpmRcOy/Bz/LHAzfCCYbP4AuFhTiaWtGa
      hIMnS9C9yvIK2MKFATiI3guMsl3QpANXKpPJYDU4vu7n4EmoMBB0Ddh4bVrhP2nCR88u9E+MQOZF
      iCtyAlyeCEpEREBkovUGYamDEGI0GmEfbbw+K+EDFFQOtFqtv78/MJYHlHOIYJIM1i2eD+GVNcGm
      A2EfqpxwwETAuBeWyjhB3xN+i2iMCIpJqKXBLkMsE/RlGo4gUkbsTxcVki2JRDI8PGznxwxQujbD
      T4ISln9xdrwgioPRheTgu+eQcGBL0viG3hF9udgydFfiviiShi0PVUFqVRwOBzID4dsXPn+73Y5K
      GCcobmGTMgxD6Xk4KXYxjRQfWGY/mePH8QGwZRS2g6nCK8TjI4JVQgSEB2w8PG7YUFgKGvZSw4E/
      x1sX8ari+FvYO2G4QYu0hFeNp2VMLHTCS01g9eD7hZkHegURwOK8DsGcDboTaGzu4KnE+AbkmNC6
      oi02WKa4a5GAQUhxFepXYBPp3sCKF/OzJ6lTpPUPhh9qSAjBEqe2D69GIpFgy+HpIYnGr+jlMfxg
      RTqOg9oIGqrjShjBDC88bfoQqDeiuwvxMoAdyoh14mce2Gw2nJHei40XPGD4ER+MQMYdV4IiJy7M
      brdLpVLQt1heFY7wplbEl9OppxcJSPq0jIQ/x3Kl3prjS9AOAatnWDC0khXM/sQd0VfP8mRQ+u7w
      JKnJw3unHGIawVD0D+7BYrEMDQ2BqcUKpgJQx0x/QrcMDYCEfl3Ez2xAGcDZ2ZmeGme38yO4aTqI
      jcDxEz5s98/Yot9PaTPD/BQ27Fm6j4TbhOb0YFKxPH7rEPQr4CId/HBT2mFDFxXDMzWxZykAiFIf
      FgZ92oRnkRC+m0zET4/BLdP1TPs6icDDweA48VNPiMAT/2SOH3ozDI88YmPACCIgQvBLBN1P9OnT
      DxAeR6JGHNEKtdroMEA0xAqqQ0RAF8Ov7PykLRrxifgeSBgpjsejsODw1qkJpvYI98Xxk4nocoHd
      pLk8vSN8nppRXAbmgTA8fGnnx5/SVIZaT5g87HYaYWFcCcdTDGk/EbVxdBsQwaBgmDMqt0t4zAHm
      Hg4AXyh0q3QT2vkJoA6HAxEoLCwNM22CCWL0pEI/RPhRXHi80PzAG6RDuzh+qhrHcbgj7HxcAI3E
      YSnQAEUzGHolEF6l/RaEJ/DQTGuYH/9EeAhezA8ecfA8K/b+ZhQRf/zfjcGytOqDO8UZqfURC8Yv
      U+iDE0xJIvx8Shop04AJdnN4eBi/pYNWrLwsvo2XnWBZFjQbwls0Gy+oQH0/4VNqYYRuF8wCI4TQ
      oTocx8FKUj0MusCQH+AUeHd0vXGCWXj0LVgsFnytjZ8shj9HDEftKeHTSnqFDocDYBe9crFYjDSd
      5hCUIE6XBA017Dy5ljZmwwM5HA7MDmH4KXi4ZvRAUMK6Ez/sBKudSs7hpVAAVpjC0ssgP8Wpwj9O
      PYAGfTReo0aB/gqHMNUi9w96JoKhrzRRYO7vEmD4ytIDGagw/CcCOjY9L43EKaeN8JEvDa5hLukC
      wprDNgPjjUbu9GZpRIYd67i/noFz0S/HUgMmRhvQOUEub+dV8MSCGQDYogh1Yfuou6UPk0L2AD2F
      4QzH6yDRMNzO11Ho4mZ4VIfCzRTHd/C92YQv4RDB+ED6Emn0LcxXqGcSpno2fuKQjR8CTBMRPDqG
      bxajjpxaf0IIRIcolEGdK83zhCASXWYwVbhIIFRIR4SmjdachOCDmO/ihpPgeK4nfcU2/gBFx8bP
      ghfzU+dgpIDt0DgduREREGdxSXAJrADwYXgWpo2nk9J3itvBRbJ8YYC+LOGrobcgzKEZfvwZNbJY
      mcKUwsGL8dFkgmauNJgDMkb4oRQmkwn+ngZedr4KIlwz9O5oXvtAfO0QVMhohuQQMIWEN0ttC7US
      tO+MCCBN4ZezAtkVaiuEmxGfpKbGwfPE2J9ct/AP8gEPGHqh1Wb5SiZdhfSVUytAHy5NFIRhqfAl
      PfBtjGBYI70SkWAkgPDyHDxxUxgYigUqFKyg6OoQ8NzF/Og+YWzLCdrc7Hxdjq5UmB4igD5pzkEt
      nTCu4QSAOyNArumkMNgOQgiIVdRAC+FgVgB80TBKxJfs6D+xFSkYgk9SS0o9lt1uHxoaooI5+AAr
      0N8XXq3Q1zoEAAXL49osj4QgZhe+HVwY/SHH81IIv4dpUEZdF7IKGHQHXy5CmZpWpIT4AyPA/fHA
      YWQ5XnGEPjqKMNCX7uDVAiAZRL+f4yfACL0slijAQ/pA7HxxhQgAJWp0qOsVppLCOJcVaIdQE/k3
      P0/4cITadyJISSlqhxCHrjHqkgkhCErosqePGs8BL0IY/WAlw2fQXUwTFLr2hOZSuGYIX82m9yXc
      d0KX8Nf/fWBT02co/C/1EPSZCL+fCGIj+mGhdyH3K36TnyL+Izx+nDzggePvfSfD/I3T/c0f/s+O
      B/zz//NrH1hA1F1R3IDjOIRsFK7lOI4SJ7ABKH6N/3Z0dBiNxtjYWHoxdAXTMi/LFxKJwOhrNJqm
      piaZTDZq1ChYLmTrDI+GW63WW7duRUREQADHLpgiAMYqhRQIISzLajQavV4Pggd6egk/BI3W0zge
      u7DZbFarta6uLiEhgePHyxDeRz7AxPh7+4HjhWWopSP37zpG0GImfD40/6urq9Pr9UlJSbDRGPkQ
      EBAgTHTw9NAri34lmodR+2jlR2YSgTWkTwZdtePHjwd2T4PrYcFcdZvNhkHKVBcPmuQBAQFU+RV3
      KhKJamtrh4eHMUvOJhhnTXisAxcGJ4HPaLVa/K1MJqNa4kSQ6RLe9A8PD2PwIb5ZJpNhIen1epTT
      3d3do6KiiCD2J/cbWRq40MhpmFeCw//fu3cvPj4e+AxSSQxug0QzQgR8G5pU0MqHB1tVVRUeHo5B
      NMC+4FAZAVL68/HvfPwIfcL//eNvOoB/5QX89fGAn8eyNpvNgOzFYjEm0xoMBrRNYTapSqVau3Yt
      1SkCOZ0QolQqc3JyKisrn3nmGaiTm81mh8OhUCjAr2AYBlpGZ8+eFfFkJ7lcjsRIo9EsXbo0KSkJ
      YRdtd4JFVqvV586dmz9/flBQkIMHTB2C6QKo+lKfevfu3fLy8lWrVkkkEmQndrvdaDQCS6GQvU6n
      Ax/81q1bO3bsWL58+aJFi7RaLRHUOW02G8i1whTqbz5MGro2NDRUV1fTQh/QVZgnqKja7XaTyRQV
      FZWQkEAt72effebm5oZ5MqGhoYWFhSaT6ZFHHnF2ds7NzR0YGJgxYwb4nUaj8U9/+lNiYuKiRYvO
      nj2rVqu9vLwaGxsNBgO6ZM1mc3R0dHJysp+fH8MwWq0WsS1kjt58880NGzbMnj0bT35wcFAkEnl4
      eOAZDg8Pt7S0rFmz5p133oFmVHx8/MWLF/ft2/fSSy+Fhoaq1Wp3d/eAgABQLXt7e9EwHBMTc+zY
      MbVaDYIj3rhYLO7r65szZ05KSgohpKur68CBA15eXmKxGJKfKSkpV69eZRjGaDTqdDpPT0+JRJKc
      nJyamopQoKKiAv1Tzs7Ora2tAwMDGOKGwEKlUkHJgxBSXV19+fJllH/Q8atQKOx2O6hKcKUDAwMZ
      GRlpaWlI+CoqKr788svf/OY3YPTBIRUWFl64cOGTTz7hBIUxh8NhNpuPHDmSlpaWnJzMcVxLS8tr
      r72WmZk5YcIEk8mUnJwcGhqq1+sBnP5zt+7Px490/Et9wAMHdQB/zxP8k/ID4UHRavqZgYGBPXv2
      MAyDLrZnn322sbFx7969kZGRDMO4ubktW7YsOTk5MDAQ6XNXV9fFixcbGxubm5sx6X5gYODIkSMS
      iaS2ttbb2zs2Nnby5MkqlQp5g9VqLSkpIYSMGTOGcs6Cg4M9PDyUSmVoaCjlP1gsFrQEo9Xl+vXr
      5eXlcrm8rKyM3M+hnD17dkhIiFgsLi0tLSwsFIlEcrm8oKCgv7+fxu9Tp06Nj48HrIGCh8ViycvL
      q6ysbG1tdXZ2Dg4OdnV1LSgoUKvVjY2NWq129OjRCQkJmB+LgNTBi//8vffF8IfNZjMajVZ+zL2T
      k1N/f//OnTvnz58/atSowcFB4F1msxkivXa7va2tzcXF5fnnn29ubv7666/feecduVxeWVnZ0NDw
      9ddfq9XqRx99FMqsZrPZ3d198uTJO3bsUCgU0AN3dXU9fvy4XC5/6qmnLBYL7h1iQXa7/erVq3V1
      deXl5UqlMikpSaVS5ebmQvzSaDQmJyePGTNmypQpFMrbuXNnQkLCV1995ezsvGLFiiNHjly6dMnf
      3x9TnX18fBAfiMVimUyWlpZWXV29devWHTt2JCUlYSCBsEi2Y8cOLy+vlJQUh8NhNBrr6+szMzPl
      cnlzc3NVVVV8fPyUKVNu3759/Pjx1NTUhIQEFxeXwMBAfEN5eTnLsp6enkjaINjg4uKCucfQxUQT
      DNZnUlISejArKio0Gs2YMWPc3Nx27Njh7+8/depUrVZrNpuhY2G320+fPn306NGGhoYDBw64u7uH
      h4f39/cbjcb9+/cPDQ199dVXJpMpKCgIze2EEKlU6uXlBXVlhmG+//77wMBAzJl4//33X3311aCg
      IErz/fn4jzj+N30APf7ZeNQ/iFvJX5UQNBqN0WhctWqV1Wq9cOFCV1eXwWAICgp65JFHMLX8ASjc
      09Nz7ty5ra2tf/7zn1mWffXVVzEB49ixY9evX1+5cmV0dHRgYKCwtmmxWFavXj1p0iSWZbu7u9va
      2lJSUmgiD/YO4kcfH5/ExES5XK7T6To6OlasWDFr1iyz2Wyz2cBRkUgkRqMRknYOh8PDwyM+Pl4i
      kUgkknPnzmG2pZOTU05OTltbG1rzaV2XYZj09PS0tLQ9e/bcvn376aeffuKJJ2w2m8lk2rhx46RJ
      kyA3L+aVnxHI/wOHSnFwkUgUGxsbFRUldK6HDh2KjY3dsGGDj48P4VsoWJ6Mr9Fotm/fPjw8XFBQ
      MDg4ePny5Y8//jg5Ofm7777r7e2dOXNmamqqu7s7x3EojdhsthkzZojF4sDAQGhgMAzj6urq6enp
      6emp0WgwUZbyWNLT06dOnfrBBx8UFBRs3br1oYceggQQlDBWr16NR4qYd9u2bQqFYsuWLbt37y4r
      K5s4ceLXX3+dnp7++OOP79y5UyaTLVu2DDG+TCbr7e3Fgunt7a2srMzKyoqJiRFW7FmW3b9/P52M
      aLVaNRpNSUmJ1WqFqEZAQIDZbIYwhpubm06nI4SgVw4PBANvEV+DwAPlOIZhPDw8Kisrq6urX3/9
      dfyV2WyurKzEBwYHB41Go9Fo1Gq1GPve09OTkZHh4eHBcZxcLvf19W1tbZ08efL06dOtViuSMCQN
      CQkJY8eO7evr8/HxQRbY1NR09uzZ4uJinU43ffr0K1euuLm5ffXVVwzDXLp0acaMGdnZ2ZxAbPkH
      beCfj3/V8U/xAf9NhOefFyz8N7+Zgv4PYEGurq5QHi8vL0fXeGRkJJ0lKaS7YCNhmGpLSwuGtCCW
      7O3tXbBgwfTp03E9tDLc09MDpXh8Q3l5eXl5eWRkJCJWlh9FgqAvKSkJmM+RI0dGjBixdu1a5Pig
      8QG4wFWhWSY0NDQ8PJwQcuvWLaVSuXr16pSUFLvdfvfuXciwtLe3X716NTs7G4UBLy8vjuOWL1/e
      19c3PDwMUa2bN296eHhAw5LWS4jAZf6DPABpB+XjUr6NWq1+7rnntm/fDgcAfSRhca+trQ3UzJyc
      nPj4+A0bNjQ2Nra3t7/55purVq2CPd25c+eIESOmT59Or2Hy5MksyzY0NJw8ebK+vr6oqGjJkiVf
      ffVVX1+fn5/f2rVr0WbhcDgQ+T788MOYNYis7u7du97e3o8//jiuCkd/f398fPy4ceMYhnnkkUdG
      jhxZVlYml8unTJnCsuzUqVMxkpCqZKvV6u+///6ZZ5558803HQLZc7pOCK86Rwu8aWlp69atI4S0
      tbXl5eUNDAxUVlZardbHHnsMUzm7u7sTExM9PDwwB3HMmDF4Yq6urnFxcSEhIRkZGZgRzbJsVFRU
      R0cHLn54ePjUqVPnz59fs2YNQv7Ozk4svIGBgerq6pqaGovFsmzZMhQJwsPDAwMD586dm5iYSCcW
      tLS0QPkxJCSECCpADQ0NR44cGRgYgA5HY2OjSCR699137Xb7d999N2bMmN/+9rcjR47Mzs5GHeu/
      tVd/Pv63j3+LPODHOv5/nQonkKKlpUuWZ/RDD87T07O5ufnDDz/88ssvIZ4MiGPcuHEvvPCCs7Nz
      Tk6ORqOB9nJtbe3WrVuTk5Pv3bt34sSJGTNmHD58GAK2c+bMQc99a2treHg4/p9hmGFe75q5n3rE
      MAxqwg6H4+7dux988EFiYuJ3332HLe3q6ooJqAsXLkxMTLQJZvYSQurr63fv3p2QkJCQkEB4Sh/0
      thoaGrZu3Tpz5kyZTNbQ0HDu3DlUKSsqKj788MMpU6ZYLJajR496enoeOHAAgPKoUaMyMzOpeiJV
      Nv7rg9JaaEIAYklnZ+eWLVt0Ot3w8PBnn33m4eGxePFi9n62KOy+Tqfz8vLCjT/xxBMHDx4sLy/X
      6/WDg4O1tbW3b9+OjIwkhPT39+fm5ur1+ri4uNTU1MjIyBdeeOGbb76BTi0hpLa29tq1a6Bp2e32
      GzduQO4J9dstW7YsWrTIZDIdPHiQYZj8/HwgeCkpKRMnTvT09Fy8ePGtW7f27t0LAe3Kysry8vKW
      lhYnJyeFQqHX63t6embOnInWNuB7YG21tbVR/g+INMHBwXiblOvi4uJy8uTJqqoqLy+vtrY2b2/v
      rKwsuVyekpLS1dUlkUjGjx9/7949LEthJy0hxGq14gIAAdHSt1wud/AU4d7e3vT09MWLFzc1NVVU
      VMyaNQuVW6BwOTk56CRHWfjq1auJiYlSqfTQoUNTpkzZv3//+fPn+/v779y509DQADVDQsiqVatm
      zpyZlZWVlZV18uTJKVOmyGSyTz/9tLi4WCQS3bx5k2GY1NTUtra248ePT506lV72/2gf/3z8S4//
      5XrA/y5uSFl0+CdlwhBCAKnDEFut1tTU1IyMDG9v7507d7q6ui5ZssTb2xsBbEBAgJOTk7+/f2Rk
      JGYPOByOtLS09PR09CXSUhus/MWLFyGxAmi+rKwM2py+vr4AAaxW66hRo4KCgsA/qaqq+tWvfiWV
      StevX48BGigD6HS6EydO9PT0OPiRikNDQ3fu3MnLy6uqqsrIyHjmmWfsdntra2tAQEBgYOCZM2fa
      29uvX7/+yiuvuLu743vCw8PRzgYxNSTyAQEBPj4+VqsVmD5V3EWO/w94QZRHSAjBKAWxWNzW1rZ1
      69aUlJSlS5fiRO+++25ZWdkrr7yCGVU4b0NDw65du8aPHx8cHNzc3NzT07Nhw4Y5c+b09PT88Y9/
      xGiqxYsXz5o1C1cSFRV18uTJvr6+5ORknU5ns9nKyspiY2NZfoyJ1Wrt6OiAln1wcLDBYEA28Nvf
      /tbhcEC69cUXXxTzSg8eHh6oHgNrCgkJmTNnDjoZ5XK5RCKZPHlycHAwVGhg/Rm+tw51VJZld+7c
      abfbw8PD0V43NDS0YMEC6NLAQyOHeOaZZ1paWhQKRXh4OERpwMtqaWmBhB/tG2BZ9vHHH7fZbD09
      PZCfcnJyQgrixAteqlQqvBqwd4KDgysqKvLy8mpra0tLS9va2jw8PDQaTX5+fkdHR0VFBQY64U2d
      PXtWqVQajcbq6urY2Fjko+fOnUtJSZkxYwauwWq1xsfHIzpB8pGfnz9u3LiYmJjExMSJEyfu27ev
      vLz8pZdeMhqNSBS8vLx+dgD/Kce/mhf0QIbI/FWjxwOf/1HO+/e+n+H57ITPAAivnoaedcrPSUtL
      W7BgAcdxt2/fViqV8+fPJ7wawYQJExiGOXLkSHNzM6ZpY59DrSwwMHDWrFnu7u4ML2o0YsQIkUik
      1WoHBwfNZjNkkNvb26Exx7KsVqsFcM+ybGNj49atW5VKZXR0dEVFRUxMDK3N4hZgjHAxQ0ND3377
      rcPhePPNNyF7WVdX99577/3yl7+cN29efHy83W7PzMykomzR0dExMTH19fVXr14FUoG4EuJZFotl
      5syZMTExLN+8Rm/h7z1nVqBXA6Z8SUnJli1bxo8fv27dupKSEp1ON3r06A8++OCFF17YuHHjr371
      K5VKBaE9kUjU2dkpFos9PT17enoGBwdBH5o2bRrm5KBPG2bXzc1t3LhxfX19bW1ttK4L233w4EGQ
      +js6OoqKisRicWRkJEbj1tTU3LhxA6V+nU7HsizaIDiOmzRpEpSoYX8vXbrU0dEBsUyZTAaKand3
      d2Njo9VqhUO6d+/epEmTvL29QXyCQp+bm9ucOXNGjx4NltfJkyeh3Y3/EkL0en1RUZGTk1NYWFhR
      UVFERIRGowFNCykCx3EGg4EqMGq12mvXrgERMhgM0JjDtEuj0ehwOGQyWVNTU3BwsLe3N57PihUr
      CgsLJRJJamrq3bt37927t2TJkqeffloul2u12okTJ0JXHEFDREREf3//6dOnS0tLXVxcHn744fT0
      9KKiooyMjIyMDGEvAro0Ojs7i4uLIT9ns9kMBgMcA3WlOp0OPf8/bU79T+n4l/qAv2mL/6nZgJCi
      /tcH91dyYPQnIpGov78fYgZ6vR6kCELI8PAwaPWIo0X8hKwdO3ZMnjzZ39+/v78fp8PUw507dwYH
      B0+cOBEl0KGhoezs7OzsbL1er9fr/f39IyIibt++vW7duq6uLqlUiqCb9uBs377dz89v06ZNn332
      WV1dHeEV6ECsbG9vHz9+PK4Wpi0jI0Mul9fU1FRWVjo7O9fX11dUVBw8eDA2NtbZ2Rn8Qjc3tylT
      pmCQiM1my8/PLy4ujoyMlMlk1GBJpdKCggJCCJ1DwPC9xOSvfKfwtYJ/CZWb/fv3Hz16dMGCBcC+
      oU7DcVxgYOCePXt+/etfv/rqq2+88QamnhFCXFxc1Gq1UqmErL+Pj09eXl5jY2N8fHxbW9uhQ4cs
      FstTTz3l4+NDFTRtNptSqRw9ejRyNcStaACGCUMyh+s/evSoWq2GICj4VAMDAzabraGhwWKxUDVQ
      sVjs5+eH5gMIEkRGRsbGxgJSLykpycjI8PHxcXFxQYmFShgplUqFQoEBy5hjDG1ajuMwwoXjOD8/
      v7lz5xYXF8+YMeP48ePp6ekPP/ywVqs9c+aMWCxGG4eHhwda0zEQzcfHR6FQmM1mNzc3Z2fnkydP
      EkKioqKUSqVIJILwuJubm0gkslqtXV1dTU1Nvr6+sNc6nS40NDQsLMxsNvf29qKZubq6WqfTRURE
      ODs7v/7663a7vaysTKVSzZ8/39PTs6urS6/X37p1q6urq7e3t6qq6sknnwR/ITc394svvpDJZK+8
      8kpsbOzly5cdDge4qkNDQ729vWjvaGhoCAwM/Aexws/Hv9XxH1kPeAC9+SEHNWS0lUYsFqvV6gMH
      DgwNDQ0MDJjN5tra2vj4eMLbPqqAbePnpDMMEx0dvXbtWqrBS8mdarWalp05jqMCBvv371er1Zs3
      b4Z0gVqtzs3Nraure/7559ECZrFYpFLpk08+GRkZKZVKFQpFWlpaamqqyWTCSACGYQ4fPgwVFKoB
      EBwcrNfrJRLJwMAA5ndjALpSqdTr9X5+fgAuaMsxRr6sXr06LS2NNqYCVg4NDe3u7qa5EQJVwOv0
      hw88Q47vbpVIJPv377906dJLL700c+ZM/EoqlbK89oZcLn/77bc/+uijnJyc5ORkaBkplcrFixer
      VKrGxsbTp0/39fXJZLKampr9+/cXFhbK5fK5c+f6+PhQoQVwhGAld+/eDcojwwspDw8PL1q0CKR4
      fNjX13fq1KnwmkKtgvPnz8NzQOYT0IdUKoXDwMgKCLKCCert7e3n5wc9Z8IPcIdT1Gg0arXa19cX
      K6e/vz80NJS5v0lNr9ejVuTq6nrz5s2goKDAwMCkpKR79+7B4TEM4+/vT9syxo4de+vWLTw0lO6h
      hY42XSDv4A7Aq2k0moGBgXv37uXl5aWlpc2YMaOxsbGsrOzChQvz5s1TqVRo8oqOjiZ88cbhcGBQ
      gUqlioyMfPfdd7u6upycnCorKw8ePGjj1bFCQ0NXrFgBNWlUoYeGhs6dO3fo0CGJRDJy5EhgidXV
      1WPGjAGL9+fj3//4t/AB/2MKwT8O8/+f388IWsYZgWaRs7Mzgk2z2Tw0NFRSUoKxfA+0j1P2t1wu
      b2xsPHv2LCh3iMhYfnQRPgZLAWNdUFBw6dKlNWvWAE1yOBxKpXLGjBklJSWff/75q6++iqkDHMel
      pKSIRCK9Xq/Vas+fP69Wq5GIQFi4rKwMnWgcLwOXmZlJCCkoKJBKpRMnTgwODr527VpaWppKpdqz
      Z09SUlJERAS9U4fD4eLiYjQaL168iG+m0LZEIjl79mxsbCwlOKKg+oBiB62g0BdBH/XMmTOnTp0a
      EhJClR5oIz6gD1dX1xdeeAHtsoQQd3f3rq6u06dPR0dHt7S0oMxus9lu3rwZFxf3xBNPAMWG86Nq
      Ue7u7gaDQS6Xnz59eu7cuePGjYPJHhwc3LVrV2JiYnBwMOGJOkNDQxcuXGhqaqKvDzdy586d6Oho
      KlYIWf/GxsampqYTJ05EREQgLQBjR6fTNTc3azQaiUQil8th+imX18/P7/r1vy7gNAAAIABJREFU
      6x0dHUjUbDYbeP2EF+tGhbyvrw9tXG5ubgqFAi6wtLQUw+lyc3OTk5NlMhlWTm1t7aFDhzC15s6d
      OwEBAZMmTcLw6oyMDLPZ/Pnnn/v6+mI4TExMTHJycktLy+HDh8Vi8apVq+Lj4zs7OwsKCqZOnfqL
      X/wC2Z6YFwTct28f0Mi7d+/C7o8dO7azs9Nms2EY9ZIlS5AE2Gy26Ohof3//nJwcs9kcGRm5YsUK
      uVxeVFQUFRWF/GnVqlWDg4OEEDr853+2r38+/pXHv+4l/QPc/wcePyQt4Hh5A8oIkslk06dPz8zM
      dHJyMplMe/bs4TgOdBSKbzL8ATtiMBgCAwMnTJgQEhJi41VqMcqqqKgIRHIHLzZ569atjz/+ODU1
      FQVkDw8Pu91utVpDQ0NffPHF9957b//+/WvWrKEa2oQ3HwEBATBGDMMoFAqj0djc3GznhYsh8cZx
      3I0bNw4dOjRnzhzaPAzOpZub2yeffLJkyRJMZmf5sQqenp4+Pj7Tp0+HOQOTx8PDw2QyabVahlfz
      JoRUV1ffvHlz4sSJKpWKCIQw6fOnDXd2ux1zUah0FxUsY/jxOPBAmLfMcZzRaETMC8N9+vRpEFdW
      rVr17LPPEkJsNtuBAwdcXV0XLFiALm4vL6+rV69++umnK1ascHNzS0xMhGQCIQRvxC6YRUU5vunp
      6TSTo/dLVb7xealUioro+++/39bWtnTpUpBH79275+HhMX/+fNC6cOAVDA0N2e32pUuXDg4OwlM6
      OTnJ5XJwB8AYRu7V1NTU2dn5zTffNDU1LV26NDk5uaam5vjx42FhYStWrHA4HE1NTVevXg0MDFSp
      VCDweHl5ZWVlDQ8P19XVhYWFjRo1qrOz02w2p6enOzk5ffvtt+CeonWAEBIUFPTwww9bLJbLly9j
      Zm93d/emTZuQ/8FjiUQijF7x9fX18vIKCAhYsmQJ3lpzc/ORI0cUCkVPTw8owpB7YnmdbeipyOXy
      pqamvXv3rl69OigoaPv27d7e3ijacz9Fnf2f6vEv8gH/u/yfv3dQEIPqYYE6gmGthJCKiooTJ06s
      X7+ecmMQ4BNejwX8Cicnp4GBgTt37vT29lKLD6RIrVZTPV5nZ+fa2tr3339/4sSJzz777NDQUH9/
      f21trcFgwLehheqtt96Kj49PT08nvA4o2Edjx44dOXIkIQQxptFovHv3Lp0Wgqv6/vvvgQDMmjUL
      lWexWNzf3x8eHo6uqM8++0wmk0HZRiwWIwKtra3FQC6wU0Qikbe39507dyCGQelAGo3mzJkzLi4u
      ERERnGCU2APZmEOg2wPUHrkRJDcIP2+HPhZkCcDTw8LCXF1d6UQBvV7f1tZWX19vMpnMZvPp06eX
      L19OubO1tbV5eXkzZ87ETMpz584ZDAatViuVSsElnTt3Lkw83pFerx8YGCB8izUuWCwWYzg7TXeA
      ZcHqPf3002+//XZOTs6TTz6Jai24kg7B2ABaRUDDmr+/P8uPl4E4h9VqbWtrCw8PZ1kWrNbXXnsN
      VP2rV68idQgMDExLS4Mc3uzZs8+ePdvU1ATRC0KISDCTAwIeSAfBrzUYDCiYA6/r7u5mGCYiIqKi
      oqKkpAStBmFhYadOnbpz586ECRNA/uE4ztvb+5FHHiGE3Lt3786dO25ubrj99PR0Z2dnVOyRSBGe
      9IWp8QzDYFzasWPHwsPD582bxzBMdnb2l19+qdPpMjIygoKCfs4D/lOOf8VL+vd0ADhoDEsRHuHg
      qurq6kmTJmVnZzt4+c+QkBDEjLTSCHMwNDR0/fp1b29vzPmiJmBgYAC2Ep1fDMOsX78+IyNDLBbf
      uXOnsrKyo6MD8C5wiTFjxrz00ks0ZqTdRi4uLigDODs76/X6M2fODAwMWK1WBG7wAVqtVqvVTp48
      eeXKlRqN5ty5c6jO+fn54WJWrVqFumtycjKMC0xJa2trfn4+xYhAiKysrATHkc57GTFixNixY9E3
      RGvC9KAsT9o9R60kPhAXF+ft7Y17oX8i5oeCyeXyuLg40Nuh6KBQKOLj42/cuJGbm+vq6trb24tO
      BYZXMw0NDd24ceP8+fNhm8rKymjWMjAwoNfrGX7wAC1+VFVVaTQaGvLj2ba2tgKxoQpOSKpsNhvq
      n7gk8GGUSqVSqWQEg4AgeoHcgvBydfDcVVVVFy9ehIdISUmBMNGIESMmT548Y8aMqKio4uLiY8eO
      BQcHOzk5VVdXazQaQPyo3uM6Ic/AMIyTk5O7uzsGfAYGBgI+un37dlhYGAUhq6urjx49iqWi1+vn
      zZs3fvx4Pz8/vV7f2Nh45cqVjz76KD09HSsBKBYhhOW1sulbGzNmzK5duzZv3nzp0qX58+dj9TY3
      N1+4cAFu+8iRI+Xl5VOnTl24cCFe+qOPPqpSqY4fP15bW/v0008LU6Wfj3/n41/B0Ken+CdhQX99
      Inr8d84oLAvTZiv8xGg0Ai0R8SOo2tvbxWIx1reIV+UViUSXL18eMWIE2IR0mp3FYqmrq4uMjJTL
      5SzLgm+KkzocDq1Wq1arwV6HlBDDS4SCkkgnLHIc19ra6uXlhfnG4GBotVq5XB4REeHgZePAiUSI
      p9Ppqqur9Xp9SEgIYH07PxkKZl3Mj2fq6+sbGhoCikUfFwZ/OxyO6OhoBz+/G43TiA0RXxOe9k7+
      zlu28zLILMtWV1f7+PjAhDl4+XtaYHA4HGq1OiQkxGg09vT0uLq6+vn54WYtFgvuDjwZqtUK1Whk
      YwUFBfHx8eifwF81NjaiHk5nK6ItCxacPhC73d7R0SGRSPBJwuc9GHQl5kcsdHd3V1VVOTk5BQcH
      h4eHGwwGZ2dn9Fr39fV1d3dHRUUBc+P4QaQAW+7cucNxnJeXV1xcHHIRkUiE8jgyRUQJVqsVSQDq
      Q2Kx2M3NDTV8k8nU3d2tUqlEIpFGowGAZjAYGIbp7u7u7Oz08fEJCwtDrqPVaq9cuRIYGOjr6yuX
      yz09PWn1mxBiMpkaGxsHBwfHjRvH8YPzRCKRwWDo7u4ODw+HmixditXV1RzHgVRGCNFoNLdv31ap
      VO7u7ni8KpWK4cX68Zy7uroqKyvHjRsnk8l+hoP+I46fiA/4e3fxj8/ICdSMHQKhHrtgVjBMsIif
      XovNQKf12vlxTiLBEAxh6Rh/DiAIlJ7/w953h0dV5f2fe6fXZEjvJIReBRQFpQtLEVmx7LrWdV23
      6JbX9f09bnX1ddW1rrruu9bVF/vKWkBAlBYEaaEkFAkhCSSkt8n0dn9/fJ77fQ4zk2FSScL9/MEz
      TO6ce+6553x78cuNfJnMeEAKqbUZaDEV7BXl1qlgUSS7CXKCG5rBooEJNWbg414gh1Kl+KDcHgTS
      X5BrQMjkahn4BuSAsm19cltakvRZRGwoEOJqxai4qu6MMSpuGpRrX/N+hRDX1ZKaFJKGAXITDAbJ
      fE85yfh5kCudTR5+ldwhjgoY8NYqAjX8wmdBThNRc/18BDkwDK8DtnV+2SFKk1mGf3xULsL+CXGt
      k1RyW2Mq4o1ngS+H+rEE5f4Q1OWGFKyA3E+CngtLSm8ZeV5msxkpFIwx2HMkuYUOpX1QTemA3MgM
      M8f35M5Rc20qmNz1jwxWooy+lvkU9Ar6lgfQ4EQvujFI1F/FKfLHfrrYfw2j4+efaMxxeOFX4npc
      kBwdkFuaRD5LV+8e9ee8m66zAekCECzQ39iDxzPPGD8J8yVE+pn5b2KPH8mWemtv8/Pnpxr5XHRf
      mkOIa1YV+y70mgQZ/Jdhd+nSgQrJ3a8kGYIcARH1ejGix5bE1dSKHwoPGBS4qHlAP4CnFLx+wP9V
      kA3TkWeMJ4WdfdONmYSNECnXE6Xo0i26AZ7SCeemnvGTjHMmPdlmXUXY+tB/Sbej77u0kl19hDj3
      QzfWM+qL6BIUHjAooPCA6HeMOn435PF4xok9cjfuy/8WH85LIMKIb5gc3btiddQZ8ugL+b0vxqe7
      RC5UVNWh7+6oQEG3oQRvRUHUQ9vDk8yf1TBdnpeCo96XpyldOvxxzjmM+kfavi64OtU99MO0+UUL
      +5L/b/wz6Yzd9kQUUKAgBhQe0IeIwUui8oDOxolqTe5FosDbMSKn18/ozODeP7aprqKzV9CNBYz9
      NsNU6qgXxL5dpG0nhp7UPVucgsEIhQdEQdTj0UMaJMl+4KhC/XlvEXny42EAcSoN/HyinnmFEHQJ
      3bOk9/XyRmon8VypvPQhD4UHREHUfd9tZ0ZUEhB5zEgAj20ij0eOi3GXsNE6+0lUf0A/I36aFXZN
      /9hMYuhh3bMFxTN50gjj9IcpUHBeXNQ84Ly6Mx8q05O7UBBeJIWNQdNji2MxphTpc47620irSzx3
      OS//OO98+O+79FydIWwlz0tzu3qLGLb+eG7Hzkff+XWIcWW3xfPuWdUGhS1OQc/RT46mzowJPRFn
      4qHR8ctfvTix844Wz2x78XadjXbeyzqzicUzeLcnFj+Fimeo844T/8457/jdXoeezEGBgh5icCdz
      x5bQlTgKBb0IZTspGJIYrDxgEAUvDuS59Qq6FIE6hDHkH1DBkER/8ADlbHQDfb1oMeJWBz56cZ6D
      eh0UKOg5+tYn3LtnKZ4A6qFkMO12WE5nlut4ohUHsuuvj0hz94aNvYb4MGBXUoECQh/ygP5kAGGX
      DZyzN6DEzL4z2sSZoDQ0ED8H7bZ/W4GCfsNFHRvaVXT1rHaWZ9DVcXrlvr2Izh4hznj52IPEGGeg
      oRuvUoGCgYbB6hOOjQFyMgfINPoH8dhGhgDO+yxD6WEVXAzoEx5Akfs9vKaHc4j/yniijHprtv1M
      I/pinXtlQIkrTNQrI/f1juoezpvtpUDBhUWf8IAeJtYqUDBg0aX6HAoUDHxcGFvQYJHXBjuG5EPF
      Rn8+cgz/R5zVmRQouODopx4yXUL3kv4V9AUG9bvoSQWR8w4Yj5Gns5oQvTIBBQp6Bf0XFxR/4Plg
      oTKDmj4q6CHiLBXHX6NsDwUDEP1kCxp6u78X60srGMJQtoSCAY6hGRuqQEH/ozNTj8IGFAxk9CsP
      GBTawKCYZGwMukcYsAGsPLpasr93765AQR+hzxMd+TDw/heI+u6+ve5vHIDoLYdHX7/9zsbv3XcU
      /2r09d5QFAsFvYghbgsamKdFkHGhJ9J/6IfyFX06vgIFQxX9UfCEVAFRjM5y4p/DeQuT9WlcdmeD
      dzXmL3YEYTdGCEPf1Rfq4ZL2sDdhPHE4fTe+wmYUDEkMiJpxMWholw5e2MX9VtKrtyhjjHH605zV
      R4h8O90eIZ7Y/O6NP5RMeQoUxIP+swXFcyYVUavfMKiXuu8mP6iXRYGCbmDA+QMi7SSKaMZ6ex2G
      AKVT2IACBb2C/uAByqFSoECBgoGJAacHREVPQhL7AT2/UZxi/qBWifonCnmwDKtAwQBB/8UFDTQg
      biSqjjIQJtylifU80KhX0I1QnAE1/sDHRf74CvoCg0MP6AvgOA0Ech8VvRUv259QkgAUKBh0uHh5
      gAIFChQoUHzCA1oVGLBzU6BAwdBAP+kBChtQoECBggGI/ssTHjhJmFFLPgwcf2M3KhwMkM6FPe+T
      dWHHV6DgIsTAqhURhr446jHqSXS7vGVv1aXpNvXvXp2iXp8P/8M+JdP9LE/01rqd93q+yG6McTob
      ttfnOUCkIgV9CsUnPFACK7uHwTVbBQoUDDRcSB5w3hLKAoe+m0aXyGgoFAoGg4IgBINB+GxJJg2F
      QiTHhUIhxlgwGMQHxlggEMA3uDIUCtFz8SPQXfCZPtBvcWv8hB8h9kJhqpghzdzv95PqEyb60S36
      reheDFm1H/ZAbHR1Hfj3SG+cMSYIAl4BHgeLzI8f+Yx0Gf5EI9NPsJFocLoG92XytuRvRNfjGtoY
      NDLdLmzTKgLHkISiB3QBwWBQpVKp1WpJktRqtSiK/GkXRTGMGahUKvzV5/Op1WocV/yrUqkCgUAg
      EMBRRFVtDBgIBDAUrhRF0e/3M5kahkIhtVpN5BuQOESdOX4riiJujW80Go0gCDjn+BOYliAIanW/
      GgkvLImPE/FTQLxHovv0DWNMpVLRPmGc+ZF//DCeh5eOrYLfBoNBnn/QNfwuAgvHXsJbpg1Ad1ep
      VMFgkPYbLxBgfLVa7fP5VCqV3+/H4AobGHroV7tq5L3iP/m9Nc/IO8Y/MkQkHCeipIFAABSTjiWo
      Nog+Th39Ft/gSpxVURQxAmgx/Ypuir+C/YCOYASVStXVNcGvSBqludGtGSdpEqnqHnXuu/fVu+N3
      CUJ8ZkPS0pgsZeNl0fXBYJDnsvywYS4BxvF++pc4BL8N6K80IG1XvGhBEHw+n1arxY4Cl8I0/H6/
      RqOhzckYw7CYJ91Fikit78kOUTBAMDh4QC9Osic8IOy3ODmQnTUaDb70er0ajUaSJJBs8AMwDOIN
      vNSGD16vV6fTEeEAIcZ/SawLmwDONpNpRJhawF9Mf+IlRMZRDV6hYedSkKgrdl707qbqySvrXcTJ
      A0iHY7KCFcm8eSmeBg9jAGDDYe+LlAxRFLEB/H4/hBJSNQKBAO5CVJ4IOpPNRxgZ4gh+wnMXQbYE
      0n/piRi3QyLXRMGgQ3/YgmKbKfrih30ESTb0Q3DWaDTQlDUaTW1tbXV1NWMMhhqVSuXz+URRxAWM
      MXwGq7Db7U1NTZIk4ZpQKKTT6Xw+H84k6eYqlaq1tdXn8zHGBEHw+/3V1dW4AOc5UlqMBD/zQCAQ
      JsqReEi0JlLW69L69MX7kiLQu+N3D5HT4GeoUqlgaSHrPBQ+3qlDn2koIri87M8Yw4tjjIVCIa/X
      i6FEUayrq6utrVWr1dAj8Sq9Xi+0PUEQ1Gq1x+PBdvV4PKdPn/b5fOAZmBgUAkmSsJ0kSfL7/a2t
      rV6vF7fo6OioqalhjMEgOaBegYJeQZ/zgNjbZXBtJtLHoSBLkgTN2ufzffXVV59//jmOOkn0+K8k
      N9Ek81FHR8eWLVugmDNZPNdqtZIkVVZW7t27F3IcY8zhcLzxxhs+n8/n823btu3EiRMwKIO+hK0e
      fz7DqDyTaQ1E0UAgQLIkmbBgsoDxl5SMfkAkxxrgiE0EIXFjeQOBgN/v5/1DWF74ionv8g/OrwbJ
      HPDceL1eyOySJOn1er/fv2bNmq1bt4KXgJobDAadTuf3+3FxMBjU6/UY7eTJk3v27FGpVDqdjqyU
      UGErKir27NnDGBNFUaPRnDp16p133oG8snbt2uPHj/NMYnCdWQXnRX+7/qJuoMGyq8hxCqrt9/vb
      2tpAlO12uyAIHo8HYnsgEIBFyGQyabXa0tLSl156qbq62mq1ulwur9d7+vTpt956KzU11ev12u32
      vLy8e+65Z8KECQaDYfXq1TU1NUuXLn3jjTe8Xu+///3vuro6rVa7cePGKVOmtLa2jh07duzYsbwB
      hz+ZYUYGfm1BmwKBgF6vJzsyGYtBm2CqYlzASSQGy/vqBwjnGtz4FxEMBrVaLVipVqsl+ztRdnwg
      J03kqoJhQKtgMgtxOp12u91sNjscDofDkZKS4vV6HQ4H4g4gHOh0OpPJVFpa+uyzz9bX11ssFlEU
      z5496/V63377bY1GI4qix+NJTk7+/e9/P3z4cKfT+c4777S3t0+dOvWTTz45derUli1bTp8+7ff7
      v/zyy+9+97tnzpxZsmRJampq2CQHC9tWEAN97g8Is1dccPIRuWvjnxIYAI6ZSqUqLS196KGHcIwP
      HjyYnZ2dnJwMec1gMLhcLo1Gc8899yxfvtzhcBw/fry5udlisahUqrKysgMHDixfvhwENxAIWK3W
      goKCxMRExtiBAwfefvvtu+66q62tTRAEl8v1j3/8Izk5+Y477vD5fEajMTs7OzExEXoDzY2iUHiq
      FLb4wWAQrj9BEGpra0+dOsUY02q1CQkJI0aM0Gg0Ho8HlAt+DvI3dHvF4lzVPhq51xG5gcNWGyK/
      z+czmUySJIHZ19XVGY3GYDCYnp6enZ1NOiJ2EfFgGpO/Bf8Z2ufOnTtff/315uZmr9dbUVGRnp6e
      lJQEG45Go3E4HKIoPvDAAwsWLGhtba2srOzo6AgEAikpKQcPHty7d++KFStMJpNarXa5XMOGDRs+
      fLjVahUEoaioaPv27YsWLYIxMxQK/eEPf5g+ffrSpUuNRqPb7S4oKEhLS6OoNoX6Dxn0kx4wMM92
      V2dFAaAQovPy8v71r3/pdLrGxsZ77rnn73//O3gAY4xcAqAFZrM5Ozu7ubn57NmzWq3W4XCo1eqz
      Z88mJyfb7XbG2NSpU81mM47xJZdckpSUlJ6e3tzc/MUXXwSDwZSUlJSUlJaWlrq6usmTJ6ekpJA/
      GVYj8BKS3/kwPrJfgeJ4vV69Xn/o0KE//elPVVVVeXl5TU1NjLEHH3xw2bJler3e6/VKkuTxeKDH
      RBoreoK+FgL6evwwnsoH+8OSBsM9jC2BQGD16tVvvfUW5HePx5OXl/fEE09kZWXBS0Q/h5jPa3Kk
      ovF2JAQUzJw5c/r06Tqdrqio6N133/31r389evRoh8NB41Cgms1mCwQCu3fvhr+no6PDZDLB1u/z
      +YLB4JQpUxISEmCTvPLKK0eOHGmz2erq6rZv3+7z+QoKCpKSkhwOR3Fx8dy5c9PT091ut0ajwWaT
      OLe2wg8GNQZErYjBAjKpw+ZrsVhAtb/99tvLL788KSnJaDSCBOt0OkEQSFSHK0+r1YIc5Obmjho1
      qqOjw+FwMMbS0tLsdjvEMY/H4/f7s7KyVCrVoUOHdu3atWjRomuuucZgMHR0dGzYsCEQCEydOhWj
      wZhL/j2IohR8AkGePNIdHR0qlcpoNDY3Nz/++ONZWVmvvvoqAsA/+uijF198MRgMLlq0SKfTwesI
      pYH1tr4/GNlAZ2PyLhMwAHyAzWfTpk3//ve/f/zjHy9ZssTn8zU0NDz77LOPPPLIX//614SEBFjk
      PB4PGeXw+sBRiMfTgIwx2JFUKpXBYABNHz9+/OjRoyFk8LTY7/f7/X6dThcMBk0mkyAITqczNTV1
      ypQp9fX1iEGAvM8Y02q17e3tarU6PT2dMbZ3796qqqqxY8def/31fr8/OTn5iSeekCRp8uTJyIlR
      KP4QQ3/7A6J+PzC1hEgQtaXYO9hMvvzyy5aWlv3790PHBw31er2jR48uLCyE0zU3N3f9+vUGg8Fk
      Mnk8Hrvdnp6e7vV6Q6GQ3W43mUwYv7S09NChQ99+++2DDz5otVrBRSRJampqUqlUZrOZ6AIlGTDG
      EA3CGEOIiCRJbrdbEASNRgO3JMwIRqPR6XT+4Q9/YIz95S9/sVgsoDi333673W5fvXp1cnLyzJkz
      QXS0Wm3U9xVD7hss77EzdIm6SZIErw/9VxRFxOHo9frDhw+//vrrq1at+v73vw82nJGR8ac//elX
      v/rVH//4x0cffVSn0zmdTkmSoBRGXTpkZmk0Gp1Ox2RvM9iAz+fbsWOHWq3eunUr6QrYA8OHDx83
      bhw+JyQkVFZWBoPBzMzMjo6O/fv3Z2ZmBoPB1tZWm82WkJCAG504cWLbtm0+n+/OO+9MTU0tKSnR
      6XTwMRgMhoSEBJPJxAdA0yMr/GAIoM95AKmNPScQYf637qEnGxf6PgnICOq32+3l5eWSJG3cuPH0
      6dOHDh2aMmVKbm5ufX390qVLR44cyRhTqVRnzpz58MMPX3nlFUEQjh07duTIkXnz5hkMhpqamh07
      dowZM8Zms/n9/ry8vLS0tLfffruhoUGn0+l0usTERI1Go9fr1Wq10WgkYZBKVjDGnE5nXV0dnIEQ
      /30+H+JDmBxXCpr+8ssv79y587e//S2Jik6n02Qy3Xbbbe3t7a+//npSUtLo0aPBOejMhwWudHvx
      +RGieq17Bee1UXTjjlE3MNaHYgRgrtHr9U1NTS+++GJeXh4YALy1kiTl5+ffcccdjz/++NNPP33H
      HXd4PB44DyhgjKYHqFQqm81mNpvxWuGqgbZRUVHR0NCgVqu/+uqr48ePHz9+fO7cuTD1LF68ePTo
      0Xj7FRUVRUVFd99997Rp07Zv337o0KEFCxYkJia2tLS88847kyZNys/PDwQCI0eO9Hq9r732Wl1d
      nUql0uv1Op1Or9drNJrU1FRBENxuN6QNCmcaCL49Bb2Cfq0dfd4/xdhVvShxdHvvYg4U+w+z75tv
      vpmXl/f4448LgnDgwIHnnnvuT3/6U35+Pi5G1D9jLBQKmUymhoaG1NRUOF1bWloyMjIwFB0ti8WS
      kpKSk5MTCAQ8Ho/H43E6nR0dHXq9XqvVNjY2UtwhCY+iKOr1+oSEBEhqMO9iNL/fbzAYEA+enJz8
      xRdffPDBB7/73e+uu+46l8sFVQYqSEZGxr333vv000+//PLLv/jFL/Ly8pxOJ8UIhQUdxV6fOFe4
      H4xCvX5lJGB2Y5zFJhgMvvHGG4yxX/3qVzDRaLVaqt6zdOlSg8HwxBNPJCUl3XPPPfX19VqtFpuE
      TynHv/An0duk5F7G2CeffDJlypT77rtPEIQNGza88sorzz33HPw9CE2GkgojpN/v7+jo6OjoMJvN
      brfbbDaDaen1ekwsMTFx3LhxRqORLEi1tbX4LxgA9EgqYRLGtBQMavQHD4j/tHd25QDZbYKcVwlb
      PGPs+PHj27Zte+SRRwSuDheugVsVnlVJktrb2xljhw8f1ul0LpfLZDIdPXq0oqKiqqpKkEv3wFsQ
      CATcbrdWq0UMuCAIcDMwxkAOcBkCwHE4NRpNRkZGWEQ/OYdBpyoqKl577bWVK1cuX74cIa2NjY1Q
      FILBoMFgsFgsd9555yOPPPKPf/zj/vvvT0lJCXFlwrr0CgaRkNjDrcUXgUDi7ttvv71mzZo///nP
      aWlpNTU1gpzciwRynU43e/bs6urqN998Mzs7e8WKFbHzMMj2CJ0D+tyOHTtOnz599913Y/KUqxgI
      BGA1wrbRaDS46a5du06fPm232xMSEkpLS1UqVUtLC0U3YA+o1Wqr1YqZJn+nAAAgAElEQVSY0Y6O
      jsTERNwLmwcxDiGu/FxvLaCCCw7FJ9wF8NEaoihWV1c/9thj11577YQJExCModfrcVwhZPE1Hg4f
      Pjx37tw77rijtbVVp9NptVocVIfD0dzcjKhQ/LaysvLUqVPHjh2bNWvW9OnTVSpVUlJSe3u7KIoL
      FiwYNWoUYwx0n0oF8OGG4ApUIQAnubm5+cknn9yyZUtKSspDDz3U0NAAUc5gMMCBAZHfaDS2tLSs
      X7/ebDY/+OCDkWXCLmYTcCRjoyQ7Kv7z+eef//GPfzSZTGvXrt24cWNHRweUM2yJUCjkdrsh2peX
      lz/88MMajWbZsmWkJbBowaBkkcP2OHv27AcffDB//vxJkyYxOQsBEyDVkD5UVlbOmDHjlltugbtC
      p9O1t7dD4CgrK7NYLHSvbdu2HTlyZPbs2YWFhRMmTIAhSBRFo9E4f/78Sy65JMSVwLuYt8HQQz/x
      gEEkGMYA5CYq4rZ+/fqcnJzZs2fv27fP7/dbLJbS0tLm5uaDBw8iZayxsXHMmDGZmZnV1dWffvrp
      z3/+c7VanZaWhqWAdG+1WtPT06FiazSaoqKiL7/88vvf//7hw4e9Xu+ECROgxUMDyM/Pd7lcVVVV
      WVlZFPGJ4B8KChLkVFJQKPywurq6vLz8qaeeSk9Pb2houPzyy2F/gL0IjkckuC1cuHDv3r379+9n
      59Y+6zlijCP1RuWZ/qdKxABo8YuKivLy8u677z6Px4MXBDcM5PGQDLVavWLFiueff/7999//zne+
      w7v3+aeA9I3FoRt9+umnNptt4sSJBw4cEEXRYDAcPHiwqanpwIEDCPxtaGgYN25cdnZ2SUnJunXr
      7rzzTtgJMX5qaipjLBQKXXrppZKcVfDVV18dPXp05syZhw4dcrlc48aNq62tRdio3W6fNGlSMBg8
      ffp0bm4u9gw7t3+Rwg8GNS6wP6B7jCEqR4kkWN3mOp2RJHxDpT1nzJhx6623njp1aufOnQaDAZL4
      8uXLz549W19fDw09Pz8/FArt2bNnxIgRU6dOBTkgcyrNWZBr9QQCgcWLF19xxRXHjx8vKSnZsmVL
      XV0duI4gCE6nUxTFVatW5eTkgABBo4efkMbha8lh5i6XKz09/fbbb6dKdsQk+HXDN4mJiRUVFR6P
      x2g0Rl2cyJWJTcTDnAqdXdBDRN0S570stuv4vNuJ1h/Sulqtzs/PX7lypSCnE0oRORb0ed26de3t
      7TDgkEGJccvFx+FQ5M/s2bPT0tLq6uoOHjwILcHv9y9fvvzw4cNOpxOhvXl5eYyxkpKSiRMnTpky
      BSPwRcIxJQoYU6vV8+bNu+yyy44cOVJcXLxly5azZ8+6XC7osqgssnLlSgwbtjIKAxjsUGxB0cET
      UCJwkpzlDyI7atQovV6fn5//wx/+kLRvIgdwCSARdPbs2QsWLLBYLPAQhrginYzjXoFAYNasWfhm
      xIgRBQUFbrcbZ5W33sJwhGgTdm5pIH7CNG1AFEWHw5GQkMBfRpkERIPUajXVC+vTFR4UiC3k0gqT
      0QzxVERbcRm/4BTwwxhTqVRarRYWfAJ/uxBXKRp7T6fT5efnIwQgKysLHiONRgP/EJNLFhoMhlAo
      dPXVV6tUKqvVynNoXpCHaqJSqbDrGGNjxowZM2ZMY2Mj+RUkSUJIMRQIdi4vVBjAEMCQ4gGR3qpu
      6xn8UDyRJfEZOT6BQMBgMOCvkfSCjndCQgIyCSSuaj9/I9IwBDn7FOXkyOjPuGLxkDHBS/ifs3Pl
      8UjjNSRBiHVIWKNi8VTDUpDLVXaWHxADQ4k6dG/nkJQAdKZGSNGipaN+Q/IBVYSGC0etVkMUQEYI
      k7vT4M2iSvmwYcPIKhg5H0EOciN/BiUYp6WlMTnjARcj0awbC6Jg4EOR9boAUH+YU/Av2XDo9OIz
      6Dj+hdwHnYCXxaLammDeASEmlyPlhbFzuxKyc0uV8eI/ixaGT9/wAizPkOjM8090kSO2CYtfZFBq
      FG7DPol80VhkvtQH7xAOG5z+JMmxoVDd6OchuT0AIoyJasNGJAgCFR6Put8AqkihkvvG8MYr/o5h
      T61gaEDhAV0Dme8FuURMmCwvcCZ+UW4DCd8s42g3PyARXAo2p1rtTJbvUPCZ6BFZdTs7jaFzu7+K
      XBNBZJyxc5vThtGyyHkqiIowvkukn7+AZ888h458fVHfJr0O7LcwXw74BPUyYpyLArtOOBcsmkbC
      b10+W4U0V3bu3oi99xQMLgxxHtDtbRpV+qNyzRLnTwudWweYfohDC9JPhduogE/kxCS59Rh0c0iL
      vCYBMY20Af70Rn3kyANPESxhF4symCzMgtZ0b+mGDM6rDIWpXEx+6ZEKGa0w/77wTYx8q7AaEjQy
      /2p4FYSK1kEXoWti0Gti9rQTaI/xv+VVAYUBDDFc7Oe8qxDldowkOolyI2+SzfGBDjw8unSWSOiO
      lAEhc+EE8rmjfMMpOrH8mYycZ+RBlbjgHxIYiU+EyYaKIYjQpaUIM76HicxxCv5ho+Hth2kYotxm
      EoIIWY2oPwFdGTb/yF3Bb9SQ3KuSSg2SMsqzCgVDCUPKJ9yLiLrXyVbD5MMWpibjTzyVJ+ctL8vz
      d4kkMdAwEFyEM4l7CVyR4c5OOH0ZNiWcfPAVvpt5mCkAX/LCrIIY6Iz7ShxY5/0AGFcrNOr4RIvZ
      uZuKH4cn4pLcgJr/CWUGhN2Fvy98AJTTzqeXE0cJ0wtjTFvB4EJ/8IBIlTnse0Jf7Krz3jQqom7x
      MLU98kPkYSN5qrP5hAlljDGeRkcV9jv7TEC8IC8MQv/AyLzTjzQDRDpRrPp5lyLsgrBvOiOOMQbp
      BiIl3PNOLM6Z8Bz0vFoRn5VNqpsgCB6Px2AwhNl/eLLO5HDSsHqcBBLDYzxCjM0gyJE/MUYIuyb2
      1o06AQWDHRfSFjRgt1Gkzt5v9+2VcSDQkdkK9gQ+yITMC4IgoBc57MhwIaLkJKk4Yei7aQ9MnJf/
      8XYSZPYiBheuICw1li7E9ZnBn3w+HxiAonUpuFBQ/AFDEGSCIM+EzWZzu91MbinMZFszOQAFucIE
      1bzjq6EpiAqKAGbymhsMBqfTyUdw8XY5ysaQ5DpOaCND7yv2ag9tXqvgQmFg+QP6wcgY1QQ/MNGT
      1QgzMTU3NyclJZnNZpXcwJbkesj7vMUAlcJQg5pG69Ki9cN77LuXGP/IguzGR3ZVKBRqbW1FxxUm
      e3EpjgsGd/5zKBTyeDyRN43q7FEYgII+wsDiAay/2ADdq09v1HN0bzUQG07+QJh33G53RUUFAsmR
      kEyhrrgSpeeNRuOZM2eQ2UA8IMy3Gc+U+vQ9DgQGwLh0X0roS0xMPHHiRFVVFRn6+XJ+dBkM/a2t
      rYmJibz7pzMoDEBB36FfeUAYXejsvHWJ1vQFLvgEeHSDmBLdAXFXq9U6na66uvoPf/iD2WwW5IQj
      vieJSu6CK4pieXm5Vqs1mUy8DyCMcV6Q99jXPLur44OyU9sWxpgoirt27UI/CT6cH8tIngMoB8XF
      xYsWLYqUSGJEDShQ0Ovobz0g8pjFoHHdjuvoLUQlf/HPp7doVlfHgY8XFSUhfn7zzTe5ublXXHGF
      wWAAh6CWyCSfhuRCxyNGjNixY8f27duvuuoqiQs2513lffoee2vd+np8cvCih3BjY2N1dfWSJUsu
      v/xy/kZkfKMynyjordPpGhsb6+rqMjIy+ClJnWSQRM5cYQ8Keo4LbAsa+NYYNkgmyYMaz6KTlCAI
      +/fvN5lMY8aM8fl8VBqMyRXqQ3I1abCEtLS0zZs3b9u27aqrrqIxBRmsEwbQb083cIAmizqdzufz
      hUKhI0eOHD58+NZbb83KyqIaIaQQ0ApLcsWO8ePHf/LJJydOnMjIyGD9FSqtQEEY+pwH9EWoQ2+d
      ls4oWozrKZGSyaHTZHXBNcisITu7wLX3ErmK/4yxQCDAp4+RzE416SDO010gdcKajNCdsGfnP6CS
      sCRJer1+y5Ytx48fz8/P37Vrl9/vp8BQuhjWf7PZjGY1KpXKYrFs27btlltuyc/PR590dCuMHWze
      VURVHQYmOwlTgCQ5kyMYDHo8HljY1q9fzxhraGhAF2jyyjDOewylSqVS6XQ6u93ucDg+//zzqVOn
      omELbQDh3OqB/MuiDUPxSAJX54d6HPHZIZTkhcQRvuocSQD8o9Gcw/KN+WcJWxYFgxcDzic8kBE6
      t1YzUX9Jrv7PZFs8k4kskrNA60EU6CzBICDJxbkoGViSJBTxRxFKugCBOh6PB8WBWefk0ufzIdlY
      pVL5fL6SkpLdu3dXVlZu2bKFl+UlLq1UlAuU4o7t7e12u72kpCQvL4+M3WHc7qJC1AcHwUX7ICzv
      oUOHmpqaGFfeldcDwLlhEUKh/7q6OvR3NJvNdBd6EVEnwCfxMjlDDakJGo0GJj4m+yponnyR0bAL
      aD9Q/hqZQAGMSbKLwgCGGBQe0AXgSNAJ4U8RjCpMPhhU5gXHj06mIAdliqIIak7xOSAQgtzgSafT
      heRWkaD+6BMCkZzJLISfHv0XJIYx5na7LRaLyWQKBAJnzpzhuQ6vNICOgG3AVaDT6dBoHvOMSgIu
      NkQ+uMfjQbhnIBBISUmxWq0+n6+uro6+x8tFwwaSzbFnII/7fD6DwZCYmIiXCw0AKiPdJbJCHOO2
      GV4c3jhRedpvVHOQys9RBQgMgq1FjWgokZD0A2I2NCY/AQVDAH2eI9Y/e6V/CBNvO6I7QmqjmnFU
      EZ7ENN52RCwkFArp9XqSswS5FhBIAAQ6QS48QE2pQDg0Go1WqwUnCJsb48qWqVQqk8nU1ta2e/du
      /AktrtDryifD6/XCoMEYCwQCMG3DnL1r1y7GGPKYVCoV7t6NFzr06IUgl1jAW1Cr1fv376+pqREE
      gVq/YW2xvMFgEB98Pp/H44GxCNlhx44d27NnTygUAhWmW5DngHEKKH0pymXJmUyvaVuCEwhy8wBY
      8PguFNR5VJLLh+AzqDxtRXAvMmeRXnLRCgFDFf2aMBXnveIhGd2bdtSR4/cu8MYQiSsYByX68OHD
      Vqt1+PDhIAGCIMAlS2lZJHY1NTWVlJTMnj1b4EpxwYzrcDjgZsSxrKqqam9vnzx5siRJFRUVra2t
      EyZMAIegikBh5h2MBrJusVi++uqr3/3udzNmzEhMTMQtyBbMF0AlSzHZo9va2tasWbN27dopU6Z4
      PB6QFQzeWQ2Z2MsY9ZX1oj+g20N1+4dYNLzWH//4xydPnly5cmVzc7NWq6Uq4sTIicKiPgTeoFar
      RRv6F154AYY+6hxH6hpvpaHen0TKDx48mJ6enpWVxeRKUPAtSZKEuVHD+qqqqtra2unTp1N1I9JH
      4daG6imK4tGjRzUazciRIxljJSUlLS0tM2fOpIpytGhDj7VfnBhwtqA4N5bQrXTfXjFnkwOADqdK
      pbLb7evXrx87dmxOTo5KpUJ2lSRJaCfpdDqLiopwII1GY3l5+TfffHP69OmsrCxJknw+n9FonDp1
      qsViqaioWLt27V133ZWcnFxWVlZfX//000/ff//9aWlpzz//fH5+vtlszs7ORkNBmk/YDEFliNZP
      nDjxoYceSkxMpJSxqEvB27gEQThz5gy6ljPG9Ho9Sk2gcWY8Kx85q+69sr5G1P0Q/1RJfHa73QsX
      Lrz//vvJSkPrH1ZcNszG8sorr3z99ddh5eEg11MhaIxA/iRolmq12m63b9iwYeHChdnZ2UzmN0j3
      02q1DocDjeZDoZDZbN63b9+BAweWLVtms9lCcjuaSZMmJScnHzx4cOPGjTfffHNqampTU9POnTu/
      +uqr//qv/zIajf/zP/8zf/78wsJCs9lssVh6vuAKBhoGHA8YyODphSAILS0tZ8+ehSm2oqKiurp6
      7Nixp0+fhjkIAZqpqakJCQmNjY3bt29vbGyEab69vb2qqkqlUiUkJHg8HrvdnpmZmZaWNm7cuIkT
      J27atOmFF1646667tm3bFgwGCwoKXnzxRavVmpiY6PP59u3bJ4piQUEBGYiIuDCZeMHgS75cnU7H
      m5vIRUnPIp0bkI7/IkwFAmwoFAprfa6AMUbivM/nc7vder1eigjtpygAnjfwcr3BYDCbzV6v12g0
      okc8MQNe7mayLbGhoaG9vd3r9Vqt1sOHD9fW1ra1tZ04cQIqJnS74cOHa7Xa0tLS9evXt7a2MsYM
      BkN1dXVNTc2OHTsgi8CHkZmZmZycPG7cuC+//PLDDz9cunTp9u3bA4FAVlbWM888g12n1Wo3bdo0
      a9YshD+FPaCCwQ6FB3QB/IGUJKm2tvabb76BkLVjx47a2lq32719+3Zy5Fqt1iuvvDIhIWH48OGP
      PvpoY2MjVITS0tKvv/765ptvhtFArVYnJSUFg0Gn02kyme69995PP/1UkqSbbrqpurp6xowZr7/+
      emFh4apVq5xOp06ny8/PDwQCXq83qokWtJ78EF6vF/GgpPuLcjNC/hhLct0balRCvczgbMRlfJxi
      zxdzUNMRSPTglBqNRqPRuFwunuLzAcRYWGrNyMf7ut1ut9sN4yF+AjcvXp/INRHC666pqTl48KDf
      77darRs3btRoNI2NjQ0NDYglgwnIYrFkZmZOnTp14sSJTqeTMWY2m7ds2XL06NElS5bk5eW5XC6f
      z4fe8dAa77vvvm3btqlUqttuu622ttZutz/22GOTJk1asWJFU1NTcnJyTk4OORIG9YtTEIZ+5QED
      0xoQP8K09YKCguzsbBzsQ4cOfe9735s1a5bL5QrJPSO9Xq/ZbMZ/y8vL9+7d29zcbDAYoNSvWbPG
      YrG4XC6DwXDllVcWFhaq1Wqwgeuvv54xdvjw4dWrV6elpY0dO1YQhK1bt+7fv3/GjBl5eXkk5lPC
      l8/nQzAobgdxUqvV8nxC4ILNKUaFrBkg90yOa6RMAiYHknf75MfpCbgg6AkrgmOfQvJ5Qxm5jiRJ
      IgYsyI3ksJ6S3AiM1pb0M/Bdng2QX3fcuHEFBQUWi+XQoUOlpaU33njjuHHj/H6/y+UyGo24Rq/X
      4yVWVVXt2bOno6NDkpPUioqKioqK2tvbk5KS5syZk5eXh3RCnU63YMEClUq1efPmrVu35uTkXH75
      5RaL5Ztvvvn8888XLFhwyy23EPfqrQVUMBBw4fWAwcUY6KwiTgaGoA8++MBsNs+YMUMURYvF4vV6
      ERpoNBpJYM/JyampqWGMhUIho9FoMBgcDgdjTKvVZmVlZWdnOxwOvV5fX1+/a9cuSZKuvvrqpqYm
      t9udkZGRlJQkCILH46mvr29pacFRhP8Q5MPlcjU3N8NiQ6SHMTZs2DC73e7xeNra2hBUChohCIJe
      rzebzRQWQu4NPCb4QVTFfxC9rN5CZ1uU6jJRsQ3GNZ0OG0EQBKfT6XA4yOMiiqLRaHQ6nT6fz+Vy
      SZLkcrl4VYwxBh2RPMBgGHjvR44cycrKGj16NHw/RqORGDyCu/Db9PT0QCBgMpnovnj7w4cPt9ls
      YFEVFRWVlZV6vX7mzJktLS0+ny85OTkjI8Pr9WZkZFRUVGB3QVmhEDjFKDQ00N814/rzdn0B2veQ
      3wVBqKmpeeihhxYsWLBu3TqXy8UYMxqNbW1tVqt16dKlOp0OlnSHw/G///u/1157bVpaWnV19Y4d
      Oy677DKz2ezxePbt25efn5+TkwMq0N7e/vbbb0+aNAnCfmpqaiAQQEUa1CVGS0hQCoj2Ho8H5MPt
      dlMuMWRMh8PR0dHR3t5uMBiohQDoOxzLEtdCIIzWR37Tz6s9kNFZhAwvF/NOGsZYIBCAh1aS4zsD
      gYDdbgdvwF9BZ/FztVo9bNgwJr8ymJ4kSdLr9du2bXvnnXfGjx//+eefI7vb7/c7nc7s7OxrrrmG
      IoI6Ojo+/vjjSy65ZNiwYSdPnqyqqpo6dSpUlq1btxYUFCQkJEBrPHXqVHFxsc1my87OLisr8/v9
      yA6BvIJANT5dWeASZfpnwRX0ES6wHhC2gbq3n7qkSfREdcUP4V81Go2MsZKSkjVr1vj9/uTk5OHD
      h8PMmpSUtG/fvi+++GLevHlQBUCLnU7n0qVLzWbz0aNHa2pqFi9ebLVaKysr161b53a7IZ6PHDly
      zJgx7777bmNj47Bhwyi/DNIfjPs44bDV4GSazWYkD0NgFOTQb61Wm5OTk5ycnJWVlZaWBvYAGsSX
      NZbOzUGFGEuGoO6h5+vMesx1OptAnHFNYV6WqL8ias44K1BY/i19ttlseHfEG3Q6XVpams1mS0lJ
      MZvNIPGUw0V1/SjzC06akpKSDz/8sKqqauHChXl5eR6PBzb99vb2f/7zn4sWLYJGqFKpWlpa3G73
      nDlzCgoKRFFsb29fsGBBQkJCc3NzaWkpNFGv1zt27NjMzMzDhw+73W6YjPR6vV6vdzgc8Fo7nU6B
      S2FR6P5QwoW3BbEeiBLd+2HYYY5/EOoci8Owb9++xx577Pbbbz979mxeXt7UqVOZHMFtMpn27dvX
      1tYGRV6SJMT/fPbZZ3DiNTc3r1u3ThTFpqam+vp6UGfY9HEvjUbj8XggykEo83q9OO3Q36lijCiK
      yCKmzwJXbQY6AcxWlO7L24sQ9824KJTID2HLFSdp7rneEPteYS8u6lR7ePfzXkCEntYqTEAO+2w0
      GsNMKKgdpNfrYeehEQQ5jgiXUTuHgwcPvvTSS+PHj3e73RMmTJg2bRqT5ZL29vbnnnsOdjy63uFw
      fPbZZyNHjiwvLz979uynn35qtVrhRjYajdA1wWyQrgyNpL29HWZDr9fb1tZGjiLemaRwgqGBAcED
      uof+34JqtZoKcomi2NHRcf311y9fvvyTTz6hbGFQfEjuJB6KotjS0jJ+/Pi8vDyVSpWZmTllyhSU
      Edbr9UlJSVarlTGGnwSDwaamJofDAXNtW1ub2Wx2u91NTU0Gg8FqtfKJx7wRX5IbBYOUgAqgbiiJ
      q7zUH0Y0+T+xCAYQaRrqH3TGBgYCAZLk4P0wWxDRfd4EzzgZgl4TYjTdbjeaECAcSJRLy4GFI86Y
      CjY0NTV95zvfmT17dlVVFekH+BVike12u81mQ26B3+9HTEFycrLFYpk+fTpVJLzkkkusVivqkWi1
      2pqamurqar/fP2zYMIfDQcyAMSaKos1mi/qATPEJD35cSB4w6LYObzpnjF166aUo9eXz+c6ePRsM
      Buvr69VqtdForK2thdGG4nM2btw4bdq0yy+/nLI0mVxoCBEdiAiqr6//9NNPdTrdpk2bbrzxxp//
      /Od6vd5kMsGxfM0119CxhwRHVIbKDODk00GFr5L/L12GD2ElSMMEW1IIFPtvJDei9eEDZvi1irwY
      xB2fISjg3eEDOXLCeDa+B62/6qqrtFqt0+l0Op21tbUNDQ2iKLrdbpPJVFNT43A4EhISUFDE6/UW
      FRXNmDFj4cKFFGJEJLujowMRBFqttr6+fsuWLc3NzUVFRcuXL7/33ntRjESr1RqNxmnTpiUnJxMf
      ulDSgII+wiDWA/ofAtccCmkBbrcbVpq9e/e+9957lFV77Nix+vp6t9uNig5ffPHFrl27XnjhBSoI
      ishRrVar0WhMJpMoiijLs3btWp/P99FHH7377rsfffRRSkpKZWUlyDTIR0tLy4oVKxYvXswYQ5U3
      ohRMJjSoFoATjgnADE2nl0iMINcS4Gk9i2nz7bmFZ8gAQjqTSwTyqxq5khJXuA0viMlpxjQgif+8
      EknZwrgYtj5Jkux2+/bt2+nVB4PB5ubm+vr6YDCIqg8bNmwoKir6y1/+QpkfSPdDVgoC2ERRdLlc
      27Zt02g0zz//fFFR0bp16zQaTU1Njc1ms9vtSGJ3uVyLFi1auHAhX/mKKUrAkEB/5weEfdNbomVU
      40Y35hMbYVYUKNGhUOiaa64ZNmzYhAkTYNPX6/X5+fnjxo1LS0vDqTYajb/97W9HjBhBEX6MMZhr
      Iafj3AYCgSVLliBq86677iovLy8tLc3JyWEyuQkEAiNGjMjNzYWMxhsNaCVFuZAAKsDgDFOhCHoK
      kSssLMluTCpujJpFYeWL+aj2Lq1bZ4g6TuSXvHmqq6PFAxq2q2wPhJUC+an9Mj9U5DpDoEZ1JpVK
      ZTQaKRYIud9kAgobCp4bqhK6atUqi8Uybtw4JksDra2t2HK4kdVq/f3vfz9mzBiyQcGSSbsXyofB
      YJg+fXpCQkJSUlJOTs6xY8cqKystFotKpUpNTRXkcnLDhw9nsmEzzAeusIFBjQGhB1wo0bKz+8bj
      DOT/e+utt4IoM/mYZWVlzZgxg8mW30svvZTC7SGFkUGAJDuc7YyMDARiazSaESNGjBw5UpJzu8gS
      xbjioPRf3tOIf6EBMMbKy8u3bt1aWFiIkpakDRA/AyGD6gCDg8FgqKqqamhogLiKytiYOUWt9B26
      KhlcqP1D+dhgzydOnGhpaWlsbOyslBMtOJYRdPnYsWNUtdvj8RgMBrwLItY8wWVy/oHBYLj22muR
      hkJ/zc3NHT9+PPxVwWBwzpw5TM4bx4BU+A8vXZBzBnNzc6EraDSaiRMnIi5Z4nqf8a7gsCdS9MLB
      jgHBAwYaImlQ5EYP851CIUBIBolyODwg6CLX5okMO7hYkg36uB7f49CCmghy4xEqEMQL8pHzQSA5
      goXGjBnjdDq/853v6HQ6IhnsXBsFk6VUvV7f2toKnuR0OhcuXDhixAj8FQygF2tFnBeR4nnsN9KL
      d4wTcNJgVkuWLHnggQfef/99Yr0sosAUCc6MMZ1OR2X4Hn74YRjroL2heHhI7kITNj3wACocC5kD
      bxNJJIgTpR0SlnAQ4jpV4K+YDH8Xov4hrvVF6NwitQqGDC4wGx/IQkQ8PIDUajLaCnKgPankghwT
      ggvgbSObb0juNsPXaSAPHkRCFCMDCe6sdQyR5pDceQY16y0Wyz/+8Y+f/exnfNB62DHmzdCBQECv
      1yMefOPGjVdffTVaC4hyJYneJQFRzYNh5oWodxwIOwedGJAq6AYvaSQAACAASURBVHK5li9fvnXr
      1rAwocilhgbg8Xggel999dXvv/8+ekmiCB1ieYlhkAzOu3MEOXJUJfcIg4mG72VEqSS4ktLXmRzh
      xhijnGQUPiLlgN/e2Hv4baRDWLEFDXYoekB0RNV5IzVfMuMyWelmXMggY4y8cAJX2B0MQ5Kr/fCf
      eUUBd9Tr9Uz2DTLG0NeXyQGgAM2KJ6DIEQsEArW1tYJcj6yz44q/UhVM0IjTp08Hg0G9Xh8MBiFO
      Cuf2mL3IAWqO5m4VFRWnT5/G+lPgQBggm6N1D5M7AtXV1Z08eXLatGmC3I2O59YE3ojHImgxMR7I
      7zBSke0OvWt0Op3IdaIGucewJF6Q9EBqBL7hJY+oBi4FgxeKHhAdUeVTISJ3lD5T5BxIZIgrEQxx
      zOv1tra2pqenu91uWGn8fn97ezsi+RDliT+FQqG6urrU1FQ0dJQkqb6+Pi0tze12w57DT4OX1wS5
      QpkoiuhRZTKZioqKfvOb3xQUFCQnJ0euNv2Qdy87nU6bzVZTU3Po0KFPP/20sLAQPWSYHATZu2/t
      vBaegawHQHIPBAIPPPDA119/ffXVV6NeCIGfJzI2wOyRA+j1eisrK6dOnfrEE0+IoohAHZgWw+Rr
      KIt8BCr5jSlbkMn9xYi+kxsfzh7qOQy5Pkwy4CNHQ+c2OQBCXCVUBUMGF4Ue0JmoEoOOhJ1A3pIb
      eQ3ILjvXqMJkUR1K9JkzZ7755pubbroJmfcmk6mioqK0tHTOnDkoHM0Yg82nvLx8/fr1t99+O8TM
      M2fObNiwYfr06aWlpRaLBfUnyKTDR+nRw5JVB1Rg8uTJTz31FNLQYjwviZY4+adOnfrRj35kt9up
      IBroV7+RgIEvYIJqw9lTX19/ww03PPjgg2F0M0xo4JP78IBvvPHGnj170MyLEsEojSCMxzOuhite
      2enTp5F1SHYeaHLgInApIRUZHcHmzJkD5zANi6KhoVCotrYW+WhgJOTi0uv1VquVdyYxxQQ0hDAg
      eEBXN1NvyYCxeUNnd6Ff4RAyLtAeH/hzDlcBqofW1dXBdPDMM8/88Ic/FAQBVSIYYySXCYKwadMm
      r9eLYmEARr7kkktKS0srKysnT57MuKzgSECXJzs1HANhTxf57DBPC+e2H4C8iVQDcnvEs7Y9QVf3
      w4XaP0x+cYwx1GSlUt5R5xZpTKe37/f7ESQqSRKqi/PxV2QYBFPfuXOn0+lUq9Vms3n9+vV+v3/+
      /PmU0zthwoTMzEzGWFtbG+r/CIKQmpr65Zdf1tTUFBYWwrUDtTIxMREO4Z07d65evdrtdqOhDSyQ
      oVCoqampsLDw3nvvzczMxMZWqP8QQ3/wgM4siUw2X3RmYIk6SJcQz2aNZ+SopqGw/5JITrIbCWJk
      nBEEwePx7N69+yc/+YnVanW5XDU1NSUlJfX19StXrjSZTGhE84Mf/MDhcDQ0NBQUFDidzqampqqq
      qsTExLNnzyJQh78jhY2SH4KYENkKoBOETZ7mGZLbWlEYIuUT8XnRxBpjvKNuUIf43/5590Zvve44
      EZI7MpJCRjwycq3CrPlM9vEgMoeaj2IE+hX4LrFnWOoOHjx4+PDhzMxMQRBKSkpwGekHqampGRkZ
      giA0NDTs3bsX7pzMzMzTp0+XlpaWlJSguCxiDS677LKsrCxBEFpaWqxW689+9rOsrCy73a5Sqdrb
      29vb2xlj27Ztw2RErtaIwgaGDC6wHjAQrLrdgxBHZDQOjEql2rNnzxdffLF79+4xY8bMnTs3KSnp
      22+/bW5u3rp1q8vl8nq9Pp9v0aJFRqNx9erVTU1NoVDotddeu/LKK9966y309tNqtSNHjkR9RzgJ
      QD4o04dcyhIX+g1rEoJM6Bomxw6RbYE3BzPOOhzmgYxnTXq8rt0fuf+pEgXvUtoUO3etwqbErzAR
      U5iSBNmNTw5hSY4IkuSwHJj1jUbjihUrxo4dGwgEDAYD7PuzZs2CJpqQkDBp0iSw/JSUlBkzZgiC
      gCpASUlJNpsNDYiQ5e73+y0WiyAIKCpVWFiYm5ubmJiYlJTEGPv666/PnDmzYMGCY8eOYQ4K3R+S
      GBC2oIGP2HJoZ4DjNxQKJSUl5eXlNTY2SpL0/vvvnz59+vPPPw+FQqNHj161apXL5SouLrZarT6f
      r7y8PCsr69FHHzUajT/84Q8tFktWVtbRo0cLCgqWLVtWU1ODXgKIDaeUAqfT2dDQAPsPLLkgMTab
      zeFwuFyutra2hIQE1AKDgG80Gs1mM6gMkbBIwwWRti4xg26je+t8ARHmhmEcoQ+DIAgdHR0IuiXt
      EGUY3G43WgSjKCyTpQefz2cymWCLlySJTDQ2mw3t3Y1Go8fjMZvNGo0GXYksFgu2hEqlSkpKMpvN
      e/bsqampycjICAaDSUlJZWVlOp2utrZ26tSpkyZN8vv9cBebTCa/33/o0KHjx4/feOONNptt9+7d
      NpsNiojH4yHP8yB6OwriQX/wgM5E5sGrBABhzthIIAwjGAyOGDEiGAx6PJ4xY8bs2rXL7Xbfcsst
      fr//4MGDo0aNKi8vx4E3m80vvfTSgQMHPvvss9tvv91iseh0OpvNtmHDhn379qHhlCiK0Bj4AjXo
      HxIIBGCVRvlJQa4q09raip42drudyUm/giAYjUakF5FfIQaJV05+JIRzM/X4kNCoex71wyGkwxRj
      s9mcTifekU6n83q9Qa5/ZygUQmwYeAA6zq9bt664uBjfJyUloVihIAjw2Dscjuzs7OXLl6enpzPG
      nE7n3r17s7Ozk5KSli1bBvaj0WgOHz68a9euCRMmQI3AfJKTk3Nzc8vKyj7++ONrr722qqrqqquu
      gsUSt1MigoYk+kkPiDwSg50BxAOqNQ0S7/F4Ro0a9d///d9nzpzJzMxE06iKioo9e/bYbDbkELS2
      tn7++eepqanBYPDAgQMHDhyAZ48xNnLkSNSRHjZsGGR5OpMmkwltyCDmQ65XqVR6vT4rKyslJSU7
      Ozs9Pd1isZC3gEIDcTF5MsJoPV+RIh7z10UIcmjRv6QK8GqNIAgmk0klA/K10WhMSEhIS0vLzMyE
      DkcRQeAoOp2O6kphtMzMzLq6urS0NJfL9fbbb9tstqlTp+JtJiQkpKSkCHKDI7ATjUZTWFg4YcIE
      XoovLi52OByi3LuYMQb5ID8/f9myZe+8885TTz2VlpY2bdo0lBcV5Dx2pkgDQw79ZwsKszPw3w9k
      ysL79MI+nBcS10bcYrF4PJ6jR4/irDqdTq1W29HRsXv37qqqqmXLluGov/baa8eOHcvIyHjvvfcW
      L148b948tVpdVlZWV1dnNBq3bdt25ZVXUmkXqiUpiiJCPyE8UmyiIAPN5XENuQGIrPB2f7JTS3Kd
      IsZlvcV+WZFr1b117h6tkSLCefuaWtHikJuUZ6KRaqLRaAQ9ZXKsF65HKQ7K6aV1Jh6PwiG48rLL
      Lps+fbogCG+99VZbW9vll19us9mMRuPBgwcvueSSm266CT9BQXKM8PXXXx84cAA+AJ/Pl5CQsG/f
      vmnTplHdKkEQampqsB/S09Nvu+22KVOm3HPPPchoa25udjqdTE4a6JIHXsHAR3/7A8KoA4lInV0Q
      dmXsa7o6h9ibOOyv3eBVklyKhzF28uTJjz/+uKOj47rrroMF1u12p6SkXHXVVUuWLIFFWK/X33DD
      Dddcc83w4cP5LjQpKSl//vOf16xZc/31148dOxaDh87tXkIrSV5f6iFDlJ3J1WN45yRCSugBBS6J
      lEQ/cBoiUudFl9aqs3WOn9ZI58bR9xv4+4KnsnMLq4XNHLE9+EyvCTV56IKw6DJQf4SfUtHZb7/9
      ds2aNVVVVZMnT16wYMHMmTM3bNhQWlp63XXXMfkVGwwGxpjZbF6xYkV5efkLL7wwd+5ctCldsmTJ
      9773vdGjR1MsGWPM5XLR+92/f//8+fOPHTt2+PDhSZMmabXalpaWkFwfW4zomaMwg0GNC9lTfshv
      HVB/n8+HPKDbbrvtxhtvNJlM7e3tLpcrNzf3lltuYYw5HI5169bl5OTMmzdv+PDhtbW1x44dKy4u
      LiwsvOqqq9xu91dffbVt27acnJxVq1adPHnSbrdPnz6dceV/6Y48AYXFmVzHTLZfA5TOFgqFKKSd
      L3bGl7An08QFeWXxqAUXZG58PbVQtDKu7Nw3gpcFpktRpKgTF5bqgdFQYpruhdf09ddfr127duLE
      iQ8++GBtbe2bb765fv36urq6F198MTc3l8kxwYIgeL1eo9GYl5fndrszMzPnzJkzfvz448ePT5ky
      JScnJxgMlpeXm0ym9PR0GHzGjx/PGCsqKvr000+feeaZHTt2PP/883/729/a2tpOnTp16aWXUgVD
      dhEc3osH/c0DemXrRBUzhYhSNlHvxf8wHrMGf3GkZErkibecUBg1hCa32z1t2rSlS5eiE0BbW5sk
      SR999FF+fj7cfXV1dSdOnLjiiiskSXr++ec3b958ySWXXHHFFSkpKR9//PHWrVstFstzzz23ZcuW
      J5980uFwzJ8/X5LLB+GReWedIAgoRwOjMGpJJicn469Unoh+InIdpqjekSRJaDZLmUdhZqLzLlec
      iLrOXR25h5sqnn0CfsnbA2k/oBin0WhE0E6k45QfHyyZTyQmVxDtJYSTgZQTe6YXN2HChEmTJlks
      FrfbferUqaNHj+7Zs2fWrFlVVVXZ2dlkX8IbZIxVVVU9/vjjU6dOnTJlSnNzs91uT0pKwhtfv379
      sGHDbr755oqKCo/HM2nSpH379n388cfXXXddSkrKd7/73WPHjn355ZeMsbKysjfffHPhwoVZWVmY
      BuUxKMxgsOMC95AZXOPzMeC8CVjiQrl5fgAPrdVqnTx5MvpKBoPBxMTE//f//t8nn3yyZ88erVZr
      t9snTpx44403jhw5MhgMXnnllXfccUdCQgJjbOPGjW+99dbdd9+9bNkySZIsFsuTTz5ptVonTZrE
      l5UOe2rwIa1Wi/if9PT0kpKSJ554Yvjw4RRKFAZJNvejZkBHR0dSUlJ5eXl5ebler6cnoudSjj2g
      1+sdDofZbJYkyev1bt68ecyYMY2NjZ1dT1ICgNVet24dNX6hTi9UpJNx7YKpdndRUdHx48fr6uq8
      Xu/dd9+9evXq995777333lu/fj1jbMKECQsXLkxPTz9x4sQHH3xQUVFx+eWX33bbbYwxrVZbXl7+
      m9/8Ji0traOjo62t7de//jVjbO3atfBPfPzxx9QvTBTFH/3oR83NzZdeeumdd96ZkJDwgx/8ABGi
      vEAQ6sdy4gr6Av3qj41HxIvHHxD1skj5tEvjx74dkwllVEWYPwaCXLOX97hSKVBUZoawhjbi9HMY
      BAwGA8w4OGxUtlPg2oujIAxl9oaZHYhSQKJsamr66U9/+u9//zvGwyJ+STy3Vb0kSffff//jjz+O
      v4J/oHlZPHpAT9Y59gXxjx/nBojnsjB/A9bH6XTq9XrI9evXr7/zzjvr6+tjzxkBoEzuP8MYS09P
      f+2115YuXUoeZia3c2Cy3sBku5/f7//2228//vhjFJ2+4oormCyaBIPBb7755pNPPtFoNHfccceI
      ESP2799fXFw8c+bM8ePHUwG43bt3b9myxel06nS6uXPnXnnllR6PZ+/evcnJyWAMeXl5qDMqyP2O
      NBrN3/72t5EjRy5dulSSixKS8KH4AwY7LiQPYHFQ9s4ujocHRI5/3lvE/iFtet4oxHsFmVyYgYwq
      dD6pgQyf+s+XgwbzgGEBQSBoR4wkYcaVpqGhyMTMGytwRDEm0krffffdu+66C9WD+ccPo2tIM0YR
      NEQKbt68ed68eSgaSvZo3o7R2XLFv6liv6AYxKWveUDUmfDfgKNTHT1BEJYuXbpp0yY4YzsDxAgU
      dpYkyePxLFmy5L333kO2F14iirUxeXfx4rYkSbDdQ3rAfPjGEqSogXlQ7Wh8oK1Fhe3QBkfFtQiF
      BAOdFRkJaEdKu4vfcuxcAUjBYMSFrxURlXZ3djF9jpO4R44fp8wSlVJQujzPDMjpKsn59GTDxTfg
      BCD9dBrReyQoNxEDhQWNpjo/KDFNdR1g/0GVR2oR3tnkqbdtIBCoq6tzu90qlQp5BjwDo5/AbwEL
      EvknW1pamCyx4r49kcrjxwCRK2kaUZ8OahbcLYIg1NbWoshHWO1oHpKc0wf+AVEAjeDz8vJA+snM
      QsIEaZPYLcjsA6cnpYH33tPPQc0xQ956g2pxjDEUK0XkmCDXCkQ+mkajoSQGXvLgC44yTspRMHhx
      4WtF9LUi0ovj8wUVSAQDoQfNxbEhOUuMaMgHsRGCFWMMsjxoq8/n48s/kAKBuBG9Xu92u1EKlIQ7
      SGQ8qcKs0JEqGAzqdLrS0tJPPvlk+PDhaETOovGAINclGJVNtVpta2vrv/71r1mzZqWlpZFzErdQ
      jj0BFDMQCKxZs+bMmTPjx4/n1cQwgLYG5Yag+LKlpeXDDz+877774B6AQACyS72JqPYfYywYDIJb
      MzkEiCg++HSYcKDVasEG8F/YG9HFTK/X4148z2CcPZMmSTuTZH++mKCCQY0LzwMGF3h5ShAECt0L
      BoNNTU1paWkU80e6M3Rtxhhoq1qtbmhoSEhIkCQJJxNsAwq4yHWRpAxenFWDwQDiDkrR2SEUBAH6
      BI53dXV1SkrKX//614yMDMQLRfIAUW48ixs5nc7MzMxDhw797Gc/q6+vR/MZvj5a3y/zwEIMSoc/
      ud3urVu33njjjY8++iiqQnV2MYXYghYHg8HXX3+9vLycKsfxOcYhuVUk/uTz+fx+v8lkgtOILvB6
      vaFQSKPRgMHgLTM5n0Cj0aDJMAJYEe5FG4/MR6RYCHKCCN/kjoKJMTLZAyWu6KyCQQqFB3QKiXMA
      0AeigKj/4/V6cVTOnDlz5MiRyy67DGUeGGMajQbnjcgxWflfeeWV73//+8OHD0fdYJxzJIt2dHSs
      W7euoqICBxWHX6vVOhyOxMTERYsW5ebm8tZhnt8w2YIMORFkxe/3p6enjxkzJkYPGV6+I8Vi5MiR
      2dnZsCCj/SEJiX288IMGeH2MMYQGpaamWiwWVOKM/UOJ86OOGTOmqamJtDp6s8QPRLmRA6g81Mq2
      tja9Xm82m1FTiDFWU1NjNpsRUQYrE5pHtrS0+P3+tLQ08Pi6ujqTyQQnP4qOGAwGikOlShWkiRL4
      oDjeE6AwgMGOQckDop6x+P0K8d+FCCv/PXlH165dW1RUZLFYtFptXV1dSUnJvHnzyK06a9asOXPm
      oD/7nj17cAJFUWxqalq3bl12dnZDQwNS8AVBKCwszM7Ohll548aNWVlZo0aNAomB0TYQCBw5cmTc
      uHG5ublUFEjiYlLpX0EO58DhhMEXhYZYJ84AfgQyMcMZSM5tIg1SH8eB9DWPidwnna1J5AVh45D7
      1+12o9wbSfpRRyBqzrjGv16v1+PxQEpQqVQIyKEfklGR9xK73e7i4uLU1NSpU6civVyr1e7cubOg
      oGDatGlM9lVIktTW1rZx48bMzMyUlBTY+ouKijIyMkRR3LVr14IFCyZPnkxVxylQjZ9AVEUTHy5C
      jXBIYlDygAsFOr04mePGjYOYrFara2pqPB5PYWFhcnJye3u7IAgFBQUGgyEUCrndbofDAVsKzKxm
      s1mr1TqdTgwIEoBbiKKYnZ197733pqWlMcaCwaDL5SorK0tMTKyuroY6D/8w37JKODdHgVwRkhxm
      Cp0g8nFicE2Jc6eTVNjrzpu+5ih9CjBpePvJ3cI6p5sSV2iBN7WTgkUZZBR6AGsMmQchret0uoaG
      BqvVGgwG33777REjRixatKiuri47O5sPPxMEweFwHDx4cMyYMYwx2H98Pt/Zs2dXrFgRCoWoJx02
      CRhAZCs0BUMbg/Jl94QS8UTnvOPwh1mS02jJ0D9+/Pi2tjZo0K2trcnJyampqWazOTExEXX/EbSX
      lJS0ePHijo6OmpqaYDDY3t4uiiLKf4ZCocTExKysLBjiGWPo5nH69OmysrJp06YZDIaqqqqPPvro
      jjvugDuBkkih74Om+P1+xPxQ9ib+hcU5FArBlIzoINimUFWU8hh4Es/nOvA8gBwh3V78zt5I1AWP
      8yc9v6zb19P6IGCGzxOMHBMGfRjrSZ2Cakh93vES8U6pzQMxYHyAfobXKghCeXl5QkIC9AO73V5T
      U/Phhx/OnTt3ypQpKpWqpKRkwoQJ48aNa2xshAtKq9U2NjYWFxcfPHjQYDAgRogCEPioNgUXCS7G
      991tFoIDDCm7vr6+rKysvr4ezj2UfGhubhYEoampyWazuVyuUaNGJSUlwTL70UcfNTY2om/fvHnz
      nE5nTU1NdXW1VqtdtWoVqgUghHTYsGGSJG3fvv306dM333xzQ0ODTqcrKCgoLS1Flj+fpANq4nQ6
      GxsbYYNijJGTMCUlBaGH0CEcDgcCEAOBgNlsTk1NpShDxuU6dGZq6/6Kd4JIjhKDx/S6CtJzkAEd
      IH4ZJmQQV+7o6GhpafH5fBTwYzabm5qaGhoaYM2HBsnkvEJRFJOTk202G+UJMsZgS9y+ffvhw4cn
      T56ck5PT2tpaWVm5f//+7du3L168eM+ePYWFhdOmTfvmm2/ef//92267bePGjR0dHTk5OWvXrq2p
      qdHpdBkZGcnJydOnT6f4NIr6v1CLqeBC4WLkAecFUSJebafYGIjDR48e/de//qVSqeBrPXLkSE5O
      DkpDq9Xqqqoqi8Xygx/8AJW2VCpVa2vrpEmTrrjiikAgsGrVKrvdbrVad+/eXVxcDLEO92pvbzcY
      DOjy+vjjj0NIHzt2LB+ZQ/2+EVoKzoF6NeAlTI7es9lsNpstMTERrQQNBgPIFtgSFabnnzRMhqXv
      +81oE/VGA5M20ax4q1qMVULnHyrSJwiC0WiEGzkxMTEhIYGigwRBgOXQYDDw2ife9ejRoysrK7Oz
      s/ft27dp0yaTyYQmEytXrrz55pvhxUFeiM/n27Jly4kTJ+64446JEyempKRUVFSUlZV997vfbWpq
      OnXq1KlTpwoKCmhwgWs4quAigfKyoyCqsQgmF61WC6/dlVdeOWPGDJPJ5PP5Hn74YY1Gs3jxYkRe
      5+bm5uTkIEAIJgJBEDQaTUlJSUFBgVqtPnnypFartVqttbW1yA5FYChMTMXFxW63Oysr6xe/+MXD
      Dz8cCAReeuklMuCQGUGQI1NFUTSZTChaQF5Hkkb1er3BYLBarVarFW5h/gFBj8JqgvKegLAv+3Px
      CQOTAbBzy0Szczkl72MnDqHT6fCaJLnuCAxB2AwmkwmlOGgEUH/i9Bg8JSXFarU2Nzer1eqWlpa6
      urrbbrvtl7/85auvvlpQUADfclpamiiKK1asWLFixWuvvTZmzJglS5ZIkmQymU6cOPH++++7XK6E
      hAS1Wj127Ni8vDxyNlAWmIKLB8r77gKQboO+ejhRra2tq1ev/uCDD2699dbCwsLa2trdu3fv27fv
      j3/8Iwg0Qir9fv/48eNLS0tfe+21srKyuXPnVlRUaDSarKwsxPkQWa+qquro6DAYDIFAYOTIkWq1
      eteuXe3t7TabDdXcMBOe3ICCU2QhUpER6UF5/GTt4aM/qSYo74Tkoz6Ec0NOw7iCAn65BLl6K1F/
      FqFI8XVA6XpyBbNz4y+ZHH1P6SB4uXDh+Hy+/Pz8yZMnl5SUjBgxAvnJgiA0Nzc3NDQgKFmlUsEC
      uXLlyvLy8qNHj3799ddgNjk5OXPnzj1+/Pj06dMRjMRXKFICfi4qXLw8oBuCLTJvYc8NBoNr1qz5
      9NNP58+f/8wzz9TU1IwaNcput4uieP3111ssFvj0qBzbzJkzZ82ade+995pMpnvuuefVV181m83f
      +973KE+HWvqlpaXB8vPBBx9Yrdbf/va3jz322JNPPpmRkXHixAkwFZIuebER48CeIMkB5oj+xvwF
      ObMMoOrT/AX010h+AINVL/KArg7Vb7pInAgLmRcj6vfxF0iSRC8Oy0hqhFqtprxfSU4IYDJ3p2pR
      TE4lwTdlZWUjR46EmwE/LCsr+/LLLwVBGDdunCAI+/fv/+ijj9xu95kzZ2bNmnXZZZdNmjRJr9cb
      jcbFixfv2LGjrKxswYIFFOZPFQP7eRkVXFgMSh4QpoD3fJAwdEZrqCyzIAitra1VVVUPPPAAOm/8
      85//LCwsvPTSS5988slx48bhJIMck+gNU+xTTz3FGLNYLPD9iqJYXFxcU1OzbNkylUplMBhmz54t
      CMIXX3yxfv36hx56KC8vr7W19f/+7/9yc3MrKyt37NiRl5c3fPhwEiSpHBgihZhcdRIVAux2O0LX
      UUsADyKe2wqKKA7ijmARRsw7RFGInyiJgRvxN426mFJEtE+cb6qzuJrYr6xPIclFnES5+EfYgns8
      HrfbjageStPlf44PfPhNIBAwGo0Q8/1+f2tr67Bhw1AUBHY/qgGHeGJI6wgNam5u3rZtW3l5OeyN
      CCozmUwjR4684YYbvF5vQ0NDSkpKVlbWI488kpWVBRMTlbMdPXr09ddfP2fOnHvuuQesPayIiIKL
      CgMiEqCrcwijBef9eWe0o0v3hS5PRVQgx4VCodLS0k2bNqF9qyRJzc3No0ePnj17dmpqql6vR/kd
      h8Nx6NChJ5544kc/+tFNN93kcrk+/PBDn893yy23uN3u1atXq1Sqn/zkJ99+++2zzz770EMPHTly
      5D//+c8vfvGL0aNHi6J48uTJnTt3pqSk7Ny5s6am5q677po1axYotcfjIUcikwmo3+//+9//vm3b
      tqSkpJqamtbW1pycHFAcEkLDRH7Ip+Qe0Gq1bW1tpaWlI0aMyMrK8vv9M2fOvPPOOymOiKf+Ia77
      WIw1j3+1o/pjehFd4kmMe9fggqCboiiWl5c/++yzLS0tWq12//79ZrP50ksvbW9vjzEOFftD48ZQ
      KHT27Nnm5uZx48b5fL7k5OSf/vSnkyZNounRq2Fy9u+xpbJTAAAAIABJREFUY8feeOMNnU53zTXX
      zJw58/e//31eXt7dd9/d2NioVqsTEhL279+/c+fOO++802q1ejyeurq60tLSlpYWVP+vrq5+8cUX
      X3311c8+++yKK674z3/+M3/+/ISEBCoQJCn1oC4yDAg94Lw0PbYAGINkxPnDSEQlEJCFQf7q6+u3
      bNmyYcOG3NzcyZMnX3rppfn5+W1tbcePHy8uLn7ssccEQbjlllvmzJnj9XqffvppQRAefPDB+fPn
      O51Ok8mUn5///PPPb9myRaVSpaSk/PznP1epVBUVFTk5OVlZWVu2bLnrrrvGjh2LcM8RI0bk5OT4
      /f6TJ09WV1dnZ2czrrss1QijDCO73b558+bk5OTrrrsuOTlZo9GAQDCOskTyAFEUUUkYiotGoxk2
      bFhra6vL5Xr55Zc3btx42223gesYjUbeptTrFWP6Ry6Jn9PADkN1n+jnxcXFR44cuf/++xMTE3/5
      y18iTSSyykIYRFHEHoAGYDabDQZDR0fHt99+u3nz5paWFsyHxHaS0/1+v9frHTZs2E033XTJJZcg
      GzwnJ6eysnLDhg0oReV2u3fv3p2Tk2M2m4uLi1977TWdTjdq1Khp06bt2bOntLT0xIkTV1111eWX
      X/7ZZ58dOnSoqakJ7uKw+GAFFw8GhB7Ao7P5xLM1u8oD4h8K8pFKbqKkUqkaGxvLyspAzREeKsnh
      NKFQqKGh4ezZsykpKUjdrKmpsVqtUPZJsnO73U6n0+fz2Ww2k8mEMA8E+YAEI3cftgWYgOvr6zs6
      OgoLC30+H9WDpOBusuc2NDT88pe/vO6662644QYS2KkQTeSy0Jdk4aGmBXio5557bv/+/c8//7zV
      auXpIC+ihq1YT/SAvkY39Eh671AIQJTfeeed3bt3/+1vf6NFphIdUUGXhcVfYpEbGxv/8pe/3HDD
      DTNnzmSMeb1eROkgJZDeC/YG6V6VlZWbN28uLS1Vq9VQRsePH79y5UqbzXbq1Knq6uqxY8cmJye3
      tLS8/PLL7e3tt99++9ixY/1+/xtvvFFUVLRq1aqVK1cG5QZzSlDQRYih/Mp7ItEI0boOwAIA03BK
      SkpSUhIF1Qlyc3ao+cjBQcMvrVabl5cnCILD4UBpX8iViYmJiYmJGN/v9/v9foTrUSgRir+j0gM+
      pKWlpaWlIbdTkiQk95OrVpATi+AqaG5uZoy5XC61DEludIOLI/kcrRi0AUwe5S4oVp36H1A0kchV
      s+n2gg9kkA2N995T5R+n0wl7vSTncETW1ZDkdGJSKZDui4qeYBtut9vj8fj9frAKSvVQcf2I0ODB
      5XLBxB8KhQoKCvLy8v5/e2ceJcdRH/7vt6q7Z2ZnL0m7OlfnWpasyxeSLHzITmxLGIyNzekYQgxO
      MA4vJC84fg/Ij4fhBQdI/IAXSAwE54F5HAmxIRhjbHxhG933rdVhWfceknau7q76/v747pRaM7uj
      2Xt2tz6PZ2ZH3dU11d3fb9X3KqN4zJYDQRCw34g74zjOAw88UF9fT/kKhh/72MfuvPPOurq6AqdO
      aTVmGX1Ulg4oMSMb4piQbnvCqVW8vRflA/a5GJzv+yaio7OzUwjBGZgysj84v7dmSwDeNSwIApbI
      2WyW6wvxCwz5MCSe/Zkdx4xtWuQ3mDUFfjkXQWsdi8U4lhQATJKRqT4G+be9p/E0UStmUwR2Vhsh
      CHnbtCmQYLoxKDdjuDGuYFbMmE+kamxs5E3WTJG+qACNatnoUPMBUspkMgkAXAiaVUtjY6NJ8hD5
      rYTMjWP1EIvFeKqB+T1K+XuI7O4ghDDRa6ytuVAEz1e487lcbuLEib7vmy0EjPN5iIfXMrxUlg7o
      m5QveNPMnwOrNjCfk2Wqermum06nk8kkz8T5S5YIHIRj0kH5e5Hf8YO3dQzDkD26fADXAWZNwJt5
      JRKJXC7Hr7TO7znO4UbcDn9g0ZNOp9esWXPy5Eki6uzs3LZtWzab/dnPfialPHfuHO8GFTXdRIfO
      DJQxerDEYdHjOM769evfeuutJ598MplMNjQ0LFmypKGhwbhGKJ/NNEgMkou4/NYovxEQFwnfunUr
      1/vbtGnTrl27fvSjH9XW1rKmZwue6XCx0YnHiu17sViMxTcv9Y4ePbpt27YwDE+dOsWG/iVLlrAc
      N8dwwDE/SKaUNM8tIL804XvHGxPxei7qMeLlBa/w2NjIbgZOMofKC8C1DDYV5w/oLcUWG+hZKxTQ
      q3ihaONRA7GR9fzBGOVVfiN4MzuLBl1EbQvR61IkI9QElZrZJUVyjjBfa57/u2/fvr/7u7/r6OiY
      PXt2Op3mXWdd1zWCJvoTCnQARmLVKVKw3gj3VColpayvrz958qTrup/73OeWLVvG+avRbWyjvtDi
      +9K3J61gfPrQQv9hMco2uh//+MePP/54fX09F1zjTV34AJa8HMEZ7XyBStD5Gv2mfcpjSgkdOXJk
      +fLl3/zmN3mdwZrAPE4Fz6155KJhu6blbh9yHdmlILqCsQliY5DKWgeUT7E4KAh06emw4kaKX5Ji
      W3nxhYxMNwmWMrLZXoGsN7KgQBwUXDpqpo+eGDUvFJxuxEdra2tra+vDDz98zTXXnD171lir8cL8
      1V5h9ilkS7TjOLt37/7+979/+PDhpUuXGi+oiKQid8tFB7MPB5d+AC7aVK9gEWk8NEuWLPn4xz8+
      YcIETgjAC5OuS3e7W4w/CQA45urf/u3f3nzzTcgXgtWRPauLWzMX5Q8FwUvdXjFqEjS2qZ76bxnd
      jFQdUA4VssTp1eK6V33GfHEIKSUv5+fOndvQ0NDY2Ag9a7heUTAxZM/wANoKildCA9XUwMKuIAA4
      d+5cbW3twoULC8RlOVcvsR41wV38TVNTU1tbm1HkPUl/i6X/jGYdMOIokBHlvPOIyGZcz/PY7IOI
      xiSNeeDCVUiZsCWaTc9s6HAcJ5VKmaYqRMsONsYTw14fXhOw14fy1d/MAcV2nou2z+sAvmvG55zN
      Zo1hcDB/nGWsY3VAHxnsN7NMeW0MEewwPHv2LORLQRQogD70gc39vB05W4R4tykj6Xoymg3g4HQ7
      /x16sWhqLXAYD5cOZNs9W8xEvsReVNeWP3lnd4Jx2/CaoKDckF0HWAaDodABBR7aPhxQ/oWG5j0Z
      bJNFwQElxieassT+SQDg+KXo6f3xx3qex2kHfAmKBBGZZgdVKPet8QHsEuYru2G+SgRX9TFaVhcV
      ke5V+ybOx1Ql4oVXt24tqwwsA8ug64BevQ/9f74HxAheuvHBPr2ENCkeHzZTQD52pSAsBC5UAD15
      /HrqmJn8FjTYbVf7zIDrjwFvkMPwjWvdmGiKS+aVXnX11DGKlOgxicQ9uXatArAMLENqC7KWzdL0
      NP0vAR9jzDUc1B9VFQWmiV71p7i2BCcrmC+jpo9RfHMLSi3x3r/RGt0Q2Y6tWz1dun1jR2KbHgBk
      s9moJ8DO/S2Dx+gMBatAedTnLpU+kcWT53lsPShQANFG+hYbakJgTSMVPicdjFtPRJyyy585XSua
      mgv5GNwSrovSMa+81DD5JSa7sMwWLJY+M+g6YJDExEX9hBX1wgyUEanErzYm6QEc8IJ1QE+RRX32
      Nww4g9eNAjNaNMfKXLdbO2SBmahbKJJlUuxr6adj32IpzehcB4xBhkxAVIi4t1gsA4LVAaMHO0+0
      WCy9ZTTogNKybxglY38uXWwKgDLm4AP7YweqtYveoGgqg8ViGUqGNC6onJe8WzHX04llBtr3OTCm
      t5fr9pTyL1pO2OWAh2YWU+D17fNVCtoZcCPS4OkMa++yjB1GxjqgV4qhxAHDMtPs20XLyb8dDGfs
      4M39K3ONMvSNWywVxcjQAZYKwU6QLZZRxqjSASNCQg1SJ4dg6jqwPS8dSWmxWIaGSq8ZV6ZQ6Clu
      vVeNDDi9MmGVlrAXbap0TulFU3lLB/6Xzg8obr/07ShxTGVSpjOjzMGxWCqKSl8HVE7+0fAy2GEz
      dpz7QJk1IezYWiqZiqgXdNG4nYIJ5iDVXegzQ/aGlxng1P/x6Zu+GcqpfXS5Mxjj36sFaLeLMCv3
      LSOCirAF9S16cjDar7TGe2Kwpe2IkF+V00kcqjLaFsuAU+m2oArHvvAWZgS5NyyWKFYH9B2rACxR
      rBqwjESsDrBYLJaxS0XogBK+4gGZW430CftgB5aM6Fo9FXVzS4SHjtwRtoxuhsInbDxmPYWNFxSW
      KT4d+veql379ymx56GVNcWWIcuRIHyrz9P+nDWOkFiISagCB+ZbyH9AXQNp3gKRwQQkdAiFIF4gg
      FyjPk4igNSACIIFWAn1QQICEAoVDIAgQABC635qiP7EMxXGliGj2AbUKwzJkVMQ6wFJRk9lRA1Eg
      BGiiMAwJQLggJSjfRwRPgkAgDaQ1kEYCIRxAl4QkFIiYn7qTFcaW0U1FxIZaLP2BiADITNbNekAg
      EWlCkNLVGigkiQoh1IFCRNBagEBBCFITISKBJN46DSWCEf5WPVtGM8OsA+z8lxmM0spjBwEIEBHa
      eRwgHxQIRwP5gYZQOVIj6JjnkVJAClAjIQgUJIhAoeA9giWQxi6bEpJdC1hGM3YdYBlVUGT6joAS
      kAByvh8ox4t5JCFQAQIopRDAlVIAoCJwXFBEUhARAmgQ0kz/hVUCltGM1QGWixN1R1eyu7JAViMh
      KUABAICu7Ayg40xnojpZ46DwHEEB6VBokggOAaCmvGNZgAazrCBhzUGWUcxQ1wvqttRliePN516d
      WPkUBEpx9Odgi9c+tD9Ch1oDAILQDlIIpJFQSDx4/PTW/fsnTZ8+d8bE8Qknhp6vtasDIQBIIaKk
      kIAABACCNrWTen313u6XV8lq1TLqseuAYaA4uHCEitohpidZqTXxVN0MIlvytQZHuBoUaCUlpHK5
      PYfeatXizLm2BXObJ9Um4oAxLyZAkw4BAIQAjQCKAAAla2UiEqL78Dkruy2jgCGKDTU5MhSh2yO7
      PaB4p5Foa+abYnrVvd6eVU5T5ZefvOiRBSuh8tVGf34Xi7/o5bq9dNftQCDsZgQUBhqVRtJARKg1
      ICESEikiBaQQNBthCEEDIQH/DzQhAQIiILKc1wSaSGkdKlK6qzPoCBJCoSQMUfgoNAoHKHSQKEOE
      5FRlNXSibJg+Z+Wiq493pF/+4+Y9B0+HGPPRy2knq1SAJBEcpRwiBMiR8h0iqRFCXgsUD2DxOJRz
      U6IDyOPDf7Ky6WfpVoult4zsdcCAJH+NRIYsjqhEcl8xCKhJK60RMTp3dsgDAq1JSAQBRBDoUHRN
      ugEIACWypAcgRG2uDhypf/5zl4YQCAQKCAEQ0QftYCAEkcAQhA8oIQQEhxwEEAJIKV/IlBvoRNA4
      RdzesGznzl2vv/Hy0bemXHP1lRMS8YRTLUB36pTnSEmEKDwUpEiCQCV0vkdRed39CPRScA+BAdBi
      Kc1I1QF9y6HtlpHyEl40obrMEwcRIgEIInItTVprBIkCBAGFIREJT4JWgQpcGSeivBUHkboiPKmw
      1a7/ahWyTlBKASnHcQBBqzAuXNAOkAKQcZQOktDgkgIU5Gt0ABWFLoROLWJ7HYZCOuMvn984Ydym
      HTt/88obiy6dO3fatKQrcigdESftq0zWdWJSuih5uRkAAIAckGEs0N+jeKZiGRGMDB0wUqZLg93J
      YRyHMv2cF5jplAbUgJALtUQkCh0pwzAUgRYgXTcW6DDfKAIgkKnyAMhx+RhtXDuE+XQwAhCgEYQQ
      iCECShIEGilA0ABKAAF4YVbrUDrgEGkNWrnCp0S6U8ZrMwouaZo0bvykzdt3r92099Tp9JIFc2ur
      qtr8XExBfVVShyqTS8fiVQpQgkKQiBdsq9nTzy9zMEuLfqsYLENGRegA8+aUePTpYjs0lW+1KOdy
      vTpxkORyt5frjxoo09bcZ5O0sW4TEZAi4x2AFJBUQBoFxTwCiQDpbOC6WgAIRBDECbuMoPNVokyX
      BJESntIapOClRhYANUjBrggkRAAhuy4qBJDvxpQrEWTGI0IgmXVEZ5WTPquAtPQgOd4VNy2dd3Da
      5LWbt7z1ytGlV10xrbFOALRmc0nERCIhBIHKgdYoMO88EwCCEOjC8Sn96BaP55BZ8yyW0gypDijH
      7VnOu1SCi2qCgn/q9sh+9nNAKDb7RL2y/bQ7l2ihP2YK06YABCG01koFSilX+Zq80PFC4XUGwZlz
      Z8fX14HEOq01okBwAAgBATQQsAe28NIEQClU4IpzuWxHqlNpkNJFkECUIxdAA4aIEsghIgCNgsKc
      dCWGFIRIQZxa206hViRdgsBzUOXO1siECp3LptZNmXLdaxvXvbphw9zmOTOnTZ0Qi8UE+LlAhBnP
      83wKQYNECXn/BV+inJCK4vE0o2TVgKUSqIh1QEUxjHH6pSUCFm1Y2FM7gydcylpmEUCXE1UTkdZa
      VNWmFOWceEcIO/Ye2bVty/VLr1owe7oKCTmOHwAJEYlPU3jhMguQkLTWCkgRHT11csfeljOpjBQx
      IlShdmQNUYiCgIQEyV5bFCpHNZ70s6EKEAPMtWVT8yc2BrouCDqFBBeFpFCSzuaoxo2tvmrptqMn
      127efPitI1cvWoLja6qlE8eYK5ECRSC7ekP9DaWj7hLurDKwDBejUweUKcdHhI9hoOiblOmtRtRa
      gyZNIf/lOI7ruh0oUlKeTuk9B4/t2rm/463T7lWY0OCDC0iavcGRZKwQeVUABOc/aMC4FuDg5HET
      vQXVSngEUivwnJgPaQ0KUAkQQjtIgkSoUQt0tH8mlDGI1QT+uYBgWvU4FVLcGS9AuwLCIAeaEjIW
      5BAQFk+ZWBdfvuOtY29s2HBk4sSr582tj7lZCJIXTt6h6Mkpc2xHilvLMqYYzjzhyqHbqdmANNvn
      g8sZK621MRMVRJr3vrOlKJiukgOKQoECQRApRNSgEdEPA9eJadKCFGkfUIbCO5MNsomqo2fwjZ1H
      UmFqyYoVJ8fXZ/10KjydwHogkIBCCATUnGEA4HU5fsUFN0XILAIQNFQlGpOJfH+ACBBrAM7vG2DI
      ALoq6aEIBSG4MgiEdDoCqBEkQbgCXC9BYRDqIOl5mVw68J1FdbVTklXrmyb8+vU/nsll3nH1Akmd
      CI4AlQB0ARDAAyFCjcIhJKMSzMiXY4cs5+b2tOar2JfIMkIZ/nXAYDzTfWjQvlrlI0hgV3VlDUQg
      CAEItOeIUKtAE2gQ6IZAgUInkTx4pHXd5r1ubc31yxdWebD7j6f8hmTSG49BRgAisqEdBWeBCezK
      B8PzhhfSBABCCIoEjhIQp5AJcoHrQ5xHE4AEklIDYNb3Y9J1UOY0aYmawHVBh4oCX3qOq0GrnOsI
      IEgpAM9pcBqShH6qMyHjuZwvASR1BYZqIgWkwdaSs4wSKssnbKlMCoOySCDx+kMDaCShQWsgVAqE
      47gxn7xzuayMxdMKdu5u2bX34OwZM5ovmeV5cDYbkEAtRBZUUoFAEF05YISIIBA0dGUIELBgNzPi
      GIjzKgAxYj3KAnB8KQLo81/LAEIFQjoQSo2QC5XurE1WgeMFYRCXBAigMgQCHTedyojq+izA/mNn
      1u3YPr9x6orLF2mlk061G2YRpCCBAESkQRFqAA3GSWCxjFgqa/+AizpFL3pYf9RM+dGlvep2ZdLt
      uqfcH8ImqPPiOP/ZSWTT59DVKe1mvPjZLOzaseP4W4eWLLzk0pnTE45IkxZxF2XsXBBkALQnXCEF
      IBAJioSWoonCvABHE3b9EyDi+R0DqKrr/xEAtFkQoBYBaa21g46EGAhXYi5E3wXUOhvqUAAIxwm1
      CIUjquvO+XrvsVO79h+ZXDvx7ZdfUhMDCJVHErUQAjn1jVATAqHuym0ruXwsM9b5otjJk2XwGH5b
      EJQnei4aWz1Q70lPmmAkCvrSlD/sxSbpvALQ+ek6kYZzgF48oUJfxhInOmHNpl2Of275lZdd2jQ5
      iSoIU9KpTWeFAEjUjQvATQghQAoAUygCABCBtIqM/3lNEAquB5rvRleG8XnFAAAAMmItcsF1ETRB
      EISu64EnPBm2oUOEAUoZasqFkEMBJH2AnS1vbmo5eMkl85bNnFQDINIpCRQXsZA4TRlIXvzBKP85
      6UMeRoG/x+oGS/+pCB1wUeyzXjnky7QBS35CUEShRkT0ETPpIJms2v/W6Ze3Hayqrlm6eMFljQlK
      p0DmHAg8J+kE6aCz9dCBQy7WZPCcAHSEQDqvZogLTkQuBwD5qm0ARXXWAACkOt8/TQBaEACAIimk
      R+gjqJwvERKTqvW8Sa6TyylNyollCEInLoRzOqV27tnfeurU4gWXNs+YFFcQB/ASCZXuDNNnZbxK
      o0AEzjtAROx3hGj5lF5n2FfD0k+GUwf0Z2ZdsBQY8DehOKlqYNsfcVwwIFIBaACtgTSQ0kppIaWD
      CE4y+cqW3XvePD5jZvOCOU1TqkAHna4GFCIbkiNVY03toplTDp9sO7xvb1YQXBjOQwgkEEkBdDmE
      o7LeCc/XoogSgMNfCQJJZg9IjU4sFwCBDzFIYfXpjvZpbm7uqstEHBVgh69TIcVdp/Vsbu/e/a2n
      25YvWTh5yjgAcMPA8VwVAqHj1CVAKwFcyQIBAEEiSowuOAYNm0dmGWxGxjqgJwYkVcq+YxelQCPm
      A3e0BqU1aBJaA0qRTaXW7Ww5ePLczEsXLJ7bmATQqU6FYUKEJLCqqiGddYWGG5e/7awfdvoyFhda
      a6SuO6jZLyxF9I7kPwsAkBGbT9dyhOuGCkICQSCQWAcIAiTwUQehQKEDD8648U27T2f3b3K8Mz40
      tqezyks6VfhWW3rjxk0OwLXXLJ1RFwuUL8GvilVlfBWT0klUgZ8GRyIRICqTH0Bg9xezjA6GUwf0
      P0myoIViZVBQZaGA8q9bup0BoVhjDeDlynd3d3ui2UWg67MmBEBCAocAtEDX9Y61t7+8aU8u5V+1
      9MrJk6prA79ahhQLvZCUcAhcEvEgBgrBE7GJsdgUyJGjMV+Mk/J2HoCuvOF8yQgkjZokAIIkCYhd
      UaD8zwiIOS7ioxWSBqkJlAAtgIgcH10FkAv8WoBjieyhMHTCKangnJQx5WBLa2bdxs3j41XXXXH5
      +Dhq/2wMtKRQ6xClmxMiRO16oUAHQRCRRJSkgRSJEBCBCl+fvj0nfX4OrSHI0n9G9jrAUib9MSl0
      K2iISCsVakUAMa+qMwgOHTh45M0T1618+5RJ1SrMVgvpBjqV810v5jg1iCLQ4AIhaQp8REARCgEA
      XJYZBCLl3b8aEVBzdzUACdQktAKZ1eg4AFprJYQQjkMoFBABkNakCJBPkxqkJJKBdmMAipCEBggF
      qkSsFYCSNQiwb+/BDZu2zZ0ze/lVC4VSMSliolroHGoXEFG4hFJQQDYE1DKqGXQdMHhW++I5UZmW
      nzK70VN+Zv+n50NgfSp2ZvRz8KPDy9tdSSmJKBcGOsw5wpk+vWlWirZu36bil8+dNC6bOidIJRM1
      gK4KhUAAFVTHpQLtYxiGIZHycjHIm3RACIQu1y4KF0hoICGERAQQSpFSKtAhIgkhhBAgUINWpDWQ
      QEDSQEAgSUtCgQSahNQZEQCEGklrDxQ4KlF1xgUFsG9HS8u2rUsvvfSaKy4LwyBUaSDUlAQtkVCg
      dMElAIExEE435eFIRLITSg3+BScN0H2303/LADK4OqDMh74/RqE+2zf6fHDfasUMJQU97Ek79tbp
      ff42gUCURIGUMi5FTmmicGpj47J49dqNOze8vjkzb/bS+TM16sD3MaCkpwBIgq8DCqUmFNqNK405
      6UI+xFMCInTFnAoQRKSBEBFBEpESoKWIOwmttVIhIjkAmoAIpZCCNAFIFIQSQSgOH0UAgaApJhyN
      EjVASIGiNMC2LfsO7d553ZJFK+Y3B6lOgaq2Kh7oQIaCBBEhgAACgV25yGKAZK518FoqkCGyBZU5
      FbUvyZBRpp7o9mClFCICOir0CckVGAY6xNzkmsRNy69at21fy8GjaZALmpumePEY+WF41kEEib4K
      cuDlHE+jhxI0gWlYnK82ChI4TaArYoiLB4HALEBMCCE8UEprkigcFByxIwA5yQBE3rUAABJJKRQo
      QceFrNJw5sjxDWs2nD115taVN86eWJNRKhbzXAQg4YDjuEggiZCjnnivevY1RH69SUHrS3iofcIt
      lUbF+QNG0EsyUvpZTLfKuPyRF+L8Y5PLZN1YLB5zNSEFEMfwhqsvqTs87tVdh9vPhcvnNM5rSEhy
      /FxOoCfiNQHILXsPt50LE1XjOlUOER2WpZq4/BwihhgAAKKkPFxZNJ5NzZo+valhXExKHWrB+4wp
      uGD3Sq5iAVoCagmkFIRhiDruJmfV1R2urVFnzrx75XX1NS4Shcp3HAkaIKCE5wBoBNE1W9EBIiJK
      Oi/rKTI+rBj68gCMoCfcMhYYXB0wZI/7YF/FWmCjSCmVBlKB40jXdaUURFppCkPtJUQYZhfOmODU
      12/ZtnvT5m3qstnzpo7HWCIkHYDbEYYbdu3O+Dh1ysww5QOAQLb/nP9vIBQQm5s4OUABaiRIylym
      flxYV59wUQDmtwzjBQNxvSAkIOAsM9QqcKQHqBzUOZ1rGpdYteKaWBzGJ13l+64UwhGkfAmOkEIr
      JSUSgEIAQgkCSAOQwsqbKFksA8fYfbz7mWM5gqZyfeuqGZ/iUcoGvhAAIAHJcxwSggAdQcIJO33l
      iXgMYFot1V41p2XbofWb3+xsPzN3brPrOZ2h8kF4VYnpzTMWLpjjakVEqBUiCiREFGSKxAlEiV1p
      YgowJCIv9OKuE5O8hSRIAEQFiApCKQC1YDMSF3dDAAcBlIYwcKuECANPxqZOSCrQkpTnSaGV0AoI
      XQ4j0iFQTAEQB6aiRBSaxGDfZpvraxleBl0HROVIn+XmRd+TPrxFvTqlt87t0uf2VHOmOBXropfj
      LQR4vVUiV66cXnV7VrdddYUEAEKnq8daAWkBytfFGFHnAAAgAElEQVQiKT0ipUO/jnRdvKru8kt2
      7T28Y1/bMX/f7IWz4p7na0gHWA16qgZJKAiFIyVCfq8YgAsN7XmLvAss4Ikg1AgakYATtwARpcau
      CE4kEJjPPdYOoKKYDsLQ01LpNEinK8ZfgQBE4QqBGkCwAgKSXd4I/qWIQA5Fa5Vi1LNVHB0w4EEN
      I2iqYRmhjIx1wLBPlAY7R2zYf2Av4dpt+dEQgstoJlyplQpVGHeFIPDDTJ1bffm82U7N+PW7tnVs
      p8UL5wFAJt3pgKoWEPohp5kJAQKQEIiQELkIQzRrjGGHAWDI3mItMFI7tDuEA4gESiACuggSuNoP
      t8z5yTRgg28N/ZaRyMjQAZbKAjVPg7uEMiEgCJQq9B0ppZQIOi4Aw5BUzsHY5Kk110+6du3Gvb//
      /cbL5jfXJauECigkj5QgELrLfA9AgAIoXxyOo3LyheIAADAEgQCaBGrkDeiFBhC8igLIy+Au9YQo
      AQnRE0SIUpIH0HURPir/H4tl7DJ05Q/7Rrc1wiqWgZ0GVuykUgB1RU9ytQZOFwCB6AA6iFIrQhIx
      x/UQMMg2SjHRg8vnNjVPbti3beuB/S2xWExwuCjfXxQgEIQERJ68n/+fQBD5eH8pSBBIAcg+YSlB
      iPw8JlLLU3fFBiFqFNwxAS6H8ggEBGn+x99xtaFhGUyLZXix64ABZmBdfBXvMOyKj+wykktXEwB6
      wnVIB6FSAoXnODEFHob14xNzx09f7/qp9mOEjgLQQgAIR4BEUzYOEVFfKI6J07YAEEmQREABSISC
      BABKAt3NCGlCUCAE73cGKLpKfgJpTbLrhKIdiC2WMUel64CCufCwCMQ+lwDrVVGKEv9aUWogsi6L
      BsiTJiQEUrwbjNAo2VGtFXl+UJOkANKulsvmzZk1eeK4mhrfDxzhABAiAArEfJJYV4Xm87lYZtde
      QRLym82gzm/nSxep58Pjx1sedJmKBkj02wLjllFApeuAAobmNet/QdMyKbP9ng7rrW7oqXZTiW50
      q4FII4fgnx8oBAAtCUGiJghDjYIc6QA4CkC7kM3lHAedUFeJYFJ1POZQTEFIhKCRhECNgACE+rxF
      JyKp2V1MDnEGMWGX/NcAAhDMnjMFe7xLViiISKKrJAUCgMYLlYY5qw+6oXjoKk1nWyylGWE6YGio
      ENE/7PRcczs/AWdZh4igAQl0iOhJAQIREDRpUj6CG8ZBhbGYiAk/lKRlTJOfcjWCE0cgQaHgTeqx
      q8JD1+oif3VibzHv4wUEQASEyHvMKACRrzEBed3QhUD+CfmdKrsi/6krDnUQ7sJIubMWi2EodMCY
      fTGGrD7oReeepXvS05qAgx27yVoQdEE8DVGXiQYFQT6cnhwEQAkA4JLrcmx/Qmiu8C9ioeAMYT4L
      TeUg0jofvFn0E/gb6tIVZtpOPfx0zjUzf+VPj0b8AwycaQh6Xpn1lBFSToNaa7hwbWrXGZYBxK4D
      Rj/DHq0UlVlcd7rgX3uVGTfGseNjGVisDrAMHQXptSbndsgcMCMRK/Qtg4rVAZYLiCa7DlTiK1sz
      TJs9CbX+7HQ2spTHyOqtZXQzpDrgojOavpmty2y8/wz2PlADFQjbT5NxgWWm/wNbECzbbSxN9HOZ
      Vyzo5wA+Ev0pD9WfBi/aiF0TWAacyloHlJjQjbWnv5+/t8xNe4YG3pIeIqXx+M9uu9cHBWC+GUAl
      bafqljHCSM2PLxABFSLsRj39lIzW92uxVBojVQcwfavWO3YY9oggc2JByOkQlIGyD4bFUg4jUgcY
      mWJEyQAqg2HZkqy4/71KITaB/APSw24vAf3wDXR74oD3dgDLigyG7rxoRRDIW/yt9rIMJZXlDxhi
      BtvJNuzvc4XYWwY8EGgkUiH3wmIpYESuAwaVYbRRFMyXx5SIHE0U275624JVGJYhY0jXAReN+elt
      8bIy2y99SvnvWx9SmfqwFIiectFg2T6HUY30QMMBeR4GJPiqxL+a9nsKio32BC/cqNJiGRoqwhbU
      z/KZQ09pyd4H2VQc5tSfH1umEBmyHIvBdlQwfXA5DLYi7KbUUnkd6/YYqxssg4G1BfWR8quDDWz7
      g0rlaNkhY1hqxBarfFstwzJcWB0wPIFA5fRkMGxfFhjyO17+5bo90gZAWwYVqwMqi8EwAVkbQjGV
      o/h7i9UHloFlKPwBBdbti/rHBqMD5nM5RuRyXuCe+t+331XsDCyzHVOGAQB0vvJ+f8a2OE2hxGjw
      FLW4HPQQEzWklHPv+jxPL5PSBZFKHB8tqhH1JxcnxFgsA8VQ+4QLnuzShw1G2lfpV6hvzroBx871
      +kxUm9q8BIvlogxn3dBiNdBTFaAhdtwNl4ywsqlMyvSU2CmzxXJRRp4/YAhW7pYKpyff6UXPsv5V
      i6WAkacDLBaLxTJQjDwdMOALfGsxGIn0IYVqaOqVWiwji6GuFVE69CVaorLbAwaJMh0PA9WrMn2V
      Iy5vaLB9sH2o6mGxWEoz1HFBRg2UGS03IJQfG1pOkYah0U9WivUNW3TPYukVQ2QLKsiG720cDhbR
      h+t2S7cmheKz+mBDGEAB1NMPZ4WqteYgff5XzhLgL80pfSuMo5TiiHUiUkqZdqSU/A23b/ISLtr/
      3nYAev7tPR3ch0tcFK01ROL0Xdc17mXuGH/gAelD+2YM+a7xNzzgBYf1/7dYLAVUhD9gQB7uIZ70
      lWN97k/75YS+CCGCIGDpn81mWRIJIXK5nJSSxbdSijVEsUyJNtstjuMY6S+EiIpC1gRhGHLjF1UD
      Pf2ivo3DEMMjGYah0Xmu6/JQ8wjwYY7jlFYDpYdIa23uWhiGrusO6I+wWLqnIuqGViC9SpcdRoxE
      9jzPcRzf9wEgFotBfhYvpSxYKHTbSLffa6211o7j8GduLSr1DJUgqQcPHj0pJQAopcIwDMOQFaTj
      ODxKZsFU4lEpMUqsR007nuexxrVYBpsRqQMqROIMtmMgmujU07KABTRP9nkiaewSLP35SxYuve0q
      IrKky+Vy8XgcAMyygyf+LAGJyFx3AH52dz8ThtUSwustKSWvfni+77quEdOsGh3H4dvR0zgXrJai
      1lFuWSmltebFhGnc2E4rdiJiGdGMSB1Qjue2P/QkcCvwDQzDkKeo3LdYLMZCnyetRu7zNDNaXKgc
      jJE6Ho+zUYhXG7zCMKPEV6zAwRkoeDHEQ6G1rqqq4gFhqc1DzdIfSj4nfGS3GDUAAEII13VZ6ULR
      016Zz6Fl5FIROiA6ISr/lNIRPgPYn2JPbK9O7/PVS3xpOsZWaQBQSqVSqUOHDi1YsODUqVMTJkw4
      e/ZsGIae5+VyuRKGoNJIKbPZbHV1Nc/0W1tbOzo62EPA09UScq34J0QH5KKKvKIkHU/GWfOdOHHi
      5MmTyWQyDMPq6urTp0+HYZhIJHK5nOd5rJW7baRgSRf9wEs313WFEPF4/OTJk6lUquDE6H8tloFi
      OOsFdXtAr9SA+Vx+pGn5Z0HvpX/BKb19Xcs/3kgTlkqIWF1dLYR4+OGH//Vf/9VMFaPOzBL97+l7
      1jGO47AucV336NGjANDU1MRmcc/zjPyKCr4yHQ+DLc56235P48C+X6VULBZzHOfZZ5/duHGj67rs
      wkVE3/dd181ms7FYjI1y5bRv/uQBTCQS/E0Yhnv27LnhhhuMh9nO/S2Dx+AaVfpAt/0p5wUocWJp
      HVD+29VbHTDYsHknCAI2VmzYsOHQoUNCiPb29h//+Mfz5s27+eabWST1LTST4yDj8fh3v/vd1tbW
      j3/841LKpqamxYsXV1dXZzKZqqoqFn/GFcEnjlCBVcKOL6XM5XKIeObMmU2bNp07dw4R//CHP+za
      tet973vfpEmTUqkUewXKMbiZ8TEfpJRtbW3/93//t2DBgquuuioMw/nz519yySXmxgkhemvKs1jK
      oSJsQRelnHlQt2uIEWRt6AM8P2VzkFJq6dKlV111lZQylUpt3Lhx6dKl73nPe8zBvZ1LRgX63r17
      d+7c+b73vY9dxNlsNpfLsej3PA8ijoe+XatC6GmNaLy1QojGxsZbbrmF1WpNTQ0ifvjDH+6buwUu
      HOSzZ8+2tLTcfffdCxcu5BtqgnS5ZRObOxLH1lKxjAwdYOkJFr482VdKsU0mk8mk0+lsNmsSu/iw
      XgmpqAU8nU53dnb6vs+yyTghzCJjsH5excA/mYiCIDDJE6lUKp1OGzcAm4bKGWezPDX3jldvbW1t
      p06d4tlMEAQmRcAMuMUy4FgdMLLhWaERJTyvZH0QDVo3IqzMZk077PI1wUUcG1MQBUSRdNkB/4GV
      AIt1DogyihYRgyAwCXT8jRnw8lvmG8feYNYl7GCItmPCQ8eCurUMMRWnA7oVJQP16FeaE3KgLsrx
      Oey/xQuBokp85cPGB601G3/CMIzFYiZbCnoWdqNAVBU/h1ElykLfKNe++bqjijmqR5VSQRBw+Kk5
      uCeflsXSTypOB0A/HvFRKeLLwTgMuYfF83ToZedNO9w4Zz9xs2ygKGhzVIYtFv+cgnGOKlro02yd
      TzeaQCkVj8ellLFYLOpjL91mn5dfPbU5WtdzQ8OIewsqUQdY+kD0ySuYnPbKmhxdNJjPnBwLESfB
      iHvQB4QCfyyPQ7f6oCe6XZPxqCIiJxtDvvRQObkXAyuvrfQfg1hH02jA2BOguwJw0Kd3m4hYBuk8
      xiswNiVFgYiPenShu8yvXmEcCWEYcoNRBWDuY5/bt1h6wuqA0UPUEFE8Py1TdkTPijo8TUnLPiuV
      UUaB06WcRQB0t1ww8j0IAnbndLtoG5sLL8sQYHXAyAYj+cBGdmC+4ljUJ9wrI7X5YOzUZkMCimxL
      YKGiPZH6PDIFor8nZ0Cx+2EAsXd2DGJ1gMUyAFjRaRmhWJ+wpSz6P88dfQzUCmC4sAY9C9h1gKUE
      I06oWSyW3mJ1gMXSL0buOsBiAasDLBaLZSxjdYDF0i+igTrD2xOLpQ9YHWApRYHb02KxjDJsXNDo
      hNO7GCPH+2CwLq4J2rd2Riu8c0B0TAo2EihQn93WcTJZF3y6rRJqGUrsOmDUwtLE7GtYuuhYtzP9
      MAz5Q7RWqC1kbzAFulmO81AXjA9eCH9ZUPuB92DQWodhaGqR2nG2DA32ORuFsCgxld3MdgLFdYSY
      nrJDuX4Zyyb+xlQNsgAA188w9ZRYTXLBn26rNvUED6+pzFpQgMhiGVSsLWgU4nkeV56BfIm3MrOZ
      CuQOT3KZ6KY0FoZ1Z0EV1YJin8VDHR1k/sxloqOi3xrcLEOGfaVHIcU26KhRqAQ9CaxoVaKop2GM
      Q0S+7/POX1LKMhdJpsac+cbs0Gn+LL/Gn8XST6wOGIX4vm+mk0opYxoyB5SwTnRrvy6oHT34v2Bk
      wOW12WLG+wx3q0SLh7qg1GgQBMbjYlWsZYixtqBRCNupeToZ3Y6qt+aF6LZZjuNQfvfzge/xyITt
      Yzyqrusa70uv9n5BRD6X9xCOxWJmTWDNQZYhwOqAUYiU8tixYy+//HJ9fT3PMaFsE3P0GN48XUr5
      xhtvSCnLEW1jikQisWPHjp/85CfG+wI9bIhtiDpmTNytUiqRSBw+fHj37t2sAMbsRj2WocfqgFFI
      PB6/+eab//jHPz711FPV1dVCiFwuV0KC96QbwjD0PC+VSkkp77jjDhMGY5cCzMyZMxcvXvz88897
      nsez+Hg8Xo7fBYp8NkSUyWSam5snTpzI3yil2MrUEzZ9zzIgWNfT6CSbzfJG8Byq6DhOCcFdwjeQ
      yWTi8TjPVYUQYRhGcwXGOOxricVibPQPgsB13RLjbAxHBv6Tb5YQIggCbq14O8mesO9vpTHiLHh2
      HTAKSaVSyWTS/FngEC6mxFMbi8XCMHRdl4hyuVw8Hh/Ijo5wlFKxWAwAcrkcALD4LnF8T1b+eDye
      y+W01rFYzCjvQeu1xXIB9lEbhQghfN/P5XKxWMzzPI4O6sM2gWyOyGazkPd5dpsKO2aRUqbTacdx
      4vE4R4gWh2AVY5wB/CciBkFggoLYf2MNbpYhw9qCRiEsQTigk7/hCJ8SNp9uv2ejBFuB2Nzhed5g
      dXoEwsafTCaTSCQ4Roidw+X4hKPHcCgRjzavAPiztQWNRKwtyDL8mCBODup3XZe/7+3TyUsHz/OC
      IGBLBQAopaw/gGF5baJvTXTQRce5YE1WMPH3fd91XTvIlqHBrgNGOf2sOlBwulUABYRhyJqAR6b0
      aJf41z7fJvv+Vhojbh1gbY6jkIJ6cP1pxxSx4fxVrojQ/x6ODthfEi0YZ1wm3dLTveB4oaifwEp2
      y5BhdcAwU2AaZlEbFQRGphRHlPOH6AHR8j7mzwKpVFCWkj/wdfm/0QMK5rZssohWH+IP0ar33Za9
      jB5/0TqaQ0BBf/hzQTW3bn9C9Naw9cZkU0fH2VRaLWi8+IdTZOcAc6Fo7H/BUEf7Y24E5ncgMMUn
      zDfmkTDNGpVjLs0hA9GaRZaxg9UBw4BSimfW/DZGJ49SSn6B4cJKbeZPjkmH/GvPUShaaz4r+g5H
      w3iCIOAvOcCfX36lFL/2XPeG5TvHpfi+XyA+ok5mTmRlJ4GRg+aHsCIxvTUX5W4XVNsfeoiI+wN5
      qcpd5cAeyFfe5u/5TkUlPp8elbBRx7sZEM7MgHzYDx9gRHNUH5jRMLe+IOXY6AO+UBiGfOPMSEbV
      DN84z/NMz/mY6K+TUuZyORMjgIjcW9Nny5jC+gOGgW5n61w80ljb+Z00MTlm9m0OMDKoYO7G2oVt
      FCx5TVV6I1/4Mx/GFy0ORuRvcrkcxwLx8ebIgimkESimh9lsNh6PGyu50Trm4OGKfSyYFxu9xTkQ
      FKnfYH4s/9d03pwYvV/R22G+N94CM7wsmqPh/wXfcKyR0e7cICstvpvmSN/3uYCH0QdQ9FRwa9Gb
      azpvWtZas87gPluB0E9G3FrKrgOGATPBhAtlaGdnZ0dHRxiG/Kp3dHS0trayLMhms/xscU3QdDqd
      SqXMLB7yG8Vw+zyh49eeBZnv+ywmuLwlzze5DBzLaBP96fs+t8One54XFS6Q1zF8XZ5Osijh3yWl
      9H3f9/14PM5h73wtbp8jZ4zoGZbB535ms9loz13XNTNl/mlG9PMBLCKz2WxbW5sZq6h7nMcWEVk0
      53I5Fs38r7x64GZ52M2MmyuPcj6H1toEcfGljUAxywuzHZDneXxzTWCSEd+IaFozCgwihjv+bxAE
      juMYBWCl/9jExoYOA/zeGllj5qTnzp174okn7rvvvilTpgDASy+91NHR8ed//ueUj+/kygRa63Xr
      1mWz2ZtuuklK+eKLL27fvj2ZTBp94Hne8uXLm5ubo7L+6NGjdXV1LEQ4o3X79u1bt26VUs6aNWvR
      okVVVVWcVnb48OEDBw7U1dVprauqqlKpFE9CeVI5b948RHzzzTcbGhq4jARLmWw2q7U+ePDgnDlz
      OIrUTPxPnDiRSCRqa2shv9wZrjwDo3fj8fi+ffteffXVmpoavhesXGOxmJSyvb09mUx2dnbOnTt3
      xYoVkDcQrV27dv369Q8++GAsFlu7du327duN2tBap1Kpd73rXdOnT8/lco7jBEHgeV5bW1tVVRWX
      WuIjDxw4sHXr1iAImpubL7nkkurq6lwuh4ixWMz3/b1799bW1k6bNs0ss4wHJZvNdnR0KKWmTZt2
      /PjxvXv38k3nQNJcLmdm/TNnzmxoaDhy5EhHR0cqlQKARCKRSCSampoSiQRr+qNHjzY0NLBW5ktE
      V5zDcncsw4LVAcMAiwOeqSUSic7Ozi1bthw9ejQMwz/84Q/79+9/4IEHdu3a9Z3vfOe222576qmn
      fN+/8sor58yZg3kPwblz57hIGQCcOnVq3759tbW1/G57npdIJK6++mrITxsRccOGDd///vc/85nP
      NDc3E9GpU6e+9a1vHTp0qKamRinl+/64cePuuOOO6667DgBee+219evX19TUsKw/cODAypUrlVKZ
      TGb27NlNTU0nTpz43ve+99GPfnTx4sXGq5FIJJ5//vlPf/rTDzzwwCc+8Qme9XP+1NNPP33s2LF/
      /Md/jHophysV1szfn3rqqTVr1nzqU59i2Tpu3DgASKVSWuuGhoaamppf//rXr7766ooVK9hHwquH
      Y8eO8eltbW379u3j6XMQBDzRTqfTQohYLJZKpeLx+C9/+cu1a9f+1V/91fTp0wGgo6PjkUceMe73
      P/7xjwBwzz33XHHFFTwmHR0dDz/88KxZs77yla+Yah+mQNOhQ4c+/elPr1q16lOf+tSRI0eeeeYZ
      x3GqqqqOHDnS0tKyfPlyIUQmk6mqqvrQhz40YcKEb37zm4cPH16+fPmZM2d43dnW1nb//fdfccUV
      APC5z33u3nvvXb16tdEcnKFmFcBYw+qAYYCX3rFYjC0GbPmpqqqqq6v75Cc/mUwmv/zlL996660P
      PfTQhAkTiOjkyZMsyh3HaWlpUUodPHiwtbV1/Pjxl1122V133fW+973PGA2i63p+vcMw/PnPf55O
      p5uamgAAEb/0pS/t3Lnz85///Nve9rYwDE+ePPnVr371kUce+ed//ufLL7981apVK1asyOVyyWTy
      v/7rv1paWj74wQ9WV1dnMhnXdSdMmNDS0rJhw4b3vve9Zh3DM9/nnnvOdd3XXnvtjjvumDJlSi6X
      SyQSWuvGxsaf/OQnW7duZZ3BZhNj9BiuW0BEixYtuu6669atW1dTU5NMJlOpVENDA5vRlixZ0tLS
      8vzzz7Or4NixYy0tLXv27GltbV27du2CBQtuvfXWVatWRf0xvIriST0vI5566qmpU6dOnjwZ8vL9
      9OnTn/nMZ+bPny+EaG9v/9rXvvaFL3zhsccea2pqYu9LS0vL1q1b77333mXLlhl/AK8D1q1b9+yz
      z86dO9dxnEsvvdQo2pdffnndunXvfOc7m5ubz549i4jTp08/fvz4/v37r7jiio985CNnzpypqqo6
      ceLEE0888U//9E/f+c53xo0bN3v27Mcff3zlypWJRMK4GchuETH2sDd7GGArOb/AUsr6+voZM2ZM
      njxZSjllypRZs2Z1dHQ4jtPc3MxmhMWLFzc3N7Os6ejoeO2115555pktW7bs2LGjvb09Wp8g6tkz
      QSYHDx5cu3bt/fffz3akZ5555vnnn/+P//iP66+/PhaL1dTUNDc3P/TQQ1OmTNm+fTsRjRs3bvr0
      6Zdeeum0adNmzZpVW1vb3Nw8efLkWbNmTZs2DQASiUQ8HjcVhHgRsGPHjh07dnzxi18Mw/D555/n
      2SsLlDvuuKOpqemHP/wh//bhyjKLznDZOMN2qjVr1mzevPkXv/jF448//vvf/37jxo2vvfYaW1rM
      ouHkyZMvv/zy+vXrjx8/vmHDhgMHDhjvCOR9JGzM4c2ciWjLli2pVOqd73wna7uf//znu3bteuyx
      x5YtW1ZXV1ddXd3U1PTFL36xoaHhBz/4AdcN7ezsnDdv3uTJk1988UV2okA+aiCdTj///PPXXHNN
      JpPxfb+urm7mzJmzZs1qamqaPn36uHHjZs6cOX78+OnTp8+cOZOdGclksqmpafz48bNnz540adKS
      JUseeOCBI0eO7N+/HwDuu+++Y8eOrV27FvJPC+Qjvobh3liGD7sOGB54LmxsNUT0+uuvsyvVcZz2
      9vb9+/ez0zUIgiVLljQ3NwOAUmrJkiVXXnnlnj17Dhw48MADD6xfv/7zn//8pEmT2MITj8d53xjP
      86677rrFixeHYfjiiy9OnTp1/vz5ACCEeOWVV97xjnfMmjXL932e/eVyuZkzZ/6///f/GhoaeOJp
      okcymQx3ODo9ZF+liZfnwqI//elPGxsb3/Wud23ZsuWFF15473vfW1VVlU6nudToLbfc8o1vfOPc
      uXM1NTUsKKPRLINENP4KIru78MgHQVBTUzNp0qQHHngAEXft2rVp06ZbbrllwoQJfPzmzZvZ0y6l
      vPzyyy+//PIvfelLQRA8+OCDu3fv/vrXv+77fn19/YkTJxzHqa2tZQ/zqlWrLrvsMkT83e9+V1tb
      u2jRIvbJP/fcc/fdd19TU5OJENVa19XVffCDH/zqV7+6a9cudrQg4u23375z584tW7YsWbLEbFP8
      6quvnj179vrrrz979qyx2PDNymQyZiIvpeRIMPa48FSDPfCxWKyhocHzvKNHjwLA9OnTr7zyyt/8
      5jc33HAD3wjjBrfmoDGF1QHDAIs/U2Mgk8kkk8mPfOQjPBcbP378r371q5UrV956660dHR0cH9Le
      3l5dXc3ytK2tbefOnS0tLd/+9rc/8IEPvOtd72ITxE9/+tOqqqply5ax65gdy47jbN68uampqbGx
      kSXavn37/uzP/ozlIE8A+cPs2bNZWGB+B0r+YCz+PNs1mQHs+OVfkU6nf/3rX3/yk58korvvvvvj
      H//4Sy+99I53vIP3VHEc58orr5wyZcr+/fsXLlzIcavRsJlBoicFYyKC0uk0AJw9exYAjh07duLE
      iePHj3P8z8SJE01gFes83/e3bt360ksvPfnkk9dee+2NN96olGpsbHzwwQfnzJlz1113BUHQ2dnZ
      2NiIiKlUqqOjY9GiRTU1NQCwa9eu9vb2efPmsXufQ6eqq6sBYPr06Z7ntbS0zJ8/n2P/3/72t7e3
      tz/11FNLliwxRrMnnnjixhtvdF138+bNJrIzmpzBgUam6lwmkzG6XAjBFv8XXnghFouxT8hxnEWL
      Fv3ud7/jtU42m2Xfsi7a5MAyurE6YBgw8Zq8/9TTTz+9fv36uXPn8ns7efJkRHz99dcPHTqUSCQ6
      OjqCIPB9/5577pkxY4aUctu2bfX19ffdd9+ePXt27969dOnSDRs2LF++/PDhw5MmTVq8eHFbW9uU
      KVPMLucnT568+eabeT6byWR2794di8Vc1+3s7OTAHpMUhvmEJo4ZN8GR/E+Q34qAA3uy2Sy3GYbh
      r3/963g8fvvttyPivHnzbrzxxnXr1q1atSi7Qb0AABAgSURBVIoP1lrPmTOnurr64MGD7JDkpcNw
      jT/3SgjBk+VHH310586dnZ2d7e3tv/3tb8+dO7dixYrPfe5zvCbjnyyE2LlzJwDceOONe/bsmThx
      4s0333z06NGpU6deccUVV1999dy5c7dv337ttdfyJTKZjFJq1qxZAKCUMv5/HmEhRHV1Nfsk2P98
      5swZjhbjXt18882PP/74qVOnxo8fDwAvvPDC6dOn77zzzmeeeYb3KojCFkXz01ht8MYPL7zwAlc2
      RcTOzs7nn3/+Ax/4wMKFC3ndMGvWrLa2Nt5tgkPFhkAxWyoNqwOGARadXNmfjTbLli2rqalh/206
      nT558uR11103a9YsTgvg5fzEiROllMePH9+zZ8+MGTMWLFhw2223CSF27dr1yCOP/OxnP+PoxnXr
      1v3v//7vX/7lX86dOxcAMpkM+2ZNBEtjYyOv9000SBAEvMJgfcBzXhYlPDcsqA/BQodhafLkk0+y
      CWXXrl2I6HneK6+80tLSMmfOHJb1Usq2trbDhw+bQRh63yPlEXnY6PHFL35RSrlmzZoDBw5cddVV
      mzZtmjNnTk1NTVtbG+QXE77vv/HGG3PmzEkmkx/60IeSyeSrr77685///Gtf+1o8Hvd9f+3atY89
      9tgTTzzBbvBcLrd3797Vq1ebig48GYd8ZLBJzmLJy8JXCJFOpxFx9erVP/zhD59++umPfexjQRD8
      6Ec/WrhwYVNTkwkGg3yYP/uWTCoy5E1evKXBW2+9tWbNmkwmwxHAn/3sZ2+44YZMJmOevTAMOzs7
      q6ureTlotONQ3hfL8GJ1wDDAIoC9iPx5z549hw8fdl133Lhx7e3tTzzxxLlz5+bPn9/a2sqCY8qU
      KePHj3cc55VXXjl16tSCBQt8329ublZKPfLII+9+97s5KTeTydxyyy2/+c1vtmzZwjogHo97nnfm
      zBleE9TV1V199dXbtm279dZbOZUsFouxT6K9vT2Xy02ePNmkqrIs49B4NhGwncFxnFQqFQQBK4B1
      69b94Q9/uPPOO7/1rW9lMpna2tqTJ09yUA3nKLiu6zhOLBYzSbNsjh/GVGGW7CaFChHj8XgqlWpu
      bt65c+fTTz/9tre9bdy4ccZE/tvf/nbPnj3XXHPNnj17OEj3e9/73vz58zn+lYhWrFjxP//zP//5
      n//5yU9+khdPRtkg4uzZs+Px+J49ey677DKKpCIDwI4dOzo7OxcsWMB9M9lzt956649+9KOPfvSj
      Bw8ePHr06Le//W02MWG+sISpdMSKnMU6j63WurOzs6qq6v777//whz8czetmiW/qeXiex4shc4BV
      AGMNqwOGARM9wh9isVgikZg7d248Hq+pqfn3f/9313U3btx4+eWXL1269OzZsxy/zy9/GIZ33333
      8ePH33zzTSI6fPjwtm3b/uIv/gIAgiDg+f7y5ctffPHFlStXTpgwARGrq6s5gYslflNT089+9rNP
      f/rTJk/NcZzOzs6vfOUr1dXVDz30EHsX2NwvpTQTee48LyaEEFVVVSwvvvvd71577bX/8i//0t7e
      jvktiJPJ5MaNG/mz1rq9vb2qqmr27NlmEIY+OijqHGYhyHm/b7zxRn19/b59+3bs2PHcc88h4oQJ
      E7Zt23bu3DnjKSWi97///UqpHTt2aK337Nlz9OjRP/3TPwWAzs5OtqRde+21v/rVr1jI1tTUzJ07
      t7W1FQBYsy5ZsuSXv/zlbbfdZvbjZO370ksvTZw40aQIJBIJViof/OAHn3zyyaeeemrnzp0NDQ1s
      VsJIWY4C5y3ly1TwB9d10+m0SRc3VeE4JY2V0+nTpz3Pq6+vBwDWBFzhw/qExxRW5w8DbGrnmbXW
      etKkSStXrvyTP/mTFStWnDp1qr29/dFHH73mmmv27t07ZcqUG2644eabb7766qtZHN91112XXnpp
      JpNpaGgIguDLX/7yVVddxSlInudxUuiCBQva29v37dvHUq++vv7AgQOcBBuG4erVq8+cOcMhLsYk
      8otf/OKNN95oampiCzjmyzmwpzGbzfIc0+SshmHIp+/cuXPt2rV33XVXMpmcPHnytGnTLrnkksmT
      J69aterw4cMvvvgiX2LNmjXt7e0zZsxg+TK8tSJ4Hs1OESLKZDKnTp2aOHHi9ddfn81mPc+bN28e
      Dy8fj4i33HLL29/+9s7OTsdxzpw58+STT06dOnXZsmVa63HjxrHpbPXq1el0+ve//71Sqr6+vra2
      dvfu3QDAS7R777137969jz32GBv0eYfOn/zkJ2+88cbtt9/OY57NZn3f5wfDdd0777zzs5/97LPP
      PvuZz3yGvehMVB+b6CyO4OLVAACwgk+n0+x54hUYr05MNNrWrVsbGhpYSfCNZsVvGVPYdcDwwG5Y
      Du1Pp9PZbPbAgQMvvPDCpk2b3v/+999www1XXHHFo48++uUvf3n58uUrVqyYOHEiG205xp+ne62t
      rVdeeeV73/tedvZms1lOOps0adJdd901btw4lhdvf/vbf/rTn7755pvTp093HGfu3LmPPvroV7/6
      1RMnTqxatYpDTTZu3HjPPfd85CMfYfsyixKWRIlEAiJzZ3YGVFdXs9R46aWXhBCrVq1iyZXL5djy
      s2DBgmQyuWXLltWrVyPi3r17ObMJhjAIvSA21MDDiIisJjkgp7a2Np1Oc5AMW+oOHjzICjKbzXKJ
      BW4znU7PnDlz5cqVYRh6nnfy5MlJkyax7+Tuu++eOnUqu16amppee+2106dPjx8/Xko5f/78v/3b
      v/3BD35w/PhxDsfcs2fPzp07b7vttttvv51PicVitbW1ZnDuueeer33ta1VVVYsXL+aOmSIcxoQF
      AIlEorq6mk1AkNdwvu8nk8lEIsFOZqVUNptNJpOsfePxeCaTaWlpYSe2SRUegptiqTSsDhgGeCpt
      pmwHDhz47//+7927d8+ePfvv//7vr7zySqVUbW3tww8//Nxzzz377LPPPPPMsmXL7r33Xo4SYXHc
      2tpaVVX113/911przhc7fvz4/PnzpZTJZPKd73wnAHCpuJtuuukHP/jBmjVrZs+ezVUNVq9ePW3a
      tLVr1x45ckQpNXHixH/4h3+44oorRL7OKORFyZIlSyZOnGjMx/yhqanpE5/4BC8+5s2b99BDDzU0
      NLAEMdE+EyZMuP/++/mss2fPrlmzZvXq1fyvxvQ82DGIxe3zxJn1aDqd3rlz52uvvXb8+HHXdVkx
      UL7eRk1Nzf79+zkmypT6CcPwzJkzU6ZM+ehHPyql3L179969e8MwnD9/Pgvl97znPSx/Pc9bsWLF
      iy+++Nxzz33oQx/ibPA777xz3rx569atO3z4sOd5PERLly41w97Y2PiJT3yCLWb8DHzve9+rr6+n
      fN3Am266iQNGzR70juPMmDHjb/7mbzzP46Ag1hNEdP/999fV1ZlVXTKZjBYZXLdu3fHjx9mcxcEI
      HCZARZVoB5BiK9MQJIgM5RVHIrZ29PDAdhVesO/bt6+lpaW+vn7hwoVcJYZfcn6lOzs7161bx9Hc
      DQ0NAICI27dvz+VyCxcu5Be+paXl1KlTRLR48WJTZ4Ynd7wU+MY3vvHCCy9861vf4hwlbjwMQ47v
      rK2t1RfuYG6cjbzCSCQSHDeC+TJwJsvJeDXM7zK2CLaluK77zW9+88UXX/z6178+a9YsXsGwgWhI
      RzzSPZ5Tv/766+l0euXKlWycUZEdVBzHcV133bp1ra2tHNvDI3no0KFdu3bdfPPNXE712LFj7e3t
      x48fv/rqq+vq6nio2doOAEKIL3zhC1wjqL6+ntUJ+3K5tIbxGPOfbKVhZWC8vqaGDw8a3wt2xZvh
      ZbscL9d4eE21cMrXhWVDk+u6fMVUKvXggw9OmjTp0UcfhYgbQJe3kX2fsTqgArE6YBgwJX14Hgf5
      UjOQrxMZlY8mWJOlBm84zvH1Wms2U5gELiORzfvMf7755pu/+MUv3vOe90ybNs3khRnTP0Q8ipBP
      AohmjWJksxTOGjObBLBRJRo5ygdwzjP3/De/+Q0AvPvd7+YD+Meq4diamPvJMtT3fZabRsKacYiO
      BiszlsiO47CIN3kD0V8RzX/mf928efPmzZtvuukmXjNxwSXWBKYzJhrHVBEHAPa1mAKrbMBhyS4i
      mwpwN8x9N6G9Bcsssz+M2ZGis7Pz8ccfv+WWWxYvXgz5zW3MnhODOv4F31gdMOxYHTAMGDs1O1dN
      AD4b4iGfSAyRja5EfhsvntnxAWy5psguYOb9N/EhRmSbrcH4ctFSDaxX+BKQjw40xetZVLHKofxu
      JyZ/1WyqFd0XBQDM1gJCCHYSFJS5H5aqQUbc68imLsbUoyO7LfLvYtFpfjsAsLTlwWepzUslDn/i
      yCsjc3mxFV30cAcwD0R23eFB4xEzCwK+vyaNgIU45KcRZq2A+dRuigSecgtGTxTodW6N3RtVVVUm
      1miwx7/gG6sDhh2rA4YHIxp4zxYzLxb5/UnMkSK/v2PUhGIMDibtiEUVv/ZGT0CkgAxEwkg4nBzy
      EpwPZslljoxa7c3ChSUOS0AzeYS8FuEe8iJD5zdHNJUhWJDxVYbrPaQ8/KPYei4ie8JQvvSejuwK
      ae4I7zzDv4h/L1cVhby44fE0WdCsEiC/AST7G0y0FRuUosYfld+8jOW4uZvGNAQX6s7oU8QrDNNV
      I82jnl4TiQCRrXK4kWjg7KCOf8E3VgcMO1YHDAM6X34nOu2KTh5FfuMn/mB2fCQis4NgdL5vVvH6
      wo0eIRLywQYNU6TITELN+28mpDqy66QREOYYY5TgqSV3rNvYG4zsqmhM5OYAGkzfY08YER9NUhOR
      vS0pXzKP5bjZBC0ajgn5cTMe46hsNbrEaGXK+1rN7NsI6+i6LWoU4msVLNQwX8nDOBIgotWit9Is
      NLkdY3LEfEAR5XdFDsOQM4pNlpnVAWMNmx8wDBjjA//JE9KC7Tt4el4wO6P8ZoRRccAB4GF+x3aV
      L9DPJ5rUXE7T5e+5ZTOLN25euFArsFoypiFzdciHk2N+kzLzDSsJyE9X+XSMZDYxbPQYrPHtGb6o
      2ZHRqDfTPdMrE+ZkRsDY5Si/awL7VETRppsUca4iIuuSqJg2yymMuFKM7jcqB/PFWaNrDrbaUSQz
      gBUtW9sg/5AY54EQwpxu7pEx5cXj8Vwux+YmYy0c4ptiGV7sLR8ezATZ2Byi7jiK7BzS7dy5wFtr
      voT8rNbIIzP1i7ZQsFwoPix6regGIwX96badgt8S/TkFvR1s63MJVA/bwUN3N6Lbs6LfRBdh3d5H
      6GH6GW2/eA5e8BgUL/L0hRvEF7QGeY0VvWvmz2ivun0qBgO7DqhArA6wWCyWsYu1BVksFsvYxeoA
      i8ViGbtYHWCxWCxjF6sDLBaLZexidYDFYrGMXawOsFgslrGL1QEWi8UydrE6wGKxWMYuVgdYLBbL
      2MXqAIvFYhm7WB1gsVgsYxerAywWi2XsYnWAxWKxjF2sDrBYLJaxi9UBFovFMnaxOsBisVjGLv8f
      wRG+oxHC8dcAAAAASUVORK5CYII=
    )
  )

  (text "DEFAULT  ：美标" (at 304.8 120.65 0)
    (effects (font (size 3 3)) (justify left bottom))
    (uuid c25f1433-5b46-4d74-90db-c586af38b471)
  )

  (label "VDD1" (at 60.325 63.5 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 000ad725-da2f-4d6c-b95e-8e7a87123be0)
  )
  (label "R_N" (at 213.36 193.04 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 01a75cda-3568-42ac-ad13-641205a7f346)
  )
  (label "SPK_R_P" (at 151.13 198.12 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 0eee254b-e9f8-4911-99c7-4bb040c28184)
  )
  (label "HP_MIC1_P" (at 91.44 96.52 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 0f1af398-3d8c-4e84-82ef-b123a7b07f69)
  )
  (label "HP_MIC1_N" (at 246.38 132.08 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 1dadc3b7-1188-488f-ae19-0cdaac1f14ac)
  )
  (label "MAIN_MIC2_N" (at 91.44 109.22 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 25ac98ad-d19a-4750-85e3-11817a66d8ab)
  )
  (label "HP_JD" (at 91.44 104.14 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 27c4eba3-6482-4d25-9c57-9e45ccae4e2c)
  )
  (label "SPK_L_P" (at 149.86 181.61 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 3065b5eb-6d03-4e87-b1a2-423ff33099db)
  )
  (label "R_P" (at 213.36 198.12 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 3686e986-db29-4eee-ab97-e3c03b5d414c)
  )
  (label "HP_MIC1_P" (at 246.38 142.24 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 3e0de1fc-c343-4e57-b572-b2a127cc22cc)
  )
  (label "HP_MIC1_N" (at 91.44 101.6 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 463f809b-05cb-433b-88ac-43d565864cff)
  )
  (label "MICBIAS" (at 105.41 168.91 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 511f59d8-d753-47e3-b2c7-2c23f55af0fa)
  )
  (label "MICBIAS" (at 255.27 118.11 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 63cfdcb3-efec-43e4-a1be-0c5414154142)
  )
  (label "MAIN_MIC2_P" (at 133.35 182.88 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 69c119bb-24cc-48eb-8aee-fcf393ff03dd)
  )
  (label "HP_JD" (at 263.525 83.82 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 7154809a-5f6b-46c8-ae41-6cd3170d9815)
  )
  (label "SPK_L_N" (at 195.58 106.68 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 723b1b7f-c60a-4391-aaf6-5086ec3d458d)
  )
  (label "SPK_L_N" (at 149.86 176.53 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 757e7126-dc05-44c9-b7cb-f4f07fc7d64f)
  )
  (label "MAIN_MIC2_P" (at 91.44 106.68 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 7d3b440c-3390-4afe-8cda-f27e55d99da4)
  )
  (label "SPK_L_P" (at 195.58 104.14 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 8921dc0b-be11-400d-87be-bb37d8438dc0)
  )
  (label "MICBIAS" (at 232.41 66.04 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 8e38b89b-eaac-4f15-a8e2-5c83132a6480)
  )
  (label "MAIN_MIC2_N" (at 133.35 193.04 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid a46c5b44-849a-438d-bbda-985c27d090c7)
  )
  (label "L_P" (at 213.36 181.61 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid a9afda0c-a111-4496-9ee4-ab9c274397bd)
  )
  (label "L_N" (at 213.36 176.53 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid b008ea01-097e-4f7d-917d-39be0708c572)
  )
  (label "SPK_R_P" (at 195.58 111.76 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid d79773c8-c0c3-4041-8981-ca9f00f6609f)
  )
  (label "SPK_R_N" (at 195.58 114.3 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid d8b78409-0f4a-4619-ab12-c830cfc33426)
  )
  (label "SPK_R_N" (at 151.13 193.04 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid dfc6bf05-abed-42a4-8b0b-7301e7e45185)
  )

  (hierarchical_label "I2S_SDA" (shape input) (at 96.52 115.57 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 151dea3c-2853-4cbc-a107-124861655089)
  )
  (hierarchical_label "I2S_SCL" (shape input) (at 96.52 113.03 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 4edae8bb-a00a-4b1c-820c-ff4338f77397)
  )
  (hierarchical_label "I2S.MCLK" (shape input) (at 97.79 88.9 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 7aa54324-fff4-453b-94ae-90ddd81cf7a6)
  )
  (hierarchical_label "I2S.FCLK" (shape input) (at 97.79 78.74 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 7c370858-87c3-437a-a092-f41ff7078cc9)
  )
  (hierarchical_label "I2S.BCLK" (shape input) (at 97.79 81.28 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid d0a4cff4-d5b7-4387-9706-f3f9e2984bec)
  )
  (hierarchical_label "I2S.TXD" (shape input) (at 97.79 86.36 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid e93337db-db1d-45e1-b3a0-046d21bc31ff)
  )
  (hierarchical_label "I2S.RXD" (shape input) (at 97.79 83.82 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid f8a015fb-4302-4a92-9549-d44feac07975)
  )

  (symbol (lib_id "13_HPM_Audio:PJ-316A-6A") (at 338.455 91.44 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 020ddfaa-c02b-4c25-a215-c64d0ce3e600)
    (property "Reference" "J?" (at 332.105 82.55 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "音频连接器PJ-316A-6A" (at 326.39 102.235 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "10_HPM_Audio:SMD_PJ-316A-6A" (at 340.995 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 338.455 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "PJ-316A-6A" (at 340.995 106.68 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "韩国韩荣" (at 338.455 104.14 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 338.455 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid ae001164-957d-4148-8084-2b37dbd8637b))
    (pin "2" (uuid 74abd760-4d0d-4a07-b8e8-be86707a256c))
    (pin "3" (uuid 370ace2e-3994-4580-b936-3bf3b58468a8))
    (pin "4" (uuid ff450175-eba1-41a0-a8e5-195a072b1702))
    (pin "5" (uuid 23e127a3-758b-46ec-8d19-a9b94ed55a42))
    (pin "6" (uuid 63f38438-020c-4235-8edb-21acaa1e5f51))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "J?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "J?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "J10") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 86.36 50.8 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 03a76c40-cbdb-4194-a102-eb7249bb1d67)
    (property "Reference" "C?" (at 88.9 49.53 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0.1uF,16V" (at 88.9 52.07 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 83.82 36.83 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 86.36 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 85.09 34.29 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 86.36 39.37 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 86.36 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 140add76-892f-4221-9fdd-cca0417d3d75))
    (pin "2" (uuid 4001a6e2-6e61-4371-b571-639423860c69))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C218") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 255.27 125.73 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 07d784cb-92ac-4aa0-bb88-c527cb93de21)
    (property "Reference" "#PWR?" (at 255.27 132.08 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 255.27 129.54 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 255.27 125.73 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 255.27 125.73 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid c804b2b0-6f70-4fdd-924b-1dfee28ff3d4))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0344") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:2.49K_0402") (at 208.915 100.33 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 09b94175-6109-4fa0-8b49-4f9c2cc46298)
    (property "Reference" "R?" (at 209.55 96.52 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "24.9K" (at 209.55 104.14 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 211.455 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 208.915 100.33 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RC0402FR-072K7L" (at 216.535 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YAGEO(国巨)" (at 213.995 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 208.915 100.33 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 5c18a76d-df68-42c2-91ab-c837df10058d))
    (pin "2" (uuid f77d965d-ecfe-41ea-8d30-763811f8735c))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R261") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:220pF,50V_0402") (at 252.095 100.33 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 0d061f20-819b-4d64-998a-dbbcefa02936)
    (property "Reference" "C?" (at 252.73 97.79 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "220pF,50V" (at 251.46 102.87 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 255.905 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 252.095 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402B221K500NT" (at 254.635 110.49 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " YAGEO(国巨)" (at 253.365 105.41 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 252.095 100.33 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 90f0b12e-465d-4c88-afb2-aa54cc2e0e3e))
    (pin "2" (uuid 6e3217f8-445c-4410-bb9b-4158d00a9359))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C229") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:10uF,16V_0603") (at 101.6 67.31 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 0e8feaaa-d4f8-4583-bdcf-8328c5419a15)
    (property "Reference" "C27" (at 101.6 64.77 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "10uF,16V" (at 102.87 69.85 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0603_1608Metric" (at 102.87 72.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 101.6 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL10A106KO8NQNC" (at 101.6 74.93 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " SAMSUNG(三星)" (at 101.6 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 101.6 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 0f5746fe-688c-4dcb-bb3b-c7663bb11cbd))
    (pin "2" (uuid f69f4a67-a70c-413c-956e-008a0d2de79b))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C27") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:钽电容_100uF, 6.3V") (at 193.675 91.44 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 18697ae3-d00e-4061-a5a3-ea40e5ae3932)
    (property "Reference" "C227" (at 188.595 90.17 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "100uF, 6.3V" (at 201.295 90.17 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:CASE-B_3528" (at 194.945 85.09 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 194.945 80.01 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "TAJB107K006RNJ" (at 193.675 80.772 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " Kyocera AVX" (at 194.945 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 193.675 91.44 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid ec1ff681-c8df-407d-a1c0-c0814ccffa24))
    (pin "2" (uuid febe6f97-516b-487d-9e33-9ad22b892a4e))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C227") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 73.66 67.31 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 1c4db724-fc89-4384-994c-aba368a6ac65)
    (property "Reference" "C?" (at 76.2 66.04 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0.1uF,16V" (at 76.2 68.58 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 71.12 53.34 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 73.66 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 72.39 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 73.66 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 73.66 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid e9690efa-0926-44db-bb7d-1ffe17c473f1))
    (pin "2" (uuid d7430aa3-9896-43c8-b0e3-108e585626f6))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C221") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 101.6 72.39 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 225c6abd-cc17-42c0-aefa-c6756328e0b6)
    (property "Reference" "#PWR?" (at 101.6 78.74 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 101.6 76.2 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 101.6 72.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 101.6 72.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 29a62165-b1e0-425d-afa7-5fb930ca08c4))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0333") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0603") (at 304.8 107.95 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 22abe756-1b3e-48c3-8933-cc965eae3e7b)
    (property "Reference" "R?" (at 299.72 106.68 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "0Ω_0603" (at 313.055 106.68 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 302.26 105.41 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 304.8 107.95 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF0000T5E" (at 303.53 102.87 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 303.53 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 304.8 107.95 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 04f34f55-fee7-43af-ad8a-bb5c30d5e270))
    (pin "2" (uuid da9b92db-9016-4b47-ad68-2045e1641109))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R263") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 252.095 107.95 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 23561df3-fbcf-484a-9972-ffeeaebd372e)
    (property "Reference" "#PWR?" (at 252.095 114.3 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 252.095 111.76 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 252.095 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 252.095 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid ad068820-281b-465f-bf7b-2f915f4980a0))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0339") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 272.415 107.95 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 2ac48eef-3beb-44ff-be84-799b60372f25)
    (property "Reference" "#PWR?" (at 272.415 114.3 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 272.415 111.76 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 272.415 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 272.415 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 1a9a549c-3cb1-4ffe-b114-3c794cdf39ac))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0340") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:33Ω_0402") (at 113.665 86.36 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 2acfb5c7-bd8d-48b5-bae5-faa9b8808a5e)
    (property "Reference" "R?" (at 107.315 85.09 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "33Ω" (at 118.745 85.09 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 113.665 88.9 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 113.665 86.36 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF330JTCE" (at 113.665 93.98 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 113.665 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 113.665 86.36 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 0a1242e3-da72-40bb-9ac6-7b52f09368b6))
    (pin "2" (uuid 9eedbe2d-c97a-4c52-adc1-607e1f789151))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R258") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:220pF,50V_0402") (at 272.415 100.33 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 331a7476-5439-4ae0-9cf5-791b61ca89f4)
    (property "Reference" "C?" (at 273.05 97.79 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "220pF,50V" (at 273.05 102.87 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 276.225 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 272.415 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402B221K500NT" (at 274.955 110.49 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " YAGEO(国巨)" (at 273.685 105.41 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 272.415 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 6bc4253a-5ec4-4186-9198-70ebd4743705))
    (pin "2" (uuid 76aca6b5-b6dd-485d-bfe9-ffd1b8c6e231))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C230") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:33Ω_0402") (at 113.665 78.74 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 37d36ebc-af00-4dcd-8afc-cc77a4f25894)
    (property "Reference" "R?" (at 107.315 77.47 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "33Ω" (at 118.745 77.47 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 113.665 81.28 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 113.665 78.74 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF330JTCE" (at 113.665 86.36 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 113.665 83.82 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 113.665 78.74 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 0e76fe75-5d61-47d5-92a7-02aea94b3117))
    (pin "2" (uuid 13890890-1067-4b26-b520-7856da1d5dd4))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R255") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 219.075 107.95 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 3f72d436-88d9-419d-a7d8-58c688347bd9)
    (property "Reference" "#PWR?" (at 219.075 114.3 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 219.075 111.76 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 219.075 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 219.075 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 174ef05a-b136-405f-9087-87519a7aec0f))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0338") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:+5V") (at 45.085 62.23 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 3fc77966-e783-4165-a24e-cacf00548db0)
    (property "Reference" "#PWR?" (at 45.085 66.04 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "+5V" (at 45.085 58.42 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 45.085 62.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 45.085 62.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 10bf46b5-b44d-4475-9c4b-379a853999ef))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0331") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 312.42 91.44 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 4ae07ccc-c2e3-4088-b25c-614850c1df09)
    (property "Reference" "#PWR?" (at 318.77 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 316.23 91.44 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 312.42 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 312.42 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 21a047d1-9a98-474a-80b4-5ee90c5340cf))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0337") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 71.12 50.8 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 4d782c8b-339c-453b-8b7d-bd72e052bf72)
    (property "Reference" "C?" (at 73.66 49.53 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0.1uF,16V" (at 73.66 52.07 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 68.58 36.83 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 71.12 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 69.85 34.29 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 71.12 39.37 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 71.12 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 60d4faed-94df-4213-a2b4-d19f50532a1f))
    (pin "2" (uuid 400a3f03-2737-4c7c-bdd6-6002a2354659))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C217") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "05_HPM_Connector_KF2EDGR:KF2EDGR_3.81_2P") (at 229.87 191.77 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 51d98b58-439a-4337-8278-08bac58c4ef0)
    (property "Reference" "J?" (at 232.41 192.405 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Value" "KF2EDGR_3.81_2P" (at 229.87 196.85 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Footprint" "05_HPM_Connector_KF2EDGR:PhoenixContact_MC_1,5_2-G-3.81_1x02_P3.81mm_Horizontal" (at 227.33 199.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 231.14 194.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "3.81绿端子" (at 227.33 205.74 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "BOOMELE(博穆精密)" (at 227.33 203.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 231.14 194.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid e7935a04-1831-41e1-8ecd-d1399152279d))
    (pin "2" (uuid 598fb697-4e6b-4feb-bfe7-5e2979f634da))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "J?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "J?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "J12") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "99_HPM:270nF,50V_0603") (at 113.03 182.88 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 5965f84d-96b3-4ece-8140-e8cc0b351e63)
    (property "Reference" "C?" (at 107.95 194.31 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "270nF,50V" (at 120.65 184.785 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 120.65 179.07 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 113.03 182.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " 0603B274K500NT" (at 123.19 180.34 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 118.11 181.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 113.03 182.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid a3513a8f-1b32-4c11-b5ea-664aaa053556))
    (pin "2" (uuid 099b071e-9e39-45c0-9cbe-4715ebf55d69))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C236") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 57.15 50.8 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 5bb296ac-3842-41bd-9d14-c6678549d576)
    (property "Reference" "C?" (at 59.69 49.53 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0.1uF,16V" (at 59.69 52.07 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 54.61 36.83 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 57.15 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 55.88 34.29 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 57.15 39.37 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 57.15 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 0e3190cb-e516-45ef-9142-6597760d1e7d))
    (pin "2" (uuid e87af819-e2f7-411a-b699-5c677126658f))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C216") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "13_HPM_Audio:WM8960CGEFL/RV") (at 137.16 55.88 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 5cb25bfc-cf1f-4a13-8b9e-32540830b493)
    (property "Reference" "U?" (at 150.495 50.8 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "WM8960CGEFL/RV" (at 150.495 53.34 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "10_HPM_Audio:QFN-32" (at 152.4 125.73 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 137.16 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "WM8960CGEFL/RV" (at 152.4 123.19 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "Cirrus Logic(凌云)" (at 151.13 120.65 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 137.16 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 83bc4389-79fc-4994-b7c0-494eded7c876))
    (pin "10" (uuid decc3008-a8e3-4623-8194-f6927f563534))
    (pin "11" (uuid 3cdd9cf0-d6c3-4b02-89e1-a71a6bf2f238))
    (pin "12" (uuid 6c910496-c3ca-4ad8-8164-adb9c3e49a7c))
    (pin "13" (uuid a8c1bb37-a520-42c9-9661-771706b4219f))
    (pin "14" (uuid c0cdd8b4-5046-4222-a815-587cca27d6ef))
    (pin "15" (uuid ae78e6dd-a02b-4859-89dd-f042e9796738))
    (pin "16" (uuid bea897df-712c-4028-85a0-add98c2318bb))
    (pin "17" (uuid 342454d9-b57d-495f-9d69-d1794e966d8d))
    (pin "18" (uuid efa39b28-fbee-41e6-b339-1296ca317095))
    (pin "19" (uuid 1952bf4c-2971-489a-84f6-005dff5bed3e))
    (pin "2" (uuid 71a5a21c-8b0c-4884-b81c-aa5e1b454f0e))
    (pin "20" (uuid dda6271f-5bf4-4a2d-92c0-2c2c523a3ad1))
    (pin "21" (uuid 639d675e-bb65-4a44-bb61-0cebc5810b3b))
    (pin "22" (uuid 395efd60-2c4e-490d-ad8b-ca3af5ec1244))
    (pin "23" (uuid 1d243ed8-2f1f-46bf-a610-7edfae3e52e5))
    (pin "24" (uuid c25a34cf-dfeb-40d5-9bc9-37c249683ed2))
    (pin "25" (uuid c86eeb26-1ceb-455c-b589-07cc83dcaac8))
    (pin "26" (uuid c0b8a273-ffdc-49bd-9306-48817d11feed))
    (pin "27" (uuid f7fd5367-bf57-4b07-8e48-a55a32de45da))
    (pin "28" (uuid 09ec181e-75ea-4ccf-8c74-df66517743e8))
    (pin "29" (uuid a3d7e2b0-a28b-40eb-9320-3457d7bb4878))
    (pin "3" (uuid 4c77db8f-f363-4f15-bdfb-1ba8dc6878a7))
    (pin "30" (uuid 76d4a4fa-9475-4ffa-8ff2-378a1a893c0c))
    (pin "31" (uuid f0ce349a-4b7c-49a1-aefe-57909f303ff1))
    (pin "32" (uuid f7aa21b2-466b-436e-b48d-1f711616cb1f))
    (pin "33" (uuid 937c95ef-02f0-46f3-8801-800c1bfd2142))
    (pin "4" (uuid 4dbba575-7cdb-40e9-b519-2decba6a936e))
    (pin "5" (uuid 4165c5c7-3267-4312-a885-d43033d97940))
    (pin "6" (uuid 0eec7df3-f101-4fbc-ab88-e6b9bafa19be))
    (pin "7" (uuid ab7c7f89-523e-4e76-95ff-85dce4b7e45e))
    (pin "8" (uuid 58c3ed5a-f9f0-4382-b5f3-e4bfdd338d63))
    (pin "9" (uuid 4eb1c472-f06d-4028-8420-8f9054ed4b3e))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "U?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "U?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "U26") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "05_HPM_Connector_KF2EDGR:KF2EDGR_3.81_2P") (at 231.14 175.26 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 5e79861d-cc9b-4c54-b267-901a76a8ccd5)
    (property "Reference" "J?" (at 233.68 175.895 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Value" "KF2EDGR_3.81_2P" (at 231.14 180.34 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Footprint" "05_HPM_Connector_KF2EDGR:PhoenixContact_MC_1,5_2-G-3.81_1x02_P3.81mm_Horizontal" (at 228.6 182.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 232.41 177.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "3.81绿端子" (at 228.6 189.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "BOOMELE(博穆精密)" (at 228.6 186.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 232.41 177.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 59c2ab49-04fa-4750-bae1-dabfde788535))
    (pin "2" (uuid 89a089ec-00e1-4e8d-9194-499864d5c283))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "J?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "J?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "J11") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:2.49K_0402") (at 241.935 100.33 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 6287d95a-f4be-445b-9fda-6e630c771f27)
    (property "Reference" "R?" (at 242.57 96.52 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "24.9K" (at 242.57 104.14 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 244.475 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 241.935 100.33 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RC0402FR-072K7L" (at 249.555 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YAGEO(国巨)" (at 247.015 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 241.935 100.33 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 1ee34162-7509-436c-90be-811a54180c80))
    (pin "2" (uuid 700e2080-7cc0-4e7e-b706-db329191440d))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R262") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0603") (at 290.83 118.11 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 63db979e-8017-4f29-8c35-bf6827d764e9)
    (property "Reference" "R?" (at 289.56 123.19 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "0Ω_0603" (at 289.56 110.49 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 293.37 115.57 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 290.83 118.11 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF0000T5E" (at 295.91 116.84 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 298.45 116.84 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 290.83 118.11 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 98c82613-cff2-4acd-8d2d-e7731854337e))
    (pin "2" (uuid a4c36a8d-1ea8-40b6-91f5-008dcf227e40))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R264") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 200.66 76.2 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 6837ce43-8149-40f2-8e77-05dab040f7d9)
    (property "Reference" "#PWR?" (at 207.01 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 204.47 76.2 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 200.66 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 200.66 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 20021788-5440-4a4c-89c6-438c871521bd))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0336") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0603") (at 299.72 91.44 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 6e50e45c-5aed-4fab-abd7-460536175c08)
    (property "Reference" "R?" (at 294.64 90.17 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "0Ω_0603" (at 307.975 90.17 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 297.18 88.9 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 299.72 91.44 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF0000T5E" (at 298.45 86.36 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 298.45 83.82 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 299.72 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid c250924d-95f7-4f18-9dc8-77f76daeee23))
    (pin "2" (uuid c9a2558d-40dd-4559-bd80-9cf8491f1aef))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R260") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:5.1K_0402") (at 95.25 127 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 709c4b4d-9a0e-4c50-b449-7dcaeec79dc2)
    (property "Reference" "R?" (at 90.17 125.73 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "5.1K" (at 101.6 125.73 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 95.25 129.54 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 95.25 127 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF5101TCE" (at 95.25 134.62 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 95.25 132.08 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 95.25 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 42ad5357-8a19-4e30-86af-d0a0a9fd0447))
    (pin "2" (uuid 0102df97-de6b-4cdc-837d-b04fa5c1efc8))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R267") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:33Ω_0402") (at 113.665 81.28 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 71efa229-d1b1-47ee-aedf-4b6b90144f0e)
    (property "Reference" "R?" (at 107.315 80.01 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "33Ω" (at 118.745 80.01 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 113.665 83.82 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 113.665 81.28 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF330JTCE" (at 113.665 88.9 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 113.665 86.36 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 113.665 81.28 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 98f3b319-74ed-421b-80c4-8c07cb788ec0))
    (pin "2" (uuid 4cdcbc80-77c1-432a-a3ff-ec0a3e201191))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R256") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:VAUD_3.3V") (at 272.415 72.39 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 72ceee7f-5a8f-4150-a98e-e5464d5d9ea1)
    (property "Reference" "#PWR?" (at 272.415 72.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "VAUD_3.3V" (at 272.415 68.58 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 272.415 72.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 272.415 72.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid bc6bbc6d-49c4-4873-93f9-d26a5cd20c82))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0334") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:1K_0402") (at 278.13 137.16 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 7495a942-3203-45f9-9d60-a1b1a3319a38)
    (property "Reference" "R?" (at 280.035 135.89 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "1K" (at 280.035 138.43 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 280.67 137.16 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 278.13 137.16 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1001TCE" (at 285.75 137.16 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 283.21 137.16 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 278.13 137.16 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid f37d8263-851f-43f9-9473-93dcbb7686ba))
    (pin "2" (uuid 74c20c79-3914-40b2-943b-6dfc91cb823b))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R269") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0603") (at 51.435 63.5 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 759c8913-c26e-4242-b1d9-ea885ee5396d)
    (property "Reference" "R?" (at 51.435 60.96 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "0Ω_0603" (at 50.8 66.04 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 53.975 66.04 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 51.435 63.5 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF0000T5E" (at 52.705 68.58 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 52.705 71.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 51.435 63.5 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 7742b0b0-0ec5-4e7a-8673-12ee4f13218c))
    (pin "2" (uuid 6e1af7ec-510a-4af3-bfae-935b287043d5))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R253") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0603") (at 294.005 118.11 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 799220c1-2908-439f-8c67-168922902be7)
    (property "Reference" "R?" (at 293.37 123.19 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "0Ω_0603" (at 293.37 110.49 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 296.545 115.57 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 294.005 118.11 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF0000T5E" (at 299.085 116.84 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 301.625 116.84 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 294.005 118.11 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 0c78aed2-e42e-4a64-9261-daa5424a93ea))
    (pin "2" (uuid 8ee979a9-9057-43ba-ad3a-014dd1b7369f))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R265") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 170.18 67.31 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 7a180d25-978c-4c5d-8667-21a6945dc9d9)
    (property "Reference" "#PWR?" (at 170.18 73.66 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 170.18 71.12 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 170.18 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 170.18 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 166b4627-9835-4cb9-9e4a-613beb0b6f50))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0332") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 87.63 67.31 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 7d2bd5bd-bde9-43ac-94f2-1c287918b41e)
    (property "Reference" "C?" (at 90.17 66.04 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0.1uF,16V" (at 90.17 68.58 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 85.09 53.34 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 87.63 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 86.36 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 87.63 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 87.63 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 8a53c068-13b0-4616-9d93-5f3a4cdebab7))
    (pin "2" (uuid bf04878a-0d55-49d9-b779-33c91c393da3))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C222") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:+3.3V") (at 83.185 121.92 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 7ded7a66-7be4-43eb-9536-08a03e151d28)
    (property "Reference" "#PWR?" (at 83.185 125.73 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "+3.3V" (at 83.185 118.11 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 83.185 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 83.185 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 15a679a5-29fa-4ede-9e16-56ac531bf173))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0343") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:+3.3V") (at 41.275 46.99 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 7e9299de-ea3a-458a-8dd2-425bc65ee2c9)
    (property "Reference" "#PWR?" (at 41.275 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "+3.3V" (at 41.275 43.18 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 41.275 46.99 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 41.275 46.99 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 04053010-71b7-434b-b613-147b70d77600))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0328") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:33Ω_0402") (at 113.665 83.82 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 85d8d98b-967d-411a-b1b9-7d16fb73533a)
    (property "Reference" "R?" (at 107.315 82.55 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "33Ω" (at 118.745 82.55 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 113.665 86.36 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 113.665 83.82 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF330JTCE" (at 113.665 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 113.665 88.9 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 113.665 83.82 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 1bcf3d87-35cf-4df6-9126-75300e763903))
    (pin "2" (uuid fc05f6e0-cf5d-4794-8127-16960053ee8a))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R257") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:5.1K_0402") (at 95.25 121.92 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 86f7490e-6ed8-4212-b02e-b60aa6640ec8)
    (property "Reference" "R?" (at 89.535 120.65 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "5.1K" (at 100.965 120.65 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 95.25 124.46 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 95.25 121.92 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF5101TCE" (at 95.25 129.54 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 95.25 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 95.25 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 10751a02-5703-4376-880a-0d5982a7fc61))
    (pin "2" (uuid 1c90cf2d-f749-4043-b298-38c3f2b7c08b))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R266") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "07_HPM_Inductance:磁珠-600Ω@100MHz_1.3A_0603") (at 168.91 176.53 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 8c5d9bb7-13a0-4d62-a99a-cdecdeacebfc)
    (property "Reference" "L?" (at 167.64 175.26 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "600Ω@100MHz_1.3A" (at 173.99 175.895 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 171.45 182.245 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 171.45 176.53 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "BLM18KG601SN1D" (at 172.72 184.15 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "muRata(村田)" (at 170.18 186.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 168.91 176.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 991ca8ee-a678-4d8f-927e-e5a1572a2a9e))
    (pin "2" (uuid cd593901-2e17-4f10-86d1-5b89954eeb7a))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "L?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "L?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "L10") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0603") (at 46.99 46.99 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 8fa9e82f-4aa3-43c9-a8d4-940b93359662)
    (property "Reference" "R?" (at 47.625 44.45 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "0Ω_0603" (at 46.355 49.53 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 49.53 49.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 46.99 46.99 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF0000T5E" (at 48.26 52.07 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 48.26 54.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 46.99 46.99 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 44e6c6b5-9a20-46d3-ad57-7cd4638874b4))
    (pin "2" (uuid ed5fd37f-9956-4732-aa35-f92e7631f212))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R252") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "99_HPM:270nF,50V_0603") (at 113.03 193.04 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 921bf874-8325-4bb9-be82-a955339b9523)
    (property "Reference" "C?" (at 107.95 184.785 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "270nF,50V" (at 120.65 194.31 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 120.65 189.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 113.03 193.04 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " 0603B274K500NT" (at 123.19 190.5 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 118.11 191.77 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 113.03 193.04 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid e9193a61-6e52-43fc-8731-e17dddffc862))
    (pin "2" (uuid 04cbdcca-4c4f-4ce4-873a-9f87357b8b94))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C237") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 96.52 204.47 0) (mirror y) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 94dc2389-1ced-4620-8e76-51a3995cad3d)
    (property "Reference" "#PWR?" (at 96.52 210.82 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 96.52 208.28 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 96.52 204.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 96.52 204.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid f265de04-2e92-44cd-be52-1d52b98046e7))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0346") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:10uF,10V_0402") (at 101.6 50.8 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 962658e3-fc54-4c6c-b984-9ce5dc3dc930)
    (property "Reference" "C?" (at 104.775 49.53 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "10uF,10V" (at 104.775 52.07 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 102.87 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 101.6 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05A106MP5NUNC" (at 101.6 58.42 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " SAMSUNG(三星)" (at 101.6 60.96 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 101.6 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 243f566d-21b8-47da-9024-b089c5e4c2fa))
    (pin "2" (uuid 989e17b1-bea9-4eef-823f-79aef7b86116))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C219") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 101.6 55.88 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 975735d9-e004-4bad-ae72-382297b0cf88)
    (property "Reference" "#PWR?" (at 101.6 62.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 101.6 59.69 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 101.6 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 101.6 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid da297bc4-3ab1-4256-8459-0407341a0b1c))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0330") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "99_HPM:270nF,50V_0603") (at 265.43 142.24 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid a1948178-9b8b-4f33-adec-97408cdb8681)
    (property "Reference" "C?" (at 261.62 140.97 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "270nF,50V" (at 271.78 140.97 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 273.05 138.43 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 265.43 142.24 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " 0603B274K500NT" (at 275.59 139.7 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 270.51 140.97 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 265.43 142.24 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 657c766a-115c-4e9a-8d27-4e88bfae3ab0))
    (pin "2" (uuid 1034f0a5-1002-4379-95b1-b0b65df1684e))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C234") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:10uF,16V_0603") (at 232.41 69.85 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid a2366199-614c-4bdd-b4eb-da3194c211d3)
    (property "Reference" "C?" (at 237.49 67.31 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "10uF,16V" (at 242.57 72.39 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0603_1608Metric" (at 231.14 64.77 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 232.41 69.85 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL10A106KO8NQNC" (at 232.41 62.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " SAMSUNG(三星)" (at 232.41 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 232.41 69.85 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 680f4269-2891-411f-8c0a-9194a6b0c52c))
    (pin "2" (uuid 55defc41-0d18-433d-9638-e7f035ad1761))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C224") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:10K_0402") (at 272.415 77.47 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid a78942f9-d50a-4878-8f16-cf5cf736b729)
    (property "Reference" "R?" (at 274.955 76.2 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "10K" (at 274.955 78.74 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 274.955 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 272.415 77.47 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1002TCE" (at 280.035 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 277.495 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 272.415 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 4eb52f9b-29c7-4c94-97e4-56e8a3dc144f))
    (pin "2" (uuid 26d8f6d9-f4aa-4edb-a5e4-54a1382b9ad4))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R254") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:4.7uF,16V_0603") (at 187.96 76.2 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid ad7a0c5a-8a00-4186-9056-5747c0f678fb)
    (property "Reference" "C225" (at 182.88 74.93 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "4.7uF,16V" (at 194.31 74.93 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0603_1608Metric" (at 193.04 74.93 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 187.96 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL10A475KO8NNNC" (at 195.58 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " SAMSUNG(三星)" (at 198.12 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 187.96 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 627d5a8e-2847-4a0a-83d2-5335674d779f))
    (pin "2" (uuid 0d1434a9-1893-4565-9b78-b0805041abee))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C225") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "07_HPM_Inductance:磁珠-600Ω@100MHz_1.3A_0603") (at 170.18 193.04 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid b80b35b4-c578-41c9-a622-37a9fe32f2a8)
    (property "Reference" "L?" (at 168.91 191.77 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "600Ω@100MHz_1.3A" (at 175.26 191.77 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 172.72 198.755 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 172.72 193.04 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "BLM18KG601SN1D" (at 173.99 200.66 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "muRata(村田)" (at 171.45 203.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 170.18 193.04 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 5340f19d-003d-481c-b794-4653ef0ad297))
    (pin "2" (uuid a00eb360-2d2b-47f7-8755-69f5c2b1661f))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "L?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "L?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "L12") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "07_HPM_Inductance:磁珠-600Ω@100MHz_1.3A_0603") (at 170.18 198.12 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid bac6764c-e5c5-4469-a250-bc7e4e12c231)
    (property "Reference" "L?" (at 168.91 196.85 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "600Ω@100MHz_1.3A" (at 175.26 196.85 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 172.72 203.835 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 172.72 198.12 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "BLM18KG601SN1D" (at 173.99 205.74 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "muRata(村田)" (at 171.45 208.28 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 170.18 198.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 92f4710b-d19c-46cd-9de0-e1f4bdc2eaaf))
    (pin "2" (uuid 28813590-5d04-4521-be2e-03725675cdfc))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "L?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "L?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "L13") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:1K_0402") (at 96.52 198.12 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid bdc0500c-f083-4768-ab7b-0654e7fdbd3a)
    (property "Reference" "R?" (at 98.425 196.85 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "1K" (at 98.425 199.39 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 99.06 198.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 96.52 198.12 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1001TCE" (at 104.14 198.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 101.6 198.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 96.52 198.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 83903d9e-f5a9-49f6-bc75-9a9b28c2b856))
    (pin "2" (uuid 26a27520-c5e9-45c4-9569-969a34015381))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R271") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:钽电容_100uF, 6.3V") (at 193.675 86.36 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid c1d9d507-b9d0-4106-a50e-52ffa8fcc7c8)
    (property "Reference" "C226" (at 188.595 85.09 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "100uF, 6.3V" (at 201.295 85.09 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:CASE-B_3528" (at 194.945 80.01 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 194.945 74.93 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "TAJB107K006RNJ" (at 193.675 75.692 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " Kyocera AVX" (at 194.945 72.39 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 193.675 86.36 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid d478402f-d254-427b-aa37-cd00b6ec5bc3))
    (pin "2" (uuid 2e6a6268-cfe0-492f-838b-3dda5cad700b))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C226") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 170.18 117.475 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid c3436bec-8cf2-4b0a-913a-dd384b47b23b)
    (property "Reference" "#PWR?" (at 170.18 123.825 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 170.18 121.285 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 170.18 117.475 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 170.18 117.475 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid cb12fc3b-ba0a-445d-8183-e264aed93bd1))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0342") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 316.23 107.95 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid ca958bd9-b5fa-4860-9cd7-6866bc5a0a56)
    (property "Reference" "#PWR?" (at 316.23 114.3 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 316.23 111.76 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 316.23 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 316.23 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid f173d980-3413-44a2-b6e6-49f3abdbb595))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0341") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:33Ω_0402") (at 113.665 88.9 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid cae85e8f-43f0-490e-817b-ccab61ebbccc)
    (property "Reference" "R?" (at 107.315 87.63 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "33Ω" (at 118.745 87.63 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 113.665 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 113.665 88.9 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF330JTCE" (at 113.665 96.52 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 113.665 93.98 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 113.665 88.9 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid a153660a-85f1-466d-8f10-381716e4713b))
    (pin "2" (uuid 68436994-5881-4944-9098-f5cf8fe2af61))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R259") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 278.13 151.13 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid d32fdae1-359c-400b-9a1a-9b7396a2f9e9)
    (property "Reference" "#PWR?" (at 278.13 157.48 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 278.13 154.94 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 278.13 151.13 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 278.13 151.13 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 929607d4-15c2-4351-b77c-2fa8eaa43d09))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0345") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "99_HPM:270nF,50V_0603") (at 265.43 132.08 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid d717adba-7264-42db-a4b4-268257f903ae)
    (property "Reference" "C?" (at 261.62 130.81 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "270nF,50V" (at 271.78 130.81 90)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 273.05 128.27 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 265.43 132.08 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " 0603B274K500NT" (at 275.59 129.54 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 270.51 130.81 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 265.43 132.08 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid c58e68a0-a64b-4652-a4a5-0c2ed6d99241))
    (pin "2" (uuid e3ec99da-73db-4ad6-8ff5-b63ffd000a27))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C233") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:220pF,50V_0402") (at 219.075 100.33 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid dbd50584-d9eb-4382-a714-510ffa47c08c)
    (property "Reference" "C?" (at 219.71 97.79 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "220pF,50V" (at 219.71 102.87 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 222.885 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 219.075 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402B221K500NT" (at 221.615 110.49 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " YAGEO(国巨)" (at 220.345 105.41 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 219.075 100.33 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid fe8dd85d-030a-4c32-beaf-4990ec7a4171))
    (pin "2" (uuid 219a5434-90de-4fdf-b2c1-a2761e5f2777))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C228") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:1K_0402") (at 278.13 127 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid e0178e75-3eb3-460e-a0b0-a88230b3dd1f)
    (property "Reference" "R?" (at 280.035 125.73 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "1K" (at 280.035 128.27 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 280.67 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 278.13 127 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1001TCE" (at 285.75 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 283.21 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 278.13 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 14a00904-8325-48f6-90c0-b9b2923c6d76))
    (pin "2" (uuid bd319628-c540-4214-8d3b-27aaa1505845))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R268") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:1K_0402") (at 96.52 176.53 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid e3588f93-9e42-44c7-8fc4-94671b75c36d)
    (property "Reference" "R?" (at 98.425 175.26 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "1K" (at 98.425 177.8 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 99.06 176.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 96.52 176.53 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1001TCE" (at 104.14 176.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 101.6 176.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 96.52 176.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 62fab4fc-1ffd-4a0b-9662-b08c76b3ed6e))
    (pin "2" (uuid e570bf07-3f23-4b7f-b904-0c6743de5618))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "R270") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "07_HPM_Inductance:磁珠-600Ω@100MHz_1.3A_0603") (at 168.91 181.61 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid e5852eee-b2f8-4233-960f-38aec52add49)
    (property "Reference" "L?" (at 167.64 180.34 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "600Ω@100MHz_1.3A" (at 173.99 180.34 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 171.45 187.325 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 171.45 181.61 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "BLM18KG601SN1D" (at 172.72 189.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "muRata(村田)" (at 170.18 191.77 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 168.91 181.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid e47ccb7b-1ecf-4a26-9dec-57c9b3124b74))
    (pin "2" (uuid b5e9f89e-81fa-45b1-943d-a2c9927d4aeb))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "L?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "L?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "L11") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:VAUD_3.3V") (at 101.6 46.99 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid e842aa51-f797-4bb5-9783-1a44dc4fca7f)
    (property "Reference" "#PWR?" (at 101.6 46.99 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "VAUD_3.3V" (at 101.6 43.18 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 101.6 46.99 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 101.6 46.99 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 7d51425e-7a15-4b94-a5bf-4c4e0cfc24a1))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0329") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "01-HPM-Peripheral:TestPoint-0.5mm") (at 129.54 76.2 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid ed2cd71b-bb75-4d34-9a88-6e3bf6c0a1d5)
    (property "Reference" "T?" (at 128.27 78.74 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Value" "0.5mm" (at 126.873 73.66 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Footprint" "01_HPM_Peripheral:TestPoint_Pad_D0.5mm" (at 132.08 71.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 129.54 71.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid c583af60-7ad8-4f53-83e3-6a7ec947fbc1))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "T?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "T?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "TP18") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "13_HPM_Audio:Microphone") (at 82.55 187.96 0) (mirror x) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid f19e3475-bb6c-4fa2-adb9-764a87b6967c)
    (property "Reference" "P?" (at 85.725 184.785 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "Microphone" (at 80.645 178.435 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Footprint" "10_HPM_Audio:MIC-SMD_BD4.0_B4013AM423-008" (at 81.28 168.91 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 82.55 185.42 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "B4013AM423-008" (at 82.55 175.26 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "Goertek(歌尔)" (at 82.55 172.72 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 82.55 187.96 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 6bc341c3-4646-47e4-abf0-490b9b946a4c))
    (pin "2" (uuid f40d7936-1212-4a7a-82cf-a27e16ae112a))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "P?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "P?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "P4") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 232.41 75.565 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid f38447fa-ca0c-4d19-8d5c-0a54822afa13)
    (property "Reference" "#PWR?" (at 232.41 81.915 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 232.41 79.375 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 232.41 75.565 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 232.41 75.565 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 1cf4eeb3-4861-48d8-ae4e-8c47890b65ac))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/f4d2d53a-5a2b-4b1b-88c3-39c0ef51181e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "#PWR0335") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:18pF,50V_0402") (at 278.13 147.32 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid f3875cee-5196-4fbd-a6be-cbc58424c7f5)
    (property "Reference" "C?" (at 281.305 146.05 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "18pF,50V" (at 281.305 148.59 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 281.94 154.94 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 278.13 147.32 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " CC0402JRNPO9BN180" (at 280.67 157.48 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " YAGEO(国巨)" (at 279.4 152.4 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 278.13 147.32 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 1a705bb4-f272-4045-923c-9de11579ab32))
    (pin "2" (uuid bae63aff-b233-41ce-9f4c-cf3e2ac7ff2b))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C235") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 255.27 121.92 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid f943997e-cbf6-48a6-9ea7-6a6426c4e6d4)
    (property "Reference" "C?" (at 258.445 120.65 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "0.1uF,16V" (at 258.445 123.19 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 257.81 135.89 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 255.27 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 256.54 138.43 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 255.27 133.35 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 255.27 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 780700d3-eeef-4575-b918-cbf9660927a7))
    (pin "2" (uuid f850ffd9-f4e2-431d-84f7-def5667cf131))
    (instances
      (project "Audio"
        (path "/20bda62c-bf68-4e55-a8e7-dd2e259c89dd"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/d039d08c-645b-4ed7-9c2b-76bd2108cc2f"
          (reference "C?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C232") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:4.7uF,16V_0603") (at 247.65 121.92 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid fb63d609-f592-43ea-a4f4-e05a3a2d8460)
    (property "Reference" "C231" (at 245.11 119.38 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "4.7uF,16V" (at 242.57 124.46 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0603_1608Metric" (at 248.92 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 247.65 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL10A475KO8NNNC" (at 247.65 129.54 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " SAMSUNG(三星)" (at 247.65 132.08 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 247.65 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid ad96f11f-c27c-4d48-82bf-e921125a52c6))
    (pin "2" (uuid 53b005f2-e356-45c6-bfc4-b4f81b1b399c))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/fd9440a8-6c85-4683-8354-fd761d502aa0"
          (reference "C231") (unit 1)
        )
      )
    )
  )
)
