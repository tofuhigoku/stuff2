(kicad_sch (version 20230121) (generator eeschema)

  (uuid 305b0c77-30c9-4e45-b2a0-3d322accdf90)

  (paper "A4")

  (title_block
    (title "HPM6E00EVKRevC")
    (date "2024-09-29")
    (rev "C")
    (comment 1 "ETHERCAT_B")
  )

  (lib_symbols
    (symbol "00_HPM_power:GND" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "GND" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "power-flag" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"GND\" , ground" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "GND_0_1"
        (polyline
          (pts
            (xy 0 0)
            (xy 0 -1.27)
            (xy 1.27 -1.27)
            (xy 0 -2.54)
            (xy -1.27 -1.27)
            (xy 0 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "GND_1_1"
        (pin power_in line (at 0 0 270) (length 0) hide
          (name "GND" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "00_HPM_power:GND3" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "GND3" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "power-flag" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"GND3\" , ground" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "GND3_0_1"
        (polyline
          (pts
            (xy 0 0)
            (xy 0 -1.27)
            (xy 1.27 -1.27)
            (xy 0 -2.54)
            (xy -1.27 -1.27)
            (xy 0 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "GND3_1_1"
        (pin power_in line (at 0 0 270) (length 0) hide
          (name "GND3" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "01-HPM-Peripheral:DM-02-V" (pin_names (offset 1.016) hide) (in_bom yes) (on_board yes)
      (property "Reference" "SW" (at -0.635 5.08 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "DM-02-V" (at -0.635 -5.08 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "01_HPM_Peripheral:SW-SMD_DM-02-V" (at 0 -6.985 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "DM-02-V" (at 0 8.89 0)
        (effects (font (size 0 0)) hide)
      )
      (property "Company" "圜达" (at -0.635 -8.89 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "ki_description" "拨码开关" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "DM-02-V_1_1"
        (rectangle (start -5.08 -3.81) (end 5.08 3.81)
          (stroke (width 0) (type default))
          (fill (type background))
        )
        (circle (center -3.81 2.54) (radius 0.381)
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (rectangle (start -2.54 -1.905) (end 2.54 -0.635)
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (rectangle (start -2.54 0.635) (end 2.54 1.905)
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 -0.635)
            (xy 0 -1.905)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 1.905)
            (xy 0 0.635)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (pin input line (at -7.62 1.27 0) (length 2.54)
          (name "PIN1" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -7.62 -1.27 0) (length 2.54)
          (name "PIN2" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 7.62 -1.27 180) (length 2.54)
          (name "PIN3" (effects (font (size 1.27 1.27))))
          (number "3" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 7.62 1.27 180) (length 2.54)
          (name "PIN4" (effects (font (size 1.27 1.27))))
          (number "4" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "01-HPM-Peripheral:LED_RED" (pin_numbers hide) (pin_names (offset 1.016) hide) (in_bom yes) (on_board yes)
      (property "Reference" "LED" (at 0 10.16 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "LED_RED" (at 0 13.97 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "01_HPM_Peripheral:LED_0603" (at 0 -11.43 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 5.461 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "NCD0603R1" (at -1.27 -8.89 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "国星光电" (at -1.27 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "LED_RED_1_1"
        (polyline
          (pts
            (xy -2.54 1.524)
            (xy -2.54 -1.524)
          )
          (stroke (width 0.1524) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.778 2.032)
            (xy -3.556 3.81)
          )
          (stroke (width 0.1524) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -0.762 3.048)
            (xy -2.54 4.826)
          )
          (stroke (width 0.1524) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -3.556 3.81)
            (xy -2.54 3.302)
            (xy -3.048 2.794)
            (xy -3.556 3.81)
          )
          (stroke (width 0.1524) (type default))
          (fill (type outline))
        )
        (polyline
          (pts
            (xy -2.54 4.826)
            (xy -1.524 4.318)
            (xy -2.032 3.81)
            (xy -2.54 4.826)
          )
          (stroke (width 0.1524) (type default))
          (fill (type outline))
        )
        (polyline
          (pts
            (xy 0 -1.524)
            (xy -2.54 0)
            (xy 0 1.524)
            (xy 0 -1.524)
          )
          (stroke (width 0.1524) (type default))
          (fill (type outline))
        )
        (pin input line (at -6.35 0 0) (length 3.81)
          (name "K" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 3.81 0 180) (length 3.81)
          (name "A" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "01-HPM-Peripheral:TestPoint-0.5mm" (pin_numbers hide) (pin_names (offset 0.762) hide) (in_bom yes) (on_board yes)
      (property "Reference" "TP" (at -2.54 -1.27 0)
        (effects (font (size 1.27 1.27)) (justify left) hide)
      )
      (property "Value" "0.5mm" (at -1.27 5.08 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "01_HPM_Peripheral:TestPoint_Pad_D0.5mm" (at 5.08 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 5.08 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "test point tp" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "test point" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "Pin* Test*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "TestPoint-0.5mm_0_1"
        (circle (center 0 3.302) (radius 0.762)
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "TestPoint-0.5mm_1_1"
        (pin passive line (at 0 0 90) (length 2.54)
          (name "1" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:0Ω_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 5.08 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "0Ω" (at 0 8.89 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 1.27 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "RC0402JR-070RL" (at 0 -8.89 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "YAGEO(国巨)" (at 0 -11.43 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "0Ω_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "0Ω_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:1K_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "1K" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402WGF1001TCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "1K_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "1K_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:2.49K_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "2.49K" (at 0 10.16 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "RC0402FR-072K7L" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "YAGEO(国巨)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "2.49K_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "2.49K_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:330Ω_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "330Ω" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402WGF3300TCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "330Ω_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "330Ω_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:33Ω_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "33Ω" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402WGF330JTCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "33Ω_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "33Ω_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:4.7K_0402" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "4.7K" (at 0 6.35 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" " 0402WGF4701TCE" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "4.7K_0402_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "4.7K_0402_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "02_HPM_Resistor:75Ω_0603" (pin_numbers hide) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "R" (at 0 5.08 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "75Ω" (at 0 8.89 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 90)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0603WAF750JT5E" (at 0 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "UNI-ROYAL(厚声)" (at 0 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "R res resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Resistor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "R_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "75Ω_0603_0_1"
        (rectangle (start 2.54 -1.016) (end -2.54 1.016)
          (stroke (width 0.254) (type default))
          (fill (type none))
        )
      )
      (symbol "75Ω_0603_1_1"
        (pin passive line (at -3.81 0 0) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 3.81 0 180) (length 1.27)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:0.1uF,16V_0402" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at -1.27 10.16 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "0.1uF,16V" (at -5.08 12.7 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 2.54 -13.97 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "CL05B104KO5NNNC" (at 1.27 -16.51 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "SAMSUNG(三星)" (at 0 -11.43 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "0.1uF,16V_0402_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "0.1uF,16V_0402_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:0.1uF,50V_0402" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0 10.16 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "0.1uF,50V" (at -3.81 12.7 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 3.81 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "0402B104K500NT" (at 2.54 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "SAMSUNG(三星)" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "0.1uF,50V_0402_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "0.1uF,50V_0402_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:10uF,10V_0603" (pin_numbers hide) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0 8.89 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "10uF,10V" (at 0 10.16 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 0 -11.43 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" " CL10A106KP8NNNC" (at 0 -8.89 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" " SAMSUNG(三星) " (at 0 -16.51 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0603" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "10uF,10V_0603_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "10uF,10V_0603_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:1nF,2kV_1206" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at -3.81 2.54 0)
        (effects (font (size 1.27 1.27)) (justify right))
      )
      (property "Value" "1nF,2kV" (at 0 -2.54 0)
        (effects (font (size 1.27 1.27)) (justify right))
      )
      (property "Footprint" "03_HPM_Capacitance:C_1206_3216Metric" (at 1.27 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "~" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "1206B102K202NT" (at -1.27 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "FH(风华)" (at -1.27 -12.7 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "1206" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "1nF,2kV_1206_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "1nF,2kV_1206_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "03_HPM_Capacitance:1uF,10V_0402" (pin_numbers hide) (pin_names (offset 0.254)) (in_bom yes) (on_board yes)
      (property "Reference" "C" (at 0 11.43 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "1uF,10V" (at -2.54 13.97 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 3.81 -7.62 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" " CL05A105KP5NNNC" (at 2.54 -10.16 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "SAMSUNG(三星)" (at 1.27 -5.08 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "cap capacitor" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "0402" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "C_*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "1uF,10V_0402_0_1"
        (polyline
          (pts
            (xy -2.032 -0.762)
            (xy 2.032 -0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -2.032 0.762)
            (xy 2.032 0.762)
          )
          (stroke (width 0.508) (type default))
          (fill (type none))
        )
      )
      (symbol "1uF,10V_0402_1_1"
        (pin passive line (at 0 3.81 270) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin passive line (at 0 -3.81 90) (length 2.794)
          (name "~" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "14_HPM_Internet:11FB-05NL" (pin_names (offset 1.016)) (in_bom yes) (on_board yes)
      (property "Reference" "T" (at -6.35 12.7 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Value" "11FB-05NL" (at 1.27 -13.97 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "11_HPM_Internet:H1102_XFMR16_SM" (at 0 -16.51 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 -4.318 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "11FB-05NL" (at 0 -21.59 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "YDS(元册科技)" (at 0 -19.05 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "网口变压器" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "11FB-05NL_1_1"
        (rectangle (start -7.62 -11.938) (end 7.62 11.938)
          (stroke (width 0) (type default))
          (fill (type background))
        )
        (circle (center -6.35 10.668) (radius 0.381)
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (circle (center -6.35 10.668) (radius 0.381)
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (pin input line (at -10.16 8.89 0) (length 2.54)
          (name "TD+" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 10.16 -6.35 180) (length 2.54)
          (name "CT" (effects (font (size 1.27 1.27))))
          (number "10" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 10.16 -3.81 180) (length 2.54)
          (name "RX+" (effects (font (size 1.27 1.27))))
          (number "11" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 10.16 -1.27 180) (length 2.54)
          (name "12" (effects (font (size 1.27 1.27))))
          (number "12" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 10.16 1.27 180) (length 2.54)
          (name "13" (effects (font (size 1.27 1.27))))
          (number "13" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at 10.16 3.81 180) (length 2.54)
          (name "TX-" (effects (font (size 1.27 1.27))))
          (number "14" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 10.16 6.35 180) (length 2.54)
          (name "CT" (effects (font (size 1.27 1.27))))
          (number "15" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at 10.16 8.89 180) (length 2.54)
          (name "TX+" (effects (font (size 1.27 1.27))))
          (number "16" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 6.35 0) (length 2.54)
          (name "CT" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 3.81 0) (length 2.54)
          (name "TD-" (effects (font (size 1.27 1.27))))
          (number "3" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 1.27 0) (length 2.54)
          (name "4" (effects (font (size 1.27 1.27))))
          (number "4" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 -1.27 0) (length 2.54)
          (name "5" (effects (font (size 1.27 1.27))))
          (number "5" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 -3.81 0) (length 2.54)
          (name "RD+" (effects (font (size 1.27 1.27))))
          (number "6" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 -6.35 0) (length 2.54)
          (name "CT" (effects (font (size 1.27 1.27))))
          (number "7" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -10.16 -8.89 0) (length 2.54)
          (name "RD-" (effects (font (size 1.27 1.27))))
          (number "8" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 10.16 -8.89 180) (length 2.54)
          (name "RX-" (effects (font (size 1.27 1.27))))
          (number "9" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "14_HPM_Internet:JL1111-N032I" (in_bom yes) (on_board yes)
      (property "Reference" "U" (at -12.7 31.75 0)
        (effects (font (size 1.27 1.27)) (justify right))
      )
      (property "Value" "JL1111-N032I" (at 16.51 31.75 0)
        (effects (font (size 1.27 1.27)) (justify right))
      )
      (property "Footprint" "06_HPM_LQFP:QFN-32-1EP_5x5mm_P0.5mm_EP3.1x3.1mm" (at -22.86 -33.02 0)
        (effects (font (size 1.27 1.27)) (justify left) hide)
      )
      (property "Datasheet" "" (at 2.54 -44.45 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "JL1111-N032I" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "JLSEMI/景略" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "ETH PHY RMII MII" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "10BASE-T/100BASE-TX PHY with RMII Support, 25 MHz input clock, LQFP-48" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_fp_filters" "LQFP?48*7x7mm*P0.5mm*" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "JL1111-N032I_1_1"
        (rectangle (start -13.97 30.48) (end 16.51 -30.48)
          (stroke (width 0.254) (type default))
          (fill (type background))
        )
        (pin input line (at 19.05 -20.32 180) (length 2.54)
          (name "RBIAS" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 -2.54 0) (length 2.54)
          (name "RXD1" (effects (font (size 1.27 1.27))))
          (number "10" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 -5.08 0) (length 2.54)
          (name "RXD2/INT_N" (effects (font (size 1.27 1.27))))
          (number "11" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 -7.62 0) (length 2.54)
          (name "RXD3" (effects (font (size 1.27 1.27))))
          (number "12" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 7.62 0) (length 2.54)
          (name "RXC" (effects (font (size 1.27 1.27))))
          (number "13" (effects (font (size 1.27 1.27))))
        )
        (pin power_in line (at 19.05 25.4 180) (length 2.54)
          (name "DVDDIO" (effects (font (size 1.27 1.27))))
          (number "14" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 27.94 0) (length 2.54)
          (name "TXC" (effects (font (size 1.27 1.27))))
          (number "15" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 20.32 0) (length 2.54)
          (name "TXD0" (effects (font (size 1.27 1.27))))
          (number "16" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 17.78 0) (length 2.54)
          (name "TXD1" (effects (font (size 1.27 1.27))))
          (number "17" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 15.24 0) (length 2.54)
          (name "TXD2" (effects (font (size 1.27 1.27))))
          (number "18" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 12.7 0) (length 2.54)
          (name "TXD3" (effects (font (size 1.27 1.27))))
          (number "19" (effects (font (size 1.27 1.27))))
        )
        (pin power_in line (at 19.05 22.86 180) (length 2.54)
          (name "REFCLK_SEL" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 22.86 0) (length 2.54)
          (name "TX_EN" (effects (font (size 1.27 1.27))))
          (number "20" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 19.05 -27.94 180) (length 2.54)
          (name "RESET_N" (effects (font (size 1.27 1.27))))
          (number "21" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 -20.32 0) (length 2.54)
          (name "MDC" (effects (font (size 1.27 1.27))))
          (number "22" (effects (font (size 1.27 1.27))))
        )
        (pin bidirectional line (at -16.51 -17.78 0) (length 2.54)
          (name "MDIO" (effects (font (size 1.27 1.27))))
          (number "23" (effects (font (size 1.27 1.27))))
        )
        (pin bidirectional line (at 19.05 -25.4 180) (length 2.54)
          (name "LED0" (effects (font (size 1.27 1.27))))
          (number "24" (effects (font (size 1.27 1.27))))
        )
        (pin bidirectional line (at 19.05 -22.86 180) (length 2.54)
          (name "LED1" (effects (font (size 1.27 1.27))))
          (number "25" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 -12.7 0) (length 2.54)
          (name "CRS_DV" (effects (font (size 1.27 1.27))))
          (number "26" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 -15.24 0) (length 2.54)
          (name "COL" (effects (font (size 1.27 1.27))))
          (number "27" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 2.54 0) (length 2.54)
          (name "RX_ER" (effects (font (size 1.27 1.27))))
          (number "28" (effects (font (size 1.27 1.27))))
        )
        (pin power_in line (at 19.05 20.32 180) (length 2.54)
          (name "DVDD1V2" (effects (font (size 1.27 1.27))))
          (number "29" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 19.05 7.62 180) (length 2.54)
          (name "TD_P" (effects (font (size 1.27 1.27))))
          (number "3" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 19.05 -17.78 180) (length 2.54)
          (name "EN_DLDO" (effects (font (size 1.27 1.27))))
          (number "30" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -16.51 -25.4 0) (length 2.54)
          (name "XI" (effects (font (size 1.27 1.27))))
          (number "31" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 -27.94 0) (length 2.54)
          (name "XO" (effects (font (size 1.27 1.27))))
          (number "32" (effects (font (size 1.27 1.27))))
        )
        (pin power_in line (at 19.05 17.78 180) (length 2.54)
          (name "GND" (effects (font (size 1.27 1.27))))
          (number "33" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 19.05 5.08 180) (length 2.54)
          (name "TD_N" (effects (font (size 1.27 1.27))))
          (number "4" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 19.05 2.54 180) (length 2.54)
          (name "RD_P" (effects (font (size 1.27 1.27))))
          (number "5" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 19.05 0 180) (length 2.54)
          (name "RD_N" (effects (font (size 1.27 1.27))))
          (number "6" (effects (font (size 1.27 1.27))))
        )
        (pin power_in line (at 19.05 27.94 180) (length 2.54)
          (name "AVDD33" (effects (font (size 1.27 1.27))))
          (number "7" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 5.08 0) (length 2.54)
          (name "RX_DV" (effects (font (size 1.27 1.27))))
          (number "8" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -16.51 0 0) (length 2.54)
          (name "RXD0" (effects (font (size 1.27 1.27))))
          (number "9" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "14_HPM_Internet:RJ45-B-1*1" (pin_names (offset 1.016) hide) (in_bom yes) (on_board yes)
      (property "Reference" "J" (at -6.35 12.7 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Value" "RJ45-B-1*1" (at 1.27 -12.7 0)
        (effects (font (size 1.27 1.27)) (justify left))
      )
      (property "Footprint" "11_HPM_Internet:RJ45-TH_B-1-1" (at -1.27 -19.05 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 11.43 21.59 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Model" "RJ45-B-1*1" (at -1.27 -21.59 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Company" "BOOMELE(博穆精密)" (at 0 -24.13 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ASSY_OPT" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "以太网连接器" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "RJ45-B-1*1_1_1"
        (rectangle (start -6.35 11.43) (end 6.35 -11.43)
          (stroke (width 0) (type default))
          (fill (type background))
        )
        (polyline
          (pts
            (xy -1.524 -6.35)
            (xy 4.826 -6.35)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.524 -3.81)
            (xy -1.524 -6.35)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.524 8.89)
            (xy -1.524 8.128)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.524 8.89)
            (xy -1.016 8.89)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.27 3.81)
            (xy 5.08 3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.27 6.35)
            (xy -1.27 3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.016 9.398)
            (xy -1.016 8.89)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -1.016 9.398)
            (xy -0.508 9.398)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -0.762 -1.27)
            (xy -0.762 -2.032)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -0.762 -1.27)
            (xy -0.254 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -0.508 7.62)
            (xy -1.524 8.89)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -0.254 -0.762)
            (xy -0.254 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy -0.254 -0.762)
            (xy 0.254 -0.762)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 -5.08)
            (xy 0 -2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 -3.81)
            (xy 1.27 -5.08)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 5.08)
            (xy 0 7.62)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 6.35)
            (xy 1.27 5.08)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0.254 -2.54)
            (xy -0.762 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0.254 8.128)
            (xy -1.016 9.398)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.016 -2.032)
            (xy -0.254 -0.762)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.27 -5.08)
            (xy 1.27 -2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.27 -2.54)
            (xy 0 -3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.27 5.08)
            (xy 1.27 7.62)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 1.27 7.62)
            (xy 0 6.35)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 4.826 -3.81)
            (xy -1.524 -3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 5.08 6.35)
            (xy -1.27 6.35)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 6.096 -6.35)
            (xy 4.826 -6.35)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 6.096 -3.81)
            (xy 4.826 -3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 6.35 3.81)
            (xy 5.08 3.81)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 6.35 6.35)
            (xy 5.08 6.35)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (pin input line (at 0 -16.51 90) (length 5.08)
          (name "S" (effects (font (size 1.27 1.27))))
          (number "0" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 0 16.51 270) (length 5.08)
          (name "S" (effects (font (size 1.27 1.27))))
          (number "0" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -11.43 8.89 0) (length 5.08)
          (name "1" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 11.43 -3.81 180) (length 5.08)
          (name "10" (effects (font (size 1.27 1.27))))
          (number "10" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 11.43 3.81 180) (length 5.08)
          (name "11" (effects (font (size 1.27 1.27))))
          (number "11" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 11.43 6.35 180) (length 5.08)
          (name "12" (effects (font (size 1.27 1.27))))
          (number "12" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -11.43 6.35 0) (length 5.08)
          (name "2" (effects (font (size 1.27 1.27))))
          (number "2" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -11.43 3.81 0) (length 5.08)
          (name "3" (effects (font (size 1.27 1.27))))
          (number "3" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -11.43 1.27 0) (length 5.08)
          (name "4" (effects (font (size 1.27 1.27))))
          (number "4" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -11.43 -1.27 0) (length 5.08)
          (name "5" (effects (font (size 1.27 1.27))))
          (number "5" (effects (font (size 1.27 1.27))))
        )
        (pin output line (at -11.43 -3.81 0) (length 5.08)
          (name "6" (effects (font (size 1.27 1.27))))
          (number "6" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -11.43 -6.35 0) (length 5.08)
          (name "7" (effects (font (size 1.27 1.27))))
          (number "7" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at -11.43 -8.89 0) (length 5.08)
          (name "8" (effects (font (size 1.27 1.27))))
          (number "8" (effects (font (size 1.27 1.27))))
        )
        (pin input line (at 11.43 -6.35 180) (length 5.08)
          (name "9" (effects (font (size 1.27 1.27))))
          (number "9" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "power:+3.3V" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "+3.3V" (at 0 3.556 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "global power" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"+3.3V\"" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "+3.3V_0_1"
        (polyline
          (pts
            (xy -0.762 1.27)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 0)
            (xy 0 2.54)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
        (polyline
          (pts
            (xy 0 2.54)
            (xy 0.762 1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "+3.3V_1_1"
        (pin power_in line (at 0 0 90) (length 0) hide
          (name "+3.3V" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
    (symbol "power:GND" (power) (pin_names (offset 0)) (in_bom yes) (on_board yes)
      (property "Reference" "#PWR" (at 0 -6.35 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Value" "GND" (at 0 -3.81 0)
        (effects (font (size 1.27 1.27)))
      )
      (property "Footprint" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "Datasheet" "" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_keywords" "global power" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (property "ki_description" "Power symbol creates a global label with name \"GND\" , ground" (at 0 0 0)
        (effects (font (size 1.27 1.27)) hide)
      )
      (symbol "GND_0_1"
        (polyline
          (pts
            (xy 0 0)
            (xy 0 -1.27)
            (xy 1.27 -1.27)
            (xy 0 -2.54)
            (xy -1.27 -1.27)
            (xy 0 -1.27)
          )
          (stroke (width 0) (type default))
          (fill (type none))
        )
      )
      (symbol "GND_1_1"
        (pin power_in line (at 0 0 270) (length 0) hide
          (name "GND" (effects (font (size 1.27 1.27))))
          (number "1" (effects (font (size 1.27 1.27))))
        )
      )
    )
  )

  (junction (at 224.79 90.17) (diameter 0) (color 0 0 0 0)
    (uuid 085019aa-c1e1-47ca-b60e-efccf0f2e029)
  )
  (junction (at 66.04 147.32) (diameter 0) (color 0 0 0 0)
    (uuid 1e668aa9-d09a-4830-add6-a6ae85ebeffa)
  )
  (junction (at 63.5 101.6) (diameter 0) (color 0 0 0 0)
    (uuid 50ddcb35-56eb-4645-9e62-b4dd5451e661)
  )
  (junction (at 68.58 149.86) (diameter 0) (color 0 0 0 0)
    (uuid 55e38474-a57c-4d09-98e7-62959c6077bd)
  )
  (junction (at 224.79 80.01) (diameter 0) (color 0 0 0 0)
    (uuid 57d20e24-7686-465a-b04a-93585605a226)
  )
  (junction (at 139.7 63.5) (diameter 0) (color 0 0 0 0)
    (uuid 5bba8cdd-a1db-461e-b5d8-d3eeecb81c07)
  )
  (junction (at 137.16 48.26) (diameter 0) (color 0 0 0 0)
    (uuid 6114511c-e571-4dc0-87f4-f067ba9a5658)
  )
  (junction (at 212.09 102.87) (diameter 0) (color 0 0 0 0)
    (uuid 6266b577-3024-4de4-b2f8-e8577b36f296)
  )
  (junction (at 128.27 63.5) (diameter 0) (color 0 0 0 0)
    (uuid 8958a7b3-1bd0-4697-b220-0ca180cd4b86)
  )
  (junction (at 274.32 85.09) (diameter 0) (color 0 0 0 0)
    (uuid a029ac80-7b99-4d68-ae6f-a3bad23b050e)
  )
  (junction (at 172.72 41.91) (diameter 0) (color 0 0 0 0)
    (uuid a124ab37-dfbc-4f25-a94a-110108be31d5)
  )
  (junction (at 68.58 167.64) (diameter 0) (color 0 0 0 0)
    (uuid b33ce443-7b7d-4383-8c91-2ad67f3547e4)
  )
  (junction (at 128.27 55.88) (diameter 0) (color 0 0 0 0)
    (uuid b43403b0-d5c3-410e-8c76-871f7fddce6b)
  )
  (junction (at 219.71 102.87) (diameter 0) (color 0 0 0 0)
    (uuid bfdeb0ee-1613-4c89-b9ba-70ea4690ee7e)
  )
  (junction (at 152.4 63.5) (diameter 0) (color 0 0 0 0)
    (uuid ca5b0828-ff4e-42c9-bbd5-1ed33c579e1e)
  )
  (junction (at 185.42 34.29) (diameter 0) (color 0 0 0 0)
    (uuid d3d2f681-6c4c-4fa0-be31-d74eba5e3728)
  )
  (junction (at 38.1 147.32) (diameter 0) (color 0 0 0 0)
    (uuid d620afc6-ad11-4fd2-933e-747b9a259769)
  )
  (junction (at 172.72 34.29) (diameter 0) (color 0 0 0 0)
    (uuid def8d569-ecb5-4208-af5a-c370881fa916)
  )
  (junction (at 274.32 77.47) (diameter 0) (color 0 0 0 0)
    (uuid e31932ed-d60b-4131-aca1-ea986761a5ac)
  )
  (junction (at 152.4 53.34) (diameter 0) (color 0 0 0 0)
    (uuid e61cab23-d14e-4522-80b6-f07c67bafa9e)
  )
  (junction (at 185.42 41.91) (diameter 0) (color 0 0 0 0)
    (uuid f9633a72-f39e-4d26-868e-ee8b9c072c85)
  )

  (no_connect (at 185.42 82.55) (uuid 2da0c76e-ad67-45e4-a853-92010c530111))
  (no_connect (at 205.74 80.01) (uuid 5933a64a-2e7c-4c1b-ba1e-a091f40a0851))
  (no_connect (at 205.74 82.55) (uuid 7013ba97-1d80-402e-91d0-13dc053a5845))
  (no_connect (at 185.42 80.01) (uuid 79fe42dc-c0ab-4f65-91cf-707f970de3f8))

  (wire (pts (xy 152.4 63.5) (xy 139.7 63.5))
    (stroke (width 0) (type default))
    (uuid 02a486f3-6173-45c6-8760-6fab55d00558)
  )
  (wire (pts (xy 38.1 147.32) (xy 45.72 147.32))
    (stroke (width 0) (type default))
    (uuid 038b5be3-d582-4ead-a6bb-8b6ac8fbe4fa)
  )
  (wire (pts (xy 34.29 93.98) (xy 87.63 93.98))
    (stroke (width 0) (type default))
    (uuid 08518379-b76b-4f0f-b225-80dd47637074)
  )
  (wire (pts (xy 66.04 162.56) (xy 66.04 167.64))
    (stroke (width 0) (type default))
    (uuid 096d9a0d-41cd-4f0c-81a6-0a5c3dd064df)
  )
  (wire (pts (xy 274.32 87.63) (xy 269.24 87.63))
    (stroke (width 0) (type default))
    (uuid 09a44f56-ed7e-4e37-a830-66b4e74f4e93)
  )
  (wire (pts (xy 247.65 74.93) (xy 260.35 74.93))
    (stroke (width 0) (type default))
    (uuid 0b689a58-7eb3-49d5-8e52-b7f66dc6f98f)
  )
  (wire (pts (xy 162.56 34.29) (xy 172.72 34.29))
    (stroke (width 0) (type default))
    (uuid 0cc3532b-d31e-4ac0-8fca-b77df6419230)
  )
  (wire (pts (xy 66.04 167.64) (xy 68.58 167.64))
    (stroke (width 0) (type default))
    (uuid 0d38c549-1c96-463f-a769-3861280aa036)
  )
  (wire (pts (xy 214.63 74.93) (xy 224.79 74.93))
    (stroke (width 0) (type default))
    (uuid 0e5e6be5-f878-49c1-8a9c-ae425a555e31)
  )
  (wire (pts (xy 137.16 50.8) (xy 137.16 48.26))
    (stroke (width 0) (type default))
    (uuid 1252eb02-9fa8-408b-84e3-fb29026beedf)
  )
  (wire (pts (xy 224.79 87.63) (xy 224.79 90.17))
    (stroke (width 0) (type default))
    (uuid 146cbb8d-abc2-43af-9f64-868246d8b374)
  )
  (wire (pts (xy 247.65 77.47) (xy 260.35 77.47))
    (stroke (width 0) (type default))
    (uuid 14d0e4c8-b1d6-48a5-a0cd-55a81f0e7cca)
  )
  (wire (pts (xy 205.74 72.39) (xy 224.79 72.39))
    (stroke (width 0) (type default))
    (uuid 15c60ee9-feea-4c7a-9779-8f7b023330d2)
  )
  (wire (pts (xy 205.74 90.17) (xy 222.25 90.17))
    (stroke (width 0) (type default))
    (uuid 161e632c-9a22-4618-b2fd-8488a30dd9fc)
  )
  (wire (pts (xy 123.19 71.12) (xy 176.53 71.12))
    (stroke (width 0) (type default))
    (uuid 1adacd46-8dd4-4259-aad2-75a7ba798f8e)
  )
  (wire (pts (xy 68.58 154.94) (xy 68.58 149.86))
    (stroke (width 0) (type default))
    (uuid 1adbe06a-2d90-4e9f-9e30-f0fca0c2985d)
  )
  (wire (pts (xy 80.01 91.44) (xy 87.63 91.44))
    (stroke (width 0) (type default))
    (uuid 1c6ca565-9402-4f63-a312-683a2ca5101f)
  )
  (wire (pts (xy 274.32 85.09) (xy 281.94 85.09))
    (stroke (width 0) (type default))
    (uuid 1dbaec42-e4a6-422d-b99f-69477695061a)
  )
  (wire (pts (xy 133.35 148.59) (xy 138.43 148.59))
    (stroke (width 0) (type default))
    (uuid 23f857f0-8a6f-4055-a425-9fe1bcf695aa)
  )
  (wire (pts (xy 123.19 48.26) (xy 137.16 48.26))
    (stroke (width 0) (type default))
    (uuid 251e1fbc-d610-498c-b67a-2ffe060cc3bf)
  )
  (wire (pts (xy 66.04 147.32) (xy 60.96 147.32))
    (stroke (width 0) (type default))
    (uuid 27531783-83e8-4b56-8f65-13d880117d69)
  )
  (wire (pts (xy 171.45 90.17) (xy 185.42 90.17))
    (stroke (width 0) (type default))
    (uuid 2aa63e0b-c62d-49b6-853a-6e3bd49926f6)
  )
  (wire (pts (xy 219.71 102.87) (xy 224.79 102.87))
    (stroke (width 0) (type default))
    (uuid 310c1d9e-810c-4f65-9a30-bf604ce21ba6)
  )
  (wire (pts (xy 78.74 88.9) (xy 87.63 88.9))
    (stroke (width 0) (type default))
    (uuid 35682e63-d05f-467c-8eae-f8ebad3cfcf7)
  )
  (wire (pts (xy 185.42 41.91) (xy 201.93 41.91))
    (stroke (width 0) (type default))
    (uuid 36bcfaad-ee28-4610-8f24-357a24f062fc)
  )
  (wire (pts (xy 173.99 73.66) (xy 173.99 85.09))
    (stroke (width 0) (type default))
    (uuid 38b86125-d633-41f6-b874-cee490831112)
  )
  (wire (pts (xy 123.19 58.42) (xy 123.19 63.5))
    (stroke (width 0) (type default))
    (uuid 3bcf03cb-650f-4617-8ae8-ed3ac5714d81)
  )
  (wire (pts (xy 74.93 68.58) (xy 67.31 68.58))
    (stroke (width 0) (type default))
    (uuid 3ee2c458-af0a-4f18-9c25-1a5695690e57)
  )
  (wire (pts (xy 67.31 76.2) (xy 87.63 76.2))
    (stroke (width 0) (type default))
    (uuid 3eebffd0-a99d-4aa6-aac6-8bca4631460d)
  )
  (wire (pts (xy 67.31 55.88) (xy 87.63 55.88))
    (stroke (width 0) (type default))
    (uuid 4035fd89-2b62-46cf-94fd-6b136f654192)
  )
  (wire (pts (xy 123.19 76.2) (xy 171.45 76.2))
    (stroke (width 0) (type default))
    (uuid 4438e750-79ca-4c57-ba45-9cec894f8d75)
  )
  (wire (pts (xy 67.31 53.34) (xy 87.63 53.34))
    (stroke (width 0) (type default))
    (uuid 45aba465-ba79-43c3-95a4-a8834d91ab33)
  )
  (wire (pts (xy 152.4 63.5) (xy 168.91 63.5))
    (stroke (width 0) (type default))
    (uuid 4683008d-dc3c-447f-bf3b-c7ae2393078b)
  )
  (wire (pts (xy 171.45 76.2) (xy 171.45 90.17))
    (stroke (width 0) (type default))
    (uuid 48e693f8-52f2-46b3-b937-e8dc4c5ed161)
  )
  (wire (pts (xy 172.72 34.29) (xy 185.42 34.29))
    (stroke (width 0) (type default))
    (uuid 49db3839-55d3-4e7a-96e6-3cd6060fdece)
  )
  (wire (pts (xy 224.79 80.01) (xy 219.71 80.01))
    (stroke (width 0) (type default))
    (uuid 4db99fc3-b2c9-48f3-afbd-fb0d23888f5f)
  )
  (wire (pts (xy 182.88 63.5) (xy 182.88 74.93))
    (stroke (width 0) (type default))
    (uuid 4e7571be-8d3b-40ff-8fcd-e72e9c446977)
  )
  (wire (pts (xy 247.65 87.63) (xy 261.62 87.63))
    (stroke (width 0) (type default))
    (uuid 50b3452e-3b8c-40fd-bf1c-0027a5d650d3)
  )
  (wire (pts (xy 66.04 154.94) (xy 66.04 147.32))
    (stroke (width 0) (type default))
    (uuid 54444062-4eab-414d-98c0-adda3cf4fa6d)
  )
  (wire (pts (xy 267.97 74.93) (xy 274.32 74.93))
    (stroke (width 0) (type default))
    (uuid 547e5b33-41bb-4e73-8376-aaee5704e42f)
  )
  (wire (pts (xy 128.27 63.5) (xy 139.7 63.5))
    (stroke (width 0) (type default))
    (uuid 5b28af4d-caf0-4bdb-b3e8-c7311e19f62a)
  )
  (wire (pts (xy 148.59 148.59) (xy 154.94 148.59))
    (stroke (width 0) (type default))
    (uuid 5c1eedf2-0956-421b-a2b9-e122b81541e8)
  )
  (wire (pts (xy 224.79 101.6) (xy 224.79 102.87))
    (stroke (width 0) (type default))
    (uuid 5c3ce4c1-010b-4966-ba77-db67a8733a18)
  )
  (wire (pts (xy 224.79 90.17) (xy 224.79 93.98))
    (stroke (width 0) (type default))
    (uuid 5c8fe262-e6bb-4227-b0dd-864d5bb79d4e)
  )
  (wire (pts (xy 123.19 68.58) (xy 179.07 68.58))
    (stroke (width 0) (type default))
    (uuid 5c9a0174-fe3e-4650-8673-1c240bd5acce)
  )
  (wire (pts (xy 128.27 101.6) (xy 123.19 101.6))
    (stroke (width 0) (type default))
    (uuid 5d6d5463-11ab-4262-8ef2-164fc6de52a6)
  )
  (wire (pts (xy 269.24 85.09) (xy 274.32 85.09))
    (stroke (width 0) (type default))
    (uuid 5dd4aa43-a206-4b9f-89cc-49e079647cf4)
  )
  (wire (pts (xy 123.19 93.98) (xy 135.89 93.98))
    (stroke (width 0) (type default))
    (uuid 5e186b9a-910b-4fae-b661-b04b8f07ab86)
  )
  (wire (pts (xy 217.17 77.47) (xy 224.79 77.47))
    (stroke (width 0) (type default))
    (uuid 5e666206-faaa-4f29-8d38-0da863eb4a44)
  )
  (wire (pts (xy 123.19 96.52) (xy 135.89 96.52))
    (stroke (width 0) (type default))
    (uuid 5ea0d1af-145a-4b03-af24-bf5b31ae4185)
  )
  (wire (pts (xy 185.42 87.63) (xy 182.88 87.63))
    (stroke (width 0) (type default))
    (uuid 5fb77338-b955-4a9d-937b-6db28aa1f60d)
  )
  (wire (pts (xy 58.42 101.6) (xy 63.5 101.6))
    (stroke (width 0) (type default))
    (uuid 5fd83a27-5120-4a36-8d8c-a1651045deec)
  )
  (wire (pts (xy 82.55 68.58) (xy 87.63 68.58))
    (stroke (width 0) (type default))
    (uuid 606b9ead-2916-4ff0-82fd-a8447ed3d58f)
  )
  (wire (pts (xy 207.01 102.87) (xy 212.09 102.87))
    (stroke (width 0) (type default))
    (uuid 61c4fd10-476d-4fdb-966b-52d59358e0f7)
  )
  (wire (pts (xy 219.71 105.41) (xy 219.71 102.87))
    (stroke (width 0) (type default))
    (uuid 632bc7be-7e33-4d49-bdcd-68f4237ac251)
  )
  (wire (pts (xy 176.53 77.47) (xy 185.42 77.47))
    (stroke (width 0) (type default))
    (uuid 66bdab22-a946-47e3-8a11-462dbc713cc5)
  )
  (wire (pts (xy 77.47 104.14) (xy 77.47 106.68))
    (stroke (width 0) (type default))
    (uuid 6c30fa9d-1f2b-470f-9298-a5cfd5197127)
  )
  (wire (pts (xy 123.19 50.8) (xy 137.16 50.8))
    (stroke (width 0) (type default))
    (uuid 6e37cb95-cd9e-4c44-b0f8-fe1e1b4ef8f0)
  )
  (wire (pts (xy 152.4 55.88) (xy 152.4 53.34))
    (stroke (width 0) (type default))
    (uuid 705d8415-7b52-4d5a-9796-87cb7095d095)
  )
  (wire (pts (xy 67.31 63.5) (xy 87.63 63.5))
    (stroke (width 0) (type default))
    (uuid 71ac7b20-a2a8-4f1e-a318-70200410e374)
  )
  (wire (pts (xy 176.53 71.12) (xy 176.53 77.47))
    (stroke (width 0) (type default))
    (uuid 73a69f14-7bbd-48fa-804d-cfa2fd6269a5)
  )
  (wire (pts (xy 137.16 48.26) (xy 139.7 48.26))
    (stroke (width 0) (type default))
    (uuid 75eab8e8-ef04-48e3-83ac-94b8006d46eb)
  )
  (wire (pts (xy 236.22 62.23) (xy 236.22 64.77))
    (stroke (width 0) (type default))
    (uuid 76e08716-503e-4872-b3aa-045e764aa8bf)
  )
  (wire (pts (xy 67.31 83.82) (xy 87.63 83.82))
    (stroke (width 0) (type default))
    (uuid 77d0c703-fb01-4862-a452-c88a14e7bc8b)
  )
  (wire (pts (xy 205.74 74.93) (xy 212.09 74.93))
    (stroke (width 0) (type default))
    (uuid 78e13b63-968b-43fc-bae8-38489eca0dfd)
  )
  (wire (pts (xy 67.31 81.28) (xy 87.63 81.28))
    (stroke (width 0) (type default))
    (uuid 792331c9-ec87-4279-a404-83381d0526cf)
  )
  (wire (pts (xy 148.59 96.52) (xy 143.51 96.52))
    (stroke (width 0) (type default))
    (uuid 7a324bd3-78ec-4bce-a20c-648219b3bc37)
  )
  (wire (pts (xy 172.72 41.91) (xy 185.42 41.91))
    (stroke (width 0) (type default))
    (uuid 7a4eb15f-76ac-45c2-a9e9-a49f2fb69abc)
  )
  (wire (pts (xy 123.19 73.66) (xy 173.99 73.66))
    (stroke (width 0) (type default))
    (uuid 7a8ba04d-8b83-42b3-9d4f-b935e862470c)
  )
  (wire (pts (xy 68.58 162.56) (xy 68.58 167.64))
    (stroke (width 0) (type default))
    (uuid 7ac647fb-3832-475e-b1c7-1b7d27543c29)
  )
  (wire (pts (xy 217.17 85.09) (xy 217.17 77.47))
    (stroke (width 0) (type default))
    (uuid 7adb1e2a-6ebf-4c6b-b4e3-a522187709a5)
  )
  (wire (pts (xy 63.5 101.6) (xy 87.63 101.6))
    (stroke (width 0) (type default))
    (uuid 819dc5d5-93d5-4a87-ac38-c58362e50727)
  )
  (wire (pts (xy 67.31 73.66) (xy 87.63 73.66))
    (stroke (width 0) (type default))
    (uuid 83ea13e8-733d-4a71-a926-55bdd0702239)
  )
  (wire (pts (xy 207.01 101.6) (xy 207.01 102.87))
    (stroke (width 0) (type default))
    (uuid 8567ff1b-1e82-4836-bb46-d5f27732dc26)
  )
  (wire (pts (xy 179.07 68.58) (xy 179.07 72.39))
    (stroke (width 0) (type default))
    (uuid 858771fb-86c6-4a83-8a1d-29d290f760ff)
  )
  (wire (pts (xy 123.19 104.14) (xy 160.02 104.14))
    (stroke (width 0) (type default))
    (uuid 866aec1b-475f-46bf-b980-979bb90afa37)
  )
  (wire (pts (xy 38.1 149.86) (xy 38.1 147.32))
    (stroke (width 0) (type default))
    (uuid 8dd8b904-f1b4-46f2-8acc-dffe61841a5a)
  )
  (wire (pts (xy 67.31 78.74) (xy 87.63 78.74))
    (stroke (width 0) (type default))
    (uuid 8f4b0042-5ed4-41c6-a5d6-e042dd5b5985)
  )
  (wire (pts (xy 185.42 34.29) (xy 201.93 34.29))
    (stroke (width 0) (type default))
    (uuid 969b32e4-af6d-47b0-a15f-9a0b84c10b7c)
  )
  (wire (pts (xy 222.25 90.17) (xy 222.25 85.09))
    (stroke (width 0) (type default))
    (uuid 9f08b65f-d069-4fd4-bf9a-77ad7faaeb5f)
  )
  (wire (pts (xy 274.32 87.63) (xy 274.32 85.09))
    (stroke (width 0) (type default))
    (uuid a08e0e89-1136-4245-8fb5-2c1c2e7fc5df)
  )
  (wire (pts (xy 212.09 101.6) (xy 212.09 102.87))
    (stroke (width 0) (type default))
    (uuid a2c999ec-792a-49c9-93f9-735a386fc05f)
  )
  (wire (pts (xy 82.55 48.26) (xy 87.63 48.26))
    (stroke (width 0) (type default))
    (uuid a3942339-60c6-4ef0-a681-61fa3bef573d)
  )
  (wire (pts (xy 207.01 87.63) (xy 207.01 93.98))
    (stroke (width 0) (type default))
    (uuid a54141aa-b915-4cc8-82e6-012fbdc8933d)
  )
  (wire (pts (xy 173.99 85.09) (xy 185.42 85.09))
    (stroke (width 0) (type default))
    (uuid a67e3498-28df-4e69-8ddf-864dc0dc147b)
  )
  (wire (pts (xy 67.31 88.9) (xy 71.12 88.9))
    (stroke (width 0) (type default))
    (uuid ad320a34-d440-445c-9122-e10d2d59791c)
  )
  (wire (pts (xy 74.93 48.26) (xy 67.31 48.26))
    (stroke (width 0) (type default))
    (uuid ae0f0686-8ea3-4b1e-bdef-2bb1156d590f)
  )
  (wire (pts (xy 274.32 77.47) (xy 267.97 77.47))
    (stroke (width 0) (type default))
    (uuid ae879d9f-7297-4b70-924d-977c9500f167)
  )
  (wire (pts (xy 205.74 87.63) (xy 207.01 87.63))
    (stroke (width 0) (type default))
    (uuid b2b33bea-ae96-4317-8501-62a97c9e32dd)
  )
  (wire (pts (xy 236.22 100.33) (xy 236.22 97.79))
    (stroke (width 0) (type default))
    (uuid b3e65ddf-bfd6-49ae-9876-0a7f4c83df20)
  )
  (wire (pts (xy 219.71 80.01) (xy 219.71 93.98))
    (stroke (width 0) (type default))
    (uuid b8828ec4-807d-4049-b487-09010bbaf4e3)
  )
  (wire (pts (xy 143.51 93.98) (xy 162.56 93.98))
    (stroke (width 0) (type default))
    (uuid bc494585-c053-493f-81f6-191438bafcab)
  )
  (wire (pts (xy 123.19 99.06) (xy 132.08 99.06))
    (stroke (width 0) (type default))
    (uuid bc68f601-9f3b-4374-b9c0-7eb6266ee04f)
  )
  (wire (pts (xy 212.09 74.93) (xy 212.09 93.98))
    (stroke (width 0) (type default))
    (uuid bd1fbad2-a495-415b-b2f4-ad9fc694c8c6)
  )
  (wire (pts (xy 247.65 85.09) (xy 261.62 85.09))
    (stroke (width 0) (type default))
    (uuid bd400e9a-732c-4996-a032-b92ea496f1c6)
  )
  (wire (pts (xy 68.58 149.86) (xy 60.96 149.86))
    (stroke (width 0) (type default))
    (uuid c7d50296-a2de-45ec-9682-5f3714cd93e8)
  )
  (wire (pts (xy 34.29 96.52) (xy 87.63 96.52))
    (stroke (width 0) (type default))
    (uuid ca9b2531-16e8-401b-b6c8-0b5caa34eb6b)
  )
  (wire (pts (xy 179.07 72.39) (xy 185.42 72.39))
    (stroke (width 0) (type default))
    (uuid cc2aa540-c93b-4673-accd-38c691a6a743)
  )
  (wire (pts (xy 222.25 85.09) (xy 224.79 85.09))
    (stroke (width 0) (type default))
    (uuid ccf4edeb-0fb0-46db-98a0-5c656e5b2d4f)
  )
  (wire (pts (xy 182.88 74.93) (xy 185.42 74.93))
    (stroke (width 0) (type default))
    (uuid ce6aa79b-8dc0-42c1-932c-5e161a89cc61)
  )
  (wire (pts (xy 212.09 105.41) (xy 212.09 102.87))
    (stroke (width 0) (type default))
    (uuid cf17e348-f8e7-4245-836f-da12728dfe49)
  )
  (wire (pts (xy 168.91 53.34) (xy 152.4 53.34))
    (stroke (width 0) (type default))
    (uuid cfcbfa10-265b-493b-8256-56478509f658)
  )
  (wire (pts (xy 68.58 167.64) (xy 68.58 170.18))
    (stroke (width 0) (type default))
    (uuid d2f6277a-71c3-4e63-b537-c4c5cff00b85)
  )
  (wire (pts (xy 69.85 149.86) (xy 68.58 149.86))
    (stroke (width 0) (type default))
    (uuid d3002761-a0fb-4579-a66a-9a651c1c67bb)
  )
  (wire (pts (xy 67.31 71.12) (xy 87.63 71.12))
    (stroke (width 0) (type default))
    (uuid d3c6499d-5a28-4506-aa43-c9637208aeb1)
  )
  (wire (pts (xy 123.19 53.34) (xy 152.4 53.34))
    (stroke (width 0) (type default))
    (uuid d52fcdd8-2685-4d38-b426-e7fb2bd3170a)
  )
  (wire (pts (xy 67.31 58.42) (xy 87.63 58.42))
    (stroke (width 0) (type default))
    (uuid d5a62208-9892-46e4-8096-2b7f22016535)
  )
  (wire (pts (xy 123.19 63.5) (xy 128.27 63.5))
    (stroke (width 0) (type default))
    (uuid d5da4d3c-3ebd-41c1-98d2-a6663e651e19)
  )
  (wire (pts (xy 154.94 148.59) (xy 154.94 163.83))
    (stroke (width 0) (type default))
    (uuid d7c8e1af-c1d6-4a1b-ac26-f030f641f414)
  )
  (wire (pts (xy 118.11 148.59) (xy 125.73 148.59))
    (stroke (width 0.15) (type default))
    (uuid e108cc5e-8200-4779-93df-69c82e5539dc)
  )
  (wire (pts (xy 69.85 147.32) (xy 66.04 147.32))
    (stroke (width 0) (type default))
    (uuid e201cc72-e883-443f-b8bc-6e685daac5a7)
  )
  (wire (pts (xy 38.1 149.86) (xy 45.72 149.86))
    (stroke (width 0) (type default))
    (uuid e2ca4e1b-0aa8-4117-a9cb-f0d62668b316)
  )
  (wire (pts (xy 205.74 85.09) (xy 217.17 85.09))
    (stroke (width 0) (type default))
    (uuid e44d70df-cc81-4bec-ace0-0fdb993830ea)
  )
  (wire (pts (xy 205.74 77.47) (xy 214.63 77.47))
    (stroke (width 0) (type default))
    (uuid e6701bed-6d8b-49fc-b2ae-529c81c1cd52)
  )
  (wire (pts (xy 274.32 74.93) (xy 274.32 77.47))
    (stroke (width 0) (type default))
    (uuid e8d9f7d4-bcde-4a12-95fd-690edd5e29c2)
  )
  (wire (pts (xy 123.19 55.88) (xy 128.27 55.88))
    (stroke (width 0) (type default))
    (uuid ebb68028-896d-4030-a1eb-946997ce7011)
  )
  (wire (pts (xy 67.31 60.96) (xy 87.63 60.96))
    (stroke (width 0) (type default))
    (uuid ed45a2c4-c00b-4499-8ae8-da3e5061a72b)
  )
  (wire (pts (xy 224.79 80.01) (xy 224.79 82.55))
    (stroke (width 0) (type default))
    (uuid ee9a34a0-acad-4b5b-9e08-8200ee4ce3c4)
  )
  (wire (pts (xy 182.88 87.63) (xy 182.88 99.06))
    (stroke (width 0) (type default))
    (uuid f3608e45-dbd9-4dc6-b19e-e4a57997d647)
  )
  (wire (pts (xy 38.1 147.32) (xy 38.1 144.78))
    (stroke (width 0) (type default))
    (uuid f44b4bcd-55f7-4c2b-942d-913f3fadf20b)
  )
  (wire (pts (xy 219.71 101.6) (xy 219.71 102.87))
    (stroke (width 0) (type default))
    (uuid f4d4659f-4380-4a53-aa0a-43dbfc44b621)
  )
  (wire (pts (xy 168.91 55.88) (xy 168.91 53.34))
    (stroke (width 0) (type default))
    (uuid f84d861c-a2db-4add-8c8a-76435e3d1236)
  )
  (wire (pts (xy 128.27 55.88) (xy 139.7 55.88))
    (stroke (width 0) (type default))
    (uuid f9a70cce-7f62-4c4c-a0b0-27d516fc8239)
  )
  (wire (pts (xy 214.63 77.47) (xy 214.63 74.93))
    (stroke (width 0) (type default))
    (uuid fe038913-1ad3-410b-8292-08d699300ac0)
  )
  (wire (pts (xy 77.47 104.14) (xy 87.63 104.14))
    (stroke (width 0) (type default))
    (uuid febd8876-a876-41b0-b6eb-a712eed1ae40)
  )

  (image (at 40.64 27.94) (scale 1.39635)
    (uuid 77d584ec-dbf7-469c-9e55-555604f0d768)
    (data
      iVBORw0KGgoAAAANSUhEUgAAAe8AAAE2CAIAAADH2o19AAAAA3NCSVQICAjb4U/gAAAACXBIWXMA
      AA50AAAOdAFrJLPWAAAgAElEQVR4nOy9WZMcOa4uCJD0PZbMlKr72By7TzP//1fd6a4qSbnE4hsX
      zMPnzmS4R0SmVN1nesyGJktFeNC5gh9AAAT5zz//pOspEBEz3/iViEhE7jzBu+s8t95FfmZOf4qf
      4/PFi7GFi6beqvdWj+70NG1DfIKH98cnfTeE8Jm6fjndas/9cVgMKV++//nSFpkXL6Zf14P5STq5
      lZ+Z03m507xFl69SYCTCEEJa44eEvc4QX7zavDU9x2JjohuL4qLetP3JZ9Cbkov2EBELEVGgJbUo
      pUQkrAgzpdtb/V30Oi3zfuNRDs/pKg2nE3en0oty7rbzTlrM1GIirk7xopGLrqWZp68JPcQXUTiG
      K+3Lh62d2kZaa83MpizLG1k/HoWrsPvJ9BlqiHnkcgjuv3sfHa6O0X0UuIrmt6j8VuHrem9hEJ6j
      /Dsgsng9LvtFLbfKSfuVlqlnklo06fPzm7b/Fq9dtISIvPefLHnxeYHmd9bAVTS/OjJ0ezzXab0K
      Fr2+w2yuIlTatg9XdUjbv6pFrSYNy1pWRd5C819e4ylrjPNyf1VeHfP4NYSQQt7i17RSmVv7a1Ae
      01UiWWPRT0230Tr99SqaU0KrH1KgiADNlVLmdu7rqPGZ9JlG0N2lsgaa9ah9KM391K+3GnOLmjH0
      9/lKuravTu2ddi4w9xaJf57PpdQTP9ziNLeauuYlVzMzcyTNxaytuQt+Ute4yLqD6ybFEj6kz6sZ
      7qPDnaV7p8wFh8BbdwhgMapXmdb9dCsT0FlJUtfFf+/JkwgJyXt77q+yW2khyV4VGi5aznwHdu+M
      XiwzXSkT+M4/pZL11XYu6ro6uVc5dPpW+mFRyFU29mFfPpOukqJZV3CfXm9V+VPi27qWW3WtH94f
      zVtF3UlXa7lTHXJ+fgf6ScS836qrI/Nha+mafLFeHher90ZRv7aqP3ySSl6/UP4C+H6WAtc4kqLD
      5wu59XW9mNNm3+Gmd9DnToF0U9hftufqi3RtLXw4pJ8E/XXJ6Yt3QCYdpQ/lvxTN6e4k3mKc66r5
      cu+4nvF1m+93nC4HP50yfEhVLus230kmbXH6msj19ZwS4tWOfZ7DXJWD1kR2a5XemY/PV7ro3TrP
      1TmmeWd6p6JP1pvWvsamn+UBV+tNBzCVzW/V+5lmf9iwq5iYDma6RPm2bP5hLTHRXUC/ypWv5r8l
      H9C1CaKkp3eo9MNyUq62EO4+YOSQLa7h7/siUnPbEi3ELM/PVd/YDV8F/fUg3Fo+dxjDVVa3GJk4
      tukg38K4FBxjuiMlfJLUUeZaDXI/3Vy8l+si9mSyMVxWcYeBpb1mmjKbq8ycEjK6BZF3eM4n01pS
      kGskFX+62sNbjfx8S+4zwEgNV3neh6XRbeJeP7nP3u/T0AIFYgLXWVD8LSphZrm01q5nZM3erg71
      LQ3Ggt4Wk3s/fTi/P0t+dGNUmRla2vsr/OrX+yviKoXTagQiEqXkd78Z68FZz/ItPF1nuMNdrmZb
      PLlKYOm7C5EiRRulFDPDrIfPsakfTjoGzTrnnMMM6llPvU5pI2+BwJrT3CGJtO9X1yOep7WrOS0a
      EBWSV6l0sTCZphrNot1Ji282/aowcgv0b6VbTP4WnC1I6sORvSPrrVseeThfirGUyOCLXn+ejUmy
      e1pTZDpuaaews7ta19Uqbi3dNZtctCHtb5RBrvKktPzF+N/hUgvCuCNufNjH9Gscz7TAD0tOG3wL
      HehSFru6QD5sXnz31gq6VTvoTUScc977WOlVdEA74xQvJJsFYtIlGVztxfRr2s2VtLQG5fRhBKmr
      47NYdxH4vPfAXyLSWmut8zwHEAPWF+Nzpc0i3ntrrbV2tDaieSqbr5deqtO4j2ZxKq/O6ZoC19Qy
      fVbvJSuljDG5yYwxEdbXyHbn8zTgpNAXc2u1L8h9seavjs5PpVs7yqtCSjrWcSXcAvT7rbrV/qto
      RddGZpHhVv7FT7cG7VYvPvOELonmFqDI3V3FVR5wtZ0LGrg/C7ce/mxK18lVJrRo/P1K00lMueyd
      zt5/uC7/zterGRZPII8756y1zjm5YVJO279YIDFnnJoF3H/ci1R2WXGRNfAt8P0q71nUHpuntQYK
      D8OA/hpjtNb4kOd5yrDvdCGEMI5j13V934/WXt3TXEXzCHfrMVy/lTZmkRYPMQJXUEVN1aGFxpgy
      L/I8L4pCaz3B+kde2pROUJLTpKtxzZ0WXxeoKpeiXJynmO0qI00BSCkFITRSgPceQxC3SKBvPyf0
      OcuydKSursaUCNLnIQSQC0oG3cilOuLOUr+VPiSFxUjiq/c+FWRijbdQ9X5pt3jbmqOIiNY67kbj
      E5qrvoP4dFfqvPXKZ7pzq7SrLPBW/g+5yDrbJ3nnh526X46sJBVarawQgrX2cDhANq+qCrNztUxJ
      ZE++FFMg6EVpF6UppcL8CtbXog0oVzFPq3je76+XEl1CmyRkkzKS9RAtngAiYmuB7N77cRw3mw2k
      V1AmkAHvTv6UIQCRQcZvb2/n8xntMMYYY+64vS5m/xaaL6bsFnnfmVa6pLc1DXRDf2rPRZY3TbPd
      bkVEG7OAhbTeRTnMzDSBhrnV23VaYAGGALWmaoSr8HGnzJiccyn6y7yLdM4554Zh6PveOZfneVVV
      zJxl2f2m3pqe+FNkEiEEcOnFJP0U9HyY4gSkzC8+Tx+mOdOf7qDYnV8/05HI53j1cF31h3D5b01X
      IfuT9PYflVIcjC0fx/F0Or29vSml8jzPsgyCS8owFtRC19AECGiMiWITIG+0dr2pf3995fCXQnks
      fw3ci5YsXuHVtiZ+BV5DHldKQb7uum4cR2aGyiWS91o6jHTbdd3xeGzbtqqqummqqsqyzHtvzKcg
      br3urmZYo/ni+dUn6Vtepl0L1GjOubZth2EIzjMzhHTM1OJd+sS6M7+2DICDkG211tgmrNnRLdMc
      XSKFnRMmNe5BgNeQVl5fXw+HwzAMRVE8PDyEEDabDTYmdxq/GNlUkIlb2nEcRaQoChDWz7rK3U/p
      mFxtakr36Ye4ZtJXri6t9N01N4o7cVqRYEo0C9ayaNL/6ygZqWVNTv8JbGaNVh9mW8xF/GCtPR6P
      5/O5qqrNZlNVFfAobmEpmZRbY0JEQUQpFfegEPfGcXTOYZVh7VAiidPleolEskZtua1hu4rmMV2l
      fxEBoOd5PgyD9/54PI7jWJZl0zTrzi4YG7AIihpmrut6v9/HPc1n5uV+njX/SD8sJvQqCl88URfP
      h2EQH+wwogvW2qIohKajuh+2fCp2buBPyOYxiYj3/nw+j+MYBx3Dt5Aob3GYlIJBZOfzue/7PM/r
      unbOEVGWZZAsoBF7e3t7fn4ehsEYY60NIRhjIKTTNSJbgODiQ6zaWtu2LfhkrPG+nJt2cJ3t6gJb
      wHT6+SqUpz36vFy8LupW4xdL95bcdKeWT+LmHeL+2bQe0n9h4X89fbINH2IcNMjMjGVVFMUtOrk6
      a/FXRcSzFgIfnHNd151Op7qui6KAyE90cYI0LZNnVWqE5jWprAW4Bb+5+nmR4s4ePMZa23Xd29tb
      dCtKu7xeC5BwIedtt9vHx8eqrqNLDMDk1kTcIaE7q+DDuV4M1EX+WW/Os0MLBTHGnE4nmZVgkYPe
      AaKry9AsctzvQ5xy59zhcDidTsMwbLdbay3E2yzLZE63ykmRFx0YhuFwOHRdh/0RqDmEALCGbN51
      3TAMkKbP57PWumkaSBm0wusUBNckRYkDEBYPWOItqZyvKRzWT+6nlMPdEW2uDl2k6fsTvP5pwVPX
      gxOlm/duzvmjUB+rphs0dKsxH7Ztne0z6T8Bu/96WgB0nBrImEVRAHMpRly564+/hnvMXUrn5/MZ
      mmUI+6m1bUGQ05IJQsRBXcw7f2KTdF+qWJMBz/t4oBs2JV3XEV2PbrQgwiibF0Wx2+3qutbm3blj
      MW4L+L7f1M8A+mJxpQN1s9fMOHTLQkbpuP3qus5aO44jxMqrtd8Bd2Y29xu9fgckAkg9HA7e+zzP
      MRPOubquo3h7te4184fo3bZt27YRmkUkmkPBPEIIeZ4jqoyI9H3f9z3Q/2qHIzWD0YFXpyQehwAK
      loUj1J30IaO6g7aSuEIuXkmbvc5wtdgFUq/FlkXOtOXRFJbmDCFQMvIx2yeVj7eWxP2VvyaJz9R1
      q7r/8HQH4EAb2HeWZVmWJZa0zAJyzH9VQImfp79zyVg+p9Pp5eUF6ngigpKaki3mQvoRWYdyuUn5
      tzBxAXB3xoFnnbhSqiiKzWbT9326Ku/MNcZNRKB0jpI+3Qgjse7LZ6jufv77X9PhTcWyKDZlWQad
      xDiOkGWjl8cdEl//uOQACYisn1yIbPCggnYbojosogB0uqaOWEBPHPGo0ePEZ4hmeQQ1aq03m83T
      05OIHI9H8DGoSsKc8DooNTqxwg0myzI8xJMsy2BdMcaUZcnMkUPSXTnow1m/hWgyayHBmVLXKCJK
      DVaLF+N+U2bnE0qE7vj1qkdUzBk7HkceeljY2SJ5eQyZcxhDZsZGNRq61x28vxIWoh/dWNtXB/YO
      8KW4s37yH5vuDF2cJswRllU63Yui1sw7ykAgGKU1Xoed7eXl5fX1dRzHp6ensiwzYzg5QRqboYRk
      /ne1zeseLdjJrcV+axDoEg1g+22aZhgGSbwV15nR3zjv0LyneiFZ7YCvksdarrrT31tdWPOzBfqn
      vaWEaEWEmKPFu+97ay2gCaMhtxUG64f3ZK6r7DR9qLUuy7KqqtPp1Pe91rqqqs9M3uJJPPOWqk0W
      Qius2/v9HtDftu1kox9H8DTAE2AaDAbbFti1wbRDCHCMgYyP6Ud+iEKxzSnU3k9XZc91f1Gac26w
      Y/S1AkEqRdhhrLsvyYFAwP1CgIpVpGieIm9c5BiNyPOi8xa2JjyrWbDTx9ogImttzHOrg7cA/b4o
      ly65X0Ph9RL65aL+59PVNRKdC4BK0RElfTGSZQqCeAie7ZzzIRhjsiJXJNa7buhh5TLGNE0TST14
      Eg6KdKCgIV4wcbjYDvKNc0B0DRDWX+PDNUe/leBVkec5nNzinN5i2HdoL/popvXewlkmkvnv52WL
      W6Xdcm5ePFdqCnMJQyARgQBoVj39FEmbRRzzxVStUwgB0hykXWstKa2z3Au1/VAPA3gLyEsp5ad4
      L4GISN5pMWW56Zk3ZXQgEZGyqAKJYg4kpFiYWCudGfyKLRg8YQ6HQ9u2zDwMQ57nj4+PdV1DFdN1
      XXRqxNi1bdv3fVEUf//735VSfd9jGdR1jbURQhAmCCismOW6xLGYwkRkTnmBEBFxEBHWOng/Onvq
      2rfXo4gIk4iwqDw3ZVk+7HZZRlprmbHee+8lYAvSdR1sYkbpzBgQnJcAiiciHzyQtyiKjAwRKWYo
      EI3Wfd+fz+cfP34YY7CFxk6oKsr/9b/+FzqgmK21fd+/vL4+PjwopRSbw9vJGEOimHRZliE4/R7S
      E+3Ut6jlp5j6J5d6fDfNdgsp7i+Dz/Dg++kzksqk8QBtr4r0REop571SShvjus5577zXxrBSXpzS
      SjOH4EUS34EQPfaYlXjvDSsmDsx93z+/vCilsiKvt5ssy9q2PbX96Hyz3W232y9ffiuKIggTkbDy
      EoQoELGwBFFKBR80E822OKGlG9V7TJjkuEkUuULAKvCUsBmjNaG0ZHnM5RPNfjVxuIIIlC8+BA+/
      OOawcuiKwgsxE7MAiIlobk8IgfWkrRIRFnovIAgzpzEjNatAxMGjNe+zOcNCbDlfqnNTnopP9zcB
      a4JhZq1UkedVWcq8OVJKpfsnZiZKOUHCShm6eDK3qrmVeN7yl2XZtu04jtCxAFbcHCGBiPBQGOwx
      MLNmNYuP7+aXeDgoen/L5bRJomsGF8EOAP6k0OBjXwafdGgbAeVgLXBHxVkMTAC8cYwx4zjCM3K/
      34MZfqb7C3nh2rRdkSBEZHD27e3tn3/8OTgLoSHXgPItvDyJaOz7yJ+FaRiGYRhOp1M3DpuqrsuK
      qwoSEzbRMp+tCPOCCSbTWmfmfXLhunM6nbIsg4/UOI5EJD4Mw6AhevsQQnDew0NAa83kuq5LI2aw
      uhf44to4fDyY6YcPk3y0E7pa/q2i7jTyp2SizyQRSH7X64ofWCtS71V778VD/ZJsaAJ7CSyKOTCL
      kNcmo5keDoeDl5Dn+eCs0nocx/bc6SzbbrdPT084MS/C3nvrnPeeyBFRyAIRsSPvPYnnICEE0irV
      UvrZK1kSJQZSYi3Dyn0/DgrDWNTRpzOolKJLNEjLTMbtYpRufeXZSyR93c5GIKWUoqUbApKO7ZkF
      89i7mD8le04rTcTtqaKEV60IgOiG1LLo9SLD+vNVul3qaj9JxFmWbbfbfhzGV/v6+jpxYGP6cTM6
      b31gZuvsOI7OBSgW8jwv8yz6RcVhCkmUBjeRFy30X9CQaK3HcayqqmpqnZmsyK1zfdd1XQedSQgB
      1lSl1DAMXdeJyH6/BzwNw1BVVVbkXkIIwYXJe7/ruqUrThDm99s6+MZ+ajHEN9FBFImwYqWUd3J4
      O/3zn38c23PwRIqL3Gw2GyJ6/PI1EDnnjue273trB+y8xnE8tf3xeCzPXb/ZPOz2mk1eQnFEbdt3
      wwBSY2ajlLXeZ6Esy9xokgkavJdhsN0wktKGDRE5F0TEWm+tl0oJqSAS/ESUo/XS9t77l7dXrbX1
      zntfFEVRFJkpiCGn3IP1OyiZfvhZ0LzNPm/m/2VQ/oV3f7m6d4CjifJkdhBwdtqfEREk9BAoiGil
      tNZ5bpRSRsPOP2IJnNozM2evL9rkZVkWWf74+Piw222bDa40gHKyHwb4iUFNb4zxbhzHMTgfQhDy
      WuuqbIg1sR7HaRE557C9iwBUZDl0IyJB6wnNYxewqJk1vPEiViqlmJiUpBw9yg00653SE0AR7dLl
      hsqC9xLC+xKek1IkEnDZ0sXBUJ4GmS6fs2KI3pEvTXkkEM13fVzymIWtVVIaWKFwFExTFZCIsFLT
      JmPeYSzQJI7qLcqhhWx+R1CSy81slmW73c4F773//v0Zdlg4/wNbiWgYhr5vj8czZN6mafbbTdM0
      i7NtEdBTThgnNVYKzW/XdZvNBudfieh0OkEzvt/v8zzHKTK8Hq1J2+0WSkPvvc4M3Cjht45s1tqF
      pWWNDusxuYMgizwThYFNhNCPw9vp+HY4hEBKqSLLmXlwlogCibX2dDodj8e+b3GQyjl37obT6ZTn
      ed/3Rum6rk0+MUXv/el0AtRqrTOtlVJSBCjimTms9O8pb8fCjmwVAkVVVcwavslQzlhr7TBWVQUP
      MKVpIUd8Jt2RNX5K4r5T1P3M96f41ru30PlXuv8RzvPlZgXHLMbB9X0/QwYHkuApMGVKG2PKKq+K
      0igN20ZRlkVRvB0Ph/PJfrdVvfntt98edvv9dttU77rEYRjeDgccngTxVFVVVVU/tO3p3Pd9cJ6V
      FGX55Qsro+EVczweT+0Zp+2iYVxrXZfVbrfbbrdZlmmdxS7AxNVPe00yxkA6xq9ocFZMjhgqCR+G
      v1jC8GJYi1DpB06CES6MT4pZFFNYyv6yWgtIIoJgXTEn0XRVk8gUrZCTTUYqyKdV0MwS0pLTVbOk
      4bkX62gESfmcFrWmH7Ms9Jphar0PIsV5WTw8PIVAp7Y/d50Ie7HHcxdItf2IcGbOue58BiF2XRec
      J1KbDaeAHv/CiJ82Jvq0QCoHTRtjNptNURSgFeud9c7kWVbko7PCRIqV0V4C9OxZkXPfBZJAAmcg
      hHtWSgmTCz5V46QdV3Sx/G4t7MUKXGfAQ2s9ETkXvBfvJATyPngJWusgTMyiWIRH57thOHcdETOp
      0Tlrp8gV8UwwiBtfMf0IT6GUsvMaK6rSS9BzBwLJ6Cz0J6NzQAqlFJ7DcQXeLCK82eycc8fj8fX1
      9eXlJc/LyavFaBd8ICFRDCHymh/benzu/HRzQ/NLaV3gHQRPl99PVfELrfr8O3HNhxDsYL9/ez53
      7el0att+ok9mYDqUFF8fn56enrTWymildF1vnp6+Dtb1o2vP/aZRucn2m32elVk2HURyzp3b9tu3
      b9++fXs9Hrz32+12v9/v9/vD4XB4eT0cX4PzkNiaZmvyzDn3559/Pj8/vx2P0Goi0iGLYJs+2HHe
      H0/bRGb2Xk6ntm1bIoLnmJrEJoVxCSRRyxrdqGieR6D5wqP3qqT1jubMlIjnkrjbqiS4bpRs0hLw
      QWk9Q3WCh0REFJgmbRnPZzWZJYjQpJGfoGwuMxLW9JyJRBRdgP5VfE/bv+Y3VwcB6QLNF1ueDwkd
      7vqPj4/H4/F0aiEX43iCc45ZjDFlnsus0HhjlWVZnhs9u0+lPYnecnTJfGDjzrLseDw+Pz+XZQkX
      FKhH4NNCM8YtzqNGlVakCVGMnZXM7lw0e+BdJZTPCHSXIHIFI0C11vvBjk6Czkye56OdXBXRSOvc
      6F0IId7Am3rO4muWZfWmKYrC5BloHa977/u+JyI9azCLoijzYuJec4LGiaxF3yG/g1Vora21/ThY
      a7fbLQSlvu+HYRBha22WZZiFxVj9FLqtZZlfBvT1Wz9F9x9mSLfSP9WwOz1a8A+s41urDBL08/Pz
      6+Ht7e2t70ePYrVi1h5EEgRYWVcFZqeqqqevX7yEtu8PhwNWCk7hQWsBD4VhGH78+PG///mPt7c3
      59zj4yPkpLe3t28/vr+9/IDADmbf9/3xePy///nPb9++nU4nay0zT0E4nMvz/Hw+hxD22x18DdL2
      w+nAJAloPsu24r3AhJPnefTaWuDaQsy6NchgDFHryMyKSC71G7FwKGajDSCSNMBEmGgG6KmpZnmf
      Z0QV7LyjVJq2P1ZKRHDfoEuwXtDGuuPpwzVWL9LHZ0HvUBspw1o3zTbLin58adu2H4c8z+HrUhTF
      brPdb7cwV8K9ZBgGa32eSxLIc0rxYP2idjg+wko5DMPb21tRV6RVXdejd4Oz3Ti0Q89Gj96RVqRV
      YNy3QvgcmDyJKCat0HInwUnQl2yfkp3MNI5ra+bHaeURxSRBvPdt20Lno5QyJguinBuV0aR4dL7v
      xywbgoTAygsZzaSYtSqyUmd5VpRKqaKoMlOwMopNIBpdGKwPgbwX5wboSfI8Z9KZ6Yq8MlmhTU7E
      io3Ruc4KYQ1/nRBIhF2gfnTWBW1odL7rBu8tKcaeJstLbXIoVXe7h4eHh6qaAvLwpF286O+ddAcT
      fxYur774y4X8O9IVHoMvsvx1nX/KCO4b/LlrT6f2cDidEH+ClSnyzBTCZK11o/Xel2W52WyqemOy
      Aj6Ifd8/Pn55PRyLqi7LmkiFQHaECAx3A+n78XzuTqd2tFabfLsbrQv9OHRDj7q8SD+OoJC34/nH
      y+vz61vUswsrLzR0w2C9C5QVVdePYb7JyHvp+wGOy0RUFEVRVFAGRqEYaA4VaPRqi7tzns+OLE4j
      rnk2XyY8TPT1jEyxKIC49Q5OzESUmyxGN4OdaTLmSYgeouzdtB1hVoqJ2fvgvBPnmVnzdMwltnzh
      Wioizr+3J+qFIOBPpKEuoPxDIlmn607EdwTzSbaaFUmpmyQi5uAMEWYdx+URT0dEvHU0U2pkjO/j
      lYjScUpQXZZl//Vf/1VVFQJvwV8lnvsfhuF4PEI+TZlwusOIPJPnMD1pvUuLRMoM/0WODd0wYMvc
      97338WIRZlIwdrV9l+ewT7rBWe8JqqSmaYCh1loX/OgdnHBCCHAoxO4k2h6YedQjxGpMB89yPeg1
      zAk2g3hgAdUFmqzQRVHgRGKeZWVZ1nXdNA1sbpReafSJ4fl3wO6/G77vLIF/YRWT3HAprEX5huLZ
      OuestcKks6wsy7JqQgjH88l23fnUvb6+vuxeHh4e4GVLRF4EOzzn3PF8+t///Edhsqooy7JkVcFS
      MtFAdFGf1RrQccfVISJewmBHxDWEdAVaIiJSU+ANEBuTFmEicc6fz2cI8mVZQi8ab5BI15ea46RC
      3kerogY8Hgh6H7H1GBLRjBUy211hwBuGgbC5L8u6rgGycGM7nI7wb1ZKNVUNTwSttQSaTMR9341D
      ZDPoBRgSmoc8/bnVWmNssXPFoEVAl/mIbz8OWKpxMUJ+VfPZgrQ7CwH/k+mDE9sL9hL/egne+8GO
      5/P527cf2HxtNhujc4xa3/dCHrt1ZgYFbJsNTopaa60N0UcQow9aibueSNNAGUT1enh4+P333533
      x+OxaRoclFBaD+NosoyY66ZpNhuTZYIwclqbLLPOBZzSgal6Do4cx1pdiw66QPn7iW/oZNCjuABQ
      aTR0ZFnmSYQVNjRaZzjaOmLzOYxKKM+9MXkMDXo6nYwxngSloeS6rrHbRdiysqp0ngWmwdnMZWAP
      pFXTNJg7a631LtAU0DjujZRSROKcC560yqb83iMCn4honWmdWTtgoLz3+oZLZ7pVTBfw/59iuqo6
      CCTChNMV3guzdoGYNbMmpiKvirz67//+75e3134YmXn07u1wej0eejuKSNd1r8fD77//+ccff8AF
      pW3b3BSGVVPVj4+PD0+PdV2H+Twa0JmNFsWeJJAirVir4NkLCSvgdQjBk5i8bNs207pqtmD/3WAp
      zMeVjY56P7jDAjdh2cqzciFrF0XVNFU8jD3xA2asF+SMJzzVZfzRyO1kkok4CnDA2efn5z/++CPu
      DP72t78ZrSEXnrv2+/fvr6+v5/MZBwmfnp6yIq+ampidtcfj8fdvfx4OB7RfaY3jh2VZPj4+Nk1T
      FoUxpm3bHz9+vHz/UVXVw8PD38u/R5pfEPxgx5eXl5eXl/P5PNl+s6yu6+12W1UVNMwEgd1oDu/+
      ILGzi+VzS84w9zOlqBTL9d4775xzp1P748eP79+/Hw6HPM/zPN9u9rvdTmt9Pp/7oTVKYzsDWW+7
      2TZNA6xv24lvw1gKvr3WZPk5wiLkxCzLTqfT4XwC+vv51D70g2DvYCdrPpR2KmqrFzu4xWT8moC2
      kD7wqU7UolEAACAASURBVKkqEdlsNsXhzRitlBJSzEyacJT54eGhLMowR5WBtIK+yxywV0QOhwNk
      BFA5Oi4iOOeJ0cBcRN03YkYDuI0xsAZ3XRdHAKsIQfv6sbPWYpOJFYuWnM/nuq6jpfozw/L/aQT/
      dwvmaUolCaXez2SkCUY5mBzhHKy1ZlZR9MOHduj//PPPf/z+z3/+85+gnDzPFWkiqvLi8fnh/1T/
      17Q/YyLoBPhCv0EyXcsJ2J2QdG6UMcbkWV4WWTyVw2TyrKqqoiigycSOMMYrP3ctEWmVRTQHnG02
      O2Z5etzjYDZwADGnrp5pWJATr9QvSBCGDofD9+/fz+czEUGCLKsKh+ne3t6+ffv2+++/w8632Wzy
      PI9nnruu+/Hjxz/+8Q8EQiAik2VKKaypYRi+fPnysN/neX46nZ6fn99eX7G1tdbCsyidTZkdk/74
      44/v37+3bQvzQFEU0DxDlEyDTcUZX3QfG/n76XqkrsXwLVQWwNy+7w+vr9/++OP7jxc4Dj7s9n//
      +98fHx+11l3XtW3rnAtuhAFtu93ut7s8zxFZ5nA4DcOw2bwHD4kGTFh44rh467pzOwwD3OPyPKcz
      ee+DiDYGpPD09PTw8MCzSgGmjMWgpGsjKrlgdXy3X9PlpYg/n3BSLNW3K+LAFLnx7JkrJpvYb5nl
      dVntt7s4zpDElVJtEBz8yfMcXej71trBe+ucdm703npvEafduZFZrB2s1SKeWYhCrnPER+u6rhuH
      qqpwIslPRjEPdhtCyIsiz3PrRwSVlDlANnIcDoeqqsoyL8s8Mkvmm5aFxcjf+fWvp39Jaelm4n8y
      8axviQ1YADq+agW7NzErZgVrBUQSYJ9SypP0ff/HH3/88ccfh8Oht6Ni450wDhaxstbuHvZZlrE2
      TIpZaW2YSSlNxN7PN3yRkH4/Uw5qrKrKuuCCBzPwKkBLrpSq63r/+ADnY2gY8NBLeHl7PR6P1lqj
      c2MM4F4pVVUVG73Z1BAygOBQfch80psSGfwz4xj/Oe+7vj+eTqfTSbNh0v1gsdERVn0/dt3QDXaw
      nkKw1nsvIZB4EiJwgtcfz6fTKTAVRZEZIyKIE5IZU5XldrMhaESHAbEC/Rx9PtJP3NbDZBhPOAYm
      G7z0PaAcdo6ot1TEipZM6/O0dF3Tst4mx79R+9H3/el0Op1OOI7IzLBV7nY7SBBT7JQwhXDK8zzT
      hmYDBc6aK/UeLCXPc529x3RMN1PeexcmRz2YJvwsyBMRgq5BzJckdBEnSpvFWENGEB+iT8vVEfjl
      lIrnAlUiU6Z1mRdllpd5gWAYznsiMvP4QNcU0VxrPbQd0LyqKtB90zSbzaSwikHm1HSQJI+7trgD
      LYoCYnvf95ON2kxbTmau6xrunng3xmYBO4SDv7MWowENO81ikUwHu39ioPjfr4z+tfRXWnV/vd0v
      N8pxt8pJAZ2IgnV937+9vJ7PZ+8cCBrSEkSEvu9fD29d143eKaWKvIinfL3zcCJ4fHws6wbla61B
      LCEEHNcAa4/4IrMbwmazsW5SssNNhYgQtnC328ULIqCDBTW64KEzISLF2hgjirFZhO50u22yIxVF
      IbPLY/RWnEZvTnRN4ZBKwWvpAYuCZfLiRYgk5VWMVmSMYZHoGYmKoA1HqKK8Kne73W63w+DAcd7O
      V0jH6rB9WcRhjQVCWsL2uqqq7cO+67rudD6dTiGEpmlQYHTFiR2/SzjX00/fVoH2jb0dupGIyrIs
      87P3vszypqzqoixMlmVaFZlURdzFT/PhQ5yeaMk0JiciqAhw5phEMWulDJEiUiLsXCDFIZALJIGZ
      tFKklAmsoFMuy5pZD0OLqLx4l1kxaxHGP8Lhi0AhEIkiwS6VENGEWTMriNWXA/lzVxGlm5h00IJg
      V0VFkTWbynnvvWjnREQRudF665iC4mlf4r1FIJS4M+U51lr0FIxqFmz0EBd7u91Cww5NX16YRqq2
      q87tMfSOKNRlXeYZBW+M2W6b7bapm1IbhoBPQYzWWWGcc204D31LpKLzKDjozN0/RXApfS8+/Iek
      xUx9snlXkeVOHTdKkFQ2nyB79sIKRGEmTgqktRGRtm2fn5/P57MbLSarqqrNbpuXBUAn3r5ijKnq
      oigKP3jvfWdtNw79aEfni0TXTHOcRSKC9cWQ4WkZsogYo7Z18/j46LzArGq9c8EbY3Rmyrpqdtt6
      u1GGnRuDc+M4slZ5ZoCndV1rrd0cNJsoODeK+OPxra5L9g46UuyYo3vCAqPjHMn70M1iH5FcRrOK
      DEBrrdmo+WR4XhZa624YrPeTPieJbDXxME8sSutMKdOUza7Z7bYPRJRnbZ51eZ4XeWXYKFGacKxa
      rf/FVhMJsy6Kar9/3G5DnudlU37//v30doBBMZ7doyB86fIUBbLPUCPSTZ8WugFMYXYjdc5B5QQ9
      OG69iura+Er0SeLZF4dnRxQ7C31otJmvhUtFaY5OoIqjezhrZRRjMzidfPE+hADDBTypI0EsxgXc
      1VtXFIVcu3/vL7LHdUI5qFdEyrx43O0HZ70TL2HsB5yNOp1OVV2AqznnRDwRgZ9nWQYHTSIq8wxh
      8CARNE0DMzIKgUmnrmuaAx9q5hh0Xhmz2Wx2ux3eLcvy69evm82mKgrsVCAfQZ01mf4PhyybLgHA
      YT90Sin1GT73PwDlf7HAW7Oc4sWdGn8K+tOs6fb3neRmV7G53vdYmEAr731/bsmH0TuQNKwdDw8P
      RVEE9+43gqmsqqppmlGP4zj6GTjSpcHMJITDYrBR0SUyooqqajwJiXLOtX0HS5iIGKVpvlIZcp63
      1jmX6TwCNPYNbd9HtxZOrqCpigxIGh2UY8PUnNKHixmJKLFQT+FXpVRZlMYYP9/TRrNH+WazCSHY
      YUj35VgysEvBXIQ2G2OqqoJn12aziffkpOa36FWRthD2QthOMSmDG1Ry+3bcYUu4UPRdJbxb4B4f
      Xjk9tC5i8RWxVUVk02zUZgtorqqqbkqjmSlQ4BD8tNrVuzO/XKoF/RRM24mwMTkkSmijDMx0sxFR
      RIIPULhHnTgmRuKhGCJMmPc+2sFTJ1CeG+HtpCk2WgP371DMreX6eaxH6LxgwzAMzo9ZrjebWo8D
      tmiQm5xzh8OhKL/keb7b7aqqEmdp5gHMOpKsUlByBiHJNGfaGEXe67rMjaKyzDd1WTbl+9x7ghLz
      y5cvYdaxwk1q8gHOMsyFt05EoN+vqgp8seu6oiienp6g8Z+9C7xSiumGO8tPjs8Ho/eXx/+v1351
      Ff0Uf+JrpnhOZHM8TLFgIdMAkng6AapzrZQo8sEYk+W6zAueD7CY+cJPIjJZVpZlGMOkWpw7Ap+Z
      CSsDkajZyyVjVn60sWpFnJssK8q9d6djWx0qKLgpOi8Ow/l8Pp/Pw7Ar8yL2Lq4prPFuGPx8G8FU
      suG8MFVVaVbH4xGxTrHpjPxGJQc418sznYK0X6SmsxrKaJwSB/M4n8/xajOMp8U4B1E0GX4n+i/K
      LnTxlHX0LMiNyeZ7b+K8qBsHD6cpMKbWdXT3GNsRVquojSAEv6UlOcH+tmZgd6juUzfJpdScfgBc
      lmWZ53lU5qbskZm9EM3uyXEioVYTEcRLkfnoEAWBB7TAJk4cfXdOp6NSSmcZdihTBKgs68IZVuMQ
      AhyAoI6IUB5pYlJvqUm3BU1F9IiP3VxvR34qXeMEmohYrPdenNda5ybz3itldJ5Vu+p8Pp+66SRt
      URT7/V5EOHgi8t7/+PGj64bz+czMeW7qsojiACerHQMFXxfDyknACBCTzPFqwmyTQRxgkG/UV9Ic
      phjKHGaGjj7P8+12+/DwkC7jNWGs02dg7i+mf0cV6079RSiPOdeYfqsBCyqK0GZMVpZl1dQhuLbt
      rR2AUxBoRESYoi8KzbrjgNjLCgfq3vmESjydcWR0ujBhvgaImSGThRCgfAd+Rb0fEWEDd3x9O+93
      mTYq6QUl9Kbm6+viu5umeXx83O/3FARHRmneyqdeDHGEP5RMMW4hib3FzCBm55wLvuu6Yb5jpyxL
      55ybdeg037IAey+cOF3wEXnxHMACSYhn49NimmJpsc15liPPfHzSwi0ClqqluJmqaT5BV2kyi0Ab
      kgyckBATKSZRUEkIT5MVggvB9X0rIor48fEJxs/Iang6F0AUglZKgsgMmlBtZ9oUWX4+nsSHLMuq
      oizzihSHfjgfj8cQYGX9+vWrUqqsqx8vz9++fXs9HIqiyMuiLMu6KLd1cz4cYS9m5nEcv3z5UuZF
      keVlXlRVVWS5UTo3WaaNUio3WTSggxtAgwHNHV1bbCyKiITfjxoJU7gMd5kqkKfwcoKBYiKiIMIk
      wt6LUqYqM5Lu3LUidpPXT08Pu/3m7e1NRDhImeUF4tlmk3Mn7gAbx5GFNpvNbrOFM7hzjolFiEUZ
      dI3YKM1CFEQzk5A4j1PU4H9fjGnbdug6Owxaa5Pc08TMgQQThBB6xhhj8u12r40xWUGsfYjhEzKR
      6WpDRUJEIaGiKDjJrFuY2KfQIudfT/fZScxDt2H3hsh8892/wj/gFBjFBcWMY3g8C+8iAmekSfgQ
      4iDkA/nAIpq5LPOmqf7r//iv0+noSc79KYhr2/aPb3/uHvbMjLPQpJXySms98Q8Onr0jZxjClhZP
      UChrrZ0bEBLgy5cvx+PBIQBcCNHAPoxdGPofP751/XkYOhGBos8Y057Owfnz+fz9+/f/+ttvoW6U
      0pA0g/PM7L0frB2dq7Jss9ngWDhkgrraNGXTVJsQArPGGbg8L50LzDrqoL0X5hhUVcGYxIlHdhTC
      lFKaFdxCsApYcKNO3fW9Hb13A2nrnMvLoqyr8/kszMLsgoevDjOXdbXZbfftgzBBcISnDex84zhu
      t1uAUrjU04ogEhTD1Ye1EhHFCiMZzYchBJNlddPYcZz2B8NYZLnSJCEwaxGn9UIdf9NxfJHu6c2v
      PuE5EgiULZCRwWT0vAdBzlTESBcJ8PTh4QF7HwArdveslfVus9lAfwdteFmWDw8PMO8Ic13XzXYD
      Te4wDF+/fpUkYMLj4yOcNB4eHiL3g9KKZ4viZrOZWj5f1mWSkJt/cQt/tQRQVVWU0UmciLwECESR
      HOFQH08zgTXiEm3vPQVBoDu0GdJWrBE+MPE0GstaCTtFvEH3MSzppkQpZfLMKB2V41jkrJR+jzH5
      2cFJcfYzmHunnIuR/MlyPjmbKWq/qyPuKh4Xmf9iWsjLnOiONStcDBDt3k1TO2eN0cYYIoGbtrU2
      K4tIOUDq1MtCRFi9r+KYIGuDFK0d4/W8KAqyf9sNz8/PL2+Hrm0VMSwowXnXjyEEw4qCUHLTLJTO
      2HNDzoO6OcsynH7oui43RuabBnCKO4JJFApFxCcRcT+czVQqx0LIsiLD+cEQBmfZMynGITvn3HlW
      YfMc5wtrDdecbTab6MQCKMeVZ/GC4qg6X9BAqofwybVfLoTtdgtPttPxCCaB+43NysUeh8h+Co4+
      8GnBfR6IS4aweTSbVqy1WmdV1eDrrTO4KdFjrKGc2T8+sFZt28LCUBRFWVciUtf1169fwb0XXnfn
      83l0rmmapmlwjWfTNKD1uDWDq6Ix5suXLzSbNXa7Ha4/j1xnKtwYPBcRxGe45abBokhEeIpxzHIl
      0vCM44Hf/WJ4HkQyRtV1iZM7eZXnhfEhaK3LPGPm3GiQvmbSelKkQNzYbDZYISCjIsuB+O/Dq5iE
      yrKEQK21juGnQ5iuLonTAbUJFszCZA27KPt33pZl03HQzBiZb6J5r5fBQYnoipP+h/LsfZF5kY0S
      Qrqf/zNF3c/wSY6+Bv2fgvX0XbmmyaSIuVqRYq2V1loblRcZrtaCogye57CE51zSfAOZmUOWvy/A
      IKRAV7BpvZOQMSbPs6LIsW3lywCzItJ13eFwOJ/P3vumaf7+29+Y+XQ6nY+nOGIAX5QAbQmEjKeH
      h6enJyxM2Orf3t5eXl5EpG1bRdJ1Xd+3RJLnpizzPMexTfEeuwRHBJM7XxqSL6Yg5YI0o7nMasMg
      0rYtrGtG6bqsmqru245mkVFgwvX+eDwej8dxHAFT6D5w/Pn5GYcWoX6JxglZJUosyXgXsQiVMXDo
      tOPYdx3UD3VZbbfbMq9+ISbUIi3R/BYpM09DqefLP7XWShn4PyyYZ2q7WEjoU63GPDw87HY7GMej
      Q7qI6MwgEhumCrgDoLHWWu+jt1ymTdM0VVFC2MQrURcMfoBK67oGaoNSTXKbcxRApuZ9LngkXa7A
      i9FbRpmnWFeWZcDZaDYQIsWKmeFoGBFc5uCIaB7OF8weVJMvcKwFf1Fg7E4ktVQ0o9nIns03O9Ml
      oGRZRlqMmi7zg1I9XTPMqXUh4VirAeFLL473dUa/gn23BvzOc0pw9v6EfgblP1P1X5fTo7w8fw9R
      xI64zHP8wkkHLT7Sg54DokFeidAck9JQQ7ybEyMh6TlxPK+UnLCD0g8QBi9YKMRRtZ4FYex9oadG
      DyBuPzw8bDabeLJEZDKPOedwYAXOtaBM7C9TKfBiTOahvjp6cQwjuAOUWSlU573f7TYABHN5DzD0
      5jiCb61tmgaiDzTsv//+O9ShacCZMAfypfkEbBzV2EIwwre3N2NMXpaPT3uI9nmeu2FEpfo9kt2y
      Oz+VrtxWMZV1Zbimu82U0UVV62y68/6dR72/PK1jUEpII2EFIWZi1pkxzCafjrowM273iAWG+Yx7
      JLiyLPNZC+FFIl7j9MHUxJnNxkmNEisnl/stxktdRgK4neCQvvTM4znS97oIPE9rgVrN6ClaBQcm
      eKgy2/lEGRFNEcqUmi9BmdfYrBtRiWcVfuY5zqckN7ykkB2boRIXtLT7zMyKSbGabgITpTgEWUAw
      JyOw1oNz8jdNyBk9sVJ+T5+g3V8GysiuPp//83X9MoLHZb9ggSkXV0ppw1qzMSqE92PbrCT+I//O
      AzRxrg1s+wjNBvRRQoZVmKV1pZkUsWZ4CQRmNioKVakphXCVXcgh7Btj8DxGeaOZExhjtMqMzpVS
      dVmNDqKXr4pSKQUdIwo0xlRFud/ucpOJyDBMsbHABrBfjENBszYjHbQ48ouJoEtAfx8WrREti1lC
      cDiHgaEwxsAoio4jP7zvoWDx3uPgXvSCT30rsjmmNIxb002NM1VAaMOIwfuzG4YgjpgRfQ/bl6n9
      TPE+0qmzQu+mp8+lZQTaxZBd/UpE4LFphgVqpBJfWgIn+pY43CICQonCKc8CZvwAjh3jVRXGuETb
      AFkgxamUq6fwHVu7WEWfX+0xyWKDDOGXWPiKR9p7A4IIk5Ip6HmmssXeZbG/YehS4q9hiX1ztoth
      jyi53hjFWlIQl/n0BMn7FC9e/HxazDhdG41bA341/7q/aYarkLro/h3YvUrhv5Z+GdwXDYj0mai/
      38PZxzwhBJ5JPS6roigQwVRE4NELh1QzhY6aDv3GMH40n9iMvCQaZkIIwBhYtobZnx0OhZCpDU/n
      kLXWCrFhs+n+QucczDzZfDsNuhnVfdbaEBzNFhps9KOH1UJ5QjeoKMXxlPIjuiiltJmYnIjANQVd
      hoNy9MSLzuYIotJ1HTPD2abrOtjwmqaB5haHPKboY133/PzMs5cLT2HFit1uBx39FIas71+DFSI7
      jmgJou5EL4w7hPEZuvqUh2JaLk/+dl7NVl2tVZgCcBK/y+SzWIrLnPBw/iwi4sHsyMzx+bDpQF2p
      8BhFe4gDUXAIzk1M8jLYoYrBWuO945dn7eLEeyKG/+Bluhi4ZDygLp8de65L6OuvUR/xzkWgrxC4
      eYQ4ZXqSXh0RBUnANxDRZBLRrOL40IVUK2kHRcSTEBM8HXEOZc3DKG2VKIpzdalBfucEU2euWXqv
      aX5pBXDpqk4fLt6KX1OxgH41LZD9akX/wyldpbfXXSAKrERp3G8pkNMZcp9WmmS6sp6Z55ApCKoR
      5kC1zAy/WGMMAqpsdk1VVfW5rLZV73plbV6YKKsivJ1zLjoRFEWhTLbft4PzXdeN1h+PR2/dOAyK
      gjYaGAdT1qRyES0mG9UYZV4KQkmX4eFH8wmasiz3+328ZpIuBcGQRDn9cFRl1tBCIYzgQsrouimJ
      931RPO73m7rOjKmKYlPXvijgWg18xzXCYIQi0On3qBpx5GMYA6jCwXsQHQ9noGa/r8mQiw7CoEpE
      oxtjkDucsN3tHuKBkr9IVLd9Wq4CkwiRxJ3gAhyvfo1wcGG4SyR6Zg7Oe6UoTCVHCJbZ10LNxjqM
      eLR54nMqTUiid46jGWeakxDqsUfyr9B4LgbqVpLo+klEs393HIrIIAH5PPtdTe/CwC3L0lJ2daW6
      edbWHVwA6zQ44hfyTlrXZ0Zg8eFqnoUA9WGxi079VP7PpJTZ/+yL/8pmyLuyhecU5WVmjhGxIVxr
      rXm2sEQBeb/fxwij0zEC4ojU+/12u23Ksj6dTrCmqvngBfS5dV27YYT+YdPsENeeten7vrcjM9O5
      x4XARDT72DTwAKmqSvFkhtXJzXDRK5Fm4UwpFT09tNYQUQHx6fzK7BxyX0SVJGGU6rre7/dKKfjS
      sFbwjwTbQCD4sixxwzC84DC2OCNKszAO5IWGHf4UOFgDT4TNZhNju0OpEr20sUmCpxAUDzA5WDv0
      dgTTetzt9/v9ptn8lX1wmgwE6KQUyKwU5ccFTBulp3O9ITBR8EFU0KyCBCgBaJYUUZyOwcShs1ZM
      s8xOIkGCeJ9pIwhTIO83VCilwCR1crYFJgjNKvigWXnrZLLSexFRxsBiE3UyKjm1BKwEmeJXqNT9
      fCEIM7NQFAQmGX8eF8ZVnIppKnAiHWgnJYlPb+YgjopVDNqOXYXwBSwqpYzSJEJM736HiN7AF66T
      ImLHKWhnVF+aeWRiHrQcoa4NGRFRSouIUhKCNyYP4d2IGkKAVdm5gIDEHHxuFM9XUPgppvm0Bx/H
      UbMKIQRxWDO4R0lN8Tfeb1RRieVDJTaJEALAyc+xT2FhifiOuqJC1jm30Fml5B7nFEOnL0cj5rnF
      6tY572eIg7wu/FYhkuROhZv09fgkkj18zMV5ItrtdhDcTurkva/rsmmqIjNNVW42m+PxSIGLooAa
      GsO+azb+wQbrfow/EHM8z3PE4ZjvYtYhOK35YbtREgZny7Lc7Td5YR52G6OoLkprrVYKzoV5XnoJ
      +/0eUir20C7TzjlxHndJ1nVtMjXYPjcZEeGcSl1WQEYYgaD2gUA2Ob34oJT68uXLdrtFOJd0KYUk
      YAuW6tU54tmES/N6z/P88fERO4zd7gES9NPDI8IIQ9MCLMaI4YQKgMIovdtsc5MhxlxsANQyuLMC
      +pkyL3i316ygVY/N4HnPMVk7TUZEm7rJtNlsNuPYw78eyqVZof++BYnr5SrF3pc5rsjmvNIYREKU
      y0se4k9YRRGM6FIkl2tBDCLtqlnji4eKVeAL/VcsPAosEiYHc7hexAwRo6ErZOZ8vmxQZp/0kFw8
      NG0XZg8QZqa5ZH15hVVsc9xhxIgTtNDZ8XswzNj+KJjgUun4FixCZg5QA2EqhDAMA+t3hwRJAkPS
      pctQrDfaRGWOcKmmK601RIZYzuKDtda5aVdujJFMRwcb3LAep9V777wdx1HoXc8GdhUJkfn9hHRs
      fEqC0RMZPYUss9gwIU3Ov86llJ1So57962Mtkkgei8UQG3Dr+b88LSr6kJ0ssmmt67p+enoqigqk
      OAwD5EfoauGVwaJwCiGeEkC4fFz9E+VuxPAxRnlvh2EgUsMw5Hn+9PSkMqO1NiY3xsCI2tSubVut
      VAzE5K2H7qUuyrGu4+1XwTrYz3DEBm2Ic8RCKWOOCzOK7caYTb6JvoBofzp3kSTipN+ar5hTzSa9
      WVguEDKkLEudTac90AAgKRFl2kQdEX6F23S4PFYatTHo4ORZl2UpGKYaoehfF3/KfR7qUkSmqynw
      KzFfwkgsIY7kJ9NNf/MJsoG5qIYmh3ZS7CVYNzkXkmKB6Qy+D1haRMwa0raQBBIffHCeZjcmugRB
      nno8NR3gFUEZ5pr35aqYhEXEWRdC6IYhtlnNp40RE66oyumMDM+7DeYQQtyHMjOFgG0RJPpxHIPz
      4KsxXjOsOtg6EK7Ns85aaxTOWxtm9hOIK5nt00IirKwPh9MZ9vEYSxPwh4WHLarW04si4lwYuhMc
      53k2GEC04fm4R6QY4Cx2VE4m29fLy4sPYbvZ1EXpnINMoXWAktV7bycWyCLTfXKIYO6qQmeZiDjn
      lCgRMRqHeHGT5PF0OgGyN5s6z3OcqsBIQspGZKIsuVUrzAof7KzR7Bh5NbVzIGEiEPeua9tUGogL
      BusK2/M4+ykBrwE9Pv9wVazfXePIv4sNBGZRFESzKqo606aqBsxpCAFxPsHJjNLYExuj4K2BG2CG
      oWOWqipwnTqc4YgCBT/2w9vra9e2xPz6+rrZbB4eHh4enmDSDHYsqqYoCl84O0JZHMhPUfZen19c
      8ERUmCxYp7USxWPw3tu2PSlF522DQ91R6lLEKvG8yua7t6I3pFJKGa2now8Izzft2+djkBRDnM6n
      mq9YYhZzgZWVsBZipizT7465QiSUmyxuaCiRvQjBFy+j8i6QmpJYYynip0BMCcRFoo1nQWiyw602
      c0mBP5uu+psv2aP3XhSCR5H1znvvRntqzyyUl8WmbkgxeQkkLESKp4OI3hOzBBdI3GjbtoUqqqnq
      GNheqUvrXJAA6PceJ0WPxyMR7XY7XEYhidoEyHs8n4EveALc996/vr6GEMq6QiCByHsVMbAeukUi
      AprD+mytPR6PQ9fHewKJ2HsfvEQcByqd2vMwDEVmiCheDKSUUu+RKmYtuQjiSkfRG+yEiPI8/+23
      36Yjl7PZFs2z3vO8t5D5tkPEV4k3V8js8PAuv8xi79vb2zCOIYRQua7r4EWw3W6hWer7vp3i5RPE
      89Pp9OPHj+12+/CwQ0uGYSBP3vuqLLfbLTPjWpbX11esFmuHqqoi4ySi4D3amWUZXqEEB+M9SpA6
      yHOktgAAIABJREFUJ3ial03qT01JqM4UzSOpIAEFsKjSd9ewm67/W+vk3yek309yuflLuzltPkYr
      IuCaIYSiKA6Hg3PufD5jz4eVcjqdAgmOTINZQpeFksdx7KwTkWHssixjpV5eXiAb7na74/EoIufz
      GZKs9/5wOIQQ2rZtygrU+/vvv+d5HtcmWAW2dG60zBzjL8blzAn8YbFHhI2K9TDb4VKpLrJ5Snai
      V1NaPq/sQJEC5wx6PcjpW+8tX2nPUj+LtPxbEkOYT6cvZjakojddeANKstWOb637HlFl/dMV2Xzy
      INYKqm3vvffWu4DI24iKOfTdj5cX8b5qGqWUzjJ0VzOTKE3aSRDnPQkF50XsMByOh5eXF+fcbrN9
      cBbGAewcs9n52ntPs2IaNPTnn38Gom4Ystn0LCJ+DqoZ8wBJcQahrCtm/vPPP4moaZoQQjcO04UM
      2lAQ3AqNWxNDCN5akA6iy55Op9PhyMxN0wAfAeV93wtPURu7rjsej13XlWUprCrvlFKaVVmWLOIn
      5x+azD3G6CwjpeKkWe8Ha8McWw6XNLOICwE/dcMQr0nM5hiHbdvi6Cy01cwsxpBS5L1zzpOPZNT1
      /dvh0HWdMabKcix1xKhTSoUwXbDSdZ1zgYistTieh+BELggLRX/bh+0uL4qyKMZxPJ+787nLMi0i
      w1AoZbqua9sOSs/gpO96o/uq7OmLmmhSFDPu93KnU0sUkBnMGBqDVNkSuWbcvXJyB24k/ejyvFiK
      6eqKX9eLc738Fl/Xq/Tq+rmV3lfm3YrSzFMGUYomUdR7GQbbndvz8WSHEXH+RGTse2uttzY3RmWK
      OJzOh+ZchRCOx+O5bedblUcYShHZ1LrBe8+tQEVj5x1VnhtmCc4PXR821jONfXt8e4Flz/72VZja
      7vT29oLwLKQ4BJfndZZl3tuus4FEGTaFycqM1OQURdjKEyE6YIrm0wgzMbMKwszQ6SlixYqIghDO
      eCvFmtV0+loAf4GuseR0olMZ+XLWQmQZlAjCsUk8+6Isyr+K8mm2lG28g/U1IIZP2uXBu5sphfW0
      wEhdiypu6s3RAYiT/Thgmy8imSohF+DE1GYY1ByzkGclQFDTtTXjOIbgIG+eTqfD6eTG0XsvTIMd
      c5Ph3G2ZFzBng1eH+dZtRFZzITDzdrtVSsFwEZLjSG3bQo4gIqgC87JgZigNlVLn89mTjONY17WU
      JVmP2Ah2TkPXERHOW+LMGzIAT6Ou43w+j85CAEGgCRwxIKKu08ycm2z3sC+Vzi9jZkIuZmYI11BP
      a60pBNYaXI3mPRB6ja2Dny/ZwrvH4xHa8HjkAatLIEfr960i4rShLzHAHjPv9/ssy6AFGoah7/u+
      H+FXC+ZUVKUymnD73Xw8ZCzKYRjqWY0IgTHemBFVkMYYywpHosF0I+WFOWpx3/fGTK8YY9BTKGcj
      vaFenD1h5s1mkwJ6XIFwdo4S2Z0l9LPpTgm/AOifz7zAI0I0877HKhCRpmkQb46IprM5VbXfbwdn
      QRvID5ndmHcdcZaEmY1mG0qEU5ojCKIZkWyYGRMqIhSCtZaZdWZA1XVdh+CstVrrpmkgbKV9X4/A
      guPKrIKLrVrLp4vBXLPn9df0YcyflHlvfq+2OYrDa5SPWLRoalr7ovt0yQbWpJu+detzLCet+rq/
      +TvvIgoi2COfutZaq4IBKr28vHjvBzsi9h5SVTVN02QZjc62fde2bd+3II4pvoF1iBAxOlfmeVVV
      2GrpzBhjhMg7HyOWgYJdCN77bz++j86OztZ1rYgNxFKl4B2F1gLNIUFP9jGjSSsQdNRug0Vhbrz3
      iLz8/PyMNYN2nk6nGOkX2U6n0/F8wu4VeRAro+u68zk457Rm693fsgICSKrqBey2bTvdG2tMPMHx
      8PBUVDWzDoGcC103HA6n19dD308SFrSN2E9glTKztRZuUt770ftz1w24ndl759y379+/f/8OsMtY
      4Tn2IkVRGJNnWfb161fczno8Hk/tmRQ32w3c0fKqhE9bpk2e5/vNfrPZKFYSGAxbmzzLS9zk4k6u
      73vomtxox3FEs1MSdN7h/jDnXFnW2F5glLque3l5IaJ4ZRLkblylCJ8WdekOG/lHuHRD/imoXaS/
      8u4vpKuyf9oYRNyGShNcbbfbff36FYTEzOKDLVxeZnVdqrZ99a845AICgBwAIge14yHU6GVZIgOJ
      BO/tODprnR+FPFwIYNn21gVtzucz7IE8+xp5cVrrLNNVVYzjdL9KXdf5rG8kmgAznj6JC4HW8HTp
      cRuzRW8Fn8RqRqEfssmUl6zr5RslrLFy8WvaPLrku1dLuwrEKY6v+TfmKwqs6+ZdbVh8eM8KmnxR
      zrmuHfq+96OHrN2NgxIanD33Haopy5JN1lCDhQq5oLdj3/e2H+bBIAQaFhHZbDLsso2OVwtF3IdQ
      sHt48N4fTscfP35AYn16emqqOi5vpdRs5yEoE6x3kGHDHO1ss9k1TZVlBQffM/xeQC64tc9bO/x4
      eWv7XimTGxWEnXNdN/R9X9cbBDzyErAkUB1wFiJqVMG3bQ8449mIn6oLAMpd1+HFuq7LshQmay0i
      uad0TLN6kec4dpEDYWoiiwLbgASHiHQvLy/QhBZFcSjLMsthTohCcZZlypi6rkOgc9ciAh/C44ze
      0ThmavLH2mw222arlIK0Pumv5wbo+YhElFDUpaMxCAlzCn8viO04eUFE4zg+Pz+HOVRFNt9X1/c9
      gh+ZubS40YH/RvQrvZ/u4+a/Ka1rTCXE+81eyIDRaOznCEU0e22N45jn0x4owCbPk19RCME6R9EV
      mIiZM6WzothvtnlV9udWKUU+ICZUvD8eNBbFAuzCo+vnRJleomuNMYaJtFJFnhd5/o50cIvgqfP0
      EVYuZHYs3ojmKnFyvQWRC6E+lYLT6pRSNEWtuDgTHj8vtgjpixF25dKQQ5dQG0F/0c2r8nisGm+l
      O6T7Xb46jBdoHtmPiBDFUwyuLOui67TunWtHZ/t+DCGM1udZFoSH0U3Aqr0QsdGT7xSziBzbY9u2
      NnhIylorEemGHvFefvv736qmyfI8EDHJYEc32vP5/HY8EBFr3TQN1Pbfvn07nE+vx8Pg7N+//iZM
      RZYzs9LUbCqtshBCXdcPDw+vhyORMiYfxzEzWbChLOqyrMqidmNvh1CYQikzDIMPpEzGyngZXt+O
      p/bc1NumLnePT0qC82JdcF60McSis0KZXJMq61pEWGsvorMsL0vWWduPHGQcxzjEkIVp3o7BVPX8
      /GythRwKL52+PTtjpCyJSiIpiqyqcFG4wgY2my/ogLYEID5FncxzY4y3tsiywhRDGEjU+dQdDqe+
      H7txKMvajn7XlIhgt9s9aK3zDFeJltbaoqz7brSjP3cD64xObeP9aIxRmoLsquZxt6/K0nuPa0tx
      L7ZzzjtHkyWFTZ7hxOAwDMq+ewJorUdnBzuCh3kJ2/0O3Wnbtmka3JP3/ft3msN0QIkUfVpOp1MG
      3V0IYE7M/Pj4CHv1TJ8XsvkaSa/ueeNP6Zr5DHtYi0gfcIvbyA5hOYpj4Fq4N0eY4A6QFbnuNOAM
      mAsxwjlHBFt6aNvWjTbXpshyItrWTdd1ve0Vs2FVZjkHUUKbutk/Pvz25SspfrHesPLWDW13eHnt
      z63tB3GeWYahm9izYuvd4XQ0eQY5yc1BkEyRKebMGMVcZv8PdW+65EiOc4kCJH3RFkvWNmZzv/d/
      sDbrH12ZGRHafCOJ++M4IcrdpVBmVfXM0MqyFJI7V/BgIQiUhrguyjh4V9bjIKNEGY+N8vnPHUgM
      MTETkyLjBARhw6FrlISXQS4mz1FvwjtnsBuIhMhm3xhmVEsxXkkJ+lnFMpWaVfaaU8ItHKcZmWkf
      wLcg9FhrYdaOWfi8vFqF+1w+YOZPPBSJtdMEXh0j+RDAq30I0neRBHZzH4P33ocghi1dYhkOKWU1
      8GsYhjZZRXDsVjEbY4ZhOLftcb8fun48rA+BmSPJMAxDHLXF79+/U4ht2z7vnmB5AIaa5LINk/3o
      DhhIIp/P57IsyyJK5LIs+6YNIcSIk5nKVZ0NXoYQhNErSK+VK8oS6TedLVkDxUAPhUSTuDR3XWeJ
      Y1jp2kC69CncGnw/EIbNWrvf73MFQlKwCEr3DiC9Qpwf0TAE6CvIjg39l4hyR+NT0wzD8L7/KMuS
      ncVtt99//x38A/lCOR04IyAnQjarnqG/hpSFVcmIYWbxo0gO/2LMM5YAn6GpqPyCXzHMqqqiH06n
      036/h3n9+flZY2LgjBdkg1NrFfaLFPZdRcLhOgvSHRn8QZielL8u1N/hInOhUkvMbkLYLDkUiA16
      z263o2Ra7LoxS2fpCsxS9CH6EAZvrTXEEmIIsS6rzWbz6y+/Pj09dV1njGGhruvev7+p82tIkbj7
      vlcLOHY9IRqiMc45GBgxP5bYWqsHlZAEFwd7S1ZdhOCQEAZvmVRiuk9EGU3idfWKyeuP+VWS2dLc
      WLLlAxjtP984p5l8ORGiFXnBv2O8YnV4Bg5CusqcHf5P5mo+h6jnXnxzEUmqG8cYOSLc9prY9n1f
      rda6wdbbXTFSXsFsmSwZIhlijOKD+ACPEWSNAIq1p7OOCl3BtsdhDqUjoL7vyXCM8enpCewRHhH5
      YCilu4SJRs9whmHwJsIbBBfAKNmI4BZSIhn0kXGoWBRFYUbTARFFJjFMliLH4Effu6ZpIgX45yrP
      EGHY2W05HgxiSSjZMeGSiOFMLvIgyg/soW3bfnx8HA6H4/ForUViWew0RB8dxfm2RXR/DF/VIGYe
      QkBtdV3X1iBUBaWoRiCOoR+8903fHY/Hw36PFO+lTYqzM8QcQ1RAxyaJNLrRj2eeRdH1fUzzD5kC
      +ofvB3gHOedgMh2hfFUXRfHx1pxOJ/QfzIaIEDi7bVuEKuVr10x0QF3u+DqlQ76L7gD6LSJf3OcT
      sW55a9zFph96i67Vcxy5a4TY9XqNiYXIXFUVgrUy8/F4hCj38vLy+vpqU6ZvXCi3KT0AzINfvnz5
      /fff67pGpHKczGPaY4zOOUy+iNR1+P333xVSURUyVLRtezidrLW79WZd1cNmE0KANxdMeWG4OmWl
      jKvNWdciow1ZRmZ7nQ6CU1SMOaTChQE+0C5FDObslHKiTl3z2lHuFrnq7WQUt2zZi2VyrksZhaCY
      dF9anbiapum6DqKMOnDnUP6pUHIVEVeLUpUkSSGdRRRltbJtH0ngVsjMsIdsVisiqspKmWSMEYnF
      Qwjq6cnpriBiSijjVa4Lziwi3TA0TTMEr8cs+LDb7eqiHLUB76GSoFH8iaNLnBlCmQWf6LrOCKlj
      YlVVq/Uackff98g2UhdjRDR4qXO6Ow72gHEBoHH5JR2osnrUAbthN9DgyJDlRQR33hA7DZ55kFhh
      swaO47B0kwoaBdJp5Hc1T1MWfhoWDCIaY2s4C/+H9/d3GMHH9eLYdd37x/sYJSNFPMeVH1cYEQn9
      4MpCzMh1YrrxhDWqVysN1IdzC2dsmwpFAd9iZtwNgaBdVOWQolrDglQUBTzuV6sV6FhlFgikMV4C
      fCurzhXzfMv9hAD+V8ocmObPzLs0wZGJLAnZSET2+71z7uXlBVFQRATSgLUWV35wbICzd+ccfAFE
      RGNnA3xBwMhus9vtwNGxm15fX7G4RVWalNUIR+tQSZXON5uNTeHU27atVitm3mw2SDlARPBKAMc1
      C1HsLgNUAVz/zAGL0n0LuMOBqav0M04XT+vkMWOqa5oG5IHbG3NmP1+pWzL7HVqaVLgInpOq8hZj
      5kqff3k6naB+rVYr7MR5n/PZWywLt4co5yFx3MzqB9J13blpj4eTc04MW2sroRCiYUQOc8wmaSsM
      guv7Xjp5o2/v7h01t227qUfZwaaQY/jQe39uGgizXdd1Q2+MqTfrgipjTF2U29V6DDZvLLixH+I5
      nkUE12RWq7qqChgr4MX1tNnWRVkY65zzw1CWZVGWyMJtjBktADGu1+vtan0+nw+Hgw8BVzEpqWze
      +yH0kYIxpeq/xlnjrCHGZQpJMUvBdSAao5xOp/V6Dab4yy+//PHHH4BXVQuUB2CeX19fv3z58vr6
      Cheaj4+P9XqtppKnpycAIngYZLf9fr/f77GTu64Tw9BIvn79OgosZrza2jSN73xhC9xEbbvOOfe8
      3VVVFU0UEe/68Yg13fAlZiHyIfTpPJassWVRUqiqqirK9/f3YRiqqlrVK8URdY+r69rHoG45X758
      gRgID0VwXFUtKQllkoIoFUUB2X8i79wvj4gz98sd8Xz+ZN6xT+FgIrLpW9C0kF0e4jlcUX///Xdc
      IMCSqQTqfe+c2+12CP4Xk38nZ+nkm6aBxACCgZyu3N2ka4plWdoCIdEFt8xAWup/DHMofEY3mxX0
      g9VqZYjVPTFnsZJFXZ7L5irzJbl4FJUQPBbH8mXKhINfOZ2sTtBNuSBOqpR4JKk7E/M9XUdp1cWa
      r/XiT4trN//11urTteMAjJPI/YtDfqinudSSd3UR0zHS5UA2pMJOmju1qZmAyB4eMCSF1EVJIQ7D
      UCBZeOKemOLtdts0J/DM5thQutUtVa0BxhTNoWR9fHzAnk5EXdcFEjEMLTtsdwC1fDFGBd97yHew
      BlDmHAKLM76EM0k/DNgMIgLVVU8sbUrJyukqARqCm+bhcABjg4w53jUIse/7sqyZGWZHk+UPAlVV
      KXsqJA4IUNhaujyQwlar1eFwwMygEsAZbGpw7H16eoJxRr0/YaLBZrOFK8syMtV1vdtsj/s9jPhP
      uxdoxOv1WoSLomiHvqqqLjNz65bL9x6n63ngsrjSaQqHcVlrq2I09G+325enZ2j96kLjUiJZDAFL
      QCnMP9AKF/T52mGAkg0HTEvJ0lzn2KV8ty/tt39ObL+1de/Det69vAZda2hpsF1A4oGAbFNIbkzj
      8/NzCAPMmJhqIoJdCygJVqrCx3j5Od1eBoWrTUC/KQo7YcbaZzBmVBLS7TbLo2YsIpYvuetoxuTm
      85D0RdYzQNzJgN6WC+aUWVomxaRrGdiYqFnv8c/RnJnVanKHNuaS+6KydWtct54MKQC4JNdn2L6c
      czBqTZj9hEgW28UrC3bzPHr3eLgRooQYffBdbxwZprJw3vuycLZwZeEME5MYoks8BRHDZFOMfKAe
      4K+qKl94lcqVRRPoyZrej3GZ67ou6opT1MOYBXkwxuBil0m3aVAV1pKZhxBxAafv+65vXGGECmPJ
      crFarbq+Vx8si1xTzOAKkrl8KgWzNa4sIGuXZYnu6d4jIjJc1yXR6MWYCwV6roUxqpVJgR4F+4RT
      HB+9tcQpiP7hcMB9JUi13nsyBr7/8N2EzP709HRuG2a2o8ll9+X1V+/98XD++PiALrJer+t6TURy
      PNhkmwSdwccgdwuDeK4ylHPOFI7dJRm0997QmDAEleuKowZ0cn88nM9ndAAiCe6gee8RRU+HLEkk
      R/ZbQA9MwJgiTGZO8ffx+tMHJk/KDaP5HYR6vIl54UwrX61WSIAuIrCbQejR63Uhi9ijOKWUr7KI
      HtjosRuMGJSEWbUCw4kIn4HgzvGQ7IoignS4SsDjZz/6EVprxYhKMBSHfK7yyVlEQ0UAnAGq7U5N
      /zGL7jefdp097GLd1KA0SoGM8vNGfYuZE9p9vkCSpQqh21KCSkJz2TmfCkoaP3JeQyqHgTSXJueQ
      fb+fN09BVVLT07AQQggDLuOsqroz/aqqbeFWVV26wrJxbIyQiMR0eYRZnGGYMnRDbjYbnxKXdF1X
      13W04+asqur19fVwOECa2D4/oXXEhLPWahpS6A0gPsAHdAXQMTO37WhjhbaouG/ZQdxQ1wtmhqWl
      6zrf9ZBrlHlgCcuyfHl52WxW8A87nU7v7+9t2wI9q6pq23boej3AicmBWpKVBnZP2Bko7Q2Tgrlz
      8nZS3oaBgzfgSdyo8t5vt1uEkVlVlXryQZXeIdH49/EoHzr102aLNFcwlIcQIJuHEGxzVtF4t9tZ
      a6P4IQYKl5iISnlEBE3/5eUFmnXf983p4L2XqtYdKyKQASWhSNu23759e99/xBh3mzW47zAM+/3+
      +/fvOOCFOm9TXNMihajebbc4r9O4LtBI5rL5fUL/6TLfVIsonyPOIid4pGZIMK+vr0SEW8Ewp7Zt
      C7Ipk083eCf8FJlZPdvywA9t2+olA8gHmDd0Vcl7yGIfJnm8Uik+fz6kfe29h/zOyTSkLEHt5rlE
      KVlcZb6WtVVQxRBwfgPFNAWiuHjpxRgBvzm4SzKdw5QE6ytOFDVi81w2pxHQL1Z+/enW2il9aqOc
      2T0Ux/XDvIYLf2SmJKQDEnEqhoONOzXcL1M014osMzH3SQQgIufcr19+2eyevMSh7c5du12ty1Vd
      uYKZSYIfYiisNWtLMgzD6XDomzbGuKpqMgxFDHAADa7v+z///LMoCpyi+FRM4UIr3g+2abCBm6bp
      m7Yoita2fd8PXU9R1E6tif58yrOXIoqcfAxPT09fvnxRG5yIGMdCwYc+xEFEtuu6bSkM3fF4Ltdr
      V5jXL8/e+95339+/FYV9enqy4l9fnxPPFGvZ+/58PuIMUmTcY5Du0R8sMAziCP/y7ds3XJvElNrr
      BMoxBZjFJXvwM2zp4/EYY0SeXCL69u2b9/75+fn19RUVlUl8gw3KskFCO5PuCrGz6922cpd4qtZa
      Y6i0pnJjsoDffvuNmJv29P7+PfrBGbaWY/REBVEkjiEO1rFj9/LyhDD/MPa9f39DOOmyLPf7/dvH
      u49htVlvt9vCFlB+D4fDcX9A30KQtu1DCH3vRbjrhvO57bphu32SEJkMRXameN69lK4qSqt9ht99
      CAFeMaCZW3L0IyWf//kWyLfr/fq1kry2RfFt3hBfW0INUV1Wv375peu6ZrUeUohtPV4CsLJ1ROSM
      FR6D0CldQTTBBzW/oAlIKpD+8EGVP6VGNIHreMYY7/skaoxpj4goRodY+fq8c2MkOJblIeesLv9g
      U0BwdBs+Aqrb0QxeF5dDkuOWTT6dOLBVnrQoROcM+M6qTRaXmZmXfcDz+tXDMq8/xqhZwPAlXIkg
      pCrXWWTzk/5zFqRBx3JTNufMIwev4Xj9119/jyRd057bZrNaF1WJ+z5t25ZlaYSMjJp12zRd1xUw
      iEvUMFJIAGiMgQ1aIXgYhsPpiPynkJqhV2KQfdOCwvb7fWEdBEmVJsDZdAr6vrf2YK31MSAQPpxJ
      bMpbpFOg26BpGvWZgRQDJQiHBHgs1R/X6/XxeBQRmKo3Gz8MQ992OLrxKewtJ9kcB4+n0+l8PqPn
      Nt2iNNnptqRQLTjOpeSFSkS73e7p6SmEsE9GcBGBhx+OQ8tUsCXKsgwybjbQd1mWhRnT3WqvINGI
      scioQhSDbynKkM4VbJYGHgvhUu7EEIIzJvrReKpiBVgytK4cSjC9aofFWzCXq/KHpGiUgpoysysM
      ngT06PkN5DheUqJ/qNyC6Rx0bslZk3Z1t+uvuXz6aYsJR0YzN3iY0hIl2Zmvz8eA5gpMCW1H2whn
      Zz/6k9otdUpdijCamrAKECEUeZ3aVWOc7qCcIS1lh1+AzhwEdcYkWdhcFufnVskf0LGDRG0KJeSz
      NMo0w9bFbyZlkbTyqb7VpXh9VyMb4LgcJkWIhOliUqdOV5y5ReZtTQSIT272W4RdZS6dc9vt8/Pz
      r19egki/ao/ncrteG+dOh8NxP/i+rQrrLFtDJEGiZxZXmKrekTFt254OR93AiDlurUX0TpulhhhD
      WYXIRHHwJBJDlMzls2maU3kCK5NkPwHp5xtps/HMEkJY11VdVsgAwkKQWwvr6rIKEnHyAAw1xux2
      u19++WWzWocUFJQoigTHDjwppgs7kPTHM7pwuWShNvEJlaOfcAIbY9EtySkYiFqWgbkwgwD4drvd
      +/v7+XzGesOxDBXalG0d6qqIVEXJLMaQc0VZOgDzmCKKCC2Cu6zX67pwItIXRelcVRR1WRbW4jSZ
      kqyHhavLsnTOE8EeYoxBhi10Rv2XTXKEgM8oJm2MFCZCRHCox0mAIWYhDXCvCrKxpDYBoBsuy4z8
      KTsluwW78512v9znDRM5cbKCEx6wCBaT+iff4y9sCvDmmMVWxaLHzJ0XuWUn3cg1epNcg8bnU5Im
      ERnRPMu2mPjC5c8YszuT+dVKusjyefceUWLuf3np6uK0L0VZmUC2AsLEHEfX2LrYnzmTzl/MF+vW
      Ot4ZmoikKO0XBgwyz1eZMvq5Q425xIDH7t0e4iT5lin41BgoPEYqy3WMQC6fDAvI9AobHPAoktii
      ICIN0Ycw4jijh2CoKVbrun7a7vh//+8vfReH0SyjAwNIQUZGhHSgmwbto4xfYedjJyju6wOw9hRF
      gRzTMIZAS0BC7rrEHYo6hFCWo9iCWQO+w8cOun8IoS5Xel9utVppstqLBuQcjKEhBHXOk5QxS4kD
      apckt3RO6pEGJxERCNHwwEGiL2UbqXujuZyI4EyW01+MMYZxZYkIuG9TVnUiWq/Xv/zyC8AXa6Qk
      BWdkkAQUybquf/vtt77vcXgAPgQ3f7jWQfzXELh2lr4dPjlKMPpTRqOiaA7sAG/z3kMy4KRy6oQ/
      Dtw0A4L5Vrm/QebP59v+vhh+p0v5TUi1Rahmrf8qmt+qRxddhXpOjls6pZRl+9O11qGZ2c3y8d8s
      b/jiRPESJ1v8Nf9GyXgCu5MnFycwF1cVKBfRnPnKupUv2R30zFuZ1HPrsUmHc045QRWl+Ucqnwz2
      0lDTtYsPUQajQ8rHqnAjIhrPD84JMYW4guOdT4nW2FoRwXmOMAG+Ncwe9iQLwQbSdV3bd3oJjTM9
      0XJKaJL0fZMSh5rsKo3SFlRyqJOq3ev0qTlSGSMGCFNAvrqULpoSkVAQEWKWdATvh2H01BRhGsNg
      5ZjFyZ4uKQu4BrFRFFbik3RkquPShc8loJAy54Fx6kmRdhiePERUlqVx1hgDa+ZIH5l5ByvrNjif
      AAAgAElEQVTFmceuhEvKOiLCPIcUjEknhNPtO+js4NCQ9fCuSRlZ9fMEL1BiivRkeUwAph0D+ljH
      Wgml02M9GVYufkGrB9D8zgMTLMshJn/31p7Pl/IOoE9APy+Gne5tzgplSrdksjYcTu4PJ4d1Tvs6
      78MFOse3bDbAS/2cVWvEEJF2cTI/8z7MLQ+PdHvht4x7TdbiQUC8gr8bNpN5ma97/s0jJHfFC2d0
      kj92vUeWvW5ynqcYeBPN88b0S0kx8Gy6tge7tvoC5xZhVOJTZgnvvZ7LwTANec05R3GUa7z3tnCU
      XFlj0gGZGVnolHRyHSqfGv0TGJRLvvMRTUyuVyLMNaGPNRuhRPGoJGZ5kCVeUQkn6SAfDiUKs5l3
      Zm6Tkcyivbje2k8wV/2sSKqbZxyzNcxMcbRcxxj5et70rREu/SXrRUyeOTg5yCUmSlwkf5cz5pSv
      DmXkPt+BIznShcr11xgj8ULyVcpSvys108zIeAt5P0Vzut7nEzSfVDjhUvl45w19uu1hwcjpVvsz
      R/MYI9yBJ/OpS3B5LNVgr89p8s/MLOMHm7Wb8ZVslmCuj7OlXB7U0rX4W0XX9MbPn4urkklIn3Zs
      8mGxTprB8YS879Q8ZzC0ZE2aI5UOeLFXE3484uqtcWqP1e6mQ8qpipJBZgQRIsGex3FI6pwemkuS
      Lq+mm4mYSMhaSykXiWEjElkuid5lBkPGGKDVGPFnFhJv8o2IsBEiGVvmyMZw4iXMIvgGOVCZJUaW
      0SXqMn2YFgww2cfRVIxR2OrCXBYky4mVj2KCcTqZNKMzuWba+a/6ZY4gxhjLHHWNEp/QBywbEiJB
      3lYhpiCBiKwxFMe0MMyEQHfKUyHjjzMvZIgjU+6ckxcdywSGlGyu3pLLGE3265AY25SzZj52tLRj
      P8XNxTIh9Uklt1rRhxfX9Ie6FC7evZ+gxribrjuQg04OIhfuftuPfvJnGtHVtBCREWxWIiANsgFd
      1zPBrx9aiwnuL8Ll/QpvIey8b8ukeKOJCYe+34rutQlqabt50zTRkK6sNAt9mI8X734SQ1ENEVqL
      6t0X1Eh+TiJiiOL1mM11bDNrLbJJ5Gaj8dcrHyCNxzt+nsC0iopAFsUCfSDX7LSGfNdN1iOXx1Fy
      4wZdY2s+j5gQIkJ06ZgFkpBMG8oxOmSRyuemPV1dnWGdqwkzyJ9XMVmfUbWALCuUExFkc9ypU5rT
      sefaBhF579maixVrpqhymr3J5OSLriNSfULX5ULKdJElJcuVbhIjz2cp7/AVCd1Avfmq5c8v7pBJ
      c/rvnK8sdkC/mddzv4gsI2C+/6++SVR9v9v5Wujniao+maJbfY58OxTLorx/41xxXpQh5f2ZvH5n
      DnVTT04U592bI8Cc8UyWYJG53mFUec1K2JNZzcfLWfmUOG/OQG5pSW9C5HG5gkZJB2QjIoLcBbrt
      x8uTyYzms7096U0+ifnhlXbdzCYiN4Zib8OwzpA9mUIIpSvAISRZgTg7/JGQWQ+y+3JXz6SiQMbM
      3ns2FwzNoVlSvE38e7nlH1lnDD0BhGFEc5MoWtTOUwrrLCLoJKzwlwUyrE6W0EiICBAZkysxpshl
      CcXHkSZrmPYcJ5MxubLFGDlceOFIiNbk0yIiYfBFUaAhtiYIIp1fuJfJbkVdjHIS0WccO+vzqriA
      9GgCJckDT1cKPi1onbL9qQ9wYpm5wYqvObq+aImZGfH3Q0rWg/UyxrAxOAFSnm1TjExUgogoCj3j
      Zx7XKIQgwmoHc4jNnV3DQcxOnfAYI7O9XILLCEN7heUOKTIzmdGrT4mHkySEJyWdEpkkH1GKc8tJ
      q74swUwjpOy087J/byPM4n6flEV0/vTFsUsc6e5RwRT+5LI0C79mlT/IchZbuY/yedNL47LXf36u
      WND1HkHnjTHLsjlnaqwutkSKMdrkQ6Y0rTTBMYkK+anLA57w2q1cWMhnId+BuRioz+fokzc3YopK
      gswxRW7JN6G+xekENZeIKcuaSNdStnbp0isxeeshxVaUmTiZzzONNzW8T7HC9RgZUK529hhGdBuG
      IfqAmR+BNdUPNz5K57d6pxQeirB6Zfd7xx7CkYZYwuCHYYgklo0wjeddIup0GMyYMJYMm2R90qvk
      Ojmw5ekCjRE2ZJwWztSvOY1e6HBJRJ1TlC7TxDCo7owmOyNROpkQZ0w3h7338DsyiePqPd7CuUkT
      es5xNdiUXRNZrpLLv8PhPAIKMbNxpJwbE2htoRqMiIxJ3VKiJXj+wKEWnqBsx1szmPwhJfGAt09I
      wU+IaPTjJooxarasIpV85u8AyjhpfA/Q588/UvPkp1toqKrvbXCcfLMsfd+B9Tu/5o/Ne3in84td
      vdvtRx/Lv1nOCzrvFjML5J0kwFpriUlIcCyBVCnYqyLCxoxO4lAds4bnf0rapdF7ydiDdkBS0CUU
      k+Qj/VVtF3hMRIoxsy3sCixRkFXEex8kAjEtj/6XORuIKUrJ6C9BwabkDLmMQ+kEWNKFT3SD5OLL
      oQRUpEwXgM6Y3/4QgdcdPLVx81MvVZmU+BQBubz3Tddih3jvh268Y6UxdYkId6+Qrw43pPu+b06n
      PIzBbrfz/QAPIrxlrX1+fq7r2rLBLacheJYxoDnc0ksas/8EiV0/DMNQSw1vlkiCRn2WMwW+/PDh
      EZEQQ4yR4oXZwGdfXYYWCY8yjI7p9tDF8pO0NwCZqkGSfLFCCBpYYkLhI/IyMZPEMX2HwhxcYAsZ
      x4W4CEitp34+wGVKiZOUs0qMwfvT8Xg+n9tuiDHingHTmEoQd33hIVbXNdK5IYnKevsEYkD9CIAB
      FQrRE40xbdvu93vMdr2u4GaGG3zwsKqqCj6m3vvj8YjYCfDut8Y0TYPX0QG4sV6HYFWJRJJPS7ZG
      EZa6aVnEwQmkyMzq8iluTp8RoUuCvJldeentz+u80dtHyq0RgTgfqyEwq2vCQ3Fj8nITzWkcz+Uh
      INSomAcahmHwHRHhnsgIapBASZSasd9cyh0zGXk+/rwrkCNiCgyrejF2Jq6SoqijMaDfxxCGMdYV
      onmICGhXlQ9svCBRJGB/xhidsavVCl7beBe+mNBqIWoV5ZgYr+s6bBgME1vFZfH/sOdjuAjyxhiF
      VGMMog/CRV2JBswAuYHg6/n9+3dgB2r45ZdfsOtCCE3T7I8HDfc4dD3Y0m63M8bo9XdE9oB2DzYA
      XEBkLniIGmJ8Cd0cQX/KsiRDTdd+HPanponeR6LSuWq1GlE7RiIC1xm6Pqb440SE6AVDSimJKYJQ
      CUkTMRQpSoyxaRoigm8+4sjPhZ1cW4qpIMYeJpaSggg+h+XDPYN8HdGT3OoyaQUFURkgg1N2fQnh
      tsdLbUS4aWWMQd5tpLVCoj5JrlYY7MfHx/F49EH0TgOSPSnDQFh53EE/nU5YVjqfYZkBlSIzlKRY
      b1gFDSU/DAPb0YsUqB1jhKCNKAgakU0VzbIoTqfT8XjUSC/5dVO6LSTKkv16/s38rcXaHn8gLzmR
      zFWrO/VPYGf+66c9ucWEbs3Ag1A+e/HHZmPyzYKlJVdGoPhjc0pk7/3hfCCiuq6FebyWnbzRIWrh
      Wj8zr4hyD2LKZNV5b8A2+r5v+74sS7a2shZ6ANhD03W4HA+pEzd0NG/9x2EP+m6aBpS53W4RUB8K
      Ztu2uEIZY2z6DnRfueLl5YUtroMO7+/v5+OpbVtsHlxK2mw2ux3VNZ9P7fvb/nA4KPQYY7bbrWEX
      1zQMYf9x/PbtGwL96O35sixfX1+BKUAiRL8ET8L84E4jMjYcj8evX78i8bEC0MvLCxEB679+/Qrv
      fmMMTCJAFnS17/v9fo/lGMVV7wvnyrLE5heRwrrogytL51zpivbcxBgljNEfmbnt+3Pb7o+Hvu0i
      SV1Wz9YgLGRELJqm2R8OYRiMs5pAA2HFvPcsFEMYgsfle0iawHrM3jAMp8MYeQZ2YVUsJhghIoYt
      FL6uG2BeaJqGmVerVV0HrK9hluj9EIc+hNgqSyOizWazwkGQqoCZuUbpL4p0Ke8VmNPpdMKcQ4wA
      Q9LtICKIg48Ep5COYzqIBmN4f3/v+96aoirKwjpDDKEY9APeTEQxxuPp1HZdjLFwTi8KgBvlYbaU
      jQH3lUNwugCBGcM3IABAucsiEtd13fW9da4oS2bu+p7PZ1cUZVUJkWFLySwuIiSShEWcnGHCpj6O
      98Xt+5aW+0g6AU0RydJV8COMQBu8BeX6+XH8nfdWATMn3R8C9FTmRwI3pfW5cHzTbi7JvgnBATaE
      QLLfv0O+42QSaZsGQUtwxRxkRykuhzY2gfJJt5RzID0bFHBOVmyIGG9vb8hGD61zs9kg4yURnc/n
      b9++IVKgCBtjXl5eEMJ/u92WZXk+n79///6fb1+R2Qc20E29YuanpydjzDB0b29v+/cP7BlE6cIN
      TBxLYvciqCwRxRiRJcSNSQO8MiQ1REJwhqoBWdKnZFejEbYooEPg4j6uF2HXaYgJfKYstZ7awREj
      BfAB8WpUQULQwNZ68dWmGDXb9QajU/sMsr4BGRvE+TqfIKhipBu/ZWuMu1jhvfchk+mAJkBDJKUC
      mmjCoKZpPj4+vn37pmiOoUGWxE1gwMeEQFFP13X7/f54PIKdc4oahFUusqwdFMakrHhMr93Ot1mO
      FDFdYsL1N1AUTrbBkCARIzsMFETMuR6N5DVDbP/4+LDWbje1Jp0IcVDryjAMh8Oh7/suSUvWWmNt
      1/QxRo0JilAKo6CTthXiNAGsPw7vUD5gMEHuWcT5Qd/KskRaotPphJQpMNeEEID1MUXNpZ/FoEVM
      X/x1LtJ+iuPTP38GIj+p//FRT96imSH+7wD0ny/3/M2JyMfY9v37fn8+n2MkZm6ahgx3g7dF6crK
      GHM4Nd++v8M4uF2t8QwzO1uWRe1qS+mg7PJvVkSEBdFQoke+za5FCkpcyu/9cDyfvr99V7y21p7b
      pvfD08vzVrYaHPF8bg+Hk4joJiRrTOF6H09Ntz+e39/2b29vvR+IaLxuTmMgdva27/25bbquc8ZC
      cK6qqlqtjSuGEI/nBv+hLe99EFqdm/rcVKt1CFHYGFdY2wOsIdojTLMGJjUpLhUCEgzDsHt+qter
      alWzNZHEx9D7IZKQgce9CFOQiGOJIDG3TetpwZDS2kFBUVuHc267XnOKXIH7luiPqk2Yvaqq1vUq
      irRte2rOiLmMSkIWXJ+Qr6AsfV232UUPnMudDkcwM/UAqaoKh4pQO97e3iixJTvG3nOwUI9RxgwL
      QZbOrjum0JLfv38Hj8GLsC/BKKdZDoy7HBISEdQ4zd5wB9ljjMRc1TWMWqfTCXYb6HYuZdzWjsHY
      6FNg/Zh58QLfISzD5gODTIiDMQY29K7vT+czEjl1Xdf7YbRPmoIMCxOu2sGOBw1GE+uMsoIf/HE8
      X1G1GAlAwKc1KqHqhW3bPr3syroyxkGxQGTteHG1umzMcWYy3R8n0kwBK0U0eozkcEY3rM8TK4T+
      KRSWoef2cenyt5/xkjl832IkizXc+uaOIrL47t+L7xPx/F4MRU6eXhCsQhBmhp8ZaAsCphqUq6ry
      mx7HbiD3siyr0vENo9WEPwOPzuczFGAovBCNm6Z5f39/f3+HeRHKpl40RzQomH2LlOoB+xwBFA/7
      E4yVwzAMwWNvqNQM6biX0f5ImRcNZGfALg6vEDMasljTNIfDAa3bFDDLkJzPZ0SUxLFVHrYFR6ka
      ZdBauxue+Pp0Adq0uqZNvN+A1JDrkfNIMifO3L6s2rcuJaWQL7AjhRTDHYdmVVWBmTVN0zUtzDXG
      GFTo+yH6QK4oUloAHDygWrSI+A06t8xcr1e51gLbAvoJKzxSNYEbmcxVVKeCk2chggMjbjVGZK2F
      IqKG8q7rCnJQUFTqRLxsPauQzNsyLzEFcAdwj9vDOZgTc6jSq3Bq6GBmHabSrR7wAq9FhM14Z89c
      svwUiBcExGfm3eYJRyCSmW5Myh8E2kDrTdeek5EdAzydTnpagO9xJozK04ENwmFeXGCVYees7nGw
      e7BMJjzb+39zzT/06/yZT0e9COX5FqO/LJVf9+ETW3zelhttZDw+feGZIljmkGK0tm3vnDPOrrYb
      WxZkTWRiZ8u6Ms4KUyTp/ND5Me8X0G29GgPJ2hSaVVuJ6eJ+TN7ZIhKCRJK+9yEIkWG2zLbrhv3+
      uN8fvfdFgdjHJkZqmm4IuN7iNpvd8/OzRkmF+WK0NhQGbuOIJIN2UVTyCuPGE++jj8H7fd/79Xr7
      9BKrqsLBEQ6aYLg3xkCI00MkNCpVFYm/f/8+hFivN9BgyNgQoysrts64gq17enmNMbqy6ns/DCFG
      cs4OQ+i6AUMTYWuRQ8AOQ9D/+t4TsbXFarWSQG3bD0NnjDmfzzDmwHiy2WwANAA1n+WehieimmuI
      CFqItTb6EIcogRy7qqjBUQzZ6KU7d37lqSBniqqQwfmWOxZDUQyxZVNYt1qtvn79qmG10ZBzrveD
      LcaTA0lury4liYdEqU54ujc4ebuTYYirZJitYWuIyDrnYyDDQaJxtvcDnjHGWUvGOBHW/zCH3ndw
      PaxrawwD0USCTo5So+o9lJ3oHA6HGKOGHoMdRmEdBrG+86DAzXr32+//C+elIYT23IhIVReUhaaB
      7wC2njGmWq+KoihcadwYpMEVhfDoQg59DhWKCEzwwzCUZV1VK2YLp9Dd7nkY4JFVYu8Mw/D29tH3
      /TCM0XtCEGZxzq02a+/98Xza7Lb1MFgNnj4iOsmiuTn/g+G7dfkiJj/CKSxeex7/6KnfpRs8vaeG
      Om5ZeyTy/EuFoJzkKBPj6BqpL7Vl8HjVysOOmI+X1MObreifKgmlvKDZWYH6tCjD4ZQE1pUFWZMH
      IIbFc7VaxXQDRe0JOOjve9/3rYjAByaXNCmJaUrcRFTXtS3cbreDi5WkeNmjZD0MEE8grEE0wzdV
      VWm2TGwzCDghhXKGGN77AdoxIAwipAI9pE6KAojXONpqTFBtF8kioDWrrgrRTOU7wKVKQOoQ1nUd
      MFf9oNUwqmYNdQ1STJFkGtZbJJJMH+r/Y1JyO0RGVIEL3YO2ZNJVEUl3UqDTkLoVDZ6IjFBpHTMX
      xnIctQqJ0aS4585YXU2Xsg8DbjilZtbEHZAZVefQpaeZDCHpcHIU0pOojkZNch7HJOMt+HFqtDLw
      DM0ojym9HNIyjwE+x3Pmq3heOvk6sepbAqOEy+J8WQ14wAz9YBi8jl1PR/u+H2xPmT87XFb6vifD
      ethuCueci0MkIlDOqBhxhF7iUxJnBLhHjHvojqqLgMjVw5WzcIlEZIzLT1aUSlXNNdeu9Mb8mOws
      1/g4l3NvSeiPlBG5lrzFJ6JxXnQHZdrA5c9FoF/8wNdXRiYfHh/LLdl/0r38+Udqxls3cw8hybJJ
      od/rurZFLIqiqFaw5UnkGCh4EbbCNggHH5yVVVlWZemc2zw9lXXpu75p+xCCsUW9MpyC3MMClwzm
      FKOESIZdVVX1evX09ISDVkhtKvwC0Uy6ExhCwC8uxdR1KYguBA1LbIkpRCO0rku/W3dD27ZWYnR2
      TGoOgpYQoLFi2YBu3dDDwE2ZsyZwGbI/pgImy5BySTPzarWC9QDGXErXfyAdq+Mwdh1eARjBQKQV
      Km/A6oR0h1BSlEprrYhhtkVKvCLpNgBOzyiZQbz3tnCuHCPo6hElnjfGBIk+huB98J6JbHJ5LIvC
      GkMiMYToAzlBtliOQmE8/YMVG44rIcUGAKiVZUlmvA+5Xq9hzgZv6IZ+xWs8ltuaELdnvOma7Ejg
      DSHdj7UpmysGCG99Ld57tKXneyEl+dO3QCcheMpwFldy2rYNMTrn2Jhz03y8v+/3e8T7JUQ7yPYe
      7OXWFkXJxAPeQqQb3U1kmI1hY6JI23WSDrerVe2cc1XJzGPWFOlCCNBCANze2OPxCDsM0PxwOr59
      vMOdBoQKdy9KGrDuXJtCmaOo4QXOLZQLVYT/AnYlEQnhkpAQxdyzYn5vaPKFugotZmSewM2nUHVB
      tyS7LD4Wb6CkGf2YFk6/6S5WXtSImZF9Inzg8616Jt/P3WRTDXoCoW0tnKbOO5x3xk0enYwWoiV4
      u2PjUoZigCmkDAjOcMi1NB5dQvItijIO4xW1eO3wq63g9fGORnNu+84WTi/LqSkDOKhCB/ZeTPfI
      gctqQCAibEuwBIzCWlsX5Xq1QiRbTneUgMLduRERCNoiAl8ImMslMyaiIWTwU0s9hHegAKRC+N7F
      5B+tDgZAVYiBnFKYmhSNVv3KQ4p5i4bUQQVoguEDLrEc6k8JX0zNTWqM2a7XNl3PwWGjmhQk2a9R
      yLD62Kgpqes6JKiD3qO6l8miEKOhsiyfnp7++OMPNWHblLfIFQVcy6HooHtqYAEDo2shSOQKCsBo
      YTrDXRgwVJOyHmMCQ7oBBAEcs6QaoU670qEqoCY5leJoRFVAZsY1gsPhgNxPymV1r9pkOALlYGvA
      IqeJWEFREEdgwvYpsSI6oDc2YyClqK5p397eKI5qKPQPOLnC/bEoiuPxCCKH9sAp8qhmBcGBMM5X
      cPUB32iiNZeKnlvkeMEsRJyfPd5C3xErkxvjrJ6fNMTPUPIT9Jy+Tld9+LQnE6E7p5NFVWMi+N/t
      eRrAkpPPHHsnr0wAPX9e30pJHjJmgEch2QHphuBptDyPOb2QYUiYhuB98EMYsxgzc2QKIQzeg7jF
      MJxG8EEMx3SXDGjS+eHctYfDAc5nPgacEOo1QmyeL1++QNqCh18IQTNj5JgYYxQB+yHnTFHYqipW
      q6rravwpRowhpPQ2hpiFY4hDr/flsOerqrKmGIYBmcywPXCm6pz75ZdfXl5ecPipGje8D8HkIOPD
      Q1w5De5YYqQQG8OYn3Msaj6Gnh5CgLYBOZqIqqr67bffFINaaRSboGJDmka2OfA/V5acTmjHAzSm
      SKPtoqhKY4xxNpIYGtt92u5GnvS00zulz8/PI+gnYbyoK5syRsWUlO7XX3+F+wp848A8yrJEfgkI
      0TBAxxiLPP5MRqYozIy9aFL2IptC1XvvYSgAfebHksrGlIVzsgWrzUHrR6HURFEUsAjFGOHYSkQ4
      pQ0xDt6fm6ZerUKMxo6JyW0CQc4CFUQS6pit6f0ocNSrer1e12UhImiCiJCtG/e2vPcNbmlU66en
      J+QJkRCPxyNu/OJ2hbJztBVjHIIXpqIs6vUqkgy4BLBeb3bbalUHiW3fGT+UpiqK4vn5ebfbnU4n
      Ee66ztrCWrte109PTzpR2DszZLl4nsiSBzQza+SGfE1vYdlPl1xEvobLmcUcRMUX51F9Qm4cLYpa
      +Ujt+zIOLW84FzTYEC0cMABU54COGDOcDNpXtT5cJtqGfuOuhsQXvgHNBdLi6+trCGEYggoakUbH
      AGzv9XodX8LpdOJkQISI5JwrilFyLFKWHJPFP6HMHgppyNJodAbFQyiD2zj2J7waoBZgM0CvR17K
      vu9DGG/lwcsbot/T09MwdMNQ73a748vL4XCAMg73OMihkHEgfFVVVZUrEfGhR1efn5+BNRBCf/31
      V2Q65uTkoO4xlEKUoHW1RapsCPWFk+MHpQNhTbQGQzCMm5CIvffAxJjy1ovIcX8AculZLlL/wG4A
      k46qShdOnLIWlGUpfNHNgRF1WcEBf7fbrbcbcJ0ypS7UOF/q7VMUF+GXmZFVFaeCMCgB0MEL4YEq
      6XIWhFB3nQQyF4JUVMRM6n1USN+UdEdO3keYNJAopg6+3pgxGJSLFJMEEByTNyQce9S2jqtnxpi6
      HhNm5ZqNSTGtcE6Q29OxvtvtlsAJ+t6kW/VV4UREBfPtdluvVyBd7z1BaChXmFhV1JyxGCBUEyKC
      mW5kaeU4TBBPft0XcwK9Fr16enrCZ+fc6XRCK9vtGlOUsdL7AuyCT9784cXXP4VynunutyTcBfS8
      /VmH9kM9l5mNZan+q7OfW726r0lcxJfbD8tdqxR+crfejBJBytbazW5LROdz2zTN1+/vMUaKDNFY
      rZBlWZZ15fvBGFOVlTGmHwbX9/XqebXeikhV18RWyIycDezDcFHyesPEtqrXIiI0xsYrUu5NTieW
      ADLwCd0P2E6AYyjXcFcurHPOGUtVVTCt16sqhODT7X94bRdFBfc1Y0xZ1i45ksdANsVvIRnd+Cyb
      7pdfY0qxBNVhRHPrqqL88vLKQjhlVZldi0mBkNCKwh8L1WUFt5B1vbJsfOW3641J8SBhL66KsizK
      0hWb9U4N35vVWq3nu91WpwvoAAaDVmxRGOfKLDMfMbmyMM7aLEwKXnl9fYWN25UFFAvVP0bSscY5
      K4yEUKPjiIHMbgyETZi5Vuu1SsTgdpLM9MBKZq7LS4L2+c7RIxOV0CHewtNDGQNGTUSIZKCGLChV
      sNGZLLTkpXIRw2MMd95u16vVkFz1oeggSI73nq1xzpWuKFLKpxEER3Y2+vyJREOucNXTznnvxQgz
      V0XBzKUbMRq7tyxL5GZxVVmW5TPiKpvxpHrFzDWVZQnve11NIrKFw/BjjGyNRqGRdAIM5gdOiVtp
      Nnk3kpjCVbh7RUkpMcaEMIhIoEBERgzu397A9PGZHDr0M1K2LLyVfTFh3lcfFl68+iYmJWECXHM2
      gGLoMgoFdNXJFutZfOy6R3kTF9l0IojMewWazB/I2xKRlCckb/QqufbinF++GaNDoN5RNo8iQsZB
      94ck7pxrmu58Pp/bHp5VuNIGCoOwfDqdgObrqoYeDZOrOiDm/D/vIvRl7DfiqPtfpVpgk4g450bn
      ChHV5XWp1EtBRAwl3HQ8dD5SoMjCkcgMccDJkDGmtM6N+fAijJUigshZY+s0+vyqa7NeBdLDSWaG
      CHZqzkQE70yQgh1DoY5xmmKKcscadVZGz3pctNHDAJ00Tp5Co1hNYw+tY98PytXhm2HSCT4OD9QI
      MEq41sYUNTdJpqPfN0bhvZdAKg6LSBRBXg749BnmKBK8N9Z6hCfki4MUFKZIo8feKOf4WVYAACAA
      SURBVMkWozUGtx8xQBX2wSZNiruivc231kjUKXYuTkT0KBLIC4lbVTpMi0mBeZVb6JmzJG3J8Ch/
      2RQZeMi8QQCaaB1ZZA2x7knUTwbdGFNsY3WwdoFGUcAZ470v3TQ/FKWIpGJ4FIBMMTJ7ONj4gCNx
      y4YMUxTh0cexKIrej/Z9Xe78oF7nE9tnvF0so0GSjcRAbITERBlfjzzN/HermCxWaA4r8pl9fIq2
      N041b7+yHIf9xvPRZoisyvEEymcCddA4wJN/J53PxbJJf24ym3DlYanYNeq+bGcs5F7uDt0gI7oi
      Jh+lzaxo4tP1MGMMIlx770OQbgjqwoick5LO5eDBZq2Fboj2qmRMmK8xZ8ryZQOb8bqEbuyY/MZQ
      dBbwAHYXlirIJTahHsFFjhQoUODIkaOQGSkYcJmljmNmk5m6YFXwcXpXTYdjrpO9XbrKV8dr+dpr
      0XryxFg6ZEnSpZbL7EVhBg+/CrFrrj2xdK5MHj18ViZUxZrvMXUyMllissYSi2FLHEg4ihgeY2eK
      nxOZjoWZKc0wFjoMAyenFN0n2r2EdHmS30uMe0OXJ30WU1Obo2syy2dbZaK8iIjIgqykVDR+4MsD
      hljkEuHlMnDjKMXCpevNLxQ4iogoreKB8WHkzjJJVc/8o3NSiT5EEhaCyJWj7SSdG4pN3pOzQXEK
      qB2JjEgQYdBLTm8Tqsj/vMBCRpm6H/O5zZfDZL62+TOLjV6o8TqnjYggjt7iw5OV1XY5MWyfIhHl
      O3fSgRCC+vAofWaVT/eRus7nZmSiaQ4p3eycTaDq37AH4oxa0n2xNF1X9zDoRhkPsnVU2G/wbO37
      3ud0acZxxkhMNmZHVSDrmACIoEdTdi4cAmdGJU4ArQscs5salNB8ssMlBXqeo7lyjhijjxdnrFEP
      MFlX1TPSMGVMkrM46Tbfb0IiMoQrtMpRYxE+Al1GqhRP1/mx8ldyNNcFliyk9QSnJPi85vn+oevd
      q1xtTgGL72K35GCRj2Uy+UQUo5/Xpr9qJyXxY5z+YKT5M/mcjDGexlFflLkcDa+fv5RJz/Ubdame
      PIb+5zg1ITMi0jQsRCkebML3S+dnaA7YjWEQGaNGa+7TaVeRHYBJRFJyjqtnOF3XvExQ6uGQ3bqa
      vLK4vkQG7c3mYYrmOUpOpl2uZVK5i6eSVnxxyS4mx2vLgyRQ0/GOr8tCK9qfaRN8AWuFGpoJN/lc
      xeiv5+p6Bq4OU4nNaMy4v9/zGjhcTmVN8mbe7Xa//fZbPo0XKpKrSiZjn6zjBc0lXWl7e3t7f39/
      3+/nL0e6ZGPw2J4JvEaAJrbWGrlKH5FPGadAWtn0XUvcZpydyYx7H3OQ0joL6xQBR9E4w9NxZvlC
      JTbZQOQ6QZLjC1UpNyIa3T/mC5+jeb55Mli8AtxcxeNr21z+rxKl91OZd3xGLj52t3baBf5moD9B
      unxx0zy4yZe6vpPOjOOlC7eejGiytRRVc1LWh3PyyNGcyIgIMDSvdlwjng5EUU+bQLveX1A7H52i
      +YWEoJVezyQpgsuI1LpYYweuueCFNigwM6QEznZmzLJQoTZYnGGPzns+Xw7KqI6uSWi+EHlhZsMO
      HGn8NakZjplSgt4kuRDRVRQVrXBCePkH6DrXmxT/j4uS5aSq+UinTZjJYEEPKXPkUhMigUY+ivtQ
      ogpZ6vPlTSVCpUPkLMkvGVDK9jeKsXJJQK/VhpTvbNL/gq90aAjmi8IZXeP1naLTdRHsKW1+OO1i
      19F8/xtLOAAZ5SwhIrIsITIzjQrj1dTAskEcGblq4pgcmDiSGDZipUgpnUc1Jx8b/i3Ly83GfCUQ
      sS/HjlwLxrvh2iEpFzONMUZG1eQCqTlRqGXzeh4ms3xBt+vuzZ+ZAOvV6WL6FRxusSpnLnnCJoxE
      q41ZfA+a0dm85Attyc6/pOvsTvkc8iUK/WV1dCp0FPqvTdd5JuK5DmS2PYyIqC+N9m1cI8N5DZTQ
      nDN/Qe3JZDJTly5JbnM0J77S6kTSFfzU7qTztqjyebt85miMcYwtcyEhte9T4klAc8eOrxVTfDCz
      O415mRCVfsgfHvdiuv49f2Wy48ZfM6spX3PoeU+YGfN5p4ez7y1dd0bXIt8vi+OafHmj/qt5WCTU
      ebnGmelaZBAjOffK/9UVzKfUCJlZ6DeEAoU3tp70TJ6508/8g8tnDQ4AuCXhUoy9fOTM7Nzo8Rqz
      8AiRR4vBuIvSdaZxDAZrBmvUaK0zxhFFETBznLSZCc/MJ0LXb7IMBSwq2cMKiEQXLM4LXxeT5Rem
      2QaYLuSskvzJCQLmr8/HgjJX+nJqm7TLzC5BOWWZnfOBT4g17+ciTWhDOQFNIEkybkeZDpEPfM5+
      9Mv8ez25vSObz4UdSeJTXlv+AOmd74TaJpXFmdRqw5jzdjoV+WTG6yFcpjSjrnFfXO9DXQWHwcrV
      9ruMxTCl067C2vyy5YT4J6NmZkStmQyKZmLdpc9ydWo3Kbe2wJ2NMHny1mO3apgQp/46Oa68U+50
      adL/fHNNdM3L80ZERj+Ipf7P7UURYSAX99F8PgvrlP4puSYjnqsxUCNUcUqy8kI3FrRMEeGma/NB
      hhTpP8z4XqIHe1VR6mduF8tk26urdzkQT5BuDiI0WwnKNrO+bnAWn/XwqtszNMcDaoG9Ve1kpuZd
      kiUGkAuAdJe+J8Nf/H7xRXuj23Il206ZymUzZw1NmsiBMq+WElhfgcjdfk66l48xRzStn68tOY+g
      +WSlFHP1W7421t0ar741X6zL83RVLuTK+ZdW6VCya1Ag/nHVVLabbMWE5oam9+YXJuF6FRDTdNJz
      ul5BpVJF83mZUPId1Jh/vvXifXy/0/r89cVn8nJn681rzkl98oyxtIjm6c/J7F1BeV7yU+grcIsj
      baghRJI/lfpEqZ1t0vP5KPTzeAiao7nOS0zRmfMZQl02NRNnYoLuAXtNCrqnZKY75Hssp7x5Sd9f
      6Zvo9nzA+Hb+esZvbtX/SZlTSd6BR9B8ski30Dx/+BblTZ6cjDEHvjmUT3pFSdI3xPPmctalFea7
      YnEJFmdgspH0sWvbwlRuGl+5jQgTzjGZCpr5VOSdzylwUtv453Vbk8lMmG7yTXjVbX0rQ/Ortjhr
      PS6vNc+k/vmyzhu90+1bb93CwftwPH9+8uWtqc4tnPN6lmhpZve43S5ayGdMG53AyLy52XiXuaBa
      Wm51eM6i9Bt1A6Es+e0tNL+10HgFTroXj2nWk8x0TZGW8hrZjF7nvy6NewHgcpRRGr21HvkuJTK5
      490imkv6dl4VJynpVpcWX6HZAn8K/fe29LX4POdqdE15d+pfXODJ3HJWaIYji52cl0UoUUKcdF5f
      mXd4gkF5V2+NS2tOoDf9XidwPsDJ6/nnecembeXrvrSIl1+ZiMiYqeyfTxSNUs5DvtUTFJhUOyee
      O4WvpaV5WzTDi8mXt3yxJptu8ZlHitLVrYWbDOdOPTe+D/Nx5cSQV667Zv7MBCWyWV1ea30r/56S
      aUUul2OW3dXnyPZI4aZr6fZKL7wAISl7/FaTeDLe0ERuvrUolN0rV55Ji7Sbf879Va4a+rF5u343
      X3VZ/n4RStBuvpa6kydOcpO35rO3CKl3np90TFIxi24BSw19ygAW/7w1D9fsfIogPMdTeAqa5f0/
      R8AJ15wb9PUzToC85H41Y6t0e56tLSaoMeGs2sqEI06m6P5OmQPN/CbBj0LAvEzYSd70nV5Nvr/D
      RRarnSPanb7RY8xs3u073y/KVZ/Ws9g3WpqH+TP5N7rfJ5N/C8foGhmchlpdnJSbaHv1v8/LX6et
      HyqLzU3EjTkY3Zn6TxfjfmfuEMH4U6ZSTT4sdvWT2mafFyXWyZMK5TSbq/zJW3DzaX/mI1qsPNvY
      92qjmZyeP7C4gnN4+lFxkpMMdh8dbpHHZHVuCXrzP+ck9Glvf0Km+7SeBxc9f3fxm7/esft0/lca
      mvPXeSu3yl8Z1+J6Tb5cfGD+opu/c7/3j8uwj8jvf618rrfmRZLWTEv7Z3HMP7G0k/nJyW3aAR4/
      0Qzv7lDVj85kziFyhp83l0M539Bd6Ae3dy5z3dqBn747+ZyPPGazlz88n6U7M5Yrwhexfaz56jlZ
      2h0PrsUiI5xvxR+dpcUn7zPvx+v8Ic59pz/0g2QzqecRm8FiV+9LD3ca/dGu3pK1f6jcZ/aPvDhK
      6H+lE3dKVttPkoXWc18a+tur/XvLtch5hR133ppv7L+xt/fR7X5gzr9lez/w2MJO/pSZ/WjfHrQk
      cAbliy8+0ofJrlskgzkX/1HO9whpPVjuMJv78/ZpJ3/o4QcrX9S0Hp+HT3XHB2u7ZeT4K5v3h/rj
      5r/9xeb/iSFlZflEe97uzX114TJ/ic08XnJO+4is8fivd1rMUYOuKT6X1iedxM8/0eI/UX5oV6t2
      9eAe5mtVafIl3YbvW+ZdvHg5dYAtSK50NVUd8tcXW5yDy+Ps/9OHHyw/SpmLzz/ek8kGeVwHumU0
      +2nh+ufKpyrg39KKFtDSRIr/Ybv5T7SaWy1/YlSPzMWn+s6tXXSn8h/aP5+WW0jxc+XnRLBFRfKn
      baN/sfxQ/+fLlJPTD/V8zsZySljs1aT2TwljuZKZKeA+7d0yHTzS9F+R0B/RgW4B6F8vi7XdQfa/
      2JO/0SBxf84fR785cC3SyWKFy/HN/8ZBpoBt+uenQ1rwe2Tm/BZWXkOQSyAcexuYdET5/e6RcD8f
      xN9T7qwK3RZtPuU6i1XdwqZbgvnklcflmr+imf5QGTtGxETMnPeZflz2UTFZedritplXmosmlFtO
      hJkWMmHm2enjRYVYeAaDip9vkIWxLHbyJ8odg8N93feWcvApX7lP9otN3yp/XQQWkWu8uuWD/ZPl
      U7hf7NId+WDy/Y8dJN5p79PHbqmo/0S5L1n8xcollZ94dyJK/I1yzS3LwGL5CV3nR5/551b5h+yh
      +vlToU9fQVn8cvHXR6q99RhKHO0yV6F3Hxzmf1mjoseshX8dVR+s7b8//Dvln+jMI/Sm5RM0z5Hr
      VqUaBGry4rwrOX6NkkiKxnCRcdiKcBwJ3OBfY8ZQRKgtEkWiIOJjdMZYZkPkUrDgGEgiS2S9nqtX
      jcbXYzSp0yxjhCaE8Kds6+LPIBJE0KKkhwU3QaLML5XRdYAkHdckjIk2pE/mscDyCZx8P0eWfP4f
      Wa/Jk4tM5RG6vPPMLSlJRNLqRZEQoyeKzKIf8N98FOOfIpw+Y3XwjLNWYmQak4helilyDETIS8uO
      yeJzPr0aPV9EiJlw5mmMsZYSYTBbIsNs8cEYZ4wTYWMcCBX6oXZJZmFAcoDGNW4d4JiJhYlS9GZU
      ogGy8c0k6hleZGa2Jl4fGueBNPKZFL7pkJZTb/7inGjpehffKf81nM0n7fG3JtCULVDM/vuBklc4
      n8lJQ3+9LA7Wzb9C0fQ0Os5beIRLTbjglPc1J26exSuXG3aAHFK1nsmMaIX6kCZDIKIYRZMRS0bS
      MaWAlBQf1aTtEWMcM7Ok7mkEvryLupf0g5lZ4XUbTxYyv607Wd0cuSY0kd/Em18cz+dnMpl3KHsy
      k/SYUW++9Hdeyak5f8UYpEe43AjVDkyma8JTx2nJftUMziEF0Me/SL5D43SNCfCUmPPloCyfkU61
      TvI85nBOkPmglITms4FftXXi8SJ7Hn/RORckhhCQxa2wjjJE1pLH2sRgxwj+JMYYlmknF1Zkacmu
      mOWs3IGex6HzvwPrP9rKIv78vT1Z7NI/Ohs30TxP1ZjDkG6/nNw1zGk+khzlc/jGu8gbNxHqc+Sl
      lCsZPdFAkRotFq2bVCFdtuIlJj1azAPDhjScHH81XaSmztCgORohgJl1PzBz8N4YQ9lm0NHptOhs
      oM75FtW3ctrSvuXQhg85+iyu2oMgPvnziv4eI7acDdx5Rh/TWZ2EycRj5jqVwWQCsS7GjPc+83lW
      yVoTEVCGsMiERRld5bGQaFabZJrcpOQPxCxhpr4eEfyfyYdgU6z8GCMZDhJFLsINZanakC19lLKZ
      OcXRntOJUilda5ljxK6UJOBOcpKxwz++jov1PPjk34WYP1TVZDfRjQH+vYA+qW2+3f4h5pGXm2ie
      Ywr6EUIYhqFpGiJC9ljNe6RZwSQrfd93Xdf3vZIaYBc5ITVl7QTrEfALeZyRdDxPv6mbR0SQ9I5S
      1DGtrTl33vvdblfXtXVTUGi6Dn0LIZiUxw65kjWHRlmWq9UK2ZxN1noeJWcSny/vWD4cIvLet22L
      LKbIC6xdzRFkDmF55RP2oPOm7GoS8GsCjrcW95Gy+OQdvMi7rfAHSrDWlqVDvs1hGMqyRD5PHctk
      P+BLvGuMqatKiYHGZFhjaZpGExmrzB4DKVF57733dV075zSmCjPHzLIxEc+zbowtgkjatlVi0M5A
      QPHeN02DDOOw3bVt0zQNZsAYg+wEzrm6rrVCpEtFnLtVVSPbLUaB8WLrfXx8DMMAvljXNVKcM5sQ
      Qntuuq5zziFl+aT/uiSL6/sgyszZ/yMvfkpmnwoElHF9XtJNtZ5FAeV+hx/fBf+3lcWpcHyDn+Rx
      QiSlJeq67uPjw3tfluXLy4tmH5dkmtDXQwhN0xwOh9PpRJlwaq3dbDb4MBczgbPn8xn0Xdd1CAF0
      DyFde4v6z+ezyizOubosY4znc9O27ZgY3paUhCkV6tu2/fj4iDE6YxD+F8/D2CIiRVEgzvuvv/66
      2WxG+S7GeK2SY14oQ/MYo8ZUS6OLIQxNc+r7frVaMQvwS5ckWWaYiOU6/nWa/LF+Y4y1RvMO61PM
      ePGmmU+yZKfZbF94Rv4rL/j4LFL8JxsjNRqZOQR/Ph+Px6Mx5vX1taqqtm0Ph8Nms3l+fjZZTuE5
      jYLkDodDWZavLy9YjlxoAJR///69KIrNZmOdU8MHGSNMIYSma0+n0zAMz/S8Xq9L58bmjOEYkWT8
      fD4Pw4C0Xkg5na3C+DmEcD6fv3//DiJ5eXmp65qTZSbG2Pf94XBYrVYrsyqZej+cTqc///yzaZqu
      66y1zrndbvf09BRjrOuamNq2/fbt2+l0atsWML1er5+fn7fbbVVVZNh7f2rO379///btW9/36Eld
      1y8vL1++fMEe2R8P+/1+VdXgZ4vqxZgDb7KKd/2s5suaf5MLHHQbMe+XR/BUllTYB+uRmZyel3lt
      /5wEPe/JI239UH+uZPN8aSFZQL6GRIDP375967quKArVbYFHELcBVZxOabAVdbui8r7vmblM2TBQ
      1I45DMPxePz27VvTNGVZ7na79XptjFmv13VdI+sSquq67nA4AJe32+12u3XGdF233+/P5zNSnoY4
      JjUvyzLfb1+/frXW1mV5OBwOh0PTNCpqAaydcy8vLzD1QN7RBYAukq/HLWrO5U1kmM2tqyqP56L3
      ZIfk4qpkJ2Mq+Sro31/mRbFl8a07G2Ze4acSuk5p0zT7/d4Ys9vtqqrq+36/3zPz09MTZ8bx/EWM
      9+3t7c8//zwcDtvtdlXX6/VaO6lCxtvb23/+85/1eu2c2+52Oi1YtfP5/P7+/v7+HkJISqHLuwdC
      2u/3OE3Zbrd8y2FRBFugbVtojWVZusQblHqNMXVdxxjbtv3Pf/7zr3/9q2karXC73f7xxx//8z//
      g6b//e9//+tf/9rv98MwGGNWq9VqtQKy69S9vb39+9//fnt7w/fYbm3bEtHz8zMRnU6nj48Pvxqe
      np7ma/GjEmi+EJMlzitcRMlJW387ON4ay1x5vf/KfM/+czh+qycP7rXHy01LCxEp9o15n7333h8O
      h77voQCez2cNn/v8/AyYUyM18rJ/+fIFSCoi3vu+72E/odnuRXMQliF34zPagiTy/PxcFAUZAzFH
      JW7ALhnT9v35fD6dTs65vu/LyllrIQ0xs/d+GAaMpSgK1IAPCit936Mbp9PpP//5z2az0R0brws0
      DMr8DdTiwckWpIRS1zUMC2qu0XNXPR7Qn9Q2RbePRjnLHnlHA52U+1CuP31KZIubnG6zDUgD1low
      JPypMzCvDeapruv+/PNPoKdzTtkhZqDruqZpjsfj9+/fD4eDVk5J6Wnbtm3b9/f3t7c3gKyaUyiR
      NzTIj4+P4/EIUlkaxYV3Qjw/nU5d1202m9VqhcQxlC06DHfe+9PpBBxfbze6ZbqhP5yOp+ZsnEXn
      IY4URVEUBdRZa+1qtQJJHI/H9/f30+lUFMV2u1Ux63w+//nnn8aYqqpgnCzLcp4o9f7i/hCgTHjD
      zwnjP1c+7eeDMr5+yEPR/u2o+nj5G5sWkZtoDolbDyFhuYMqCgHZGAPlETiVy6F6SglyXK1WUF29
      98fjcb51UWCUf39/h6S83W4hAkOqhekZ+BXToRAMONg5wzBYa7uuA85CJ207Au5DcAshYB/GGNV0
      U9f1arX6/fffVXgfhmG/3+/3e+gWdV0bYzB8YD1GCpGf01mcGXnMiLDAI0wCmlOWhr3Xti2OvGBF
      resas4ShdV0HOywRFUVRVRVsqRi1rg4Y0k8s/I++stgK3zVWUqad6M5fxH3grLaCVdjv9xCZz+ez
      5m6W5D3SNM3pdMIzp9NJD9UlGf36vj8cjvv9/u3tbb/fQzDPjXsgqu/fv6MSmMIo8ZLc/pPzS6W3
      GON+v99sNtDeKLnqKj1778/ns4jsdruXL69lWcYYwTZgXnfONU0zDMPT09N2u4VFsaqq79+/g9Jg
      SccZ0maz2W63kGagH3x8fIBbTFLLzj0L7qzjz0HJ/0H4++myqKb8vzgQLfOeL6O5ki9y1kF4PJ1O
      IgI0t9ZCM2Vm2ED0uBLbCYiDB3JnMpintSu5DRRyFuweOITc7Xan0wlCOgRbQHPvPba3IiOMPKgZ
      dnmAHXHs+x470BBD2H97e8NJFIRuZn59ff3y5QvMRDAr4Yjpzz//PJ/P+/2+LEt8OB6P5/OZiMiY
      siyfnp42mw0RQTZ8enrarCrnHLbrx8cH7P7wKVa+eDqdvn//fjweYa+vqmq1Wj09PX358gWSFyzF
      4BxEVFXVbreD0UlEYGO11sIWtGwkfUx8vrP0lKkFc/0aS8aZM1+8dpTURVdRGgW0ISJ6hD6pFt/A
      +vH+/g4tKteBFCvV3KwqkR5phCAhyNvb29vbW9M0mnA9jhlecEohx+Px69evmGc9OAHrjckv1hhD
      xOAW2jp0rPP5/Pb2hikaTzVJIomPwccQhth0rS3c//fH7+v1erfbee+fnp7+/e9/Q6tAJZvN5vX1
      FWgO9ffj4wN1YtRQfGH6w0bDWdQwDG9vb733QzJ4UjoPhwBxZ5VvlTlAzOFv8bHHy5z8HqxtkW7n
      794ZQk7G8Toz4k/IN/Op+Dne8BNNa5k0d082RzOQvnWz4YTQOQeNsizL9XqN/aaGYJW1IYHiV+xA
      bI/VagUQpCTsqAGEkmKuQhbcYDabTV3XqtKq/IutiAN9oPP2afv8/Aw0EQrDMEAwF5G+76P34FIq
      0aAJ7MbcphFjBKTC8vPx8QE5rus6HyPwCO4WVVVhB4pIVXwBSzgej8fjEdPYdZ2ufdd1X79+/fr1
      6+l0Utm8KAoIWXVdD8Pw/v7+9etX9XMAL8H8rNdrVUoUMdXeMqeSRXJ/kIAWa5DZYU5uFNLHTOZS
      PXn+VusK5ZiT1WoFgV0lUK0Qz6jLEzPDiKySu/YBJIEz88n5DRGhFcAotE/KlEXlQzFeQQCqhYhz
      Pp+xBaCeqiVHmQFYvu4Ray14QIwxd50iIkgtUCNgw4GxBfof9EvMKjQ5SDDQ+XK1GBxLN+ynS3wL
      gObv/jQQ36nhv1Dy3aEf8n9/okw4xITC/0rNf6XcRHMgL/xYAB8ATeX8PhOQ8QpIKldmlcKwLXHO
      AxKkbEJVsnPObTYbvAvxFi2WZYkj/ny3Y3vn4jlsEbA/AOmK0oYQ1vXKsgGDUXzE9pPkg0wZu0Yn
      Ib8rpzkej4fT6dy21lrLPAxD07Ufhz1b86UsfAwSInqL4Z/PZzil6cBR+TAMsPZgW1ZVBbVd/fCg
      BEDZr6oKU73f72GQgZUWezjfxosSeg7ck8/08NZS+NM1zQHxFvnmPGayke68pU0ABLGguUFcawap
      4LAxhLDf7/PXjWGolapv/fnnn5hnHQukitfXV3hMns/nj4+PfGicTibg0ZizJdAGzNwfh329Xq02
      a/XV1/MPZhZmmxE8jmGhoGAIZVl679/f3//888/T6XQ8HkG6IFHQIUgU1epWgrqAX/NLtJNVeHyh
      7zz5j6Lwz4m0i+/eqicnxQn+zmny57pxp/X/WrmJ5kVRwG57OBxg/4VsCM6fH/XAlMHpijk2DNzM
      AbgqVamZGwI15CZK0jHkHWw/nIJC8VQo1+umqBNma3homcyTF8dfeLGs1nrwqH7lEHPKsuyThwCl
      9VDLDz6rbaTruv3xCMfh7XYLvzEYhay1QIQQBSZO8BIgOPAX/dHDK5web7dbWF1x6GqMAQM7poZg
      1AKU68nY6+urnqbCZ/+HaOgWvn9a5kgxmbr5VskF4fzd+xI6XscAAdaHw0Fr41SgrqFFzJ4+EGMk
      MjBNEBGwHtpkvvmB5lhltcaoOALQTBWOvVJ+AKF+t9uBkt/f3+GrY2b3BpTLcmbRhjyEY0+cP2Hd
      cfCL/YXtpkvM2dW5tm1hfH9+fl6tVhP+mi+EfjOZ/Mk60m0q+rtw/J/jBxMp4Q6g3/nzH+3Vf63c
      u9kPFIO8ACvHer2O6SIcnBTVZAm9D4R4Pp/hxA1owykiJRcu3X7MrJoy7CSgcnCO0+mETQvkVbHa
      WkvZwSMZJjP6ogBMW+pDCIWxRNR11lobipKIIMVD+UW7fRpsriVQUld1N8YYm67DoISpG3psniGG
      GKPpWmgPTQiwyWDe1AwFlYKTxwumDlbyl5cXOCTgRefc8Xh8e3s7HA7qMAMmBMTX81ucl4JtyMz6
      fKvwtcr56fOUIe8ELybSuj48BxG5tn58CuUoYPBFUUBf0Qq1TmA9J4NbBuUUI7vmxwAAIABJREFU
      IxkzgjUz97035oz4P9eKgimKCuQH0uLMTUhdR2KM3kci0jNqNFSW5evr6zAMbx/v8Ip5fn7GuDSw
      TxBxiDcAQ02CY74+qwRveHl5gYgwDIP646t/PfoMMvj27dv5fK6q6o8//thut23fXS0ZU7ydIuxx
      Fr742ESp+hSzHgQ1meltPwSFExni013waSX/j5arbBU5LoCsofFVVaW2PzwPcsflSQjFgHLgNRiA
      Hj/qKRaMM0SEYxzI1/mJ/DAMcGOAWyQQreu69/d3GCKgXFMSXuCoYK3drNZqwCHioigcGyKCf25h
      XVmWgEVjTFFVsFTq2FFiutavOofKa+AlPgZmHr1NJAJYISlj8x/6w+F8KtoW6FBVFWyd6gWB2oqi
      gNPkbrfDHKpaA4uWsjTcd1UPHJMii6mPM2UYt1hy7KZsM9/a1RM5bo7U8xfzJiRzN8p9SCZy+gT3
      8z+1UaVAPZLJzcGYB2ZWITrvvPKtXJxXBqkdmFRI2b2HmHzkm6bpe8/M2+1WrXN4d71e//LLLz6G
      b9++wcFRGbZ2JneI1MvG+BIEiUvCr6//P3nvuSQ5jqwLugOgDJ2iqnrOnbtru+//TGPnjE13V1WK
      kAwKAL4/nEQgqIIpqmeuLaytOjIChHR8/rnDAW6SJCEi3iH//v374XDgQ0Ys1SyQvKHy8vLC6L+5
      vw+CQNuLG8pNAd8uMJ66UjGSp/t9S7RaRbXQeXpj3p18+XwrKLfYxkiaXvI7mvHB1M/N0Ts5yYf4
      Z7MZ00znE2RXDDahL27duqBg59d2q5EVAwOfM41ZAbCTYb/fb7dbPsHMMM06g+1KXkIcV+62TJlo
      L2ZzavaphJBSylAqIYTRZV4UjOncMOZBTPa5s45tua5Rs4VrjOFAS66L7QwVhdSQLD7aF8SREOJc
      FrSn4/EoAXmJcgSCaS6NcYl1pNs6dpcfcCPZccR+JGiCQ1jz8bO+6h2Hcn9Cp6wWxMvNVr58t5C3
      F/F9/lgURZZlq9UqTVP0LqVqlTkE6+SxCr8Brfz+fEEDxMK748FHFgfofmnWWsQrW8EVxTsZu91u
      v99nWc5W42KxcDPFBc5ms1W5YlcJAMggqLyYd7+PPPXQ3P0ZSMnH61zcOosK22rfv39nNyPrAG7M
      y8vLz58/n56eAODx8fHh4YFjnLqTAteo1PqpKwxDuDMuMy3Ubj3iq4qRQsYL76abzJo8Lf6O8qc0
      7CPs/t31ThnGsVu3qHEfR1HE+3WML4z1ji22jH3GnTiOWYKbE+3IPIu9BEw5WbgZx9nbwMHF7FKf
      z+fsTAfvRg4nuy7mOo0T1jdcppQyCMIwDAVBGIa6EnnDlPlZF/rivuRimYbzB44U5pbEaeoOGQkl
      V6tVmNShNQz3s9mMTZPz8YSIp9NJAhKRCznwd/BsExpvmgQAvEnAYTmIyDucHF/MIMKmN4dwOFeA
      L772+v7VcSG4Sc/9NJGz+BDMgfa73a6+6Ob6PpORKrqfmXpzks1Fsq5TwotSdxrF7ZE4lyB1XD2u
      qdZaIS5D5NwgLq6f1dLpdOb4pfl87sshc5o0Tefz+Y8fP/iAjwtzpMZM4dN2TtqZuyBRURQAwB5F
      PrThrDT/A5eTZdmPHz+enp6Ox+Pd3R1H0NaKwlgAkM0g1KPhDfkIsk+cl+nZuuW3MO4mzk5v3i/C
      zTdV3VVaUzD9F6WrN8m55e0EkTfcHU12OcV1hK970BFtAODYEgArBAhRx5BJGfD2O1u0QkBZ5lqX
      h8OeiBApDFWeYxiqKKpPvmHj6OAQLyGEFAGEgBYDUS+eUIYKFV85UF/kBBQEQRBKbY211pDNsozt
      g+V8HkhZNCcSq6pSSqXp5RYk9lpmWSYl8l4l7wPrSpdlyfd4EBFpQ0KiJYUiEHKWpHEYvTztoImZ
      YceUGzTnITmdTr///nue58vlkkPW+MIZ3uwNwzDPc2tBCBVFsbUWUWptEYW1oLXV2grB7oXaMAIQ
      Q6J7vZAdiXY43ll7zctyXIQGEVkiFM1lYQDgRXeRtRYQEFEKIhJKqjDKX7f7/TEIIkTJOJjnpdY2
      TSO+GdxaqCpTFNXhcIqiiI08DvNgw8UYo5TkK8XZFU6EBMISWkICAQiWEIWypPlL/tMYwzs6srmb
      UAjg+9O1Ll3YOJuMDOwASIQAgi8x5+oAxHy+/O03XC7XXCar5/q0AQA06J9E8XK+2G93L9tXDkW9
      32xC5joAeZb98a9/ff36tQgCItput08/fpRlGd/dlVofTqcfP36ci+Lu7i5NUz629sf374fTKUqS
      oqrysjTG7Ha7Hz9+vLy8lFX18OXLZrNBKY9ZFgSBACBjyBiwBJasNmBJCBy6DNMt8O73HwegIZ7e
      4g3v0y7dZ3uR1CfmI3zFXsfjT7dxb37jj7BvtqK3asb7NVLskAlVU9WRdjuu7cIBR0aHPIub92qY
      pLtL321zzNJt6DNSs1eBT9MxmHJ0B3NV53BnDcGM3t0rxPEAjAK+V5TXKiIGYZimKbeHz9kzMXcH
      W5yf2t2WxY8zb4rjmO9iBA76zs98ltVtiPEBzlAFSkjuBdM6bKLIwVN44J3q5Bs8drudi13jIGIA
      mM1mHOQuhOBz4TwsvG/BRjdTSA6JgdGlOJEpjBOZkcf93TxXCNtk2+2WNSVH36O36c20l4h4lGqK
      aQz79PwgKGi4hfPVONklL2rQXzatRe5osivK9+b7XfOtFjb4AICtTNck3sCHxnXGAswuteBwOOmT
      849zCXzsgC+MtNbudjsOUecD0ix7Ly8vRVGw35wPebJVKqXkLagfP3788ccffCsGh0VZa4/HYxAE
      q9lca40EbtcHro/GTJSBIZyawnC7dY0U+yvSkHJ6Ez0f12cf78hnGSXdYt3nwXPhzmHnXBNi+Mxh
      y/TgsBYAiKIoDJVjXoxNvDA4UgUaCs+oxHuezKrYESmuL6HVzdkfZ787O4C5MO/B5nk+myco6jN7
      DIvWWnYZOSMDm/i28/mcZUfybiOQUi4Wi81ms16vGf0Xi8XpnPHuLisqhu/mklXBh1eP8zl7iqLm
      +lZqjg4CAHuQlsvljx8/+JwIR9otFov5fL5YLDgoqCiKp6eX8/nMmsNVxLtwHNyimkuJb84xdIS7
      K+Vdy9H/vndVdBmQc4CwebTb7VhdcQY+N8sKiZqLHHgwwXNbffnyhd164AHuEHXCZmvU1dLthdOm
      TtlDB4Cwec2Q/ywf5nIRWewkwSbi1qkKRIyiaL1eZ1l2OmdsELCFMZ/PX15ettvtfr/nfabz+cwU
      YTGbsfwvFgs++sudZW2xWq043olviPvzzz+fn595YNm2wybcC79+86+6G6FcruNvwrihNIIb7vMQ
      YkxkGCPPdh/vCuo7uvmLAPcXpW4HB3dBnVeXkUupq+iXVlnuS7d9x7jjnmVOyv5i3tNjBMcmaIEX
      ObPdJEmYXLslXbe1WbG2eRWcH+bh4g3Y24OYYuN8JCKunS8hcPXyumJjAsD6YTxJktzd3fGNoyyU
      m82GNQcHxrizPOzL5uYtFgv9+MgKyX3PkZ3ucP9sNnt8fGTS6u6k5is4eM9ws9nkeZ7nJR8lZerH
      ATAcki+8yxfdXExnUuN5fIH2P7TWSas6f43xxG02G74Ikwd/Nput12s+AOx800wzWWx424Oj75lG
      uB1L9k27y9Dh2i7mojiD7wy84ixK8Qa+9A6UOuDD5ninfzuFv9Xpu/45lMVd7k/NuWLW/ZXRZVmy
      zPDhoOVy+fpae2DYFlmv1/f392xpCaXYFtztdhzbymHsX79+3Ww2iPj8/Mwj4K6u4yOjbMxhc7MC
      jzDLdu8EDWnrXqnolaUhCG5l8/c23DRRn6N5RA6nQGov8vqC+lZb5CNpRA3cXJIj1Gp67fxh0NPi
      4NJ5ortVdueboYedgCy7QgAvEr6NxAExi6BztnD5Sil3padqLjOiZjdVCJEkqZQS0BLUi5C1hVvJ
      1tokjVCQuwYAADgi0G3n1k6YIOAL81arVVmWiJdXXvDCTtM0TVNe/aFS6/Wa2bcLe3eBm0oIa20g
      pUwSvLtjW8ShOV99x84l7vVmsyGi9XrNF3jFccwhQ7xckyS5v78PgoiPBXKbOYNsbjFja8Dnkr3G
      5tBkjWeekny8aBln3McvX77w/VDMIvnKYvZEBUHAI+DuieX5dVjG/XKcejabsR/caVYHxNSEfrMJ
      xfvtfgs5RVG0Wq14B8gnjC4zFw4ADJH+bhA1m8yiuR75y5cvrMudYmCZWa/XbFw6pRVF0cPDA7uV
      bHNR2t3d3XK55KYKIdRmY6pqnqa8sRSn6Ww2u7u74+0E9liySGDzCicnV3z9CxuCrO2Y03QntBdu
      Jk56V3JaRQ1JYLfe6TUOtdZvwDjHH6/LJwS9T/X2sbeckYre99NI6o7M1TKvjG795kbNRYn4romR
      BrkHHa9HRADL5IWa21dcOY44Y2O0uvsDGLaiKHL0hw/+SBk4nw9ZdLcLuHe1GGPyImOWx4ma84Gs
      D5xLh8O/uFhjDJ83sU1QpnPRuBdhV1VlAdyNKwDA2XizywWuaF36NgFXzRY6NvEqRPWpUetFoHNn
      bXPUtqrqa0OcJ4ENc46KgcaBQ00Uh/Ai83rlYIid3RR6XyR68wghzPWLN7XWVhv3agXR3JfCIR+I
      yBsDTkicP42nzAVEcWl8toDVnvReBUfN/W7MWNmo8uNAsHlnoTu6zIqQPL8TNg56liXfDPUHwZXJ
      WzhOSfgeattcAhFEIXeZnTPs5XM8hnHcyTYi8h2QvGMkmn1g7gjfwugiC2xzaI4bECqVxoloDjSI
      ZkupF6cmwlN39ocmHbwl3/rgprUFml1iPuK/7W1tL9r6RsDNTg3V+3GOfLMN/hoZL+SttTA+DKK5
      ++zPx7h6b1XDjwvRdrB2tavLj42HRza3yDaFCL8xRPWz7jiG9N4xzWKNTSC80wfOduZl4z43sZiX
      lz2yYmhC3Oruu/1bNwjC20xziT024vqguUNtaHYCwFuZ1nt9pWuDMeSPGNtJ1HgAhBDsurHNtTlT
      JM8VTn2Wrz8LrUe6a8lPwosUdF3gsLnWDLqmknexmsNTuL4C0C/Nei+9dIPGeMHY6kbYtdB94/Y/
      qdmzaaG5N3ft9eZLvp+HGt2jvdd4iub8l+uFa3ndQnnpnUMT2dxC4wsJNZcRMQ+w3rWIbjzrSuHS
      R19aemffn+Up0jKSs4XmvTmxSa1Ku6ABHWwZam3vs93HbyaHSK2GfbzMkbGduEin5HHwwtXVvrih
      B6gxgbsQPJLfnxsn4m79+Mn12SdT4LnpXU7RBKtgJzFuXth600hXJnhD7DzOrVFryZzw7neFvkgm
      n3G4XkjvvKKPDj6WuSp88HWZ3U6v43HSu+XRN25c1f6oDk/91Rz5n8k71ENN3AgML86RMltrzDnT
      WhjqoyTi1dlO9whcry6HU0OU00c368WV+4mrk96pY/d9q1WtXviPu+r8MW+pBD9+qSWNTuzJMzuo
      OeiAzWkM8qi3kz1nNYrG9Y+eQeMq7cq2352eyftYao1bSw59KX1Taa0/h77/lOQ3b7zk6avsL0hD
      Ta25ee+a7H3s7V3qv2e5V99Sxys08OCYEvL/9Eu7NW1t1G4+tq+ErN+vyIWIK95BRP476cET9G7Q
      WHe0/XIQ29DjZ2jlH+7Ubc/dEPxBB938/CPF1s/SVb/G2wB98uB62upst8wh6Z2Sbq7hkXaOlDCx
      2DozXr5/K1qhl33k8U9BoimFtOZiRMHA9Xp/ByPpfbBV4JQBcYuRPLOmPUfTGPdQY26m9z3oBpC3
      8S6RKlOQ9D9HO7079WoRALjZs/7h9uziZgAn3X9CHsW+WdfNNNSpm48Mrb3xKm6W3GKyN8scZ3C/
      jp11x218DU+v+n3A+pGu/eq1ObH8NzXjHW0e168tKH+HdhxfmH9NevdU3jg9hH0+xDelm0qiMxms
      G20rz/UQ8689OWtf4hvrhQ6i9T5e8yDPacU8HXAqY6UmdX9yn99E62BArLu/Dv3UQrSW1ulFt5uC
      TkRAYyPZbfaIzdH9coSedysdZ/TQGQEYIDdvgHLOSADQvsywdyjw83BjSH6mcLXxYt/UgH8jIPYK
      TG82uEb/oXU0xb4cF9EhCZySRpZP93s10vSJhB1uTdvQQp2YxtHqrYVMydlChKFnWxn8iZwC6/6f
      H0yfws17cbxb2vtI+vRHxr9sMYyRZ29q69b3/iCMKK3xTtWU0M82YQB62eW7068A9I88+1anwc1s
      4+W/SZF00a/3mzcBuv/NTeNvYiMnPtXm5q0nb1LFN63tjz3O/mjfYz705kPeFLp9I+hwXT6WmeZL
      wMvSJKebELG54oghYLDMoW+GpuqtHAE62DQl9bLg7p9vLdYv5H3rofu9T8C7rR1v4TiZGBqEt+bp
      suzuNy22Pq513pemaOJPUbQfzDny4OAIXyNSr4j2CkZvUe9r5y8tCoZ1g/9n74O372n5FekvkIyh
      hF6sy/sK71l+nansFj5kubeAyWOF/Uvx46bS9GyfOPgj9g1/GPfG9H6ezlk+Qi3flN5U0U2e9Cb/
      Ru+Xv24JD6VeFfKLcJOIRqj6TZLey1y7nrrxxk+XwPHMrQwTh7H15SCaT2/ir37kmoP7HvMpT429
      LXNE3Luuhl67yf9+StdczhG3wFBpU+Sm28gPIkKrnPeZCyMO6PHFNlRCN930br3bzu2tYgqFH/qS
      LTw7cMfhX5b+Mg33F9f1kUp9OZmI5lMaMF2Sx6XUWaVDjw/eujUdocZTl3j+J6TW8u5tZI/nwSPh
      La3uZxuq0WV4H+COzHQv1H7WaH+iJPT+2e3XO3TGUOabFtIH0xR+fTXdtU/9E5vwhvRLUXV8FXxW
      1W9SqDeJeW8h/M1frH5aEDSFK3R7p3r304kIRA/l7G44DFFXL4/0Pndb0PZ9I12+aYS+za/9Nt9a
      GHaoav8bv1stCnY1yl62Icuolwa2jiC51dygMFz/2t+Tm17stzLQDzptbrTHVzC9hbjx79ssnM7f
      38ShepYul83NxIHqmlMFgDgef9KWRs7uK3LsydZb5qegybiX+S+gzAOY8Dldm/LrOLsa2np5N4Hw
      caC39mGc7GchN3m6j9KDnpYhg3HiDsN/WvpIU32L6Sb1m9KMoRn9xPGcXtRneVd7h2LEX9TCa3rv
      Ir9JZG70bpp/bBwdJuq8XiifUun/b9OI/PwFVd/cy3mTC/GmH3+oGb11QUe8ieiG39w9cJMYvqWV
      Q7EoXmmjU8a/fmKU7s3kAzrc2rIb0s/e6KOvV9+dem2jd6DzyAoZ2hW4aQcMWbtD2w8TU+9amg58
      PWvsVgYAIH9OB9o7zgHrDBPa+A4Q/wjATRn/6WM7LkgTc05v2K9LLdwb0uUj7ppWmj5HLQlvIU+r
      6tZTY2juL+Ob9OStDf0V+d9UzkQe3frTjeyUMrt5hqShle0d63MIPT+YhkqbbqVN5y+9o9FyfHWL
      GvH+QZ/0thpGnhPs3QM30v0pNu74szfx4lez+Dcpy+50/JpGvbklN/P3foZRCXRTM3HRvVWHdYlU
      1w/s53+bp2Xk+26eBvjMrew9z34iIL2VCQ4h8rihNETM/S9HFEC3ll5jaLzMt+oneAvtmpLtTWkE
      yns7Na5X3s8wOgPQVRKfZQVyORYufeRvWsWPaMohe6hLtj7LgfaONHGVjS+of4saeBNnnd7CIcfG
      uNu226SbrfpQhGJv3RMrHnrws+bwJi/+9Md9JBo3kcBbz71o1XKhDDVjCPum2yJdqepiwXjH3w0Z
      N+GmZQyN5xxyx8PAmNzcungTyvwF0Nm7skbW+aebaJ+u+N8nV29yWUzhwkPG3Eiej8hAt+TxEt6k
      1aai+V+3+TC5npGcfz0r6ULzlJXWZaNOdIacwlPQvLdtvb/e3N39K6lTLyhPnMpx7duFv3cXe3Nn
      7GaB6D3SfWzKfntvLyZusv2fsrM6xQqZWMg7MvsLc0Txu5Y49/q4zdErpTcB3a9ipCj43LOg77d2
      P5tH/Ooqegv3p3/KI601Of3BoarH80+x43qfHVpX70hdjvNBE6qbWsGg706t7S/4d8jVUOqdkX9L
      S35d+sv2CSaO25StSPCa/bnm2nh/3a89aD5kx/msATvX/H9K098xT91Rbn3zvoa9qUeDO2wD3HmE
      W/k5HaAMjYmbgqFxG/E/tBhBb+Ejv/bmn77J09Px67GayDRH7JLWn0O+S3+cu9m6ct6a2a63erzB
      rQJ75dZ/ZUfr9R1D6VebUJ9Lh8fXy/THfVBqSc54g0cq6oVj93loMfYWOGXQhoZiyoPYeWvCmz0t
      /rh3EWFomEZgC64Ha2J7XOq+G2io5W8yh9+U/2ZRrcYQtSVyvC4/zwiZ7Y7hRCH7FLIzRcpbUnSV
      p9O76brB5fcH6uY68YEAO94tuF7P3XrfZFFNSY4n+V+6t0G9r5ZPtKs+MXW785G15kP5x9Nb7Z4P
      2hA06pkZKb83/200n8hSh/PwS9avhgkRp8e6jJ/8HOltFzImrgp/bU985WarPW8Vry4GvVXcRzC9
      VUW3te9IN0dyBAeH6v0IlPtpul01TudvQnk32xQBQwLnL+9WcHMeR9JNc+SzUu88dkev9evInx9p
      w+emKYL9Kwb2U8q8EaE4tOp6eUTvYhgpoff7cV3UfWaIeg9x2HcYrZ8yf9fF9tg0466S3pZ06eR4
      mz8Cke9+aurK9/5sGctD0AlvZHm+QL5Jc0wpfChPzwwO/wre0vDXV8vqn9hm38L4OHQOTUcvfbnJ
      G/7TzIXeNJ0WfCSNq+03NWDqWVD+s7sgfXO190E3362cA/ePk7Vtzn7Fzd2XF9lywtQaDtGVKAAY
      P4naYkYfTFMKEYBEhNBertxV16V60PqsE/fUR+jqO/pLo/6f8aq7kEfeC6b979/aZqSxWzMB3MAi
      ABACor28lnOgE0ieYLjM0zxLV0hq60u3/JJheE4/nnq1xcivN1PXdJiyZD7iSvULefezN8u8rD4C
      BEA3d62FSXXui6IdL7/nqwH8eQ/eIIDDPQSwakhvD02S5yqZRHX9Am/SCkTsjkAL0bolvAmJJpKa
      Fga9ld20fLhjbRg4HDxo03S+cc2b6ETqLXaoC0N/XtozQJy766S7nnt7PcLyerGy9evQIAx5wBAR
      ei6D+5zUkgEcWE1wdQEcOg70Vgkc7/tQ8yb1pMk/9OFmq34Rjn/WxPn65v84M8INgoJb/g3f9Ov9
      HsYxgi4cmerFYydaf1esnNvARUJ/kGbXRHBz42WYcEvMp67tmygzgvuf2Krpamzo2d5Gjrd86KfW
      9IGHth9ZPET9bw7xG+MLLSL6KrJbO/VZltNb2JLz7pKha/+hL8bUcWK8b3A+C4xaCD6kpMe19VCx
      /xbEHFdyv0jBvzX1MiQYWFk9npYWOLbQvPUTDEN5g+ZXhQghhLzkGW+9b31cfX8Za4F4qcFa6z5L
      KVtqln+11vY6W/y+fJxNwIAR2otZ090gRATX+snhxZvkb4hoD2WeWFovWe7qV/fhysJrJKQlbEOc
      ulXaZYiY7BIQNrrfG72u0BLWYkZ05QbxS3b32iMiTG7JVQkDHg9EbF3D24jo1VNdO6lb1NCvvzS9
      SdN8Fj6+T6sNpREB607l57ahpenflL83qVqYWm6bRsS5CK21tVZKGQQBACCiNVBV2hhDREqpKA6M
      MUIANDFV1lpjCAAEKimltTbPcyKK4zhSAQBYL/rKWiuEQJRExpJ2S07Wb90EIjKahBAyCIUQLNwM
      yaoRdGut1vp0OjGOE1EQBEEQJElSVRVjh9a6MoabzfVWVSWEMMYYYxBRIkkphRBJkiCiUkoI1aBM
      e1K52U3jUetKKcWxOojIvRNCVFVVVZW1EASBUqw+r/DXV3X+nwBQ3+3OGguIgJDYp4cARFDXhZfI
      0yvvMxFZvGSQIAEAQUJDYQkuuxRdQRn6pgXZLV7GLWkGR1dV5X5CRGulm0EppdPBWmtjTCCVGzeu
      RakQABAFSyARSYk8WTxQQgita5nh4TXWCsSq0twsY0wcx0QkldRaG2uDIKiqip+l66lkCbfWNgiO
      2LrS3JCQ0pB1Y6DtVQfdA45wAADvBuHltn0kACJSUhmttbaEoGSotUZEYywiqqaHnJ9lY+I0fVYa
      gRjsM6+HiN0UvjLSi3Hm0SJtUxIigiWoDaO6KMGyDTWYXHLealWvcu1q3ybboCOxv6kDfzq59WtX
      rtCWlmDhdqjHj/ECQEQiW1XV+VwYY6IoEDLl5ecWp0NzlJKIjDF5nrNWQJGEYegguKqqoiiMMUSM
      0QaxrjIQGASBkhIAykIHQRACBkHAbUAQiGithka2qqo6n89u4MIwjKIoCAKHL1VVnQuurjLGlGV5
      Op1Mg++IqASEYRgEwWq1SpJksVi48eLesehwZ1ltwPVKtvZKLutKz2djKI5jRHRP+dJQ6ydPhnxa
      alt08uLgu8xRs9qxJYhCeFBb7+a94R6fIfHo/dzKU5ZlWebn8znPc2OMUkoplSSzKIrCMAQAYwz/
      ez6fsywrikLi5bAMj3CSzJIkUUqVZSmEUEpJGTgoR0Sex/P5HARBnCZhEAiAsiz3+31ZljxZM62j
      MOQhYsG21mZZprW2TTlxHLNYCiGCIGBg7XZTCEEIZMlaezqdyrIsqtz9qpRKkiSJYtYKRITIWCyt
      tT5DAkSmEXmeb/cHrTVQ3XchRBiGaZomcSilhFtg9ympW8VnUel3N+AvLo1uGYIjD04p+dPpfLcN
      CrzF4//GEl9VVVmWRVEQURiGiCiDQAhhgApdHbJDWZYzOwviIIoiIVDrqtKVMWSM0ZUFAIUVL8XD
      4ZAVWVIkmlaz2YwpMABorc/n8/l8rgxztFIIQWSstWEQpGkaByEimko7emIaw5yIEOvuGaJS63NR
      cEfyPA+CIE1TlFIpJaXUxuRleTweTqcT9zHP891ux4AIDV4LIYQQ+2O9YaCfAAAgAElEQVS2Xq+F
      CuM4bpR2Q6msFY1WZDSpcRxAWw6QIGxMfkuktc2yvCxLImJ63jMfAoFqhVv/SgBMwK1tqDwiokXL
      eI2ACEiIjPWMjABABLwzwf1Bi4hIFjmISAhBZAERSFCfl3lIULoS0puBG6m1Lopit9vt9/vz+Zxl
      R5YfKWUYxovFYr1ep2nK81IUxfPz8/Pzc1mWQMIhNTPlb9++SaUIYLvbMcuez+f8IAACYKX1uch/
      Pj/NZjOhpCE0xmy32+/fvx+PRzazlsvlIp0tl0sG2XOWnc/nl5eX0+nEcq6UWq1WDw8PAMDq1hkH
      cM2PLBBYstZm5/P3Hz9Op1NRnl3ONE3v7u7UnZKBQroICYBteDY46i6lzPLidbv7848fRVFUloQQ
      EiiO4/V6HYYhUdAd7c9N5BGFDyLgr4Oqd5fm/9lG6oFfu5x6Yi3jDMkzUN4/lTeVjeqtmNcSU54s
      y/I8J8R5moIQAZFSyhirtS7LMs9zpVRVVWGkACSv5Dwvi6LQlSUiQYIz7Pf7rMiYLmmt0zRl9aC1
      zvN8v9+fzszgasiWEk0YEpFWpRBCAAZB4MOuMaxyNOfnxpRlyd0+nU6ImOe5EGK1WrEmqKrqeDwe
      j0cm7FmWHY9H9iCFYWitNcawU6iqKmvtfD53JAs8WlcbB4396NSMtRaQPO5cM+6iKPI8j6LItb9G
      ZESJgph+DzjZ/aKMMSQu8+XTcFcgNla8+57RXAhhPXuiq8LH0xCUt5Izkg6Hw/fv319eXrTWxlRO
      80VRst1uT6fTt2/fFouFlJIn5ffff5dSIkgeZO5dEATr9Zqp/W63y7KMfSabzcaZI6w5np+fiSiM
      41Sqw/Hw4+nnj6efeXYGgCAIttvt/f19afTD5s4Y8/r6+vLyst/v2ShkGs4+uoeHhyAIpJROO/qr
      1A1vVRS73e7333/PsqzSBWdmSYuiaLFYRFEkBfeFhwudSYR4calxx3/+eGY0t9aGUqxWqzAM5/O5
      iUOlFNOLz7p/pjf1TiiOukdawPeO8qfUcjN1AXcIjsdraa2+IRzvFj6l2M9SeDdLaO+CEhE7lU9Z
      luc5Y9/5fAaBeZ6nZbFYzKSUxlCWn7L8fD6fUUKSxyqUURQRgiGbF8XpdCpLba2tCs2+4+PxqHWZ
      JAnD6HK9WiwWcRwHUbhYLVGK6Hy21hpArTUAhKGKVICIBEgo5pw5CACgLMssy87nc1mWhDU4VlVV
      5sXhcOAlVxRFVVXsskfE5XJpjDmdTofTMS/yKImRRJTES1it1+vlcplEMRGxAnt+fj4ej6fT6XA4
      sNbh8hnuASCOY6WU20VgnC3LknUVf9l4yQUhluyvJ2L+zhYPAEgpZ0lCRNZYrXVRVc5rzFUIIQgR
      kIw1VVXlec5POf0hhJBSsj1eVRX7srgQVlGIAlFoU2mtyZgoihgd6rjX633Crj3Yq+xHpI2HoigK
      Zr5CiM1mk6ZpHMcAwIQ9y7IfP37w+IRhaA0Aic36ngmpEMIY4okTQmw2qziO2R33+vrKqhEA1uu1
      w0SjKTvls7QqS52/vPz588fT0xMg3D8+RFHE7dkd9ijFbDY7n88vu+3Pl2el1Hy1XC+WRVEcDoc8
      z79//86Dwz6x3g5aMEIpTbrQhUW7edjwFguDbRRFi9UqDGIgYWocF+w0F0JY0tZaiQIRCaGsqnNW
      7HfHeDbfPDwmcWqslkBpmi6Xy9lsFgRBbXca86s9Lb2pF2pb37wPpFo6smXeTS9nXFzHtEhfUSPF
      3myVM0yHiHnzYbyYG2m8Jf2nh4iIvZyMFDJQ1lptTVmWu50GAK1tlmWHwzHPcyIThmEQSI5XMcbw
      vl9ZVtbaKIwBwBgjpQRQ7MuOokg2DhAACMMwjuOa9gYhO3aCIAiENKZi3sr0RGvN3kaG3aqqtDWM
      IIzmzLUZ47jbjMI8xAx2Qogoinh3TkqZpulqtUqimPfTiqLgBzkzE7eiKNhpwBpisVgsl0v2FUDj
      LDoej1mW8Y6rUmqxWMxmsyiKfNcKgxHn5GaESjGZPZ1O++OR9YFS6u7uLk3TJElcq1jBlGXJLgsA
      UErFccx0VWu93++Px2NZlrz40zTlNrA2KoqizHNrLW8M+HPd+uwIxUTK1pIw9gUfj8cwDDebzXq9
      ns1mSikiKooijuOfP3/udrvj8bhcLheLBSJKKZMkeXx8TJJESllVho0nAAjD+kEm0awPFp5qv1gt
      RESkjWadd39//+3btyRJssPx+/fvp9OJTS7+Vyn18PBwd3eXRjERvby8/Pjx43A4LJfLzWbDwwse
      A63/BRBSMHPnQu7v79frdRAEXL+UMgzDQAU8p8YYIZSUUghgFU5goiAUQshAMXsoy/J+vXl8fFyv
      NtZasEYpwasPPpXWuekbz+Yy9M5+90tHX9yfH+Ha70g06u/uHTry4pSmlNxb+Ls10GelbpMG71Cs
      2ydQKKmM0lprsnlV2qwkIq0t+9OrqqoqVZal1lprjZbKsmQA5VUaxhEAWCBVlVRZlEKFQZwmvD8J
      ALwOuWp2vGhDVhtrrRWSoS0Iw8qQttoQ+UjkJ2NMqatSV6FAKdVsMSciJSRvuLGCOR6PDOK8zcVK
      IoqiOI7T2QIRq6oCIZPZPDpl+nQyBJWxpc632+3z8zN7chBxfjg+VvoecDabCSHystruD7vd7nA4
      8DaslPL+vnwAlEGIUoBAEEgIldFFUbw8P7PTABGLqmKk5sfZ2pBSVkbf39/LQEkpz0W+3+9fX1/Z
      OeAoW5qmnIcQ9sfT08vry8sLgwgRzWazdV58IZrP527LlzWoG8Nxoj1dsLCJZnHcvCzLu7u7L1++
      sLeaeTR7qBmd2TPmdnFlGKSLeZrOpZRlWTKaMz5qraEoQaogTjTBKS9+PL9E6SxKZ0IIEtIAkpAk
      JAoFYKM4DsPw8fGxrppgu90W5xwsIWIURevFcpHO7u/vF4sF+1Wcwq6a5Dbqu8NCREVVVkaDQBko
      EBKERLCBUqGKeHbyPD/uj6fTKUoTdvQfjofscAyCQKxUEAqyHBhmiBAIEQSz+zAMw1CxExLIOKeT
      s8YmTtN0X4H//af4PW5y7SnYN9h+vLT28qV3crrtKqG3SfKlzGn6D7xec3rTs5+YiEgNzZ9zIrtf
      maiWeQ4A7A1sYgykCwo0WrO9z+vQ+Zc5g3MC8K69EIIhJs/zLMtOp5MmIIulrqw2QogokFEUpWka
      BMF+vweAOA7n8zkzoDRN2XMOAFrrOjrNmNlslqbply9fhBBKSGttFEWM1MYYNqXDMGRvrNaarfgg
      iBzKcPudC5htfDbzOZCO+8gLLAiC4/G43W632+1+v2eaDE14Q5qmUtZObS4tyzKm+fy4MSbLstfX
      191udz6fWZdx7WEYMqs9n8+73e7l5YX3bNk6AYDVajWbzVijvL6+Pj09vby88KxxsVVVufgKdhb5
      uvPdaWTNO6+XUmo+ny+XS94tcJ5ldnm9vr4WRcH95aJ4SHnoOHyQZU8pxT0SQrCdwU+dTiettesa
      Fy6EWM6XLHWz2awoiizLdFGyJcRqLI7jJIyklCwVrkcsP+xA6zIGLye4LaXD4fDz58+Xly0PyHw+
      36zuWENorXlaxfHA8TxPT0+H7etisWDbyDnHyrJ8fX2tqkqI7wB2vVys18vNZhOGIZDlVeZshfel
      mzOOeAmFGur4zXL+SuQaksC3ynYLfHm0f+kC+XjJI78qvtGte1OEUBKlYAA6lwUiKqkQEZUkoiAM
      hBAiqLTW88VssV7Fs1RICQRhEqeEWuuqMkVRHM9ZnudgLAAkSeLWNiM7L5vGp2ENkNFkqd7QI5QW
      BLsOiCiKoiCKhQqM1ZXRx+zEhqqB2tA2xjAzYkdtHMd8w4YQghc2L1pWD0yg8jx/enrK8zxJdlxI
      lmV1tFwYqChkQQ+C4PHxkUeGUVJrfTwe0zQ1xrCPWCn19etXFYVEpIvSWttspkkiPJ8LKU+HwyHL
      MkN2sVou16vZYs6EXSg5Xy5WmzXvLTNUbbfb5WZNOWXn7GW3JYHLzZo3HmqvjjUGyKLYn7Ld8bA7
      HkCozfqOvVKc58ePH3Ecz2azKEru7wLnoPiItLWcM6xdWGFLKY/HI3Nw3kNmnY2IZNESEFAYho8P
      X//nf/6nMqQtFLo6l8Vut/vHP/6RpnMiAkTn63u4v2fYZWsDEe/u7p6fn8/n8+vr68PDQ1mWUqhA
      hWVRKSlDqdaLpTGmzIuXlxdm5efzeRYnmy9fQ6mklOky4sZLKY21vA1TVdV8Pm+c4NZF6Pq+DkS0
      1rAriSMvt9utUiEiGmOOx+P2df+3v/1ts14LIaIkNfSyf93ttnsVSPZJPnz9ws5GY8zhcCh0lVel
      LMvdbhdFidZlnp2Ox32WZcvlcjFPec+ALRVWVw4pJs7gxGzjXL7lTvEfabkjJjLZd6dL8P/1lk/9
      a+fDeOfbj/d5Ebsj0KvhukUN1TnaosE0ZOL4lkHb0+KMBfa91hF1JQIAM2IpsaoqvuuKWQxDJ3Pt
      SlulVBiym7tExOPxcD6fFQomqkmScGgKk1xesXyaQ0opiKI0rIxGgjAMmZexG503hZjUaF2yAsjz
      /JSf2ZXM7ngmMg4LBKCz5VmFhGGYJAm3lvdjiehwOIRhzPSE3URM4tI0lUJGUTSfz3nCdGN8MM/l
      zxy0PpvN1ut1upgjoimr8/nMHm32crDXG6CGOedQzrKMx5DtBg5kZPcCm/xsMVRVxZF2q9WK++ss
      OxczU1UVn9UKw5DhtTKGXe0cZUHaKKWEePM1v10hGZJdh3q8YcDdR+SIGiAiIQVvzzo/GyswdoIh
      PiGikJKI2Pyaz2bMTHlmkyRhfcZbl/P5HJvAIc4WhQlBva1yOp32+70uq6Io4iDk82tKKSkEt1MI
      UVbVfr/fbrfH45EZABMOJzZX3WQaa4wAVErNZrMkSdiq4ya9vr4KIaIwXK1WvH/OmwQENk3Tu7v1
      fD5nDxvWpwHEfD5fzJe80MoyMFXJKv/bt29hIHn3uAsZ71bGvbTxFxHJ3vRuL3PXFzTuJ+y6ffw0
      xRP1H5XaHqQ+5ar83L7a5/03xi9NNbOO4zg/yZzyoqhc4ESkokgFCgVZQoOggbTRRZmfsux0Koqi
      Kg1GqKIwSmcyCMiS1pZNbKXC+XwZBFEYxkEQMR/nfUiG5izLSluTbsf+eJ3z9uC5LMqynM1m8/k8
      jWI2wxFRAAqoPTysORguoyCeJfNAhmCRDJR5VVVGqRxxDwDMfeJZmsxnm81mtVrpyoJQpbZVVRVl
      URTluajORcVN1RYQodRWhfF8uX748i1JI47HOJ1OgsDVzkE41tr1en1397BabRaLpRBCKR2GMaIs
      ikJrfT4X+1O2P56UUrElbjYfWJ3P54+Pj3d3d+w6B4A8L5kYVlWVnfJzVgSBPR6PURTxhqExJlaB
      MbXfBhVv5Rl/PXzYQL5Y6Ax/wjvRShYJEEEC1TfaG0KUAUiBSoK3eBjCmIeqMGA0r3RB9L8QCZGE
      AN7kWK/XZVn+/Plzu92mySxNUxczLoSQQlhrlZBxGC1mc7BU5cXhcKhjHE+nKAyxUQ+sMp+fn7fb
      rbX28fHRhTC5CMXWslFKWWvTOF4vV6vFerFYsFt8tz/++eef/9r9648//rhb391t7heLaD6fW6Dt
      fqerkj1vHKyCiDyJj3ebRZrMlitWflrr77//68ePHz9//ozjeLmYzedzlkl/kIdmorvge5Vui91P
      EQAajvHofdxV0fvrdKkbUTw3YdcH9G4JI+A4veQRb8/NDvYOws1nLzX2XfZQ75tbujARXhtlWXA4
      9vF4zPKzYxMNcwH2LzMhQpSIUuuCfYWHw6EoiqKoylIXpS7LUpuSiXAQBJEKFotFHIcMVdBw3hpt
      k8T5dtnRKah22fNqB4AwVGmaRlF0Pp/zqjwcDlEUJUkyS1IAOLEKqao6wo+IH2dizpEevAfLpDuI
      QlZUjq9FabJYLBaLhVKqLHJ2W59OJ+bgXLgLwnGxdByl48xz5NjAJkSdvFOyzOvd43za5fX1lXdZ
      K2s4MIYLZLXHVxS4w4pMIctSO7OD8/MWIoMRIzgbQ75R3LUlJ4JFv1TVny+hjdxlt30CcFFpqKTV
      hseQZ9m5s799+7ZcLokoiiIVBi70iCM1sdll5U5x9/f7PZ85YguGx9wYY61BRD6hdnd3p4vy5eXl
      58+f+/1+t9txJBK38HA4PD0/f//+vaoqVt7u5PDQYtPaSCk3m02SJFIEqCTbmigUR/LwFi6r2PP5
      zJaWNYJNySzL0ihGRDbRkiQhIhGEPH1EZKsyy7KnpycntKwdu/AxNGtvoqJvmvEhnvuO5MNWb6dG
      gPKttbz1p/ECR3AcJimbnplqDSxdO69az7fWsvuTiBTVm8QCrosjA6ayVWW0tqY0iGgDS4qiJAyk
      ioI4y7Isy5E4IBzIWAGSo7GspjKvqlIbay7xDAbKrDTSyDkqpaIoCcOYXa51NLcBBEQyVpfGGAE2
      CaM4CCvAsiyPeX2eMJ6lMpRSCEQpw3o3CYwlbZwDgUMG3bELq3VVFLosg2bPtgYXxDRN1+v1er2W
      Qa3YlFIMIjIMrLX5Kdu/bvevW621IAiCUAKWKJBAEAgCtETamLLSRWnKCoWy1pqy4mjr+gCtlAxA
      fNbxeMheX3ZKhmEY7na75+fX3W5f5JUMojSMtSmh2dMTgi+KQa1tWeqy1FFkq8qUZX0o3c0lV8H7
      hH7EziyKwzBElHywqVfy/DTljMqVyCLfW2UFCgBBACilBcjL8phlQZQwHBe64m1nKWVRldv9rtQV
      CEQp+L8oib/97bdQBUEQ8Plenk1/o4Vv92FlNp/Pt9vtbr8955lA6Tbty7KsqsIpvCiKILXQcP+8
      KMqqips40efn5/1+r5RaLpePj49MhNm2c/TFfeD+Gm0BoMwrXVkZQaSCIIqISMogjqIoDK0xlsw5
      z/Jzwbsp3759A7JCCD4lt5glSZKUVZ4XZ95Lj4VQQSCVYAvDBQc7R7nzIw2t/9bUdKnxzQf9NARY
      Ex+cnt5BHYbuoB98drRF/rA0FVjsuyGZXJ7rPrrDfIjokHqkX/2RkdRupvuz+4Y2aoJlHf926cpv
      XjfX217guXf0MAgCdnoEQQQAVWVc3AuzbOZZ7uBMgJDEM96lLIqCtGE/iTsaU8eJe/SKiFzEiNv3
      dxd98IMutoSdlXzRh3PFML06nU7UJFNVvGfFAeAMdtxUpdRms7m/v0/nM+6Fu3zRAHHcBR8t4VCZ
      MAzZG+sOnTLdzrIsiqLD4ZBAorUusvPhcOAdV9775fh0gYqPz/z8+VMIsVqtOJgnyzIAWM7nSZJU
      uuA4FibvrAtPp5MbWD6VzvEzbuLY0b9cLjlQnUdAa23LygUUYQMKH0w+WNjGbiUiIMJmr+V8Pv/8
      +dMYuru7m81meZ6zQyNKYo7iYMXpzjpGUXR3dxcFISISGbZ4rLVKBbyTYS+n5CGKotlstlqtmHHb
      +lSw5a3F3e5VCPHw8MA03FDlJAEaTf/6+soxSFVV3d/fbzYbjnx354396vzEcF9Hr8exUkppVVmT
      5yV7+Zi+cPCSMWY+n8/ncyXF6XTKsiPLIQ8R+9mNMV8evy2XS0HEa4FvpHEapTc2sWs6jNDzN9le
      LRfKu8n4W5F94iMfbNVQ6jXFoBfuJxTV/fIdo3GzFmqWnluPinUO+ru3lkg3IFuUptK8TsqyVErl
      eQQglJJE2PgQOLxJ8hEYdnQwj5aB2qzvLGKen/f7fUWFlFLJMAqTmiNXVldWl4YMSCGUlGCpKvKy
      1EhQlGfG07zIkvmMnSSIyJcN8E4Xc3DTpDiO4zAylebQ7KoouMPn85n1QSgVWrSVRYvsWXEnNaBh
      xPw5EKiFZAc0H3thLcLrjT8waVJKHQ4Hjg5MZzErpKqqVqsVNQdbknh2t7ln9ygP1NPTk4uOYO3C
      Nkqel9kpB0Bd1aeleDtxt9txfr5e5nQ6JfHMaCKLfP3e+XxmiGSfFaNJEtQRF1VVka7CMFSB+GAY
      VsucvPzbBFZGUSSE2m73fCBhvV7v9/sfP378+eefKoiMMXmR3d/fMwNlwBICpEQAi3i5EJ/hjOXV
      hSGyxk2S5P7+nh3o+/2O91Gstdn5/PP5yWrjDlidz+en15fjOSOBKgrzqjyes3/+859sPP3v//pf
      fGqJ3UHCO2TbvwIt6bLavry+bF+VUgSw2dxLKQ+Hw3a75cPDbBXFSfTb374JqVarFQKdTqfjcc+O
      LyllUZxPp8PLy9PxeFRKCQkzmFVlycqeGU8cx0K423XaRGzIWdGao0/Hkf+ENO6QmVjCzWffXXhL
      NwxNQct+GilhYlKIiILIAKDlm5gYu9nH51zVvDYY06WURMiIBs2S01qzc1wI0RAcAZbyPA+TmAOt
      wFgGncPhgIIAQFe2LIrmKH8Yx6ExdayxO77P2LRZrtLFfBYnp/ycn7LjOTsfT3lVBkIuZ3MOS+ew
      mUqVVVW9vLwURaGbo5VsPjMx5wUrJfIhPaaHjJjOkU1Uq7kgrG8OKYqCe8fRI9jEsfG9HO4WwCgO
      2KrgkBhe27Y+1hjO53OtNZP9w+EghODTj7Y5sM4BjmzoOMc6hwwxo+cgHL6QMk3rC/84rOhwOBwO
      BwDY7XZxHJuyCoJAxokQoLXO88yUVZqmqYzZRfsmQemFEl/sGM2hCdlerVbPz8+sgXhwDofT8Zhp
      c2BjbrPZOJBin5Kzjdz3rIdaH5yMLZdLDt7P8zxNUxbRQCmrzflc7HY7rS2AzfPy58+ffL40ihKt
      9Xa7/+OPP8pSbzarLMtfXl7CMAawYRjPZgn7Z1oay4cPZtZWm32WPf38eTqdEZHj/fM8Z9uIA1dY
      eaezmTUmCGSScMxVfQEne+HY4cM7+bwlezqd5vP5arXioxXOCmwNeO9c+F/ehLz/KKAfaYyPvFNQ
      +GYVve6aZqLfV/ab05CA+clenDft1DKh+F9FYIAIEIEsvyuRwBCYqjhXxbkozkQUh4GUMoqSOI6j
      JJRKGF1VVdH4JXjzkPUCKIRZEqVxaAwVlTG2qjQmYbRezpWA0+mEYI+HnZIIlsIwRGvA6CQM4igM
      gzAHmySJ1hqRToc9AARKLeez9XIRRKFEUAgcqGC1USiSWcq4yVxGKaUAaT7fhmGe54eqYrhkBh2G
      oQylRQsSQEIUBUqJ+uST0YgoEchoJBQoyFAgVRLFm/XS6DLPc10V9RGVxYyIwkAi2DCQjw93Rpcv
      Ly9lWRZnw7cFLGbzNE6iIMyybJakVVWR1Qh2PktWy3mRZ1prXRXxer1cLKqyrMoyO51CrYNQzpJI
      SpnEYZUXoVSRCjbLla3KrCrz0xEAwiAIRBAEksCghDiNlqt5WeXb7faUHRSK7ChmyTyOosViFgWS
      LJiqyM5ZnITgXdfF//PlaMpScWSciCTyyxJrCokA2sJqtTmfCyLabvfnc1GWL1VVHU8ZCqmw3ikh
      i1YTWEQSSkgZxUgiCBURKQFVVQlEsiRloMlYXaZxGEgkUykEIBspKYE2y9Vpdci/ZAAA1iRhJAEf
      Ng/P9mX/ui+yEoDO57w4F2k6e3x8WM4Wz89P+9dddsiCIDwfz7tofzwehZBSivl8AXAfBJG14EwE
      3uKF5v5rodBUdrZI431UVPn373+EYayC4HA46CJfpMl6MY8DFUoRJKkBEgLIaoUooyAO6xc3IqJS
      YZLMFrPleZnvt7s8O78qZa09HA5pEj/cbxbzNIoiAGDV65spLaTuTlkvjk/E7g8abR/XEO4NAcYY
      KQNrbSCVNrXZZEm7nOwJE/U0oW+m1O6yxt+NKIkIbD0IztldZ6ubbAGALAKAYIcFXhxuRMRvCnDw
      aus3fFrR3IoJVyqBiOp3EbhHEBG8g1pY/ysRkUsHPrYJ9bU8ZLlGUd+K6iX02o+IQIQk+O0K2Lz7
      wSLWvu/lchmG4WK1YhwUQgRBFAQBSrDWlnlljAEQ7BqOokAIoQIRB2qxmFkLxpiiqM5FQSiCOJon
      qRBiuVwej0dT1T5rIYQgYKuZ9x6DIAhsAAAcJcaU2W1ncWxDHEZ8Ux1vY/JTbLNzhkBKKeVvv/3G
      13JBc0mWUmq1WjW+dcmhysx8fc+DWx38P76FY7FYuPtPOFyamtiSNE3ZHb9er9nXwbSLY9c4vIGl
      gU/uSCkfHx/5ohghxHK5Xi6X9cgYI6UM4/pCR+4703YiWq/Xd3d3Skg+L8ruVykxUEop9fe//30+
      n+/3e9IG61Gdzecpc00Oh3d88O1LrJ16ubkTfe7jYrF4eDhnWXbYH0+nEwq5XC7rMwTnfJbMoLko
      kcPteZQEAId6u2J5zDnuiM0+/pJ3L3/77TfeCFksFkKI1WothAyCkG9qtNby1Nzf33MY6/l8ns/n
      d3f3LF18yyaXFgRhWVbOCHAYWm8nNfXGcfzw8ICISZLsdrs8L6uqWi6XDw8Py+Xy/v6eg8SFEEqA
      JW29AAO/U4vFAv/2tyAIXl5e+AogAPjb3/7GxxH4gklXPZtrjoh1+fi44+U/iob7aUQBuO9dVBjb
      NK0XJTMWI4EhEgBu5sDaekSaMURXrDe//F6S1ojZJrMFEESGSAnBDfXrZqi1ZLkcQUAC0RJ/rucC
      QCBaal5yRVS/GcvfM0UgSxdR4/YIJLBI/ReZ9I9YXhaX571tPd54tADu4L5bqMaYqjL1cZU6eCAQ
      QhAYazkoTRBRVZqyLFUYsOkthDCVdv4Z1WxyMgQEQRBIBQKr5rS9i7pjBHQOTfaPu9a6+wMuI0NE
      VF8Xw9Ux4vM6tE0fuQpoOujKb5mr7HfSdbLNsnfvIqjfnsE+KN6blU1yPzmHLFN79mJzL/gcE18L
      7GsL0Vxs8vLy8uPp58vLS33QX8g6+LMs5/P5t//629evX9keL4pCFyUR8WXaoVRhGIaRwjpu7xKU
      LfpuWKU+IOiagT4xBwACg4gIsoMm9S1pRVFkWc43YfEsWGvPx0YtGp4AACAASURBVBMRzefz3377
      TeuSvViL5QwRBSDfbs+ShlLxjPM1XkEQJPHM+dABgE/5ckBqHMdSBsZcTg9prTnUh5WZlJKDbvf7
      vfCuZqPmHRGsM7xIU+Kwkkt/mzcc8Y4OewK55DiO3cE0bhvBVXS/P4bUnKE9nU7H45GvrBFCLGZz
      5geOkkMf5PkMdGim6hXuYQReuymGYHQKxe7N8A6d4erylnAdtQwA7H9jsiWE4gte+9vDCGmR3yBI
      CGCpfjOA20ZuSDiQg07rR5M4Ld4ociIiLk2AVzIA1DsrRI2D8RLUQmSJhBcpIAgarKdGkMRF8EgQ
      Yh3qzddj19rLIKLAEABYgbWWoU84lFJJPMOiKt3Pfta6+wBwNdDupYWXS1d4uKTiU5fMayQiGk3G
      GL51q+6DvSgM5b2rqAZlQCLS1oC4vLLANYmFu7eRPmFhcoeI7ChnLGbmXp8Hud5QIrpSidCBM1cv
      7/c6om2bk9bNT7VQMnD7i/BK03h0w7VZNDHpTmWK5rAiEf38+fNff/z+559/sjZSQp7P58poKeXX
      r1//67/+a/Nw7+ZFsjFoyVqL/BakeqJsczKgHqsumndjE4dWjg/oBEYIwWju95dt22boLv1VKIhM
      npdVVUgZLJdzHj1LWinFF2OxFHEgqVD1ZYqM1wCgZGibt8pBc32QbUL+hVAuzspNk2MkRMTK1bXH
      eucDeLfGEQ5GcyklNMPL3IW3MTgD14V8OOt60mvZlu1xc3Jlr08hcHskCndOwgGZqa8gbY8/XKnP
      OvUCeu889n7fWlZDqfXr+3Dcf7aF5tB4SLxRqiM1Ca0ASbzPBwZBAlqEOkoV2CeGyIyY+GWKtbUn
      EdF/i4iQbRRGRAMkCIiI9/aaNX/BcVcW1EvYgEVuFQgCixYMkiAyiBKRAASzfMTL+2/BUyY1LhPw
      O5ObqQchFMc0O3PEn25s9pAcmqvuZPijLJicNl4ba20oVY3MAAYZIHhvil/BI7z1jChIQG1TsOuR
      SYuDKmC6ChfIC64va3V5jDEI9dFq1yUeVtda2SxOAGCvi4s4hIv/kSxZcm9TQ2BWyhGf1An8BGv5
      BwEAyAacscYopRCJXy8oUKCoV28gappPvBvRRJgSb6tCPYzsuWOPG1+VI1Bwm3Vzkot7GgRBqAIk
      OB2Ph92eFVUYhhzyGEWRQmG5TzwmAEgGAVAgACGBAMQGyv2RbyUmMA7Th6C8NTVAgmz9QmV/XmpW
      KyQigrHNO50EWQuAgVLGBABCIBFYpSRR4Gm42kfNFIaTu4yBwKAAAsM35wmJLJNNLwgEyEaheoGG
      LIMUBlJJdIMgVf0mUj6vezzuX19fORyIJ4grZbNJKbVYLO7u7tbrtTP43FA4EDemMqaWQ7Se4ehh
      PTfM335vZPjyLj1HC6R3Qy/AFY67OfVnZwhb/Qehw8F7Z/xNmD4ljcsVADRvUrXceyFEUeqq0u5m
      VhIoQVq0DiX5X8cvJSBIwYzYWmusJf6erXAfzYUggYKsAQJjDdTLkpmlGy72CZPwWCMCv9CLm4oW
      SZAESYIECQNGkOC4EiEBms+A1pXMTL/xr2AQSrBEhqy1ZHUj8JNG0n1Q3eXtq0oHeeixyCYXIlz5
      74gIwI/SrS36tsQ0QwAOmslBwOUn4V0w1Nt011w37uSJu1tmjj437OzSnpZwu+63CsGGLLv8bIm7
      Bx1e2+YFpK1B7w4yf8m6x6E/U0IDdeSGi5nhC7/Yn8Bfsvfg7u7OHRatPUWex5lTPc5CcGiQPzLd
      vvemkeXXCy5OodrmUKVstDWBsda4IcXGeHJqwDXY/8C/+q4wNz5wrd0RsdL1MVrXWWhItF+LK5ld
      QI4C8+EGPsMJzc6nmwvWoy7iqGreHt4t2cGxq6g1jE44ocELzmC8dx5dVNR1ROnV2pzgP+lW7bKN
      T+6IePwaHL8k2dzJkZfFj+9PT09Pu92uNJp3KJkGuY449t1qG3kX/AHUr1kXiIYpWlMOkLFAZOp3
      NjrhqS1mqj26IK5xrH6jek2roSOKnFNcQ7IEJDBAgn0vpnGeW6uVEKzO06Te6VksFnGUuhpvjrnq
      Vt8s0YuLShCQtUAERIaYg0tEZuZABGStkALAct9cx2oyxVusvPtMQPXaJvJ2mRt8QbJXq7pBPWg1
      7zJnVNsqvj7wH3fg1VRxMYTdKPBaJSLEmk+7X63lt/0Kr5GXGWpQ3hBPuUKyV+PZaq0/OHVpaNlZ
      Bjy+RMg2DAprLQIFQi7SmXiAvCr5PKoQQkWhUiqNEySw2iAi7/ULIZiGkqN7BMSRJ5YQgSyBaKvG
      ESnpXYFuHFrZ3KgiYsDn1K2GWn8iWbKVVULW8bDePYVOATSwJRr2oMjUWpMlpl42tQblSIPGDQoo
      UAQRx8xoa6/GvPFjA3mmDwCooLZarCUViDgJ60vPPXeZr/zYM+67bvgnidAcWOX9z5pNWz/UgQAB
      gQABZEPJ6fLmdDLG8JuJbg74dDAdwtCbU/+5aRzKkfhVe1f5iUhbw+fO/vn7v15eXgAAUJIQ7Fu5
      DItg8b4oOTdrzB7qOZJKSikBDRDvVaK1ll/thVB/A/Uu2sVvA5dNGoAafy/dIYGIlz1P50bnH1sL
      vy7Hsk6qZbE57ykAkQwiLucLsjifLRdpG5m7n/0vlaPb/nDTxYHR9ko3H2rXQZOH2Oz1aSyDuGMf
      3Gd/YZDnfXZVu90/36EJHpe/EgJEa6m76qh191ODFNZaxMv3jlhdEW1ExMsmYRN+blt7rY7NQQud
      qWc31XErt2idtqNGOFx76o43z3JgZRiGfKSWvQoGyFrLxNxeX+XhVGUNN8a2SK6PZR9J3fXpAwRf
      ium8w9TwcWe9eV2+DCl0ZI8DE/zyyVP2bgabpWtdRMq1KF5kgBoT00maK1YpdXd3t17dcWUtfcwy
      ycFRiMi2TtNg5P6y28Qf6pYWdx3hcxu9Kt+fI9HcfNea4m6ZN2enO0dwjQX/rkQ0+CYgXiznsuDD
      HCqIgri+dEjyjDQuU6Gu1x25F+henFTODyyAwJLgit0PEiVi7af2fGKyETBgKKer+eJHGRzYh0M+
      QbmGJmTPKlMPAEA0ZPkCcAmoyVZFbrVGgiw/u92d6Un5KNkC9NaHJhsPH+fnL4kpYDc/AKB17KnO
      cTVYzYpy5bvPvdalnzzsrr9AdMIK9Y6w4A8gJRpTcUl+ga4QV2+r/Y2LDdzmjPPrdVvCHe5rpzfC
      yHsd5BreXfMMTa4W5w2UsrlMBpAEgiWFtYMFRWOmENUSQ3XdiGiBUApDFmUdWgPXU+w178p+xz4X
      QWsA/e9d/kbbVd6DAM4vT4SyXm5CsVA1lpvAhiuA9d4e0Kq3BXx+Rxy4+14Ll98FF7mGuQJ9x0gd
      Qjx8zYerFxsnZKslfiPRY/E1Roire1cubbPkP+s4TRed/RXhZxjC8VbjoW9NDZXffWS8PW9Ktag6
      s93zkVoDuqpP3j08fn18fIzSNEkSQ/UrHoE3FdzbzJsHuYmICPYSZcCuEiGEkBJqx1pJRJydibMU
      gTEmENI/tuYUP78pkzkKGwcoFKKor2u1ZK0VgOyC495Za/ndxYWumLkqpYgsh+pSc1ZcSDBldToc
      D9udQCRCKQNC2SzDqzXrSIy9filV/3tBf0XqZQG9YvqRNFTgECR1aVFv/k9J42V+fCh6l1P95a2F
      9taqXWt/KbMjImoZttOeel91vfLZKvlNHfe14ztqHK9oCOVvNu9NUzauyz8rtTria0FwoUTJ7Nu3
      b8l8HkVRUZV8W721VjUXNDlkrJ/l6IlKc8ivUgoEVlWVN/d3AgACIWIYKkRUUiqlgESe57aqX4MV
      RZF7Da9Dc0Tkl+QAQKWJo6vdba9kLLeNGiuQ0bxsDkBJKYmslFJz5AiBUkoqNGX1+vxirdVF6e8S
      8f+mDGMLzR1HvnrcPwg7RFaEl8eiQKxPVfkP90je5ZwUAADBm9chNjzO+d3G5cxvw3V7fLpKHSHG
      24g4Wt1wvZd0tZKHbjOkC38kMC2HWE/2Ca1ubdpe/zXI+Bx5d9/42z1N/ktrm12jtlI39UkKX+Aa
      +wyAqH+4RjCu9/uh1IOn17bZdWZoXFntXwdr7cPcSxG8VAfmqEWEh8zTrgLoYu7QcP1SZTyxot5G
      OnOKu6hUyIeq4llKRGVZcOSQ1rooS88wEoyPbgNDIElAGUZhGBJCWZa6qoqi4GMpEkUQBHE0i6Io
      CSOlVH4uwdhjURpjyNpAqfrsYhQBgBBARIYsv6Q3K3IhQ/aFzmazQEirjakqAXA+nyutNbcfgYg4
      qhgEGDLWWtRoTcVUPQ7CRTqjlMjY7XZ7qjQB2D7LsJcTu9S+Q7ErB5OXh5h2nWo7tQz2t+Z8NxG7
      ydabJfS+4idV+sE0hc6Pz2O9+Dt+3ukN6P2+C14jj0hEM9C2unH/h6dPEdGb89LrGRuZ0E/H8bcK
      Tyv1mkHO3QTuGKOl3WH/j3/84+npKcvO2hprLV/bZq1lL7fbK0KCJArW6/Xf//73R/FYGv3Hn3/8
      /vvv+/3ekNFaB1Itl8v/9//5vx8fH+MgtNaeTqc//vjjv//7v7MsU1J++VK/+a8JVyMAMMZst9t/
      /vOfP1+eLeG3b7/9X3//33zgqzjnL09P379/f319PZxOWmtCEEJwrCSIOmapdgeRYTXw9eGRvn5N
      opia5HabumM7Ms5qHIJ5F/7KJ95TjsPx+oNoHOQjctxq001garkgh1oLt9mo4+A9+VrUBvo8p4Pt
      ZNbc8Zt/csIWWxzsLUdT+PtLrZaRB5UjHHzoS07Cy3MLtDhk/7pkrH/oPjtcGtc51PE3jj95DvRJ
      pfXsi7ytxk4aurN7CqNCbxeh5T0f87z9xyTf6HXj4EANGpLOHmdEtKTLPNtvX56efxwPGd+FLIQg
      QK01Uh32ik3kfhoGptJ3681msynO59fn+r0lZVkYY8JAVmX+sF4tZ3OTJIFMrbVZlj0/Px8OhziK
      wjDcbl+EAH5zAI/eOT+/vr5+//79z58/hAxkoObzWZomNknPxfl4Pm0Pu+9PP7bbbVEUfCKJBGpr
      DNkgCIgMR2qRtXEQLpfzEHExSwMEsBrq4/RgPSziHcGbgP5ZfvN+Yo7oboDpSR9U5nUJH3l+oEzw
      1s9/mvRPSVO8OkOo3WvOv6nGVhofwNpR1mdRvq/AX52GnB6/NL21uvftwXxc5j+yoonqXVDXBgfo
      dAmIAjLWalPmBb8cRgRKCCkDBcDnyeurXvlMoi5LMkaXJQeKWGurvCjOuXsTWaAEEb28vMRxrATe
      3dV7nu4dCT9//kySiO+Uvbu7S5IEAKy1fCghy7JKWxUGSRSHYag3d2iJL3/lt1ABouCzalIgSWkt
      IlmLfNUfR0gW57woCug7pEIAVJ/Mu2Hg8iPKo9W9ib93AEcAYBtnN8++6MnPLEwA2Lfzlivv60Ae
      8j68070zZjfYPsLAP7WeoqFx68vcW6/H6PuaZMG7XqL1VI+fmi68tV4JoqebLRLXbfPb/C3UtsOo
      iSuwV/sp9R9X2zAuOq0JGaJmF6RXMtsNa43/Ow0jUTdp0uMczNrRedjXnr4yh40pXk5je55Dj/ZK
      2lDm3jI/1wf4pmQ7kkzeQUXnduDYYiEEHzOez+d3d3cPX78k8UwGyloyxghU1lrLbzMHOJ/Px+0r
      8cv8+CgQ4mIxXyzmNTRbXZb/H3Xv1SRJkpwJqpqZc/egSYt0YzAQLPZlH05O5P7/450At7dgCwww
      PV08M4NHODWm96AenpGsqrp7ZuXORqQnKtLDibmZ6qefMt3W1W6zTgLFDSnn83nbtlLK9Wa52a3b
      P9S73e7HH39kP+rQz4TvzXqz3Cy7rinL/ds3b2bjibWayI1G+XQ6Hk8nUZoQEQoBAh2QlBKcF0hE
      pKtmv983VR0qJTg20N+nh7oXpN/38ubfHISA0FdD/46DPQCv778w+fDLhn9Zdf3W0WvTXwVPvnM7
      8WF9tdbv2N6DcfSXuCtxIpoHDdHnyBzfOh194b1cP6oXZKHfKyEAkA7IIxAQDnGM+JgJ8X2QiACA
      /jDOqn5wU9+/3h6vhCfP+/jxqU9b6j9zZbwH+qnXvkdHLmd1D4+ACFxJiICwj3boU84e+OGfGV+n
      0Z/94TcVwPco71+nKr5nPOvl4w8cS050jKVgvuW4xrh85ng0vbq8skRa60rX3oFHCwBSyqIo0jjW
      Wt9Yw+m+p7cvBHZGR0nsHHVdt97unHN5ms6tR+GH1jdKhmHo+C2XdVU1tVCSy5pyq684jj2CsXa/
      3ydRfDafu/GYHbFJkmRFfvnqOo7jummstR7IAZFHFUEaJ1EU6a6LF3erxZI5nGEMtNJ9ksFXI2WH
      16GeLujTpenBARzjDbD/sRh+go/J0tNKwcBLuQfpj1/eU6cHXwBPmRkc/tSfub8cr33e2CeJ+Mdz
      nZ78EUvuT/5Lp8c8uCtxf8JvyNjjRj29sV8Gc56g8oc/5zm5v7dBYtKT7oVEdN9HEMEDcFIXDicC
      AC76TPcv7pG5MARGwXNC8WU16D1yHD5HqAjyRCgcJyOAl2zXkeAoXSEEEKAnoL4IBgB4cl4hCkRr
      iRxI71E4lEBCkgckrrwBnC3pSYAQ4IE8f0/fpaTvjxmUCoDvV/i33hshNxCgkAAAjAAPIAkEgLeA
      iCS8J+8EENdPdSAIpVCE3pIlIiQpCNGRIACJVnoCFwJJQIfeOpJSntzk6XJ98BSPXv1pBMiDG35I
      oz81DR/tlOPB9//tU99PRMZXRPmz9/AN0U+cZ3CsyN3/hk1PCeCt9c565wnouFOEtI6CICqKUZLn
      u+1htz1st1trGX/7osjSNM2KIuy6OI617gCIL+G9t9YeqjLpukNVeuu8t6vNOgiCpuuklNa6fVWV
      TSOCIBuNxmrKRdZQyU83X15LAVIoFGmaTifzutV42O/Lg3e+qhqOjiePnhBQ5tloPJoaY4xx+/2h
      M9o55x1FcSjnaj4/d5FtyioMS0foCT31zYbZFpF9Rnpf5RdoqL011OtF/uxJcMLhb+LNv+ly6StU
      Hsd3qnSEZ7xzwxm+i7547iZP7+q0IuW3Dv6u8euYyl80BjneX5G+K/rw+zzD3zuefcxexh0PYP1D
      9LgBKbKCIOG5bA4n0SECgAWLnrgGAaFX4IG88wTgkWs9ICChRwLqy9CJo3oSwBqxz9z/X8lnD0xQ
      n5hORM7RMboXPSGCQAGeUHgJBCiIvCAvQJBnPg8BgYg8ke9L0v2lDMffMr5z5/4W3hw8MRDjfzBt
      4Bh4nJySELjudBAEIIV3UJb1YrH69OlT13Xc3PHsbMaEiRQAEoUQIAUAOOc6a+qq3R+q27s7ESj0
      BEim05Ni5BxprfeHervZ13UdBMF0Op1MJmEceu8362XTNLvdTko5zovRaGSNt+SNc9pY3bVwBEks
      izlh2Biz3+9vb29vb2/3h7LrOkQcjUbgYTKZBlKC6Dt6DxP4eOaJddt3yZZfL82fFV5PSVo8jTf/
      2j3R009PLyEeVEH4nnt72vMaTjbMg2k6xfi/WjQ/XdDfNGZ/0bW+Xy7jE0V1eg8vXfQlkoJ/y3nD
      4lSRv3w/x6YwgP1nZt4cAglUXDrSAzjhvbdCIZFD4bkypRQohTBEREBIHggQBF/siBkRvADPfYEA
      e6Uino26eu758KFN9j1vAQkECDwhg8SRRCIhHHkiAYL7MXnpOQfCeSJ0VuJQ7AgAJQiBIFSvoJ0F
      th8H1vyl9/BbZf2zIObkir/1/E8R3m8S8c9cQJDvk2+5c0XXNYfDrq5rlvKD3UngjOn/eRr5wzX3
      jXHgHSIqgdyerOu6Lzd3VduWdaWtkeTrthGldDtb13Vdl1rrJElms1kQR6NAIWJnjXFOSHnY74be
      wgNbgsfiJVzKraoq7gCMiFpzDqp4OkWn4uKXSqFvS/OXzni6AX772/oVoPv7x7OEIyISPXCdwxNR
      /isW4tPjHz3F9zzUVw74LVN9XOV/gXFkh48dVpjXBulhqMFByPSPE/1TCEtD0SwvCQR4QV4QCiZP
      CNAToTZCAAgH5EBIEH29IurtTHFqyoEAtH/REHWkvgjeI3dlvwmlQESPnkgAOQEIUgC5wAvhOFeO
      AMELMEievGT4DuCZtDwpTfH/6zHso+9drv5rO+4RDznQSsOf5EmfW67V408KedJJGP7Ql0YIYb0P
      ApEm6eXF+WQ88YSfPn3yiIAyz3NjzG63W6/Xxuimaby3Qoju4oILbXIjMxKIkms6wmmL8EGq0LEQ
      4zAePQv/81Ssw3GP/4qd/jVp3u+YJ1/+oss8xW6nERpPsfzXj38gFo8cwiNZ/I37eVAU5WsVd/+M
      zMmjGfsejPzS+CbSf3z8d78rXomnLlN64qvgOfcAdH+8APACYHB3E/YhIr3nk44+D3xkdRFKIRAJ
      PWgKnFNGh+QleSQHILxAgdKGRBiYvniLlIBIKDiwCgEAHHA/W4EE4siDf90bdBz93cLX3sLprPBH
      BL5nfPCdP/I8ROTx3oS02ijAwAF4AoFWgkfQYF0QOGfBSEkAUiCQ4Golx/t9cg9fG79kV/ojG/vs
      D5+pbfc9Vx8+/xkpx0Eg4iM/83GA8+AG+eiJoxedZZAOR5hMAgf5yEVxufUgEEgp8zx/9ep1kWVd
      3dze3qJScZIFKmzqbr1el2VpjDbGKCWyLBt6WqVpGqkgy7KrK0kIAqGua+5JCeg9WYlI4Fi19MNb
      T+5UD90/yInn48lglvylNyJO/6R+Bfz8fmj5LOdAL//pKxfqn/mFY07x9dfvAR4L9Oc9kM/K9KdS
      +BFGeHb8GbXC6Tl/nUoYpuml9/6sbfHo+CeXexxGckTonHjmkMBj3/VDogTnEUmAV0DKe992vjzA
      cuWqsmtr4Z1HUEEQplmYpsFsLNNIxZGQiotSg0fne/RKCA5IeocIeORAXnrwlx7wV70gQeTZA++Q
      t9R9xAUACAnCC+lcLEXUubjz0pGX6CTZAKJIVM5ZFFISOunJMUA/Tua3pfOzj/OdaOZ7TvX946V9
      9z2D8xLRPz4DIvqXKYHhmJ79855rqiAiF2wZKqu4Y/lrhuRRFBVFMR6PtbdhGHqEPE+vrq5ev3kj
      hVjTyhJVu0PYdFzFPgzDyWQiBBJREEgAaJrmw4cP+/3++vr68ux8NBrFSeaBJIqyLMfjcRiGVrdw
      tAlO55YdRUff8ol5gY9L+T+VS985FHzH0oET4fWSHn7JqXj6/VOUPRx+byjBSUYl4256/Kv7FtnD
      MQ9P8vTO4fl1f4LN/eAmhqHi8DeF5ncu5a+8mF+6hU4rN/L8v4Tcnvo/e7OOPx/P8ORW8WnI89GO
      GeJAeg6dTqvXUp996nuqBfF0JnuiWQReCiJ0RugWDwe33fvFChYb/f4D7naurZDISRRRmGZjGBXy
      d9duPpIX03g00kluVUSgPArorQR3DFYi3iiEREgP/SU97XM6CQAgEf0LuvzpXJ586uU4kOgDsLjh
      GAkERHCOPBKgQO+17xq/2zbrvVu3oiMP5BRhHtIkCSaZyDMRFUZ6D0gCCT14knAfA/aLxndv/gfl
      nL4CUP6/MJ4CWPLsPO65ae6+G0WREGKoeigkCHkE5sffSiljqUajUVHsa91aa1UUTibT8XiqVNi1
      ddu2WuvD4UAInHA/Go+LokizREpJztZ1XVXVerPRuo2iIBCY5AWBAE/caSDNYiFEXSJAX+yewHG/
      of5uUZAA+bB+JyKiFB6fEY8vvIsBj+MjFPUL483Z8HkBo30TXz/9/qk0P8aK4ePgv+Ptf+XGvnnz
      T9buCzd8wjC8NK1PVeDXZf3Tvz77qr6uHb9y/q/c2Fd++Ohg//JpXzoJ9YWkqecZjgRI35eFX1lP
      qXsAYQkSwth4Wm/bn3+uf35vPn32t0vcHagqvbcYCgvoSbYypiQOv3xSr8/S370O3lzj2ZnI50aF
      HgWAEASCG3oBDIFQX8HmT98Xv9pHc/IdQ0DfRvgeowhPx76AXhFJ40RVB/tt+8d/dx8/7z/vROOs
      81ZAOE3Dq1n2u7fyYg4XwseJx4BQIEh6oKxffI+/3dp7BIC+ItN/HXPyPYvw0Z08/ZLomdS3gQcf
      rsKSdz6fd13HBQ4nk0mapkoprfXpCbBvS0veOudcgIiIWuv1en3Y7Tfr5X6/L8vSkU+SJE1jDoyZ
      ziZRFJX7nRBiu92uVqvDXgohTNulxYg8Gme5E++geLz3bA0EQZAkSZ7n42KEiFEUIQruARkEgfiO
      KXqx9PtzQ51OX4//T7oUwsl77acYJd+1EEId+y0do9zvperwWwf3VBEclcHwDScIiFNvJAJy3V6U
      gH3NYnYgSClxgPnecz/vo+EC3js+x6PC6DTkJXIzsGPUqlLKu5NmBdA7yrnpGgwlsE96GJ2u7Gch
      P3/PiWdw3x/jgQVzegYhhPUcJHI8VV80uTchh/6lJ9jEPjDTTtTYYy2L91cc1PCj+X80WMPRtwDa
      6SsWBCiQ+udVhOC4oQoehZ33iEQSHRAiN9GC5FBW//FT/d//YfHP/2xu7hIEpVQ6H0GeQxSRsXZv
      dNV1iy18/CwmUfpXV+f/+38L//Zv1euI8tjIEFA4cKkMvLHOWSGVJU+AgqMgQQ4vop9AoNNeekII
      e9JuglsDHmvZ46N2bnyA6JvT8gFGKOm9F0oSgUQBjvsIgkQKnFNVHZft7T/8P92//J+Hf/8DHJzv
      yDoQYQChUvNR8Te/u/o//jeVJRRIUIHxSB7DILKmQ0FEfYr54N87fXHc/3p4oXQSHcHj1NuGx3EK
      xU6/cX2T28fZvPBEAjw7ntrrDxbht3HJg5MLegBRh3eBx6720G8rAkDuHDI/mwoJWZ4w38K9W6+u
      roIg4IBFFEKgdNZ3pl2tVneLm8Xyrqpbsd+Xu/1N8Fmi6LrOdLptW+Os957ILZckhIiT6NXrawBw
      zt3d3XH9lrZpqqr5mH7mCuyIKBUWRYH0u8lkwq+GnzcQjKvnegAAIABJREFUcjaeIGJepOWh1lp7
      gNFodHVxmUQxAHEbZCaIENEjcA4dyD6qEgAAPSDCy/XUEKUQChFfxOZPq+/3A8Twp9Nqws++sEEw
      nUr5p2/35ELCe+D2eEQeiLvP3S8+1n+n3bZOpRUAPfIOwxOUcdqTCAAHQS+l8ic9mOjY60A+UmYn
      W4u/9881RTrdaacPOAiX4YlO+2L7k346dNIAYaDVWF6cbstn3+7p/ZyeE0723qPvhxkU4htggBhx
      P7yWwOOtEnnyJBC5Sy+glALAe3DCO4UYAMhD2f3xT5v/8Y+r//FP+vZLKlVxNpv89Y/RqzMxL1Sa
      OuPbdeUWrf6y2L97p3f7wx9+QqSRgyLIsmiCAXQI1pIzRiAqFCilA4FCAHokZAeXPzYI9N7jSeQA
      HKUDHW1wf2xPOswtyxE6dqce1sN9ieqTSXDORTJA7yy5kCjtNK623R/f6X/9Q/eHP9F6HassnU0h
      iDttqvJg71at91WWZXkeyAizCKRyoKz2UnGnPeDrPnqhp91L+v3vH/e5pSM25H8O5xn+etp06bR9
      0tfe+l9+4JPsr9MbGnYQOxSttU3TlGUZxzEipmkKx83F/DgRlWW53+8Ph4Mxhv2ibdseDoemrKw2
      zlgncLfbISJH1HjrqG+z7K2BsizzIuu6jqVzVVX7/b6u67ZtjTHb7baqKgBgaR5GylrbXl2f6mBj
      jNY6DMMgCLIsi8KExWcURXEcE1HXtU3TGGNOJS0eoxsR8ZdWqnhRmvei7bjNGbkAAIj7VqJuEJrD
      rZyIrd70OIJrAEAppJSIjKUHcUNDvxUhgOC+EzEiHpv3+eOyu7fg++13rFHJmjkIhOjjH/rTwwmc
      p2OicI/RgNu5ojHOezNsY27tzVsbH3okni76R9+cCmt4TozCibwGADiJbRo6zDHpNkifAZiwDn32
      Bp6q0v4d8UY9MuaPpPBjBfCcB+Lr2KpXPCgByJMlICQBvndAEXGesxBECCJ2Xmx29P5T+6//U//n
      T7Avk9E4efMm+Ou38F//i3t94UeJj6S0pA6tX5fBx4UKvP7wzuw3u58/RPl4ND6Ls5lxaLPUC3Ce
      EAGEACEtAQnw2kkkRA+AHElGJ/DTsQ0B0nsQQhJ57n97FNwBHnvN4LGL2/Cy+HPbthIQJBACBOy3
      EIKEt1YgebDK2mBzcD9/av/hH/1/vKNDm03O4vPr7Ooas5EsK//5pl2u3eKw++efsBhPonH4KlVZ
      YmXQAEl0lhwiHZfxoNS5xSBPuBt6V/LCuN8vR8w0kMjDu+PPDOKOW5KIiKfoK+/30Yp6ukKeHvbS
      ePqr4zfU/48dMHgvyweyRRAIAikUgkDEqqru7u66rkMlOaabiLhqLte9Mkbv9/vtfs/1VYSS5DwH
      ekdRJJQkoqZpiLyQIggCZxAAlFKEoJTquo6cd8aarh3CUsIwzPOcvG/btq/UqIT3Hj15Y4kckTv6
      Ze12uyZyYRiy4HRACFKpwBnbNe12u+3qerVaVXVVFMUgYPE4Hs3qSy8ITlTdM9J8+NuwjjnEkkWM
      DKIgCAar51RUEREco+W7ruOfwJH3EEIEUci9PBD7Krv9c2vNsligQhVwopcQ3JPTANz7NBiMGGv4
      h1EUoexLGxtjjDFDr5DjOn4gjKy1xjvvfRRFrPustca4tm27ruMnklJyH04pkVv5ns7MsMMHq3z4
      6/AyTqk9HgOsO0Vbpwv6FDExiDgV/ezn4TNL+Rz5++TF04kSIiIuGodEQRCI43i6UJQQD6yth399
      afQ6ErmFMTnnjLNEJKLIAioiiUKClw6CqpZfvuz/6R/3f/9/t3e3Is/Gv/+r9O/+Lv27v9PXFzSf
      aOFRUAToZ5rOtZpPr9Kg+rfZ+o9/XN/drv74s4iKeTZN/zpoyNpIWfTaYyBQOPJc+wQRsZ9Ggcib
      hNUkC3QhBFJvSVjvnDOMpBDRGDNMS1+H79iEjBc/IkZhbK1FYLwvnXMCJBAhQSAlOoK6ad69b//l
      X9f//C9UHdKr6/l/+X32N79XF5cuTpNDlX/43P30bveP/9N8We//6T9UlCcitnNZJ2jDwKMRYuiO
      22Mp59xRreCwnOAhYcKLh4XakMlCR5w+ID7vaXgiRgZJkogju/hnGYP0OF05L6ENOKldcTpYQJwq
      j2GwONpsNuv1OggCEv2OYwA0qDfnbNu2QsiiKLTWfdiipyzLRqNRmMR122y3W+fceDyOoqitm67r
      iChJkjRNt/ttlmVcTNE5x/JhOp0qpQKlVqsVL6o8z9u2JetYKg43udvttNafPn0SQiBKAGCONwyS
      Qes4rbXWKhCz2QyPttdXgOOz80x0H0f+IjY3xnjvjbMMe7uuY5+vDKIkSwfhAgCBVCxDAcADaGub
      ui7LkhOfrPd9kIMQSZIURZHneRiGSshhCWqt27a11iJIGUZVVcVxHEVBHMdatwAQxzGClFIgCCJq
      uqbruq7ReZ5HcSzDQFtft7qqqjT1KVEf+AngCQUKT5ZfSVlXZVlaa0ejEXNeZVlWVVPX9X6/5wcP
      w3A0Go1G7NAuHDzI12KwTkQAAnqS/6gtUBL1bWOJYABTRL5tNauoMAzvK+mwlXCsrdN13W63K8uS
      XeeDmR9F0Xg8nk6neZ5LKQU9g5WIiER/RgI66b7W7/auM13XkXWj0SgMJaAAf99t+eQ8wPXs+7V1
      Ute+V9vPbElB5D2QQAQQ4Mm03Wa/67SdTCZ5liglwTr0DrXFu/Xh//r73d//9/bDx+LiHP/uB/v7
      v1lcvhLFNI7PIzmSrkVrraTO0U46E4fTv3qVpNHV9aX8539tPt2u//CfpOLEav3mahmKTqowSc/y
      qUT0khDQOde0dV3XWuvpZM77sOu6LE3zPI+iiLkKAOjatizLui6jJGbbfLvdCiGytODOA1wzxnnP
      y8M5lyaJFHVd154sShhNJmEYCoUSwJO3umvKvfl84/7139t/+0Pz5VM0m6xnl4ezax/mrfbGdYHH
      Ip8k8yacrfzHT/qnj2WUuGKyrrpdNlPzSZFikkqJASJ6IG20MaYsy641XGKbiA6HgxAiSaPRaCRF
      MKzAttX7/d5ay8mNWuuu66SUaZqyV5CXyZCaCH2ntBiAKxTS1wuWnS4V+JYb/7eP+wsRDUY/944o
      sryp6lZ3WmsHnjcXEYv03lGHngIhZRimacoILwzD8XicZVmSpUme3t3dCQBjzA9v38ZxrJt2u92m
      aZqPR3meLxaLtm2d1be3t03THA4H59zl5eVkMomiRKqwOpTe+yJNQ6mstUziSykDqdI4qYLQdJpx
      J+fIsfRvhCYiDnsH56SUcRynaRpEoVB9v7pH0Y1fnSOOAOz/9UCaP/p913VVU2utnXNsvFRtI1WY
      dznX+eX7y5KUu5UPq8pa22N5gDCOBmjTI0TEIAi4XjscdTjDefIordvvDtY4olRK2bYawPObGJAw
      s2a7zV4bU0zGCSTWMsTX3PDpNDcMEYH6dN7eZ+0cNxOpq3a1WtV1y/UThsBVLk9s7VkQBGmaP121
      rF1Pvzm1jAazl/9prWXhkqbpkIo2yEetNf+zqqrlcrnZbAaqjl9qEARd17HiLIqCuwM/ve7T+pmn
      4KjrurIsyTpe2afHCNEXThkg1dMznMr9YQZOjR6A+8vrrttvtov1pm3by4uzcDwKiaT1vm6bL3fV
      f/xkPn5Cp+Pr6f7NfD0Ot+gTR+eoAhlJEAgdoDNeH1q7bzuZFfFf5ZPJTNeNWWx3N7ciDOKLcR2Y
      pcQlyXx2EaksTzOuymWt3W632+3We1/kY2ttWZabzSZNEu/9fD4fHmG/3y8Wi325Ozs7K4rCWntz
      c+O9n8/OORQBALz3Xdctl8vPnz8T0dnZ2Wx2VrdVediBQEc0n5+DAiLyQNV+v/30Gf/0s/jDf/pP
      H72tZTw7jIoNYVt3nQcHWllXNPXc2XmiQHix2Vd/ete9uVq0zcdkGzRnP1xPg7AQQvHKORwOnJHY
      tebq6qooCiJar9fW2vGkyLIMSARBgIhN07dQcM6NRqOiKPi3AHB2dsZIgsVdXdc3Nzd3d3dRFF1d
      Xc3nc3qZN38kE14S5U8Xz1dO8ovGI3iOAHEcX15eRlHU6s45x9Kcjh6O4R7Yng+ThGPMoyjy1k2n
      UyFElmVJljDzrrWezWZZloHzWZalaZrneZ7ncRxvd+v9fr/dbne7XVVVRJRl2dnZmVLhYrHYrjd1
      XVvdhmGYJMl4PB6Px6PRqFUBG3mj0YhbIx3LDXDUQ8/nSCnJ2jAMszyZz+dJkvB7hBOt6b0/qbH1
      /OScbsznsTkRdV3HGqmqKrZTrLXaWSFdZ4087IUQEpBtOqZQ+LeISIhCqVhKpVSUxIy+ByqDjl6p
      wWjia7VtSx5lZ5uqCoLgpKG146v3tw4gUAGJpm1RCBlGiJLZmq7roihq20AIxZm4ABBFEZAAEt5B
      U3dVVSGi7mxd1+v1erfbCaGCIOCptMex2+3CMByNJnGcnvLXw1o59WeemoHw0NsGANbaqqratkXE
      KIpY7Q2vjfMUyrJcr9fL5ZLdMkyt9EjDubIsAYBDa8MsHy70YAu98Mb5YGtt27acONczUCd/9SdA
      4NRyp4cVt/GEWAfokz4cF8BFQO/huKOAqCxL7z2QS5UKgxC0bbeHzc/v/O2t101wVgS/m2/P4p+w
      2u/sREVRkk+y2Cl0ZAG9I+8bW2+7Zp76PIcwz96u6//8sLu9qe9u9N1nMxI+yze1aSAognH2Zkzo
      relWy/Xtp5umbVnwMVXCliIBJGkaxzEAtG27WC432+2h3E0mE4bwdV0fDoe6aqWU19fX7B3lqknL
      5TJJEiLqbOeAGvZfOUqSLAtTIZRp2+1ms/z4Ufz8Pr65U9VeZqIdqZXwn8rSWA9hakEKbw5e17bG
      BKLQp7Yxq1u9XjRpXGpqTZtHblxEQRA55w6Hw5cvXzabTVVVztJkMkmSBBG7rttut2W1D4LgbH7B
      2GW3293e3i4WiziOR6MRv3Q29bTWQw6k7uxqufn44fNmszk/P/cOhhAsAHia+/qsIH5J+j86+Jtc
      wVcGg7BTUc4fgiBI0/Ti4iJJEm01AKgoZJDEAIv3r/deEAgh6EgJxHEch1EYhkKiUooA4qD/odNG
      5SIfF1mapmmKQqhAzHGMgnpKZ7XqtObJl8fRGV2WpW7FdDqN43A+n+Z5nmVZFIRRFM1ms7ZtHd2H
      LVrrici4EzeYtWEYRnEwn885aOrpHBIRgX8mXIU46pzjx46Fgl+aTSllEIVhFzdN4xxZ8mEYJ0Eg
      lGyNZnouiuIkSZIkiaKIEIbwSUZ8Sqk4juM0ISKttVLKWntKuPMWYmfxbrdjaS5E0DY6za13xGvL
      +x7e8tRz+22mLBzQbrezzlljyqrabdfamrIswzgSgCqUgVT5qFBCGmfZxQx9uR7J9iYRFUXB2lsp
      5Zyrqmq73R4OB9ZA7KIc6JGBV2X1exrw0Kfves+Kl+UIP3td13VdK6WSJGGLbFjobPeUZVmW5enN
      MII2xjDCYoXXdR3mBS+OIaAIET3CKVXaYxhPHoi1X68YvOMcF9c3OeyXmqU+GGBg04cliIjIFSeP
      9PyT7d3XAnDOAYjoWPc5lKIsSyHEbDSO8gw63a3uVu9+Tg+7IKDw+jz68QeaJ/ttuagqJzfTfNmd
      T2QYeXQIAgJJRFrb0lApgjSLxdVFdHUmf47azbq6+axen01mU1WatmpXq9Xb12/QW65ytz8cOEyN
      GWG22Nbrtda6KAqG56vt5u7urm3bLCtms1mWFkFQjopJXbUMx0ajESva/X6/3++Nd7MkyUbFaDJO
      09h2umkaNvXyJI+C8G67Xtzd7e5u080ybKogkNHlpbu8UrNZPjrPJmdhPtJIRA50Ga3jVjc0zvPD
      zpNRZEaRylTQGLvZ7K6uL9IUjXG73e7m5ma/KxFxNpuNRqPxeCyEOBwOh8OhPNTr1TaJMw5Y3Gw2
      q9WqaZo8zxmbe4TD4bCvyrIsd+VhNJ1EUXSoysVqud1umfNlTvK0xshjofGbmRN6oRjvg2PwWRLv
      mTvp8Yf3xhjrXBSF4/E4z3Ne/13XHQ4HNtPBeSEEKskuTRZHo0BJFB4871+nTddUy+UyCII8y0aj
      ESJqrVunhRBZnOR53vtOjn4FFh9pnKRx0kYNOTPId+ecAIzjOM9z7kzknGPHHgA0Tdd1XdV0HEpH
      5LnV6SAeh6eDF2LkvjnV6nSKma135BwBoQCh4jQ3zhEGVVOGYRKniYpCWddd17GSTNM0TiIRKJBC
      COmcc+QJoWpqKWXTtVHdMsDUWksp4zBBEkhCAAoSEqQESR69A+/AGG29cc5tNhullAokR4xqrRmx
      ZlkWBJEIQhlGs/OLqqqcp0Nd66apu7bTttvsIhXEeSwBVRSOsjwmCKRyznVGG2cBIIoSa721Pgii
      8Xh6dnbGy5qDjpnZZ2qSExAAYL/fs3rnCg9MO7L/RErZti1HLzVNAwBKqTCMi6JI0tQ5t1gslqvN
      fr/fH6q66S4vLyfjcRAIdnYN1slutxuNRnmeF0URRRG7K621eZ6P8/HhcEijVILsrGPTgRlSdtYx
      +hiNx0opT6S1aY0ud/uqbci6KE3aqtbGBUHgPFhA6xybmQxIAT1rmtlsliWpQmE7zXTzaDRSSiFK
      vF9Pj+qhewAAL4RQRGCcQ6Fm83nVte/fvz+U1U/vPtrXF7C48f/xb+3tuxgaOcmLv/09nl1Hee4W
      78IoMuAXh5vJNh5RPsoLUknbeit967UWshaqiZPs7EK8voguz8xu0262qul+mJ2tfbWyuFrf3Sw+
      ByFUh/1ytRJBOJnNZucXIgiVUtloPJ7N91V9t1qHyaeq7RDx0+fPTdOmafr27Y95NgqCCACu37z1
      KFar1d1qneSFdh4APt3cglSXV6/evH6dj4okiSgMrq+urDHvP3/4+PG9NzZKs/e3n9tyI1wbKo+B
      Dyfj2Y9/U15cTs5fYz59df27YJS1gSP0aAwsz1qLbltWi4VwdeCqsfT/9c2bf1ntnHY/v/skMNxu
      t1++3C7XW+fo4uLi6vWbYjINk9R7f3X1qqqaL1++/OlP77S2Z2dnDug///Sz1no0nly/eZvkRZzl
      syA0xpFUN1++rNZbFUR67j7ffl5uljJQ19fXl9dX0/nMOqL7gumnvLlnAPPUEPyKZPnlf3peyjvn
      OKCOIxKH4GNO1/z06ct6ve6MjuMQAJMwjuPYOeetrsv9pw+fD4eD0Zpt3zzP8fd/g+zXkRAIycn6
      Ask701Tl+0OJ4Ancjz/+yJqyqeqrqysAUCjYBkVEo7XuOt11YRBMx8Xvfnx7eT53xiIiklgt1nEY
      ubxIiwIAlBBtXZdlmRVFHKfe+/12t9qs19u99Q48CSHQkwoE55EiQRzHEhA9MSgcJg3xga3fTxd7
      twTTFcRlah5j83vGQChEJ4QPgiiMvfVOBQHjSs6jZSaOlRKDTW5EwOwzx1F67wMZDhiQaSk6hpcQ
      0ZCYG4YhBw9pbZi83u/3QnKsXh+NnyRJGIbGmDCMkyTx3jvvt9udM6SN9t6TQMfUfCvjJEREEggA
      ljzTRA4ojJMwDBlBM1LjzDH2+/tjVxGOGYrjmOvssH+M75apj91u544tBNfrvnVs0zREpJSK43Q2
      n8/nc0ZSi8WiqqqBsk+TRCnlfR8b07ZtXdcAMBqNZrMZezvpGDkThmGRFqPRiOkg5oVvbm7W6zW7
      4PkeXr1+DYiTyQQAGt2x0V2WJSIyRaCUmkwmDsgBWfKL9WqxWLBJ5JwLIzUajQAgvAhkELLnjUuA
      CiGU50T95wexX5j6CCKlVBBHs9lku9/ttvVmtwXqgsVN+ulDu7ybKBlfXcZv/8pNz7zBUGZJZFWo
      rNUfbz78KN6kcaIkeQ/aOxcIJ7EVWEkp0hjnZ+HZPPz5HbQa6m4apm/Pcr3Z7be7my8flMKurZu2
      Op9fnJ+fsycTEeM4nkwmq9VqtVrd3t7WdU0Am80miqLzPJ+dnyVJBgBCpFMV8EZarVbr9Xq/33vv
      q6oaTybX19dn5+dZnqBC9CQdVpPpYrNcbdZN08VJtthvUt1cRUERh1EShEEUXl3Gl69H04twNL+6
      uoqKrApbh6QM2SC5W2+qycxlia9a0CZBmefjawh/un1Xda2S4X6/3+921npumXZ5eZllWU9sCjmd
      Ttfr9Waz+fLly36/t+TX6zWvn/l8nue5J0qSZH52Zp3rdT/5umsXNzfe+8l8dnZ5MZ1OB4L0m+O3
      0CZfGdTX9BGEvdP9nvV7YbRtu1qtPn78WDU1h50opRx4pRSHLX78+HG9Xjd1TURFmoymkzCKrbXF
      2AohojgIwwA9SSmVAN22VdPc3UUgUCnFIepd03JkSyBVEAShVI1rELGu691up1CEYfjq6pp36Gaz
      WS6XZVm2DMYRiYiLc3FsBREaYxaLxeebL4vVptWdM1YIIcBHUTQdT7IsY8/NEPx2QqB/rbj5I8z+
      SJr3Iaje+6ap67ruOtM0jda6qetOiLZtwyRmQcyuTmMMgEfEUZYLQDrySoxqrbWuz5HrC9/gEOsq
      EFFIKZQLgzhSUQiNoCMnwHDe9t1EyHufpnGWZWmaKxUyagYAY4yU0nsXxwkipmnKhEae5+zui5OQ
      w28AwHuQMlBKqTDQWoPAOErG00mSpmEUOdeTyjJQMlDsvCUibVzbmbJq0szkhEIGgLbtzKGsvfdx
      0kUelqvNcrVhA0KpAIVw3vPj86PJMFA2FErx5AjFtbp7mMPYnAX3UHFiCLRSSskoCOKILbK2qhaL
      xWKxYDtACKGN2e33URxLKZMkcc7tdrtPnz6xyYmI3EkrTdPpdEYEzvm27ZbL1WKxLMtSSmGMqWvq
      WlMkxSgvkkmEx5h3XhZf2ckczw9EeKyRyGzYbHZW1RpouV2vNotVtlgn270y3mepOr8OL3+o04nZ
      1wplHsooDkDQ6nY7z+aTxBQShSfvBIHwkpwiHZBOQjWfZucXLkypcVR3CciL2WTjYLNaLT59RnSE
      kETpdDqdzWbMj3PU2mg0uri4qOt6uVrp9Zq/H4/HTL8yCkEpQhFOp1O21tlwAYA4jifj8Xw2S+IY
      AKx3AjCIwqIoJpPJ7rBfrjYyLBFxkmRvlRSrNQUBRgHOxjqNSaASAMI7aTx1AJ68ckAtgIsTkRfQ
      1q51gaYsSs5UeLNLPq9unbUcbntxcXF2dnZ1dZVl2RAdKwJVTMbj2fR2udiVh115YBSS5/nZ2Rln
      pvCOK4qCK7t+/Pjx7u6uLEvTtOPx+PLy8vz8PBsViOis66k5GGq+e4C+cN+fLULl+8YpUU732PJe
      wiuBaRxNJqOyHHnvddvd3NwYY7quPT8/7yOeTWdNZ63ljhaIuN1ujTH4+YaIzs5n8/lsnBdhHE1m
      s1brtK6VUl3Tfvn0uawrAEiiOIoi9l2laZplmXa2aZrPnz/vdrsizeI4nk9n88l0OplwsHnbtn3s
      NVPYSkVRpMJQhSG/ESZ7OfyGt7lAiuM4zbMo6WPwOBH0kS90SAh/aaIGpPWghuLASTEtVdd1XbcM
      md2xZDCHTwzzyy4UFjQsmJjeZcColAqCaIiXYIKvaZpBuBtjqqriDCuttbWe+WKewSRJOI9LSpnn
      GctoPImBcc71UZxhKISwVgz09GQyCYJASGCKnI9nQZMkyRBRxNiEHxkeRn8zjX7K950am0xbs9bh
      WMw0TUejURzHDAlVFMZZGobhbDY7HA4ch3Q+m08mk6PfCfEYEM2vn0NWxcPKBN57Ie6j0ZlGN8Yw
      LRPHcdt16/WaDYjRaMS7l6M8OS6Nsf9QZ44jJQaafjabdV1XVSWjid1uNx2N2T611vLEfoX0JOJM
      F0QB3gEAefQohQA5mk6aztbloSk31HSxth6FSnObj7s0b4PMQQeeYimKJFFJctiV5aHdxvsiyYUj
      AQI8IFkUHqUgISiJg2KkZOx0J6y3bRdMVFHk0/Hkj3/6o3ZtmmfXl6+KomBlP0CHKIomk8n19XXd
      NMyhjcfj8/PzoijgBOCw5TSdTrfb7fv376uqUkrN5/OiKPqF55EE1zIQTNPFi+W+3Oi6fn15eTYa
      nZvw4HznHUSBnI4aJfdt2+illl5sVC1q55y0odu3+0M1StJ0MvNlKTSJ1oVA4zSfT6cf7j4vFosw
      DIui+OGHHyaTSZ7n+DCTOU3Ty8tL9nyyBXZ+fn5+fs7uH9ZhxhgAiOP4/Px8tVrtykPTNNPReDqd
      zudzXvl09Nt/JTbx0dv/jSB9ONVXJBQ8cbkPg03q6+trjvxbr5f77c5aE0VhXqQsWI5bG7Ism80m
      aZ5prde7bV21iNjpt4jMt4jZbBZFEROndd2u12uh5MXFxZtXr9l3JYS4urpCxDAMP9/e7Ha73W4X
      ShUFoX3dxUGYZVmWZVEUWWvzIh1sHQ50JkT2THRGa60t+TTP2DcmhEDwcRwnYTSZTKIoGvAuPBQ1
      X5nDx5Pz6JdExGWCWfxp3QohkiRN05gdZSjVcLyUGEVRHIQ8NYNXk2O6eQqSJGPiW2vd6s6RD3VH
      CFmWEUGnbd10bWc8YRjGQRARoGhlPipGk3GSxFVVoRBpmmZ5HoQRAbRt27Yt0768rDlm01pbloyw
      QUrFCbVEBCSs8bqzRjspgihMwiAGqsgjx7owa48ggTNggIjbfCEiSOO9A3AAHpE/8GfPLbYRSQj+
      p/FeO4fWpmEYRlEcx2maBVEogyArCkScz+fnFxdZlskTh5M/JlgP8arHeRZEdGy50zeudGQ5MD9J
      0/OLCw5yMMakaXpzc9M0zWa/Y/WQJMnZ2dl4PE6ShGMfOb6Y9e5+v6/KxlofxyFv/iAI67qPu+d0
      5KIohjDelzbe8D23UkPR4wgEQJBBEEopyTnXaey6sNGmsypOsMhdNnJR4lGhx0jgKInVaDSezcu2
      vV2uiiKTIEMhpXXK+9BZ6Qg8YpQEWaFUSJ0BT976r7crAAAgAElEQVRaEKCSKIjC1ujKVorCMI7C
      KGLPlTj2JWCrJU1Tdoqy4uwrHx1tINapUkoGZYxmuIwGZ5MBAArhkYhLwXDUrJLamrZtFYpMRak3
      W60JvAwDMc4bA1Vpl3W5tnuMqcXaEiib+NLZfTkNkyydtnAra4e1Ru3SSRSGfbghK3UOemMoR0QI
      wjlHCFIFSZpleaFWK/ZhJknCAensrGfrmUXbEH7eNM2kGEdxkqSZkMo7QkQQXBrpSSX3k/HNBfDS
      Yc/+6unn77woC+s0TS/Pz8F78B6Ruq6L4jCJ40AqIUSRpfPJVBB0nQmPmQT7/X572Fvjkyytmnqx
      WIDzxnama+kk1pbNuLOzM67hxVD6bNYHnGitl8tl0zTGty6OOXQ7PBLOzrkkiZRSyF5TAELkwCRt
      txw+p7UWMhCq1zdAjpciO8lOJDDBc70fTqd9QO74bITiYwpGKV4HaZpykGbvmMZ7UYR4DBCRkgO6
      mSpiOcsjCCKOSGFmYIgcZxzKqJlZXcn1DQCZ62QynQE1B4GyicCcdVmWxpiiKAbirK5rZuqZAuJr
      DU/OvE2apoyd+Z+MkU8jTAbrhNkkcUwF5DG45oc5ZXQ/nU55qyyXS95XeZ6Px+MkS8M44i6xkKZD
      5hR4C5zBfHLOwYKhPn/vHqGzp5SIWJQrpfKiuLi4KIqir7sPwLFog90zm82ur6+LomC5DMfwStas
      fDBH9XRd57xhN3UXRtZ6huQc0YEPU8afri0UEsADOM48EkKRQO8dETHSL8tSeiesha5zTYNSqDSN
      sqxSEdfTlQiRklGanp+fL27vDk293K5HecE1ZyV5IBKOkECGASYxSknkvHNKKULUxlRNQ8coqUZ3
      /lilZKiUwK+PW3nxIinLkpOzhwkfFgwnyvE37PEe5sF7zwVvrSUi6Dqja220E6h027VN1eqqMy0S
      QSAxjJwz26beHA6Bl8KQka31KC1R5X3TtkJa68ABaQ/WaWeM6zm3YREOyv50KXJWOptcbNQqpYZq
      JP5Yy4XtY+ccLww+Gx//cDF7AFAo4AkM/+Y4FRp/Lsz+9PtHmD0IgslkopRK03Q2m1VViUpeXp6P
      x2MhQMrXSZhUVVVVjfFuX+525WGxXhlni3zMsYDb/W55e9e0VdfUfNogCLKsmM/nr9++mc/nYRh+
      /PiRYz3evHlzNptzBIQQ4u7uzls3mUzY5ca2fhzH3nulBBFxJUGWBu/evdvud3XdNk2zPeyNtUqF
      h6rcJpswDBG8UmqcF0mSJFHMeafwKLmfngk+fhGbD+Lp0YskZ5CckBBGKkk5D74Xjk/P6K1jtyzP
      NcfhcZWMOI55//DaGt4Hi3UgwfQWr0VEtNYNDslTeMUyi5c4I30AYDKBvZq84hlwAYAxNgzv3YzM
      /hdFEcSxDAIRBK7rWmOqthVHxdgLfeeYOfXes8/20RTxhmGRwap1NptxnElZlk3Xamuqpm66NohC
      viXG2qd1w4mIvOOoPv6GRbb3XgWRRDn0/fXO7+tDVVVCiK7rrHMoRBRFaZoOkI090ix32F5jpMYR
      srxYWYkCgNFOdxaP5aFZTwCIMIjZoOFzsviAb+xwQR4EIjcdAAAU5DxprQ+7cvH5Zrtek/Oj0Shc
      rxCByHmvgbTwXjmnvBeur6CZhMF0Ou6auizLu90KJDhNgB5RSkApBB8GgkhYJzyRdeQPh8Nme9iX
      h9FolFMopawP5Xa75ahZOCYb13V9d3f35csXo3UUhoB4OByWy2WaprxWh4XdtO12tzuUpVJqNBp5
      73kxNE0TRREKEaACBGe6w+GwXizbtg1VEKdh2zSrlc3a9aE5pOQFKiUCJSBO0kkYT+Z5VAgrO0dS
      2NTs9O7TF9hsuroG5zySFb4lvTzsduUBAEajESOkm5ubruvG4/F4MpVSogSBIITgXKHtdts0DaMZ
      TpKaTqdsmrA4YFZttVp1XZfFSZFmRHQ4HNbrNSKmcYKInjziM6XWfqN0fjq+oidewgpPvydvO62d
      JWtMnqZJEhtjgiBIkkgFgojIOTsaFUVhjDvUVWdau910XUcIUso4TQB827a71bppK902fImLi4s8
      z9++fTs7mwqB2+16vV5WVZUkyXhc5HnuvQ0CqZQIAolKFkU2Gud5lohjhSWtdds6Y4wHYriwWq2+
      3N5sNpuqajw3p/beOeqMbutGKeW9ZTR2UVczo9kcJyJBoHCIFv5GtRY65c1Pvz39WR98jDCY/yzN
      X5p0FgpCCFZiYRgyTmSoyNYrB6JwqCIDWyDBIgmgb8XNg3keKXs8wnBbPBw9opd98Di7gwcBx5KR
      pTmrCvYUwTFs3DnXti0Hq7BAxGMIPGffMT4aMidP74ShPZ/cHWvxIGIURfvywP5PViEsBQbjwFqr
      AsHKAQGUUt739TDZo1BVVV+o6ihD27bl6AV25/KpmG4aTDx/LNDBM8NTwXPImpJ9DHCEn3QsfjD4
      1njy8yxho3KABnDEvOLleGTGxQTA6ZHWOt2aw3Z/2O28dUWenY9i2K5UmoRpDGRIV1TtpQik5yhj
      JWUQqgCkGBWFs3q32yVJ5lrbOeuIhFBKSASPpiPTOWcQyaNvdLdcrtaH2hg3m80VWmt127Sr1SqK
      ovl8HkcRz0Nd14vFYrvdKqWyLPNErHq32+1sNuO4HZ7D7Xa7Xq8Ph8NsNmOXQ9M0HC4ynU7TNAVP
      ArBq281ms15vJMr5dJolabvdNE2z3G10UwfOWmu9Nl67MIwnUfz6+jydhE44AvQ6bpMytw42y7op
      wVSkIbZadNWiq9uuS5KEnbFc6IN9HlIFHNPCa3u32y2XSw6cZUzXNM1isZhOp0ma8gZk24tTGYUQ
      0+k0SZLtdleW5WKxkFLKab/7hBD/q92dJ+sHnhSlJ7r/ZrDy+Z+cEdLUHYOtPM9RiigKAMDYrj2O
      PM+LYhxn6b7crXfbKImNMZzvY03XNHVVltZpeWQ45/P52dnZ9fW1ULjb7dhjzDFjNzc3cRw78vv9
      njWHEpLxZdd1aZqzzbfb7Zwz1jsA8N6vNpubm5vNZqO1BimiIGBj1xM68vxb5wz78NyxRNqz5BK7
      ogcyEB5mYj8gVPj/xEnNz8G4ds4VRRFKxX3QsS/PKAaeoRcuR8oJEZFAAAZhhIhJFHvvgzDk0H3G
      7IOQ5WeWCoNQGts5b6RC0xoAbJoaERBBSjE4V5nDhSMeb5qmNzuNtQS6aW2nIxVwyr5zrj6UZF2e
      Z0RUH0rdtIIgEDKKQgDIsnS73VRV6Zy11nD1BiFE27a73W6z2ex2uziOx+PRoHu5MAAxB7fd1nU9
      Ho9ZSbDHnLMGsiJn9pltCJ4Z55zpdFs3VXIQsgilInLecTkkiKKA4eFisTDGTKaW0RZTdavV6mZx
      07Yte1mFBG3aQ+mXqzsUxDlZ293a2A4FZUmEiFrTdrvZxKEfj6MwKcvysN11bZsnGTgfSBmHYRyG
      SZKcn58zqcogTimRpim/oKEo3WnOF5wwd7zYFNuDgrxznTWBEtba3Xrz8f2Han/I82I6KV6dFa5r
      4ptFs/jku8ZvN3BYR1khnPVeWFIeQkSZh6EYz6jRh/X+7suddrbruteAzpK2JnZatG29WZKuAV3r
      zJfF3QeNe1SBit6+/TGWdDjsfnr/YbFY8DpRUrL2/fLlC2fDX11dTadT59xdFLGIn06nrIaNMYf9
      /sP793d3d1KIi4uLLMu6rvv5558Ph8O7d+96xBQoIFyv1+vlqjqU4+lkdnFZJPEdov7y7vZuGXfa
      dFrXTbvfSxFnQSSy0XQ8S7MYAvKArgucSOO63gaidY22VRqle9NUdzefPFjAN9evXv/wlqMk379/
      z54MRBSXl/x2mrbjuKYgCK6uLjnr9d27d1VVvX//Pk3Ts7MzZy0CrJbLTx8/Lu7umAueTCbvP3zY
      brefP34SgIGSIxwlYQTEtSjhGD7Rf34oUx6I10dy55tA/uvAnIiEuD+JQARC8nT6qx4SmW6/3376
      9CWO48uL6zzPoyCUAr33SMBu4cPhQHQVRQnrxc1+t9tXzFw3TeOdIfJg3PnFfDYZj8djRDw7O7u6
      epUkyWqzXCwWt7e3zDNrrd+9e2et1dZYa7Msm0wmURCyQs2yLI7T/X6/Xq+/fPlyKMu2baVCe197
      ymdZwTHQHsE5Vzfddrtlz6IUQgrBpC6cxGKczuqg2NyT8uODQB8OftytYkCRxhiGz49o5ZfeGv+E
      nZMDDFRK5SgZ4AwuNQAYjUZZlg1sJluyDLSNcwwVORWTQeVQ24z59MEaqOtaqYCIWG4yt6C15nzO
      pmm07oQQVVVxLCMDcCEEp+dYa1erFVdJLopiYP+99xykPBqNrO3vh9Puoyhi8D4UG+CwHBb0zF10
      RjvnOGGVz8m3ZIxx3gDApMjxJK2Um6eEYcha5PZuyWQc6/+6rp13HA+X53m523vvuZzL4XBghc/1
      ANI05Y3NfzLGrFarOEo5EZyIxuMJ9eHwMftn+FdMi3Vdl6bxJM/5ugwZuHL00937aD96IEJAxK7r
      drv9brdr6ybP8+vrq/nZZDZOqGvE7aL+/MGX2+7zTfX5vUwL8haUBBURhqEMwftQhuN8XOb1p9ub
      3WFnyTvjpRBKIHrjNiu9XHVVCWG4r6vN4m6vMjW+mF9cns0v0gCTJKk6u1guV6tVmqZc1Jg3m1Lq
      9evXb968mUwmRJTn+c3tbdd1Nzc37CPtuu7D+/fr9VpKeXFxcX19zWupLMvlcnlzcyMBeT/zr+q6
      nc2mb354Ozs7j4IgcHQwVbsa+S+SrPfGUtN4dCZJdF1tt/u6baQEEMJ0QlfV9u5jW64y10iJzvvN
      bru6vdlH6dXbH169esUxJ1EUMULcbDZsg7Iqur27W62WcRy/efP6zevXeZ4DQBAEnN16e3tL/y91
      79VcOZKkC7p7BPTRgiqZVdnVPd3Tc2fN9v//gH3Zh13buWs9c+90V5fIpDqHR0NGhO+DAyB4KJJZ
      ldVzNx5oJBgAAiFc++fMcRzvdruffvrp/v4+iqKzs7OTk5M4jo21zHx3c3d9fa00IWI48b+6UeVL
      WyuB1rTpsR+rDaiTLLVWWu+QM1QKy5LLshSta9AfQcdJiJLlb02WZcDW973xePztt99++Ob9bDaT
      k1hV9vr6+urmU57nEkSgtd7tdj/++ONqs86yLAzDy8vLk5OTwPOvr69F2BJfqDGmKEvxZBSmyPNc
      DJ6T6ez9+/enp6eSxJsW+d3t8uPVp5ubGyIy1QNuazsV3GmtX+eN0/ioLuiDq8faNi5SwnQ6TMO1
      Uw2goEHN9rW2SmkitrYqCgCgICDf15o0IThbFbkpC0QMw9BTtSogZE68vU14n+31Y8/zgsD3fFUZ
      yPNKLMJiqhaaLkKKtXa73YjwGMdxr5eEYeh5uqpKYyr52RZslRsVoEKK/GAyHJVZXpPFvEh3exGQ
      iajX641Go8lkMkh6VVWxMf043mw26W4HAFprsDby/cj3Y8Gg87w9c5ZllavdZUQUh2EvjqMgUIia
      SPJFwZk4CAdRpJSS4jUAINBuoiEeDoc8L7XWqsFtIKJeP55NZ+JyCT3/cDhcXV1Jur/sg6qqZrPZ
      aDSS055lmVJKwKcCP5IO4v71PM/3cTwe3t8vNpvNYnEr0DEyt3EcCnBCy37kz2edJfU5ZGDJGkPH
      zIfDYb1cr+/XlSlPhvPJdDwcDshnfzrR37yP/sccVlt3tdr/+DGanRsMrEKDyoJnmZCdVt4gHhZD
      t7hdceEILRmxrVeqKu1yZe7vXV6CH5ZMu/2BJ4Nk0BfK63kYgpvN59vdbnV/f3N9rZVi5vXy/rDd
      jUajdxfvTmZzCTAXXv7x48erT588rZMkqarq+voaAEaj0enpqVjeIz84m58UabZaLG9vb33fT4s0
      3aWr1co5d3l6dnoyiwcDdHx+cRql293Np33wE7g95JXdp84zOR3u87TiUivUjFrrzECVbrPbT0G2
      6VWFdpVJ891qm233yfvpdDI5OTlJ4iTQngJMd/v1brtYLG5ubnzfr6rCOffp48+H/W4ymX349tvR
      aCSR9SL93N7eLhYLRBQUwJubG2PMxcXFeDyW7LCT+bTI0912u9msozu/HyfT0RgAGqTlLll/xrb2
      LGX5lcxA7AuID/BB7TO7PpvWxBol8XA0iqIo7iXK04COGS1bKRtUlqWTGGqqE0eFvovv1zmX9KLp
      dHI+O3n//v3l5aWgAqzX69Xq7vr6er3d+L4/Ho5OTs4AgEiTvhIkWIcUJr3BeOKRgts748ABeb6f
      IFbGzIoiSZLNfrfZrGTkQRCcnp6+e/duNptJ9l+e52EQW2uLLHfGpmyZGR1LuukDEW+qP3Bjkn3j
      PD/YzbsTh03Yphz17uQ+nW75U/z+Yk4Rq4sQUE0k0WBi8qMmDl0htZyDm/p+krUoBm6RbZnZVE4C
      ttr3ylvELypUXrJMhWCFYZgkSa/XE3okoqgk5ohELJYEgUNTSon+JW5VEZMnk4nkZEpIgOd5g8FA
      OIoxRjyQ8liJLBwOh+J+lDeSVlEUif4hTkVhPzJFraGp62aUwBgJHJYYf6gqmf8kSSaT8WQyqb2p
      iBI+tVqtWsu4BK6IeiHW8Ol0Ku5fZpYAlRY9UWzHk8lEQhWFFxJRv9+PozCOH2J+xNjSNeI/aYLh
      ggYsAKDjqijyNAOA0Xg8k4RMj4w1YRT701k4PjH2x3yxyT5+9L/7oAaTOKIgjrwwcA58UqSVUzDs
      DU/Hp86ZyuT9KAwV6DL30yy/X+V3631ZaiLjeeyHw+F4PJmO+z3xEPpBMBwOR6ORoN1eXV1Za8ss
      FxQkyRUS46QkWEp8lKR9ytKMRqP5fC5nDxG1UsPhcDqdigH09vbaW6uyMGXFg35foO+UYqXRh8RN
      Jvr8An78SX1acVHZ1SqYjIt0tS7tPtsqUMoYUl7BCMXeW9/2yjxBhaByHWrth36STOYSVCoqVJIk
      5+fnUS9h5sVisVot03RPRLvdLo7j6XQ8HPZlV8jIp9Ppfr/f7XbMvFwuZXF7vZ5YjTzPc86EYTge
      j9Pd3hSladA9gyB4BajvqHEnNq698iyhed260qUkLe16tkO7CYWaJ0lixnWqHTT+IVJKMleKonCO
      DTtxhOR5LmZYWxlwqJQajUYXZ+ffvKtjV+SAC91fLBalqYIg6Pf7cuRbUcZhbQmx1hKDc85TunUK
      ep4XJnGWZbe3t9ZWQsEmk8n79+8ltMxT2jmnSY36g/l8nu1rTV16Pg1PxKZ1Z+mzc6sbDoztcooE
      J+ZU3UiITx8HAC3iEiKGfuBrT5OKw6iN99K+J9K0ewy46gVBbZonjMMAue+cG/QSgYVMorBxvaoo
      CKMgzPMcgGT9ojAEcFqh7ymxgTDzYNCPokiuKK2SONRnJwJJLLWmRMb0PA/BAbAi6PfiJA4n46EA
      HDaZnFpcK77vEyE743sKk0jRzPdUWZZVVT0kWHtevxeHYRgGXi+J9vvhPn3gH0JeZcPNJiNku+vF
      ElLZhk5Cw0Rl7SVWQah5axFKkqTXi33fJyRgCMPw5OTE195kNBasGGGWNf/XHjOPhyNZCLFfhWGo
      lCfdwsD3fV8R8sV5GPiSiCQGouFweHIyk+kiItHJ6DEe5NPmgKnRkZFBoU7i2PP8oBcNZ6Mg9D1P
      l8ahF0JvFIzn6CXF/bq8usG7u34Sn/Qj6vueTxpJa+UYHdkoiU8vTv0YsnwbxcqD0k8t3a+Km8V+
      vauCyD856V1cJu8uo4t3/ekkUkopYiT0MUn47HROyIvFwlUlOxdFwXQ6nc0m/X5S73AAIhr2krP5
      LD/sichZA4jT0XA+n53OZ70o9LQov3L7OM8vxDtSljkgDSej2Xg2Go+1JgKnfB8Qk8kk/OYbdXWd
      /f3KZWlxdZskUeL5UUiOHDMb6wgqBg7JXvR6o43XK3i3q3DkD2fn/cvL0Tff9AaD9iRHUXByMgsC
      TyMQO+dcmeXaozj0L85Ozk5mcegTO3SMzvWi8GQ6KbMUrDGmMqbSCMPJeD6fn81noac1Atbbo8/n
      p5IlqAjYGQQPn5PEX28PdowvIeVvtBvw4wZNIKlDKI1Ji7y0RqkaZmO/3wop3+w3eVnGcU+MnNrz
      NKlavywRiTztjYej2Ww2n8+Z3WKxYObJZCK4eEIxoiCUKFUJdBaCYPdclOXHT5/2h4Pvedvtdjae
      kFaoPT+KwiROBv3NZrNPD0EU9wDjOH53eXl+ejYaDH3fzw/pfp9WzhJRL4qHg8Fqtcq0J1qUxJJ1
      7S0t94IOM+tK2y9R8+MmsYNCx1VTxOeVI113IGyJZtsZEUmr7p+tcCoV5iRjSmzokgcETcwJETGj
      pEjFcSwyYBvNInKxkwrCzEHwCB1YJHTVVIZsb6zd9812EaFYKZUkiW2Kt4kg354oEV2FBEtMi5A5
      mU2RdoVQBkHQ6/WstaioTd6VjxVEZsn4akMAucmPbdUpKacQxw8+bqHFnqfa1RWr0Wg0EgNuq9a0
      BjH5fMF+k+0YBAEKkltTJFOmVCi4aAxEIJxDVKh2kPpJ/d+np64JcFOE1A9jNfEcAUbKi30HbNk5
      IIsMQdQ7O99Pp3h/5xZr/vljbz65fD8qh5HyQRGAYwCnfUWghjRSMVRVlAQqqAp/uc2//5T/fGcO
      ZXxxPvnnP47+9V/48ls1mHhJopABoGKwCDI5EmUkCMCS8p4kSfdDnHOiD7WTJvFLSZJIEmBLQZRS
      Aj02n8/zImVrmNGLB73eII5jhso5Y61i0qof6fls/P4bNfqPardPf/rYn0/enZ32Z9PM0w41V0bK
      HvWydPTxZ8pdWAGH/fC7P+j/9i/2u+9wNAobICPnHCIEQSCKgkiRZZXLBp5Op1JxRZixjFNkecmk
      k60rnnNJOJDAJEUQBaFE7BjjWrbdXdD2rHdt093Z446brdvhiCy83eB7REy4IQLwREi3xmy3W/F2
      VOPK9/3b29ubm5v9fqu11oEeDofD4TgMwyzPJQ8uDqMoivI8rywDgOjucRwv7+/W90s5ZW1qgqBP
      C9EQvef8/BwU0c3Nar0WB2YUhnKQlVJi7fQ8ZYzZHfYSMBpF0XQ6nc/nEtqX7Q/39/d3d0vxuziE
      oijYOSISYHTJXhZi+1RBaWkFfE7d0Uf/JiKAuvQRIjLbLlt4StNFIoOGUovOTk0aOgAoBEmrZGZG
      JhLeAAAIiKS1JgIioZLMTAqcozrU2jkiLWEq7X4iImtrF6tzDrkuNaJQLE7AjjUBEIV+VBueOtuu
      qso6/AYAkbWvwa8Bx1vIGzFeAQMwaAJmQCQd17gf7YQws1LonCUkT6GvvcBTKCUpESX6UOh06Afg
      B3EYNcF/AADgnCYqy3o8zoHv+1r7cYyIyLXaI5i04s621lpmSSv3JOJTdcrSN8+p86HETgq2TqVB
      wZADUKSYGYMwCSPnDHS0BFIAXEOPqaawxgMDft5myuK/IgatlIqiIIgNgQkAkcGBkWQWVhhEo/PL
      8vLMX15X1z8X//Ov3mw4PZ9VEdhEkzGABACe1gYcedrrJaGhpCz01bL8jx82/9dfqk/LSIfR774b
      /vEP8OG7bDgEP0JNAGDIldpzANTA3fR6PWJgZq0UAHieBx0TpHxjv99P4limThzXQv1R0j6bzB0R
      nXq9nrMVoa2MQ78HpFGBQrKADmwF5Pke9sLoYs7TafrxavvxZnTx7vSf8N35yS4OiyCwDGTZq1xy
      uwqvblf3KWZVkPSGf/jO/+c/mPeXZRwzchtZK2EOoi9God/KaNZWdTKhY5G6xAKgtRY2DwBSEF26
      SQij7DsRgMQrIKaDl4C3nlpU4Alt7VKGpyTi2T3TUv9nKElzNpidogYpgpmb0FsiKspit9tJUY71
      ektE93eL5XKZZYeTk5PT4enp6WlvMASA3W4nziprrRhm89II1QbJEUuzMs+FTRKRF/h+GLQ3VlUl
      3svpdEqe1lpb5xb3yyzLfO3NZrNNf6d8z1RuMpkMhj1JTSCiyWQyHA4FCkJwmG1ZbbfbzWqbl4Vk
      fu6z1DkXBWEcRg/FNTtUu53GLnP9bDuWzbuSOHXSo1uy+LR/N/Ggvb2zNoyNtZqb36FxeAgDwE7S
      JrTBy91XPJYChOzW9JRI7LwgIY9NeqcEsYjMpRvsYDnD2Ck83T6QGkijVrlrX9qdYjnwbbejiZLz
      I3FGzNyUucZWsm7IomtH2xLNJhCw+XQUUA50Tb15QADnDNennZoiv62iINflW9qF054HjVdDniZN
      Xm1tHV0KAIDu6IuwY+V/qSEiQl15mlFpTxEgg7NcMTCRAifYPtZoxZOB/0+/U6vb6u56d71I/vb3
      8bvzsNd3iEyR0oEBxehyW3k++egC5GS/q37+YfP//ve7v/xFFVV8cTb84x+TD78vxhPyfVYayDJA
      5ZxjhYgE6BB9pT2qEYR8z5M5kWDhh83ceCwaxqxUp64jdhQdbPD6CX1CNtY6FZbWVs74GhyjdQBa
      W3Cs9GAwUtORC4P8p427X8ar1dxBolUeaItKGY5cFVpXrHbL5ZqtpcnIvzyF2ZjjsGIAa7RChR4q
      BqayKVTdTZFj1s1+Q2srAK9lPPIViAjNyFtqCAACkIdIzoH4hOBBfPmMHH0kHh4JSd390H3UUyrf
      /ZOZERwAMltkcNSktHCT+GraaBbABhK1LGtEaKJbAJB4uUCrwXj07t279+/fV9ZdXV399T+/Xy6X
      pqqMMWEQTSYTY9w+2/u+75ESEGkA8H0tMjgjlWXpjBWkeDHdXF5ezk9PzoJAKVVWlWykIsu3222e
      lz/8/adRf/Dhw4ff/e53vX4semEcx9PpNM/zxWJx9fHTcrkUWkRMhl2+Wfu+X4MmKbLspHSBKNPt
      QtQkgwnpEX1/fZl0E6PSrpHcKfNuu4vx9FQ3vR/IIhAAswMrdngGiR4igSdEwCMDOiIwM1tHwGwd
      AoBVwHWVCpEM2RkSGZCtMAFfE0ANYtLK1PHtQBAAACAASURBVF3qI5PebtY20OclBtgKod35kvJP
      1J2Xx9OED7rCg3uzalDtRVMG4Cb0Sl6E4jkEAAfsLMvRAikWzkwEzFJNlFsfKSM6ZmBkIN0sgpQ9
      BNutb47AUoqeqSk4J0NtKL6VhEzx61j7ONWTUUJUWs0dGqEVGk3r0brL1CGyBQJkUBbYghN3vCe4
      2NY2qhvnHqphZL/7kFRlkZX7H/8e/HSz+z/+z3C1jL/7DqdzNZgU6DmmIQFvDdgiSLf5X/6y/rd/
      y/7zh6pYhSfnyZ9/N/rTn4vB3OkeEDGWFq0FBuVpy8iM4DyFslUIARCkUDgza03Mbc0BALaEIFdk
      I4imUi8uMyEzsLNVPbeADFgxOyTmUhMAoQFgFSIox8SOfRU5P9LvL+jnU+/mY3Z/5/3tr+582v/w
      3osTUJ5XOnW3zv79f2z//d9dntpRNP2X3+ejGGPtlGYDgfaAK3YG0IFjTxOz1QrbXepqvDbFFlhY
      Plv50lZPkh/WPipE3rL8ens3G1Xmp9n80P58utxdUe/oBLVk3XWC6h7tkycyH9TzXuvpEuNugaXE
      LCIiKGYQ4OjK2aY0N3t+6PmhddvSZGJL7A/68+ns8pv3w/EkK0rJ+/3555+3263veaPh+Ntvvw3j
      SILBqrxYr9dBEISRf3p+JkENwgh9rXzt/e1vf6txsLcbfxEMPn4MgiDLMyJSyjOlLSqT5ht2G9/z
      9vvDaDTK0rSXJL4OkCk75NfFzW63WS6XV9e3m83GIQhiIGnfuWpTZqHvx2EkABW7dHfID/2qHwSB
      A+vAQm2ZqPMKBRGqkUAeDC8tFXIOBDTzkWz+kjb9lnZ041OK+VQpe/ou5pb2PWM8evZdzw74qchw
      RI5fuohPOduXt1eE2eaZz4zh6eQ//Ypn/3sk+zz7qF/fXnomMyMD1xoaOQQn/AMAhB6CkyhGQ5D5
      Cs6mvv1utN0jO3N3tfrPH/x0n98swsv33njGfkTkA7DLMpemdrPa/Y9/T3/8sTxso1mv/+dve3/+
      PZycmt7AoGIAh86hYwKwzrNOOUJ6e3TG8Ye89OGP+xGhqJl1Mh2wAiACYmOdAw587/x08Iff2eUd
      73f51dX2//43dbdU4wl6QZWZ4maZ/f2Hw80dRdr/8E7/7p2dDo3vAZBWCFxrb1KDALlhNc+OjR/S
      KF/aKvxYv/w17bEc9pzR9fM7/xEd6I7/Sf8aQ7EmXk03P4gkHomZK1Mws2AwtHlhu93u06dP19fX
      AjPXS/rz+fz09DTp9wSu43DY397eFkVxcXFxepZIOQFEFIyHsjQi7B8OB1RUluXV1ZVSKi1yAVAs
      iqIqjbW2tKaqKmTIsjwvCkk8FMM6ERVFVppKa50M+kDoeR4QAqEK/Mj3FFJlTVXkzlqAoE2DbwU4
      gLoYk5DEZtI+s44vVpL7ZTvg7XTwder8RbT7s89/5fqzf75Wt/wNL/osYzv675FO8PoIX/rXEU1/
      qpe9bjB5eztaIERkbK8zN7RUqhAgIjelLADBKoJBktDZgJ1PfPf/2M3PP+NfP+2v18F/fOyNxmHS
      970QweW7Q77ZFOttvloyOjUZ9v/4u+Rf/+T94UMxiAoFrjbXESMjAzkIrCMGh86+4UOPJNaXPvPI
      UMDMVNfmAweiQxI6R0jWWWALhBh48cVZXGVUFbt//4/Dpyt7vwkmP/VnJ0oH+e5wWK7T3Rqs6f3u
      YvS//6v/p98fJtNKeWQdgQIUHQmZG/yNl0YoKJ9fctZ+vaz2dBd1r7xO0J8fA3YvMrzKi0XpFECV
      6XQqFgyJOZGUzsVicfXp5ocffpD43SRJpvPp+bvz0/PTOI7DMKicKX4ul8vlNt3qUIeRL49tIyZI
      q9nJ3At8yQrcbDbf//iDZOfleV4ZZ4xxXJuIFSkHnJXFLj14G+9usRAceWZOetF4PJ7P573hABVt
      9zuJierFidbaVtVus00PB7BOI9iyIgawjlmcW9QN9u/MGD8V3bp/Pm83b3//uiLeK0a0zi+fp4+/
      rH3pQ/DJWTo62K88/Fmpv7sq8HgSnmqvX2USfgsh/e0jISauzUpWqpM4tA6x6gXR5enEWYcOw+hw
      c1vu9m51ZX64JhYXurPWonUWKej3e+/Pkz9cBH/6hr+9NCfjTCvQupsCjQyEqBkR+Is48Vvao6Vh
      kE+qazu00+AsAgMwKrDguUHfu3w/RnTMqjLpjx8Pd9v9Xz8yknEAhNSLgsvz/r/+Ofpv/+zevYOo
      B+hZQXrovPfZo3s0qpfIa8t0X+dbb+Hxz6qMbxHDH73iiRDQ7YzP3P5wgh4YG4DkB7XQzYIYLDU6
      pL6HwL4KxqqkkUtgcVYWaZFL5vlqtSqrnJm3q7Ug64mjmIgkrUQyPKVJ4st2uy2KwjEyM5LyPM9T
      pJQihtVm/Z9/+2sUhJLLbarKl+oTivwonMymQRSqOy113k/n8ziO8zTTCOSsc24w6NXgzC0+EkON
      Mfdqe9rhRdm8veE3IujdAfETZ+PTDfFFw3jWavFSz+4AntKCZ6jDq3T27ZqEvLReNn40mIeXPDqN
      rzzsv6DV4xQvDUtYOqqnhx8AkAAcIFgkIMqs03HovT+LNcFs6v/9h/yHj/ana73Z6TzXgIaANEEY
      4rAf/emPyZ++Cz7M4XRy6Pec7xfOEVtCBegQALl2FFlikEsA8Abp+4u6PfQHR/Va1AKUcgDACOwY
      gKgEpMCrRv0w/C4wFVeVZfBvNpgZYwxpjaNEX54m/9uf8V9+n707L5Ke0T6jNkQWnWZHD+860rib
      HfLyMX+7BvbGnl1VDF+OLj/qD0/ms723+wRs4h1eks25ae3lPM83m+3d3WKxWFRVxQwnJ6cAKE5d
      KRHTG4w2u0Na5GmRLzfL/qY/z+chmLxI79fL9Xa1T3dFUTjm+/t7gRtRSrnKAIBtCpBK2QAJfPI8
      z/P99XqdZYVzzg+Cfr+vfA8A0jRNs6y8LRWSRAzHSTwYDeMoQKJDluZlIaWFSGuf2fNUL46SKPQ0
      9eMEnI3jeDwcJVFsrVVIBC1ADbJ70VHx7Cp8hpq/vXVX6y09X3/C28n3ERuAXyrDyk988+0vyc5P
      x/O0m1x+SV16xRr++kjeeD5/8Sx1n9A5kw84TS89HxEFBILRIqmK6KAg6ve09vvDQTibu3eX1fc/
      metb2O7QOENASehPxnQyS/75n9W7UzfuFXHAWkEQkUEEYnbyAuUAgIjBkns2Gf2LpuVNPRnqkmsN
      KQIATWCQmcEQ5JKRECXw4buQSI3G/NNtudxSVURx7J9O/W8v9D/9js9PssGgRE9bpZEYwbJxWGvT
      6oXt8fbxv7TB3t6eClhfxANeGdXDJmmApbhjIH7lLc7xfr+/vr6+urqSyBApt7TbbZ1zhanEjH44
      HPIiFQCo5XJ5dXUVBEFeFOv1WrK+iehwOOy2W9eg4bORCK+6CJ9z7vT09Ozs7PLyEhFvbm8R0dp7
      Y4zg6ynfE9zTtMirbS7ZoaPRaDKbTqfTLDtkWbbarP0wkKTr/X5vq6qfxP04GQwG437Pnp4qRM/z
      5BPSPD/6cGZGfKYu6Evz83lq/hJhfYUc/BqbO8Ajsv6Wpz3dtb/g7a4zhrfc/lKfr6XKfHUh6xd0
      fktjRH4gog4AkAmg3oGuDgWp/+WAmR2SsooKRog9FYS634fzufeHb8xm7RlLko7ka/QjTHowGFdx
      XPnaoGIHUBFYdmiRyKEDJgJAJnxwS351W8vR9zbOTwAAQIF4B0BmIrDoLJJDRE0W0M1P1DBRHz4E
      60O0P7AzSKSiCEe9ajg0cWJIoyXfKM1Qoa3IGQ8YARkss2pl1+dHIuN4fkF//UI/bzD5Sk976b/M
      jxSPp9KMM5atY+uQwVq7WCz+8pe/fPz4UZAzKlcDVjvnJpNJv9/XvlKarm+vUJKrQ+/kbD6dT2zl
      7u/v9/u9c240HAo0XpZleZ4Doh8EvV5vfnJy8e7du8tLRKxLBzuQ8u5ZlmGeS8qoAKlqrfuDQdLv
      WXaL+yU4u91uS2O3221bLJ6Z88Pe5Bm9f39xfhr2Ek9ppZTEuZclADgpzozIiAD4vIDyUvsKsnnL
      S3+ZQP3ZW143kjz70qfqc9vt7aril7aXeM9nj8Fnh/S/YGsHXNc6eK4x16EIIptbsMAEbIm0Q6ws
      WwAij5Si0Kdh38zHSpHkzID2GMmhJj+xpJ3WjpSzEgvKSquKDQjiG5MSSwsAo3uF/H3pBz6zEwjB
      wYMxByR/FRCcc5a0cogAbAEZybCi0Mu0DuKhHRZYlooAnEVE8P0qCCxpBk8BKgbFzAhI6KCJHJQ5
      RPhaX/TL2pFhBD63n79UteUngmfz0udfRE1hGWZ2zqVpKhiidXw6MiL2er3pdDqezDzPc2AFyL6q
      KqmCnfR6RJTu6yLpWutvv/lGoO0Xi0VljICRzGaz8XgsoGbOOXG07vdpnue7/aHFTzUsWVoqSZKT
      k5M2rma1XB4OB6HmiE1ktrPZRvsKRsM+z2deqIPQkwwB657MHkpU4jOpud2GiNwY2Y9zQd+yAE8f
      13Z4RbZ9yZD9ioH7dfbwuoX6s6M96tna736BSHKkPD477Jd0z+7s/TKa/kWKy1tueb3/0QPrtJTn
      noeIgJ0pRSIGhRrYWeBKK3SMDB4jqUCrQEWJQXToGEWoB3aIzrNEFZIFQFISyeKcIwQAJ1J5E+j2
      SGr+le2lPSwBM4/jAi0wEJFjy0yAREzAip1Chhh7gI6jmCN26GpMG4RSAMvE6I9oEAxBhV/sxX37
      Pn/77a/b936BKfLZwWBjcDxSxGtvQVN97IhQIGKNOBSGAFBVVZYV+32aV3mLkUdajYH9IPI8JRjU
      +8Mhz3PHPJ3NJIfe84wAZw4Gg8vLSwHYyvN8fzg44DqaUCmpASK/yBgk0VpkeQCwwL7vR4Efh+Hp
      6el4PN6uN+v7VVOmscImX1JrrRQWRVbkqSlyJykFwM5Zz9MMzGwdG66TdRyzPVI0j4wW9IDiUv/y
      Vtn8s1T1qTj8+o1vN6R80cC+1Cj0ysDe3v8t9/7/Tvp+exOx8o2dickhOGSLwETKARArJgZkYit5
      YtiUSEUkJIdUKrRIyoFipxlaoof8lYj3m1vXEIAMct4YHQIyAomoyYRM7EgxaGAAMuQsAdR0ChyC
      1Bf1GBDREgBAperEKxHGqXnFf7l4/nr7ZVLIFwlJKIK6NIIgCEajkUAn5nl+yPI0TdEgIkpJ3iAI
      JOIFwFVVleWH1Xot8S0AILhybEFiYIbDoeRhCl6NtVYKUzjnDrt9FEVtha88z7Os8DwvSRKh/p7n
      Kd9jZoV1KXBBpZfEXWiKhstDPM9TBBrdfD4XYJb2mxq29VQ8fUh7fMusfjUvKDftpX89vf4r6fjR
      Kz575aX2i+2sRxpo+3s7+11N5b+Emv8DbDjPzHNtWWYQG3qTIUIMAOSAudGviS0gAIFjsghAJGmO
      BABgLThAtAosgiFw4ICoyTtuXZFiWiEAYCQHQL8l7eMGeLpJtxZSXmdhAhMgKUlhZiDnlAMCA8AM
      CAwSqc7IQGjBScyKsAGH9cMfAloeMmaeD2L5x5D4l7bQU9Lz6zXLl17UNaYPe319TqHvHb55nxXl
      er2+urm+vr52G9BaD8b9k5MTIpQSJUWRWWuNLYWOV2VZFoWkfYZBPBwOx6PRaDgkBltWVV5IvezS
      VFVR7jbbdH9ogae4xl8bDQaDOOltNhsAkJIJeZ4XZU5EZV7kaSYYL4iotfY8NR6P59PZeDzu9Xqe
      rzRCvxeP+gOB+nKOlSLn+KkWwk9sTU9txUer86uo+deixb/spV2K+dJ4nl55doJe7/Nse5aUt1d+
      gdrxK8nu6/6D36i1lvFXGiKK9C7+OkZ2jIAozkNiYARLDlABiNnEqdoYDYxswSGCYlIA5JzixvnX
      cOH/KtG1k8fouhflJ3EdlU5gHTqH8vUEosewJZLgVLAAbbqT+vrh8q+1Lvl4y1Z5vVuXpj/VmD/7
      dESExznS3YbNk4mg3++LLTsvq8ViAYRFURhXgxFZa6WyhdaaOQRwjj0B5ZaCMDWOU2kF4HC9Xhdp
      Jv8SZFZuyuR2z3iDE54YYxiwduAwS8E5P/AQURCq6zquNf4SAoDv++Px+Pz8vD9IQk+D4zLPt9s9
      MvQHSRL3PV/J/gcAYMIWKwUFPKqdz8/M4puo+RvNF10Z/I2b4y1vf+mW1+n4KxcfPHjP23vf1F7n
      Ck8J+tHM1PrjZ9fnFw3pH8Bl21cQP8CW1idZOtRDkkxlCW1hRrBIDi0AIINidMAOwSIAAbLzHWjn
      AgvEYBAsgkUnGGXQRMswACO6xlwvAeDCCahO0vytmrxCfkFEAMcPyZjUkPIH9YHJGTSWuFLoEJQj
      5YgAtSNicAiG6lsIQLsmtByh+eCHP4+G8evbs+f3Jen4q4sFD29/lT08VesFMzIIPESMrNOecsBE
      RPrn5XK52+3SNI2iaDQanb+beJ6nGlJYFMX9/f3Nzc1+vzeVcyZbLhbZbi8WjyiKQj+Ig/BkPldK
      SaEPaLH5ECvnrLWr1Wq32zHg4XBQSkm1k+FwOBj2lVL79LA77BExiMKhGjHCbndYbzee5w1GwzM8
      j6NeLw53u916u7+7uSLA+XyqTgPEQPseo0JQiMoCOCAEBdxaxn8DS8uRDeH1ni/de9ThiNgxfx2q
      9Mvu7Uq4X/qlR/rmV7QjvaV9VmN9pf2aCT/iqc/7u/ioPyE4YQMEjqWob022HDX+aAQJU3f8QMod
      A1kkrmk2URPE4tB9RbPhK43q043cGl5koblr5HGOHDquyAGwI+eQGIHRMjoABVwHrAOTIwEpAGSn
      GLh+AxACvwxj8ovb6/orv1qA4rdo9dtfiNaAzrGqTcxsqtKayjGLnQ6Gw2FVVYesOBwOq+29WDni
      OD47O+v1er5Wgp4tUeoidEskzH6/T3d7+e8333xzdnZ2cnb606ePgChVmUxVPVADImZO05SZGVAS
      R6VqsRTs9TxP4ASk7lia7o0xWVbkeb7e1vgt+WgEALvtYbXa3NwtA+3FcU9Qrh1Qk9YvH6sAapix
      Z5fiWUX8iw/Alx74LrF+aSc9o5d9jUiMV9rr8tuXKhYvDeypDf23a10m9IvtmG/kQI84h1yp/3DQ
      aInYAfOT7B75U2ogNu4+AgDNROAqApHcSwXMTKQZgNE5cjWCPljxNjKAlA9qzNbgwHFryv7C9kXa
      JDKQoLIiuyaQhoGgZkc16iygY3RW1egDjCTQY4AASMxQg10yOECS8BwwjM4ikKsdxUet3bFdwzq8
      YFJ/ezuSRb56e0mGe2ivhLc+/l2oeVmWm9V6cb/Ms5JJiRU7SZK2pBczl1W12+/v7++zLIvDYDQc
      DgeDKAwVUXo4WGMQwBijtdZIAGDKKvD8QdKbT2eSxx8GQV2W3QrEJlrnhDqLpaX1jurA96MwL8us
      KNbbrTGmNKaytiizQ57J74csu1su/vb37zebTeiH2f5wv1iuVuvxcFgZ5xgRFDMyS5CXuMvFSvOo
      tM7RhDydzC+g5m9c76cm46cWmGfp9RttQ7+mtaLHg2nqSXsjEXxpNo4+7dfQ1i9q3Wl/ZZKftn+M
      FOawhp5AZsAH0tsYakg5xwiMwAAV1RCMDdqvE1kdUPiB5OyIA7GmjP+AT3ihEQIAEzaAwk8aAgCx
      AmDkB+qL4ICJkIEdoEMGS/XnwGMaLQZ6apGU39yQW4903fgRnFP3Xw6ZuJlP5IcwcHkIsgJ0IJzs
      RRZCryU7fTHDcK6xtLS8jZnTfXZ1c/23v/1tcb/W2n93efnttx+kpLDStfUyz7Lrq0+r+6XnqV6S
      vH//XqLFlVJSicIYczgcRqPRIOk557brTb/fTwb90WjkhwETCupLGyIp1PxwONzdLdM8A8bpdDoa
      jeJ+Tx613W7SNL2/v0fmLZFSyMxFUVSVtc4VRXlzt9inWaA9XwemrGxpjS09LygqYxxbQMXsuPaF
      HlX1a6kWwGdOtO6e+WflO/lvC4dfX+cuvW7ezQxsxUd/tISPBuG4dvI38D0sz4dn0HyODAiN6oHd
      Z3a+9qFnO+buJ0Djh4IaOoQ+K42+1OEVWvmUoB/NgEiY+PiWV8bwdEjtXUe2xSNN+UXTx5uzt579
      b/d292if1Nj0iGisQcRa8hJDsAi1QAjAtUUSmZCZwTESKwmbBXYEFTOSIyK2TFDXiqqtNAwgRaVF
      eGGo9dPaIAOICPRQkKTeY4/R7RERHseEQVMhS97WCmWIKFUMGQAJ66I+zEBIoKTgL7NTSACsCJmR
      GYCJmJkUQx3Vw8w1SjUgABO4WmAHYHAsNB8lubWd5+YXBngcrtMK5vVZ4yb+EZq4STmM+Gg/GAdI
      vpRKAUSF4JgdGyLQRA4BHVt2yMQMiArAKWoODgISCJQRIzoLiMj4AHCAqBgcsMU2v6ozqhf118eX
      mdlxhaCAlIRjyxsRJUrIOeeq0u536W53ADgMR6OiKLww8HzleV7g+eAcAFRFWWS50kiOs/3OVcYU
      pQJMwij249iP0eIwGYZhKGHmfhho37PsUCsp3iQ2GUn67/V6jtkY8z//+rfVakWovvndBykSLWhc
      ZVluVitT5rYyikjiVZgZGT3SCCpN8/RQSqkcZ4xCHXh6vdnt0+x+vfEC3/d9C+AQLYBAr7VI9C0B
      YX50oh+m1DlwjPyybN4S7nZP13YrIZGPIL5qCtuU3GGgY+G0W6SCahHtkSbFzPzIf/bw3u4JbAPm
      W7bZljR8qg0c9a9PJrtWAmpn5IgffJFI+8zkvtr4S6KzX3rCZ57/gm77W4jhbcGULttmZgEzqmWr
      zvS6TqhAtyED10iLCEQE7JyrrPGUxla9Y4CG5Xc2Bnb3TA3fwvh0t9DjyuiyD9u6oNDsN8uPBBfo
      pGkYa1HK98gOF+JcFxFwzGyF7BIgIqB2jEYooQLCWiVBOZPC7QAcAgI4ZjEiPVQjQTzy0R+R8vp7
      mR0APZGZFDIgIbJzTjiT1j4RASIhOmBmsuwAAVGTQuHKQFpw08Q7C6C4ruDLDZgKW2AwVE/msVjw
      jNT+RZJK84VOhuCAW+ohlMUhRFE0ms5Qe8baXq8XxJEEgJ+dnQFwlmXoGACMLQGg30/6/b7Ekh8O
      h/V6LfXegiAQlBUp4ylx4kqp/LCX2kPGGCmvGgQBIo7GY7HFh2GISp+cnARBUBRFmmeHwyHd78uy
      DDw/6PVDrYjIGGeBTeVKY4xlrmxpnHGlrz3nANAVldnsd1c3d1EUJUkS9x8VhGk3ebu3m63+mhyp
      X/p3V7RprzzsctelxVKSWCOia3AjENFhXS8NEKgjcci93JEfgRAApYxUV4ZqxeqWLjzc0imD+cqu
      qClIsxvaE94YdR/MT0fc5YsI+rN/Ph3GVyemR2P+LV6Bn9NdXvqvICK1D2l/93yfmZ21zjnDjogU
      0oM0DTX1b6lCVVUKUWKEkR6Wsst6213hnPO0ZmbL7ki0abkLtPmrrqbybZ/6d0JElJPc5JFbkGq5
      mqqqrmJYax6IxAhNrT4pe+vEKUpEiFoqawM7ZhEbZf/rJ5unjuH8YtLnVEP4G6XYAYBDYGZCYkJA
      jYgWlbWWnZF/iTTUMMa6SgYRSzFVYEZkQAQmAI/BAoNCUFrrZq4cs9QQ7Ih19nVjyxsb84Pq2tY+
      BABETJKkGI/OirLX6xVl2e/3ZbGkDLfnaaHmiGhs6Zzr9WIRop1zEoKitZ7NZsy82Wz2+73v+yen
      MyntXZbl/f39x48fP378aIwRh2q/3zfGIFG/3xf4XELlK52m6XK5vL6+Xi6XeZ57njefTSeTSex7
      zKy1b9gd9tlqs9nuDnleMhrnnJwLhwDMaZpeX1/7mgaDAXkPUhEDC+4ys33FunYkP3GbC3p0Jrv9
      WjmovQeeO+RH1x9EqcfW8HqoAOKyqBtK6Xrs9H/0rq6c9RLvORq2pHV1T++zdKdLF+qxvI0gtpPz
      dBjPju23aO1sP1UUnm1v5FJf9Opn38uP9cHuJNcD7lTvE2naGlNTFWYrfRRpUkrVDNs5h9yUDm8K
      eB49n5nLskREVNRVGhBR8rChq2g2AkF35M45oadSS/boo6Ap+FeDguCDhF7zg+bwMbO1lhGJUBKm
      sGN3YmYxawDUUPf1wDrWlTc2aiR1RGx0PgQAZxmILCCAMgASjFNZRKWNs8ZYqb6tPI+QnGXHoJCI
      CdmyZQLQWqm6KiEhegTOCHAlA5tKKdWCySNiHVH5VSP/+UmDhrhbK1oQpEXOi8V6vW5T7ZvCqChm
      dMEAaFdTaz3oj5IkCcPwxx9/lJJyv//97yUg/fb29ubm5vb2drlcyrva6rvG2sFggKgsO2e5LMv7
      zfru7m6xWKRpqgmHw+GHDx8u370LtDLGSNH2Q1Ze3Vx/urpbrVaW07IsBZ3RWQdEzJxl2Xa7zbJD
      VY1kN9KjTf1I8H1plqA5XC9aWtzj4vTQSLjd6629BRGNs0QEDK4pXIidCvEsYxJlgQCx1uweU2du
      tk5NjlsSIOy3/b2VpFynBnH7KPkpsDjye5sI8Arx7XIj7JgaX5zBxwT9dSb327XP0vFfT8FfEs+P
      Xt1NZnt2DO3Ktj1Jpq7jQaktGLJyrhbVH25vZIJW7m7fKAl7iMhWiOvDM1uO3ib1SZM/pSIBd6rC
      18dDkLTYoRQix1oAFyb0SNekhyFL9TcR0RtjoGVs6XVjOHCONDkEYOK64IzU40N4Ykp+Zj4768nM
      tZUcEOWcPvQhBlWyM5YtsmPKDSzvN9vskKV5ZQ2iCvxIeb5zzlaGiBQBOovgfKWiMAx9r59Enmal
      SCEToCZUGonI2qqx49e2onoSnmyPX99aEgQAeZ6vVquffv55s9lkWcaEREoMdM65qiqttQTIzKpG
      4IovLi7iuDcYDKTgXL83DMPQGCNBKYgopvPdbrdYLH769HG322mtx+NxkiRRFMl7N+v13d1dnpfW
      WgaU2nJFURRFUVWVCnytdRAERJRlfBmH6AAAIABJREFUxWazCcPQ8zzJ8m+DbZjZOmZXa2lMWHOm
      +gOlCvExAXn7RL4W08Id8zR0+EULYyY6MjYFjrm1cCG2B6P1JnWfCY1YRI/rhWPjfYLHpcSbzK5H
      LAs6lPQpH2uJvoyBm4rmT78ROkThLaS8++run09p2dFzfj1h/exIno7hFan5l73i6dO6KkI77caY
      oyVu1/1ZJgqA1lprXL1MSoEIR50xINdSOTTSRktVmVn4t6f0ERWWV4tMJOS43sCu3hhNLV1s5QPp
      rJQifDiHcl08Y+3ebrd33b+x/jEzIWrfY0YW2xEzN2NWSjVZTrW03oSTfGlmUOPmfeyJYQREbRiM
      cw4JAx+YDof0bpN+XKzut/vdbleUxjnwvTAIAmZwzmlFmlAhK4LQ8+Ioj31vcMjiwEt6URz4vqcR
      kK0FtgrIgXiBhbm6ZjCd8uJfacN3z3JVVfv9/u7u7u7ubp+lAIBKyXoxszEVQK0taQLn3GQykgAV
      QUaUwHDxcIo4LxaYoigWi8WnT59ulwtEHAwG7969m81mQRDsdrvlclkUxd3d3W6fOufEGGeMcY3s
      Efqe53lJ1PM877DdbbfbqqqiMNFBoLUmeKBIRVkqpUiRVhqlOEWNaM/Mj/L7Hy3oC5SkpVdy12te
      UPlaiZDvPki2rFLK931f+XUlQwZjTFFV1lqlPM8DcUHXOg4DSN07BnSSFYhKa1DgrC2buE4A8JSS
      Mk5y6kTZ0VpLypZcaY2nR0sOj1lO20dIQH3SHtmhuuCjz8/US/PTfemzD/mi6//I9hXH0BXPW6FV
      iKbnee27WvYPAKU1gKDxAdcU641OiKiYgR6keG5YRe3Kc9wazbTWrolZoqaYvZBXRPS017605SjQ
      oQtdAni0czoMBkTKAwG4AwMAQRC1HVSHjtQgSopYIszEP48owCBIjIjYOBcR0ZSi4/KDRlLH53xZ
      LisiQivU17V7CBAsgmE2jBbIMRaVu9/n18vtf//rz+tDVlUVWyjLElEFQaCQPKUUgq9JEypNniKt
      daSg72Mv8sfj8XQ8GvaTMPA8BAJisO3e59pB9ww2cvc0vTD+z4ifXRFBWC8ACCqWbDZxV7Z8nahG
      yGfiLC+s5aqysjfEFJ4ecikfsVgsRAy/+nRjjNlsV1mWIaLv+8Ne/+L07PT0FACIYbfelGVZlqWw
      AeY6lMvzvEogjhsrsbNggZkQSDM9DFsG4JyTsBYEttYSUruFfKWZmcEyWAQUZ+TRTMJzEYrN5AO0
      1Pwp5RI6vt/v0zStqqo7uSJcBEGQJInASwKAFNNLs6yqKq39IAgYoa2tZ8qqqiohqb7SSqnBYOCc
      AwVFURwOBynHBwBlnqdpmue5UHMAELYhpq4kSUSd6UrT0DmQLY2QqFKRpETZkTlF9aaY3TcK6W8U
      dZ+V3LsPecuQXun8+vPf+Ng3fshLb8fGiiI7pxsVILVa4jj2fR8Ji6JY7/YS+cvMYRAEQTCdjkW2
      NaU5ZGm7JSTkQO71tdc+f7PZyPpqraXOb20edeycyyXSIE2ZOQzDMAyjKJLSi0VRyKsVkmwMEdBk
      kOIuq6pKns/MURRJUIQ1piiK6+tbuR4EQb/fj6JIaEoutQvKAhF9LyQiAfkbDAae5/mBRkQrpWrS
      tKqqyWgs50gp9StinIjZYpO8zly71xjIOgZF7Cgty312OBTVanvYZdl4OovGEPmBr72yKNjYwPM9
      hb72tEKlyNdy8BgAiA1WmS2zzWZz2G2TKOgl0ajXSyI/Dn0kMZ2KpdciEta4Il9ZAW2pOQBIGHgY
      hmdnZ3G/F4ah7Yi0zE4pxdYBAINdr9dgnRSEK8tysVh8//33y8VKilTs93vxsuR53uv1hqP+dDq9
      XS6YeTAYiCV9t9tdXV39/PPPu90uDMPzs3dhHJVltdls7lcrCY8RucEaJ9ZmWXGt/DiOq8qUhWGE
      Xq/XH469wCdUWZkXh7QqMk/RyWx+eXF2cXHu+76IsM9oWo+9UK9Mrz76X6MR1k3YETXlR7uHVkBq
      aheBMca4siwPhyxNU8fY6/WEGQo1z/O8LEuJ9Ql8P47j0Bod+KYyeV4uV+s0TUXaKrL87u5OHitx
      RUop5r232cm5ms/nURQpVRteSJFwOWZmYCJi56yzeWkOh4NEIM3nc1SEiEorsZdVVUVEiCSiXKsp
      u06Ievv70ZR1+Ud3lrvT/eysvrQ8n93N3daVdI5YWrfDl7Y33vV0tK3wK7KSUmqz2YgrSRg8AERR
      NJlMhsPhfD7P8zJN08XNrXQwxiDAyckJIl9cXLRC0/39fVbkYvfwfX82mw2Hw+l4QkT7/f7q6mq/
      3x8OB1m1JEm+++47kSq09p3jNM1vbxeHNBV3y+XlJSkvjBJjzG6f3t0tb25uptPpeDz2fX11c+0c
      JEmi/QCVds4Zx4v71Xq91po+fPhg2Vl21tr7+/v7xepwOJSmGg6HZVmenp5GUcJs86K6uro5HA5R
      FE3mM+ecbOOiKC4uLpwFZ11ZFNfX1+v1WiZ8NBr5XsBcJ1r8MruEGH+cAKwDWGMBGBQzYFmY3PB2
      n96sNmlpLGgimo7iOI57UawQyLFipwg1s6dJI4lNvF1ZZluVcZGlWZYV2SE7pK4suKrK3DdJ1Eti
      0p6zTEhIiAzOWeyY3V7aM093VH1AjnKdOptcxDKxoQFhEAS9Xu/04jyKot3hkGVZY0JgABj0+kmS
      KI0//PBDmeVBEDCzMabIq5vru81mk6YpABRFIRtsvV5PJpOTk5PJZJIkSZZlvu8LfrrYJ/I8B+ui
      XnJ2djaZTFCp77//npnXm01hrDw8z/OrqyvnXBSEzrGz1WazTbNiu91KfecwDIMo1Fp7lX9gyMHF
      YTCdTi8vL/v9fq/X2+037tUIvba1k1zPbdcL+ux0i0lRay1Sj8g11lrJdhWtobUeGmOKotqn6Waz
      2ey2pnLb7bY1iYg2hIgS0YmIcrs8J03TNE3lGABAlmVCcOM4lisyWWnTlFKTySSOYyGa7UjaIBYZ
      ktjXDodDHMfyQCHQMuaGUtcfLpN4RHBfEs9fP3IvUf+39//sXUek/L+2dbVgZs6ybLPZbLfbu7s7
      ETfKslyv14fDoSzLJElKa25ubr7/z78KbpHneUWeG2N8X89ms7IsD4fD1dVVlmVFVcrSixh1eXmp
      SQHAx48f7+/vd7udyL9VVS2XyzAMZWMwc1VVu93ufrXSWkvRgJubG9/3RR1crVbX19fb7VYEDmtV
      nudpmud5Ph6PBfx6u91++vRJJOs2J7Asy/1+f3NzAwCVNbLHkiTxvMBae3d3d3V1dTgcTk5OBuOR
      7Mb1eu0q0+v1+v0+M2+32x9//DFN0zAMpdrk28n3EYlsrzgn0gM1o2JEJqTSVLtDusmK1faw2u4d
      6ag3miVJ0h/EYZBEkUZHzmoAD4HQonFIQHV2V+1FZQTQAyFneXbID2mepdlhn+9toE5L7anancEy
      AELk56yXv7hx09orgrrleV6v1xuPx0qp1WazWq222621ltl5nif1OfuDZDabbVdrOfuyXswsUONB
      EIgfVdjq6enp+fn5dDoNw1CkhCiKRAPr9Xq9Xk8plcTJfD4/Pz9XnlebbqylNM+rsizLzWZDCLvd
      LvB8APD9wFqbZsV6vU7zQilVWTbGMIIxZZHlCK6f9OYn09lsOhwOkbj1uxznGbx5k+iWNBzxUrF7
      inScJImE6wq+e1mWVVWJktJSxtKYsizTNN1sNod9poMAEbXW/X7fAVgJ11Xa9wOtlfY8QCmh5YrS
      VKW1hmWdwigZAg0Gg8lk0uv15KVFUXz8+HG32x3S/JDmvb5NSEOdr+WqqqLKioFea4VEjk1eVJvt
      /nA4GMvDNNde0OoyVVFZZ4hIYW04EouVYLB2JoEQCcA+PUivbL5X/vwq7Zfxht+0tZwPAIqiEEvC
      u3fvWhK2XC6zLLu/vx+Px3mer5f3aZpK2cY4jm9ubpxzt4u7+emJtVbKnI+nkyAIPM+7urpar9fr
      9XowGIR+gIiLxYKZz87O+v1+nuf39/eS7iHacZz0K+PyoipLM5+fFqZarVb7LF/v9oNxWVXVerdP
      syKKe6PxdDKdElGvP8zy8pCm+10aBjEAXF/dFnnlB/54PI7jnpwC56AoakylvCwkCmK/34dhzMyr
      1Wq/31fOemGQJH2tdZ6Xu91he9gv1ytJDry/v7+9vQ2CYDwea99DRYJkAM5KdN9RHnW3PV1ZuWLF
      IQTKWlsZZ4wjInCmsNUhS9O0AHTDfk8FUa8/DiM/IIp88KkkZA+Y2ChkxVZ5xGyRG8wFUgBgEUsL
      niavFw/isBoMsnSf7ndVkbVEFhEJFUKDt2CPReyvsrvaP52xztSCpijZ6/X648ePd3d3Qs193yfA
      4XDYHySt78Q1uWOt2U12l8gEFxcXJycnw8E4ifvMLEHlo9EIAKIoQsSqqm5vb1sjcxxG56dnWZYZ
      a29u7ipniyLfbrfp4XB7e9f1GCEoZrYMzsJ6ewBgPwyMKdm6JAomg5ECVETsjFaeQhK3KCAhqi6z
      PxbGX5ilF2Vz8RgIyRaPKEgqh1IiEHWjuYVbep6nfQ9BFcZYqItx9Pt9KYoqHN45FwS+PFDsMKIi
      ieRORHlWSnWPfr+fJIlIZ8JCAECQ4CWVVsz6YmBl5jAMhZH6vp/n+Xa73e12h8PBGBPHsfAkoTW1
      hq4x8HzPU+Lm9nz1eNs8tJcOEnTM669vx2cf8mva/yKCOTwZiSxlHMdxHEuBFfm5WCyqqkrTdLVa
      HQ6HMAzn8/l4PBYda7fbMVgRw5VS/X7/5OREZIg4jj99+rRYLKROrvDs8Xg8mUwGg4G1NooipZTE
      illrjXECiwoAw8kYEZVSd3d3NZJ1UWRZFgSBVH2M4x4iz+dzka3W67UYskVTHI/HpyfnSZIQ6aoq
      ZA8rpabTaWkqgVddLpdiWtvtdr7vD5J4NpuJoVY42Wq1vLu7i4OwLMvd7iCpKxcXFzLsmhECQGu7
      +xLcREaQaLc6kqA0lpmIgaAoKmYOAi/xBzoIlRdpzyeFAfL/x913tjmO6+gCICnJuWLHOefG//+L
      7t6wZ6anQ3UFR0kkgPsBkiyHcoXuCbt8ZtwuWaIYQcQXmQMiIWGyzHbKogyNAzdZmh+LrBNF5zyg
      OnDo0TskHGSkVRXykIWssZlthTM5hAv7odLXw/TJWecyZ9TAsjOLGNKJWNRPizDecGzGj4/H46qq
      VNXsHKZxjTHe3NxUVVUURR1Ls8QMBgMz2Jyfn9/d3RnfYOrBy8srS1q0XC43mwocFcGnlLj1irZV
      FGOsyooVLOgqz3PvnQseJHiC0bA4m46Hw0GeB3PYgy1jtGuuh877eTssR8mO7w9cn+LYUWY0vVP2
      m1JF2ggOUy0pITgyTZONgl8unXNZPhiNp4PhOMYYa64k1pw0oXMuxqQKImo0XQlDkYd8ICIUvEcI
      RR6K3LI0UfAU/JTPyljrHKPwqtz41dK23/JhbqeCnbrT6fTs7ExVl8ul0fq6rq1VZtO4u7u/v78z
      al5keZ7n7969OT8/94F2RxDMbcui+w6Z7pdqVP6E8pcw5n01iy0Mi1Q+Pz83CXcwGJRluVwuzXZi
      /MHFxcXV1dXFxYUp375+/fr12+fFYmFnQAjBCL0Z200WtD05GAzsGLi6uiqKwni0lNK///u/28pk
      5tuH+8V6pYTmlBZTur27W65W9a+/ckoppen52fW7t8VoqISoOJ2eLZfrGPn2/r6K0Xu/qarZbHZ+
      eTEej82cU9fJjGbB+el0ao7wd3cP8/myrpP3vqqqi4uL6+u3l2eXRkSGw+F0Ol0slzc3N8N8GGNV
      bjZvrt6+ffv27OzMbEisSgduVJ2T4iHeUf+6mrMNUlXGzaas6xqVXPCkICwCOhwORy6YMYBcIB8Q
      FYUBlJkTiwKj4RGoUusRT4QISOgQURGEk5IKiAcgxLwIhZ+MRkMV8Z6a2Htstbdb9wroTqnXFe2V
      vfV2WEylDgeaKOlhNmRZdnZ29ubNGzNdVFVln7au7u7uLDNc4no6nb59+9YUMmarm81mJl/+/utv
      i/uHqqo/fvyY+RBCyLJsQhOYTERks1yIiHmp13Var9cK66qqHPnhZHx2dj4aDUMIiBocFnm4PrsY
      DYekIDE5jyCpay0iAuDRITwk5d13D7s+CV0xZbftQ9NN20U7jUMIZgLt3k2EIYQsFMakY+u/ZTwI
      xwQA48kwz3PzaWkMweZPFoLhJJhdAnpBetq6GJqEa8ovY9M6fxt7XZcn0GSlztZsDo6IWJblw8OD
      8YYh+Bgh1XE+n9vueZNdGd/X6Q1a36l9e+bh4J5el08y7z9e/hI63n+1TaWqhhBms5mtAZsCm+uW
      N/Gmhh6NRp06UkTu7+9ND2ZuSykl2ycAYPEXeZ7bU+fn56afMcbWNO+28bz35AIiVlXVCWRZls1m
      s+l0aobZ4L3x9RcXF42nU+KiKExp8+XL18ViYS89Ozs7OzsPITgKiAkANpuNqlpjgNBkx5ubm5ub
      G+/97Ozs6urqzZs3w+FQEEzNaH389OnT58+fVXWYZ7/88+P1mytzBrMRE0SHCAAO8dH4qwOjYnN8
      AonApq4Xq02MMfd5cN4TIeJgUBABOq+I5INzThFElFWjmGc/m1FRuDmJBYGUENUROceOgiMoMucQ
      yTL5KYCK5QQhi6hiaQNgpWUfGXR7xv/IyjxkzKGl0T0nlsZI1sYWSJf7rVOzdK6BFxcD48RXq1WT
      tiIlc+iwyp1zCmz2bavw7Oysq01Ebh9u1+t1PhxeXV117EVBQ1u9C++cc2ZNrar45cuXX3/9lFIC
      ouFw+Pbt23fv3p6fz4JDlQSiwzwfjQb97dPvODRxdnRiCNs7Ww/Fo6S8OyK898aAd6/sPD37j9g4
      Qhvmk2WZo+B9ptoEFjWSTjbIs9wQnu202NRVFHbODYdD7/1ms7Fp6v8HAKqASN4H53xdR2aJMTFL
      luWTydSkp9VqtVgsqpRq5pH349lsvNmg96PRaHZx4fN8tVotNxtBGE0n59NpjDHFaj6fL5fLwWBw
      cXlGRCKprmsEc2oMRNSJOa9Yjnhg3/9Z5Y+r+aXFdlp3cBZF0Q9+M6cO03uYsnI8Gi1Vg/cGqGI5
      t4whMKtGlmVdAlyTsSw1l4Voj0YjbMNKsU2dHmO0jAFEtNlsqrJWgfFoQs6T897reDz5/PnL3d19
      URTXb94W+SD4TAVYRVQIKSsG+WAIRPd3dw7c9OOZCdqKIKCJuarrxWJhCr0syxRhOBxeXV3d3d1t
      Nhsievf+vR0zRCRttFDnOnlzc5Nl2XhwbdaCLMtYhbsY1xb1qMeX75c+T9Cn+TVzYlUEFzIXchcy
      5z0R2BgaYKlTkSQxcuQUWZJwTFIrJwEGZINZJxIDKEZBVQfsnXgHw1oLjyFznpxHctTodMFg6lFV
      BVUARVssXTjmZv7ShXqUbWrZLOyvAdQtpKt9B6ODiTWx8ZSNU3VWnJ+fm2KNmc25xVhAu8F4881m
      8/XrVwCIMb5///7y/CIP2Xg8nk6nVRlVVWLSxBY6WXNKNZvyeV2Vk8nEbH5lWS8Wi3wwGDIb0ERi
      jpxGo1HmabNeLueL1Xz+/Uano/H11cV4OukIuj4eRvTYMNrgbHnzvZ875zD0rggZeucAozCKlrHW
      xNDHP9EGftlY8jzPnc+890RQ13V3fprGCkkdoOaFiEhMiBjIGfp7Sz2tMVs1WV9i6rh+AzUOIUyn
      U9Oo2PY2Fb9tpI4/MrJiqtWiKIbD0Xq9SjEaAv1ms0lRENh0uwA0HOpgYAGoO1tsb40+WZ5kzF/N
      tv/ldNzKnixMbSBPR2ofHh6M4R0Oh6PR6EsLqehD6J5yzhH6TpCyyIOUkmX/Mu/grcc6YheE+fDw
      cHt7O5/PZ7OZMbx38zv7ydTudrMx8qvVysiBydQmF1p8ZheBvV6vHaLzCG0cinmzbDabzaYqiqyR
      MDgZC0JEZtFpMrj3AGQAwExBRZ7/ul7NiHwWQp4BQORkQ+eJHJHFip7Oa7jDqNq/goINilOWZZ5c
      CHkj9Rp76h0AROYyxbJOMUYBiEkiCCdlUAVLru0UiBUAnRCqILBEVWIJKIycgssVfFBPLkPKiEAR
      QZwqgJgfiwqLCCKhbqXqZy9Qy+ck7XfL1ScAYKheZplFAGx97fr8qnMu5JkJeRYtbEEwxlCbZrwb
      OkvRaVY0Q1mZz+eI2AAZDofL1XyxWNzf3xuhB4DxcBTy7Pzs8s31OkVh0GxQgGsivsqyNDe8GCNz
      HA+GdjAgKhGNh8VwOPREkTnW1XL+sFovOPjFYvH590/L+b2yXF1dhMz5Io+9EH9V5Zb0PH+fe5AW
      Da4jnQgMCuQF2GdF5t14OPJZAFEBlcSDFOuyKssSgFQRBYEVGIxLcs4NhwMXAjMniYvlAzNXm7Is
      S5AEACGE8XAkiRWJIzugzGdFyEmxmTZSRAAU14ZxJpEkoimpCiKE4EPwo9HQzlXzK394eLCTw7Yr
      tmYQRAw+jzGulpv1qqxTjEnWq5Illqt1jLVzIUYVIWZdr+vv3x8AQBV9yJEMTntHCrGYt2bH7pjv
      FQBQsF2e+z7pzU0N+r66F5LxP1pd8/yy0xJlQhTun+5mrsHNprp9uP/69VvNcnZ2Njs/Rx+UnJJD
      8kkhKTjnuE5qiVcYQNCht+Vcbcr5fHHz9XtdxrPp+WxyNixGqKSiIChJF4vF71++3N/fq8KbN+8G
      w7FhnNapJk+D0YAI67pSlaoq67qysV+vV6zMygLiyDl0iJg41rFKHAEVEVerpUUOWhR4ua4e7uaL
      +WowGBTDUWQh8ik12dkBABHrOm02jf8yIppov1qtOHJV1gCQUtqUZUyJVQI6APEEBApiIGNg6LRt
      nPeRMUdEABLhJhRaQEAlpiy4Ig8O0BnD6pwiCpEAJYBSZFWndVlXsU4paZsBOXjqkDkAm5TECoaQ
      2pyXLLFKUqZEVcoyX2Q+C34UwtBB1mHZKwOIIJAnRUBBanIwmWrmOAOEiLZ3rCuoFoQkAOrMFEeA
      KsrCMSkLKRrkuQNs0p4giqhzvhiMQlZk+YA5CnMIWZ7nDlAZJCmCI/TCkKIIb8qytPCF6fl5MRrl
      w2H4+rVmfvvu3YcPH87Pzz5/+fT7779/+u3zYrXJbu6mk9vR8Mu7d+/G48l//R//o0ppU5VZkZGn
      lJKiAqdytVwsFsyc5/lmvb79foOgVVVV5Xo0LC4uryej8WK1nM/nm9Xi7uabcFosFt++fXu4v83z
      HIJ7U1UzFgE0Tz8ARHLoiEEBnKoAHBF0TCYWESJVYCTdsYLurR5VZRUQZBWn2mV+ATAgiGbpCQMz
      r1ar5XK5MttjuSHvWMV7n2Jm5HU2m83GE1V1SCEEAmDj1ln8wGc+NIj+2MRxqSpLNMbfvGIM0FJE
      TBifz+cPDw+LxRJ6mLedkV1awA0jMZ2OyMAzmRnRDQaDoiim48lsemZ6Xkfeu6CqCGRgM/2swa+Q
      Fv8mHPQfWlSbDA7Yg7KyGKL5clXXsXNfsbADAEDvEDGE0GntENFUWzZN5v1iAThXV1fX19fT6bQz
      dsUYP3/+/PXr1+V6FUK4vLw0Tny9Xm82mxij6UPMgLler29ubhDx4uICAMz//eLiwn41ds8Sx5hH
      fO4DMy+XSwvqs0dMPgAlWydW7ZcvX6qqMnHh7u5uNpuZMp2CBwBmXiwWJjoMBgMXQlmW379/R9Lp
      dBocYUtMe8Gc2hdJu8Wj22JoNmZMIu9cUAVHho1ChveFqkbKVWuWTUzrijf2kPOmsRyEkGc+I3Sg
      BC1qFZAigaIqJpWUhDlWsU4SlSUmEGBmRVEJfuQwAySgJnOIwRY82zVR96L5UbZCOSopJu2X3ggw
      qIgmFmYHmI1GHz58IO9sglRScP6X9+/H4zE0iJhqigtT2Zmrq/lZVVV5//32+/ebWFYh+PPp7N27
      d3lw3nun7tu3bzHGT58+iWhKfPX2zXQ6/ed//S91XYfgR5OxBUyYG0/wflDko8GoyLLlfLFaLG0d
      zmazybB4c315fja9Gw7W69Xdzc1itVwtlvPlwjscTyZX19fnFxc+z7iqBEEQ3AE7fkicu7XRLCAA
      APBqzkittktVURqMYxFJdWRMnlwHaF6nmFJKdeyHLfWihOrENTMrAmuD5oyIo8FwNptezM5ExHKn
      qkqMsapLIiKHSNCv0CN5JItzY0kscbPZLBaL5cN8OByaE5JNj0lJdq5YzJW2Widqg5tEk2giB1nu
      Le6gGGRERAoxxuCdD80Z4IPL8qCqzhOCgirSEXL8GJusup+JQnXHXeHoU/+hiw2y862zHSKzrNdr
      CyBKKRVFYe6G2MLSdogZ2qrgUkop1ZY8LDGryMPDw/fv3+/v7y+vrt68fXt+dmY+f4gYY7yfP8yX
      i9v7OzNyvn//3qJ+TFHmiIaDQZHnCFBX1Wq5XK9W3rlfPn60Btzf3S3m89lsZqnPzNQ/n89DCG/f
      vg3kDPl6Pp+PRgNV3ZSr+eKeHBSDBiLCgEy/fv1qDovOueVq8/DwMJ1OsywrnHOAMcbVfLFeLlH1
      w9t3IlLX5efPn32gwWDg0LySm0Vh/xBRH6Cjv8y69dNtXjMxZ6DbS4CI2GTBVq1TWlX1uo5lHVnF
      OZdnmVfMQhh4nwfnERxCk7YPiBWBHCAJAotEr6zkxccY67LiFFMdFZXZxeixKNSjB0cQFJgMLBe0
      y1L9ZGkSxB3sCVZFbMKRjGtse91oWRGROa7Xy/n8YTgZF4PszfXlcJAbj++9H41GKcb5ejWf39d1
      mecheBKOy8XDp9/+tVrO6stLIrr7/u3m29fFwx0qKUdOUTmeTWciSeuUuP7+/fv3228xRucIPV1d
      XY2Hw1TkqiqJN6v1ZrXmGJXZE82m43dX70bjwWq1ur39btaUy/PZZDS4mM1UlVQ1pdtvN3e3N5vl
      quY0vbi8vLiwxg/zQmJCZVSDPzrYAAAgAElEQVS28x1UHDSKl758c5SM2EXfJzd7RMqcwS2azvw9
      GsW0MIg650aDgQ2xGa9yH0x7OALn88xi+Yy7Md9BC8YrNxuzQsQGost1ICrQWgDM6dCM19aAu7u7
      +/v7siyn0ykAWFwoEU0m44uLC0Q0W5lpzRoS09riAMC0+VmWDQfjy8vL6WwcQgCW5XKRYiyKorPf
      Whxwj7lLewP3Uo3H0c35zEfgEUH1Lyx7LbE5IrfN8lOW1f39/bdv36qqGo1G5hhu8lBn4TRvRdOB
      mj3DRC6jyMvF4tu3b/f39wpwfX1tfgXQDkVVVRb7Z+x2x7abyaRcrc2xjIgMzuX29lZELi8v3717
      t1qtvn79aunbTXmKiBZ/lFIyp0kHaM6s3vvxeGjhC6vVyuw05r1gtD6l9ObNG+vd//q3/2OQqvZq
      RFytVvP5XFUvLy/+8Y9/VNXm27dvt7e3o/FgMpn46YR6uGAAgHjEpxgOFgMRoW8InLbYXo2ChkiA
      FDQqVMyrql5vqkoSAJoT2jAvHGiGLiAEBNckYDKaIQjEKgrA0qC8E5HlvA/oUl3Vdc0cyzpVKSIi
      QJ4FAgDD9gVhUXWPcCxHF3BLmKTt7y7TQ4jgDC5YABRRkZJwHeNqtUoqCjSdTpVIQE0iBABg2azX
      m82mXC3vbr6LSJ7n0DpxzOfz9Xq9WCzyPJ/fP1TVBkSdx2pT3t7eZBldX19PRuOLi4v5fG6xLIvF
      4vO3ry4LLRwIKoI5NS7ni1TVHnQwKK7PLn75+H46Gt/e3mqsLelU4ULhQkYoiIV3hKqSuI7MHMiN
      RqOL2dn7N2+vzi+gzWqp2mTZ7MS1TnQ7OpJ94u73aM32VhFlTnVdbjZVjx+w3euJ8jwXBgTXebcY
      xVQE51w+HBjsUYzRe595Cg6FzblwlVJC0bquRJL3RZZ55zCJiKZYVpvN5otCVVXmJJ7qWFXV7d1N
      HUvz/w95vtlsjBbEWFdVqarr9WqzWYcQYqxjrAHQPCxTSsvlElt4mU25Wq4CgYQQUorr9RpUEZU5
      Iupms1ou5wCQZT7LMlV1O8vzgO1oUPH2r3fD+Ap+/FCqemkNf1pRVYNe0laeNUpn0fPmJGAYobZS
      nXMeiRQebu++D0cSk3Pu9vbm7u47EZl0vFgs/vWvfxkJnkwmIrLcrDWxRVpXVfX95ubr169lWQ4G
      g9lslue5KUPNmT3GeDa9sLiz1WplkC++dUwcDAa2n3///XfzgDRvd4sbenN5YdqY1Wrx+++/397y
      aFhMJhOzhpnLive02axub2+Wy/l4PH779u1kMnHOfb+9XS6XX79+HgxyY3FMx0KEFmpY16Wq/t//
      97/v7u5CCJl3XZARtKS573gHB3xASsnsZI5Cw6mwEDUIFUquYclFa9FNWZV1HYWJKAu5+XFmwXkR
      p0wCAuoQCB0CaOOSoiqxFq04JWElMysQERVZECJProq4ilVK9UNVI1AAPyAISg4UAAkYX7JcG86z
      GYGu1/ah/WImOm0zR242m7v5w/fb+yzLtFWlMrMDyPO8yHOJKdblcrXK81wTk+UyYuE6Lh7uHu6+
      G5DfPz6+70zlq8XDr3XpiYoiM09Pc3rc1Jub71/X6/Vvv3/CRv2qALBerzfLlbJMRoOLi4uPHz98
      ePdmWAwGRVbkrnxbp5QuLi6mkxEor5bLm29fvn3+cnfzXRJfnp+dnZ19+PDh7fXVaDBUFucQtUnv
      qcoAQm0ykL1zfY+k9M+/bSzoIck3vxFtvYI6p8sk4hDNw1dblOeOvTLP8WI4COQAYLVamddOnufm
      6blarYgIWLoQUMOBqWJtXLkdiQ8PD3aoEjTOmJPJZDKeXVxcUPAhBHOWMP2UacmN77Pp74Bl6rpe
      LBaj0Wg0GpkCdD6fb5Yr58gWx3QyMu83e9B0u9rgWf9MWvwiyv731Mwc5RGccwjUkfIvX7789ttv
      BtjfAUPneW7YW9PptKqqL1++/Prrr+a3t14vVdWSAxh00b/927/VdW1a9f/7r383o9bV1ZX3frVa
      /fbrr1+/fhWR2Wz2+fPnm5sbADg/Pzf5zDk3nU7H43FZluboXdf1P/7xD/N4GY1G0+nUYAY+ffpk
      95szeKfcV9WLiwvDlvn1118NhomIZrPZYDAwDfu3b9/qur66urq8vBwMBt77jx8//utf/7q7u/vt
      t9+qKjrnrO+z2ezdu3eTyUhkwBJv7242m83vv/8+GhTX19feZ/BUaLG2bl2GhqSqwWvjBoqCoAgo
      SgIqQFGhTFzHtKrrJOKCtygQIgKFVMdYloTiFByCBgc+eAoCEllrThVLzalOkoQFgYhc8JkPmc+C
      8yEnImKCdQ1linNAUmAfxs6DWQEAQRl+gqmJjHwLKACyooBaSmsGpeB9nkmszO1EW0RVZibVuq7r
      qkLRFJuwgw68z4Ielqu5cYrX19fX19cWrH5zc2PzVW3Wg7wJhBwWg3o8hk0JiGVd8aLtl7LRPVIo
      Mv/m6vqf//zn+/fvz8/Pvffj0eDy4swQQEfDydnZmYAaJky5WYnIbDy5fnf97t07C0g27M8OY0pE
      DtcA7B7tj2lT/GNUw5MbFgOCBqmqKd5xahJQqGqR54QokphjTJVoyoPLiiLLMvIuBDfMM1I4n85M
      tV3HaBH5eZ5nBlnuXedJ5pAyH9CSBiTmmMp1AzdMRFdXV6PRaDydWDhScLi5OAsO7+7uqlghuNFo
      NB2NVbUIGYqSauZcEULJzHVNw+F0NNKUNsvlZrlciRjwwGg8sDB0IhBR53AwyM0HUpVVzby0DTM7
      zimrrSeE1or16rJHLv+GBH2v2JGM0GRR6dBLzCA5n8/zPPeeDCNpOCyGw+LsbPrwcLdYPNzf35qe
      7fLy0mI7H5aLh+ViuVnXdU0Vravy9uHe0O2rFMeDoWHtGqab2TNVNcuy9Xpt/oLDYTEZDorg1+v1
      3c23erOeTCbXF+fn00kRPAC8ubzQFKv1anF/t5o/OOfK9fry8vL64txgIQDg8vLy4eGhE8wRdTgc
      TKdj59ACTzabzXA4fPfuzWg0MDfEN9fXpkJcrVYpfSKixWJxdXV1fX15djY1be/5+fk//vGPL79/
      Lsvy4WExm51DuyeJ6Cg+eFfstj0lMhi0UOt1JSIV86as1zFGZhcyQyMh9MKcUtIUpd4gKIg61MSe
      Cw0eEXEjXMaqrCKDAjpBMD4NJKEoIHnvwDvyuThFonVVVhwfNqKBMS/GIXhxhNwP7e87z+9SKOrd
      008j1TMF92JK++MQsuzs4vzd+4+jxaKqKiWLmWxNZQre+zwL3ntNrKrj8fjs8srnWQhhNJ28bbFn
      z86nv/zyy/v376fTqVl3Mh8eHh4mk1meDwLo2dlZVcWsGIw2lWly0BEqMHOTp1vUebycTT98+PDL
      h48dTAXIkNoDxpZ3WVd5nlucsyien59/+PDh48ePo+nEGFlEtO2uDaSMR3RK29Q6p4l7R9Z38oL2
      WQNznjV1uWtT9hCRaAMVa84hAKAK2OIjmhMuGv66DzAajUYTU2siorQRpEVReCTDeh+NRl1cX1EU
      BmHR5agDAOuwYUkPRsNuKV9eXlrwtIg4CgamYzydaQlND27IvQbJZGeDZREcDAZZ7ofD4dl0ZoQA
      AIzPsvQYba/3k5a9uryCOv+tCPrRETChzbakCXPj8diwSuzUz7LMezJQTGOUTFv99etXs8oMh8OP
      Hz+enZ3ZIrHM6BZ4aZTaWKrRaDQsBkVRGDvcIeBra+RogDgmE4tCsNk3KF0L2LH2D4fDi4sLy+dr
      gAHn5+dv3rw5OzszLxczAr1580ZELFtpCO7y8tJgmADA/Fhms9nFxUXn4jIcDt+8eQOI5gthEp69
      3XzbLbTqw4cPFoEsLYCw2Yf6+pbHxt85Z5l9vMva0McuLygJQBKISarEVVWhC8H5PGTOOWDgxBIT
      xxicUxDRGEU0ISQGL4heEKJCBCFsMqIpsCSWuvLKJAwaPWTOO8EMUVNKFcd1rBxoFnyugUBx3wlg
      f6k8fxNJUzS135IIg45Go2u4RnB1XdecvPfONR5EqmpxMN6R915iUkJbOWbwuLi4cM69ubwynfD1
      m8vhcGgDO5vN8pCZDYaIFAGdG09nm7qqIyOiuf2gQkrJUxcHC4MiuzibTqfTrMgb9RcqOQei5J25
      4jvnpmezj/xxPJltNpvpdDqZzMazqXOm5FEitRNOFc0Npz2tnxi6Pfbcd/f1CToiojZBOrArLhGQ
      Eokk70J3f5Zl0EKgm5N3IhxPhjFGR8H7xs4JmUccDIcFABRZZswGEVn8LaKORgPv/XQ8sbVu9Qdy
      3nufZ845h80GznyYzWbj8Xg2mWrPxxxgiG0QSvBU5KHbNgBwfnaWZ9nZbCaS7JEsy0JwBulsHens
      vRYH0w3WaaraKWfogIU/qu1C3Me97E/BiRf9hWVrpekbBqjJwowERDQYDN69e3N+PuvSj5hR2rAZ
      TKdZ1/X11dVkPC6rSlVNCWPU3/bS+fl5B+tmi9DUcZnzKaVBUXSO3tALP+7mbjgYeO9Tlv33//bf
      DA9gUBSuhe0O3k/GY//x4+XFRV3XgNjBLyOIc05VvMPZdOzd+7PZxKAjjOcIIaRU/8//+d+Z2VQ3
      HV6S9zSZjIhgOhlZ9kjr12Q8FmbvHAA4pCLLf/nll81mY53iXlYvROxyCeyNeadIbGxlsjWXWWER
      RSeAVVWXZUno85ANsrzIvIiUVZViRKAiy0KwpHUDMxpXiTnGLHc1Yi0qQEWWDfIiOKfK4BM57w01
      yjlATSkG0EmWiQghr3Wz4jrULvchuMK7ncXbdGQHsMBmwTgkS23RJ1WdAkEAm1SCABBjhSX89ulf
      dSyJMMZYM0cRRLJHiKi1YCURUdFYJwCQyIi1tLm/zfMCnGeQKPz15rYIS1MGmOcbAMznS0QU1ZoT
      ofdOAUV6ucxCoCYznPOk6ny22lR1uvd+afjAjcctADTKJ1TVKsVUJ/QhFJAUVpuy5uTIksk5RFCF
      h4f7+4d5VdeAmNq4UBN84ST96Yb30UxyR6hP+xUOUjATkem4TVpExKCIGXrvVbAjptRL72nYFNKr
      2XzD83wgsqPZsGABbT0Fu1+NfR7kDVwMtVGI0EKsmYONtZPINHHaXtkizFg2rz2q/YMc8YvYkP8c
      BRG9d4gN1pVxrNBwlM2aCSEggIn/4/E4tflajcNFxIF3BrvYrxbaQAmPBABgWat2X905rTOznesm
      nHXrpGMO7HQxGUJEtF2WzjlH29k3xbRZU6mJ7kNENCHP6un8361ye2Q8Hos06d59m/7Q2mnvNSbd
      jjEbpU7cpN2kWntk3W7pn6YI1GwPQFaoYopJQMl5l2WZd4gKEFmZUdU7FzKXZZYdryFPdWJNDE4a
      +6oL3mfBuYDOESEgKRBqE9BHCqpOMIEOPXGWRU4cU628kTQQJkBCMvL9nB2EDSLIca4TAJyj4JyF
      LwDA/f09EYpIStytLpsIBAcAqI1Lc6d/UFQi8r08y9AYBW00txctU4enAIgMKiKJNQpzG73cTEqr
      QbL5cFabR+pJJa6lv0QErbtXSiIiKs31RnXTLl1VNZNM48be0588Vg4H2T/2QP96nzapbj32xEzP
      aInKbZi2uSAconc+wlbZ1zD7u1k9tfVN7DpJRKTbl9rNNliiSS00ysAi7ORqXLWg+wQQ5m1CyPZ1
      rKYIRzCdVMtrNvDHuivg7O2lE8N6esQfv/53UaH0y4l9eLQv/XkEyxSYZSEE6uXktLXR8FwAiEoE
      zrkQnKp2KBYAQAC5DxiyjvgKNjrKHqvSRIf129DNY5aZ9k+cwxDy7oxnjv3Wek8huN01tmWUEbcs
      CACYD7iqAqjx452YIsLtKwBaPWl3tICZ5trAcmjPCctXh21eaegRmr0h1RZkCpozY5/WiyKgE6DI
      qapiSk3SrjzzmfNOkZVBGBW8c3nIgneWUAKBUmRLB4LOMsejA/CKTjEQOVQksvuFQEFQkURU0avm
      iOx8HXwlHFWiclT1TaepWQ5NLCggomHRiHl/qfmSW5wgwCM7oSWgsinXN9+/f/78OyIy7AwOEXns
      qRCkiWDoSArSToXdvLSVb1ngjvIAgBgdU00qqtugVlXpjAEOkIiMy7SDofNtQ+29y/ws2+LQqaqA
      bml6u92s5d77Is90N4n5iaK9031Hb37igcMbVLdeRNBZw3rGVltwnpzs1d8+gojdrd2PVo/l1YWW
      69m2oSHg+93of7FmWE4W6DF32voGQGtk6QBYujsPu/lMOn56AB975NWHxE8v/fZvZ+fgpycr6SZF
      +icxbWfBten69mhWx6H0p6khZI5s50APsacfTNCfuD0q372rvxj2Wgu7i2evUyJiOCq2u5r12Zae
      RLhNjKC7sQ57A9u1uWtqv+PdMda1sEMwVVXXMHrd65FFFTAp1DHVkQUgy7IiyzPnHQGBEiAa39Uh
      UhjEY8NbOREiBdUG/KttiXQnkKqKqPG+BKoiAOhVMkeD4FNKIBqFI2qGZJqFbodup8aqagdi+/14
      ERFQZe9wMBicTaZNunlNmFSdOnWAItywCMzaxBspijIBKAEpwq5PWp8UYK90S0VEPJKqcqdiVVUR
      sLzRCA7a1OSkAg4ACKg9YBDbVB+i6lpLr7BoD0JLVAC2UVF7bfPeDweFWe/adeXg8bK3wHxX1/6m
      pV0I3e6t2qlBFNSc+gHaVdgni4a7Ty093i7lVseyrbO/PRQaT6ddmiKaoAsM63XG99KxW+Vq0hAB
      gDRGGTsd7IBtVT0AwCp7M9ofILIt9/g4/jgtfsUZ8EeUfjO2SAbaXdm5E3d/lr5A05dsmhnh5hRu
      F4ZRw0790tGONoPZdsYRDWy7mfEmpqGHoLQ3X+1TzXHe3dP9uTdf/Qd3mSDpfkcDg5XeCkGBbR9d
      R8ENZQmbJUrHV9Qua6Jb2QVlV7vY/9z7sz8+iCQEEaiUtImpTJHIULedIyAwaq6kkCwaQAWh6Y+a
      EgKQiAKSQ6gV1FxfsqAIgqDIFSdVVkJneE6GoWJHAhF7z1ko65RYysSOcIBCaByu2L5rUHt2JqnR
      m7f9OpImNzivqoPB4Px89uHDu8F4YLBWRB5ICZwtve74REFD7FJlEFQUVALaZh3aWzatmW175GOb
      3rZ/m50XIoZb3FfJismUpt8HlA7H0YpHUkLcWeQ7FLJPeaDVXSPiIAtXV1fmguUIQFkPmIy9xdAN
      2tYK+tha3/9y7Druqvygk4gPmL692nYI8e5wW9nyVtR7CnaoAxwUbZmCbpP06tx/o30+R6g52vGj
      v/YPqr8JyX6s7M3I0RPqRBd2CRBsF+jBPHZfDldLd73/rj5n0NG+vcb0T+J+R/YqebIXuz9tt8Mh
      MYX+adHT/3Qd7L+63+CuO91thzccdrY/Vn2p3L6wqpCrWarEZeIkmnkk70yUIWUQRRVjKJm5Tgl9
      UFCSJtQLAAiQABWBFCJzTFXFRKoIoJwkVoTqwAEhsak1AQEI0IHm5JNXYRDRkqNnzAwtt92mHdvW
      EI+dUd4TBw/Wg8JgMHj/7t1sOq1TBZ3xtM/kiSgLq6CSSGqR1refiM6ov6Iog1F57ZlzbGS66dij
      5n01QHNaoKCCotF3BNoyxE3TeZspHhGV0N5MSkrGVWh33ts91OSyZ2AxG+RoWOSNznAnO/FpYvIo
      Iu7exe1qNkG4D1eLAAbGhdAhNdtfe68/3G/9T9odlO2xBQLm/NShssF2N+x66W4P4c4Kt1cnSCuG
      NcsSusBi6O2ox8Zr76ejBH2vPHnD36E81uXHrm87tYMY1TMmH7BdNs79pFldVYjGzmmPX9vnHhBb
      xZj2FlLrjGT/tE3ePtJ972sw+l+o5xStzVPUPSs9GbnZ7dpT3Zi3hjZA0L1qbT83COO99b6jftk7
      MPY4jO5Kn4nb35UIAhQlVZErEQZF77z34Ah7HScigRg5aYooJJpQlGNijtoE9yMREpGg1MIYNwkT
      OeBYY9KAkBvziCTKjZCEThUCUuZ8JN5wTMJRWJxrIf+6cbZOCQCgtiJzMzLQ9z1vGmzTbnghBG40
      yPNgYjSAEPVnDADAJslTEE0qCCgIToFBCVBASVEInACjkgAbypi2PCj0WEYAQEdqegXdzQNlYpmS
      SQFqb0FQaVT2nZoFdUtMbI6a7ICtyh3JIMR3+PSG7wSzKpF32DqhakfQt11+hLgf0bS02w+7xdR7
      Rsis6rh9inrcPfUwqqztjlx/vXYtwN6x070XEUF3hOKOK4Hd+7tx7otRfXlub0vskF2Uhu40uBA7
      A9QR9OfT4NMH5n+scjj4p++Bdlo7L7Fmyho2Z3fSe9PXr6G3QvZZ2u6LtohmO5pl3GkDgCkA6KDa
      /VQP3Z+iPRXHwQ39xlhxLpgpHjsbu2Eg9yz5uMNiH1n8Rwew+97nxZo2Y5uB3HrUrH2HCmKZMEFY
      xFjO3FFARE0AgoRE5JBQm2hSisQqyqKxlpgI0Tgb7zwF7zQTlDpJwgoTKqeMgcgxoJo6TCmBAoC3
      UGqkoEDoVFNkjaICKCCkQAgWod522TZXb8bBlsnRJUZICgKIGMi3HnG9TX0g6wCAarY3yycYqQYB
      pm9dR9ROwdsufNfRBBX7VRA6Gq+GN4CATxGAHYaS0Og7mn210wttlZxbnxzoHer9rh3dm1sPxYOe
      d9pD1T5lBLDE4qoNJ0WdRLKtv8E/s5YBADbDRF1tnXm+2cTbhjJg/6etQNB/RUNtVXHLEx3ZHn3y
      0dy2nQlF3a4m7GT/noSFaImStqX7Yzuax+j+Ca2N9RGxjbPQ/Xv/ZF7+2Jm905LHrjffeyPSgKO2
      fyFC51KAiMaZHu1cr8IjsVpbEmBcXrMOD1q1bUj/2f337fVXYdeuuFtfvyYAMCcUMBV/qxDuTAbQ
      I/oAYKPRtUsPlAl7A9vVQESsYtyogIoKINmIEoq5HiCijX1QcMyR6+QkDz4jdSlmBAoMBCBOWAK4
      wuWlpLqsiHzNSWItmkA4kPOBEzIq+CwElTLWMTIKEBGCInrvvfOZEjKgIhpIooACuaQiQEQeISXW
      WHPlnXOAKqCJUEXMHQEFgRRA1OiFmlYfAEQBVWG7VBrOXc3vTLuBtgi1LSVt9NTd+FF/DE9soob3
      1ySg1IrnCGiuEWgN0HZGzAcHwJRR2JI2aVjA9ueninYVGiC8dczIViNDaB/uqU+7T5BvbKG/7c9H
      /c0fL/uuvo+96clygo505XTNJ559skl78330/v9MTPffubx0nP+IeemzLI/f9RIM7+e97sRPtpNZ
      lVS5ITS95Cm2+UVEI6swMJIjpx7YAbAmVQRE51wIVACmBMxieEoiCqiETgkZlJiLQYGsQI58YLXo
      R3WgBWHmyPuMCEBJQACcpR9AREHzm0Ewg6MAq7KKKpNV0iV+fhH8+TPG7WDvv2BJ2MB2bBQqQKe7
      QKCO5Ws4ULDrIMaYN8y4HHhqwMG0PkZkdOcSg4J9PvbgM8srqPn2fV3LX01VT5PyJxvw5FteUfne
      DD2pdviPXg5P/tOszR/UgL+ubK0mbXlW3w/37Y90ZH/ARUFVQJnZQie899RSx76Aw6AiSSQBCFGj
      eBQVBpMFFJ06cJ4g96qJEyODekQicYiISuTJO2aGNp7byIpzLlAT1cEKzEoqgKamZlVVEgViUU6N
      e581WOkYUXvV2Jw+83b35hN0prvzsSr3tVvbMxUAWlq7/Tgmpvf+3GNzj5KR00Lkc8req09R8+ew
      t6ebe6LCvWcfe+rJTXJidF5NyuEpiva6mv9kFcorirZWhP6VP/qNz7z400un3e5e+iMT9JggvFvn
      c+u3homKxd+3Pg9HWohoXnTbEGhFYFVwZMF9aAmhADJy4BtqbqY2AjE/kK3qxlxfYk1E5AK6rEqR
      QUEJlNVseaJJWUSAUBQEKSaoE5vbWTeizT+tUWrLo6vuqNuO+QA/ZwHsGRtOP/HSCk8Rsa1i7QVL
      98kGPE80fOLZV/DmWz3vYRPbK4f8zpHyswj6yZacevtzbvvPXU4svmcu7peWxxbrc15xlOt5Zv3P
      qbl7/ElZ86dwUkfr6Z8uDX5ITzG6w68oAIIiWnpOB4ToQJGbCBdkQlFU+19VFB06yD2KAEpj9QNA
      VUQsy1JVy5g2m01VVUhUx1CHLACRefuJMe8mNHCTIxtAkFjIiLvKvgVrt6c9DdJuMvfnjGc78o8N
      5inF6YnFrK11/bHjvI8KaQZD7IWk7pUfFNG6Zjyft+jL1o9G9j/ZxGfy4Cdk2GcKHQci1c71Z3Lu
      h5qTZ5bH+/Lo/ae36Ive/oeWvVYdFRj/uJe++sHny2pPlo6n22P0+ldeIT30a+iz/33/y8fsddp3
      VW6fPXqP0URREkBVVEBOGB3UyKjAMYrDBE4FUFQtDAaghDW31ByEVZUssFZJVZUVAAI5JTQ3mKiC
      Cs6gXRpvYFVFIgJEQufIo2hkETFshMbpuSV3j2w3lCaTXC9N2kvl+90xP3JPV+cOeendY599GBaz
      cJ+mEWwOKY+QrL9QBH+l3vzE1jpKGvql5wXR5ozucfSG+blz/zEXt8fe/pyfjtazx5Q9ubD+VnT5
      FeWZXPmJO//M8ue0YW+l/ZQ6d6m57nXkkB3ZIUCikljgyIJsOUoSIFZgdcwSQUqJCkqQoiT2yOBU
      HTGjICopSkQWELDkk4ZSgkSAnAynnnIfgDwQtkBjppNBaMN2LBrcwBYQnaKLLEk0JSE0VxXsaDSi
      OW9ZWOSWP9fWpxvo+NZ+xTgf/fOx2Tw17ABPGiT7VO6owvlHynP41MPGgMWCnr7jx5v1igcPJaOf
      ohjp6zG78TohlL2u6CNqir8DWfx7lp84Moe79zR1fmyvHq6TH2nP4ffHSr89pmlR3AGf6TevrY5U
      QATqOlESBSUQRmGGhAigTojAOUAE8qSM+zQLEYsiR0SHKEAOEByRAgMjIjpyFlGlimjJMaSDqBIk
      ihKDR4nmfw+7Zk/TyDdSzCoAACAASURBVFue0b5by/ZYOkZqf0SGPvrrq/f1Y8/uUY89AvUncOiH
      5Otp3rxT4jyHDe8kxIPO2GoA6B3OAAYBB9pL7tOv+TndeEzGOTwwT4/vM0+Lx/iIv1C8el05rRo+
      oex67BH4gUE43Zjn1PAYa7Z35fki1+MS/REm4DFNCOyuq9PyeHdPl1RMEVhF5Xg9qqptLmZPFCMD
      2XckEOdAHAaXqQIIoqBXJAeYhS58WllU1RM55wwZTVlYARVYEgBmwQsAOQBWZgZhEXFEIThUBVAE
      IBXUiJAQmACInDm3YG/NiAiBZckQANWtWP7oUJ/WqDy2+zpJ6Dlb/vgbd1nzbc09fb3uPrJHHu2R
      PvDOi8pzCNGhasHKPjU/lFBOr/sTu2j3ht5IPW9/HhVC+z89OVL92/rzvfdgX0F5uvxH57KPSjlH
      53GvPIeUv7pJP3IQPkm1n7z/9PXH7tzjK0/34kXjc4j0233fO4rQkDQUAIQInUPvKMt87sihCgo4
      n5xjgVQn1SZKh9S74M1DhiGpqiMiAuO+GUA5iaoqJiMQmRMBjhxjBaKAIkgilBeBxHwmCVRQmEAI
      sR8VqaqmgjaWzZrduGn/APPzyKQ/UeMrGI7T+pnD74eE+BXL+6WP7PDmp5ma08fmYzxyv4jFi9pt
      u5XtVW5GEfPVf1LPdZqR3yPijwlKe8fD0fY/9tMhO3b0+tEa/hJG/uhRdDjdeIDV+VhVP6j7On00
      Pv9wPcojP8aLHOPN7crhLOMja0yPEvTDtr1ofLrV2DxI2EF6WTEvsV2kR7s/OUyOUnAQPGa5K0II
      qEkiOh8RysS1xihRFEkpY/U+d+hFRVVYIqsCIBECikoSjtqgwCozoitUtS7LqqoIMQSnoCwMwSEo
      ETGoSgIVQnXoDveFoNrwakcHfqCcePyZa+bEXcenEqGFan/iXSeW4pPlNEE7HNWjhNrv/b33/THd
      xYkXH9Zw9LA63ckX8VAv1Wz++Zz1D+pef7ycZsBfN3onDtHnV/LMnx47LE8fya9Yrs9s5NHXHT7+
      TGX94ZD2tfYnXmFpFQiVUAiFnJADy6CQASqyKCjXLJVoYkBQn5JlSHAAkFKq6pKIssxTUFBlTiKW
      qAAMCNbUPsycUvIOLZVTCz6DAIDCqoogBOCpS07S65HpRrCFo2p4czQQq5O9O1UOBv/5M/gCC8rR
      CvuV/izO7OhJAO0qOr2Su+9H9OanJQW1VErNXB5BowUAAMEWmOWw5iNbDvfvebIccmGP9WJP7489
      HCjsc/EHc9zUgC+gxaqKj6DL7w7icyr7obLtvhmmnhBvu7Hab9tPP4SeX+FjFPavNlFQp7rd09gd
      3nqw97vrjzoOKQJ20HVEBkMEHY5YHxXSPlUIG3AoS4aMigiAhu8iSsKI4L3zSM55VU3CJExESaWK
      kYgokFcCVNbEmgjJ+YBKtO8uSdDkV8L+dWBBUWdei6R98UWPqUG2JlI8rlw+sUgQT/36TPb8yXua
      O4/p6F9U1evW6h4FPsHC9kmTHurNj1b9AzK1tOhY2lHPrjXPrKJPr5+jxzhRyd73J5kveIrw9tWm
      /c8n2/PHlaP86YvYzD9HjNh7y1Ft/nPKTxnzo3z96Tqf+cbH9s6JK92Ct7zS2gPfP3wK7U4kBDYf
      GCbvUb2CIjgFAsycV0LvvUeqqgRdBq52bYgkUURQRRFNyg4RiTxgkxDV8ueBqioKW2YlhTY5VJfo
      zpNz1mPd6c5RBcZjI/akxPPIbX/Ioj3OgL7w8X557BQ/LM/UYfRv2M8k91KRc08V0309FBBMeDvR
      sleXJ4nRD2p4X9GAv4qgHxuHR6X4fnnmEP2sMXzmjj1dfnCQ+1zCH32APf+06JOPjpqb0XLvTgYA
      BRUM5AMhgqQkMTKjgCNqcJ8ZoU05jCiIrEoESQVFBRQdAUDkRIwhOPQOGYQ5CRIgAokIuuCzPFdQ
      TgoQhbmWPDgRUuWUUj93DyKSxTJ1YLi9Xho7D9DYcF897D8+XzukqZeJ4VB/3b9TDmZsn8S9qgGv
      uGFv9dqfHg5IeXefgVg2UJZNIYAGjF4AsOdAutuTBu9WCQw7UoEIpIV+fJzy6jaPbVd+ZNMe6v0b
      mAX9wzfwn1xOn2cvoI+P8PI/43yiZ0I+dOVJSe5Q3nyyqtM/vUJ2PF1OtG2PoLfaDO02oLHnxpt3
      F/stNP9vQvDkPGjklBLVLmWUObQs8ojCkFSEowIgGoItADAzg6IPIolZWLRwwXKJpCqpKjMjKGIK
      iN57ABFxkpg1MVv4qKCAiKgkVCBQh+oshQbYXmaABoFgFwH8mVaBo+WnwVh2pT8Re5PSkcTnC2p/
      Dn9gZe8tnkEV1Nn4mmdr4zGKSBRTYgvtdc45Z4m9WcUhQZffyjUKMmYGpXblIaJTMeQGVQEBsGwW
      2GQLkQ7Xv8nanpIlJffes0CT5oootYhCqooNWrpCS5HRNQeStjo+MP9W2sGTQcQ2qRWxqkmS0IiZ
      2J9LVXX9fAgGo9xwH03mFBGxbeaBACClhIjmabs3l3uqmL2MkUSGdfqTy8Ge33d/PlFesQr7DILN
      qc2dqhJ5e7uIEBISgljGYRARy/Nik2VJq8gwrfu5Z3tkbi8DsuVcDiGICHNqMyu2r2spoHOuruvu
      WSIyhw1yTkRol3t4Pn15tjTTtzMd14P1v3eEw4DB+8lxukk0zxDTW3p0Cpo7HeUBUFnihp0LnnxO
      CsoMAqnmkiMQAlHuB6CIQHWsIyfm5CwXDmtMmgefhRFpxcycJKVEanDuSETee860rusqliCcC6Jw
      XdeQOAsuDxhUgiip5ehEixgVJWBVYESU1pCG2vB6ANCe8d1IHJhGO2Npm1D0tPZ8hxz32WkU6Gx9
      CNB60MFuOiPtJVZT1RY90T53VL7djLxu15zmwF5Qj6AKEvodTUu3YlgVVEW4rmvbCUVRIGISjXUS
      ER8oy7ImJZ6ybRIiUkFmTskWnygY9nGTpcIRokMHRGRJ/BoSICwpJVCy9AaslrFbASC1GzvG6Jyj
      ZgtB59fa5VDfOx6NsB7+xKrNp2q7K5p8F12+3b3R6NNBETGH2ablus1yeZgZsvuO2zS+r5uyp8vR
      U8Sa8LNecXTBdedo/55uMI3FcxQIPSJy6g+eYps6yqIKrTTEvVXsCkLnxdyM8C6jZE4XvRHooQm2
      qeCcEe42ETnRT1C1H6XLh3U+c5furZlmGA+u92dZtUn15AACUvAUErJKEq44OQoBSdXSMoNXZAVk
      dIE8IIgKJxEWEXQIqswaYyRAUkGg4IiA7WRGFZWoAAIkREAI5BWh5oRJmNkBOKQMyTskkR4xJm2A
      T5p8etAI9P3yEka7PQBOj+ruoL2Mg/lxbckfxzY9/q7mz22WZ+McjY9IKcUYI6dNXVVVhehGLEXI
      mDnWnFQK9kTkfZPLU4HqyCISIy+Xy/nDMsbYsCSOgNAhee9GxWA8GhXBI6J3ThvMT67rOsaI3mVZ
      ZpxUWZZlWVobTN4cjUZ5nhdZ7lxDoA15GZ6a194ZiADY8GLdaa9bT49ufLWdDBZJKakqemcUoY51
      RxeIKAoDgHNOASxDa7cV+997pcuZ2IkLL5u5FxU9boDar3OPFv/I27sKtXFrk6qqinzYmNEAzNdt
      tVnXdb3DjSJ67/M8d84NBgM7iYnIUGE1cVVVtiQQwDk3HA6LojDNwJaNYk6p3mw2NmsGJBtCGAwG
      3T3dOYGqoAx4wAkCwAHrdPjrM0fpUGx/zhgepeawJYjbPxEBQR1h7kMdpFZm5rKunAtAnhwCoUcC
      7zMHCC4nckhJhZhR2RF4h8xqKx1VHCC2hMCpijAI20kqBELEzGCwAcISEwp3buakpmd5dFUj7mpc
      WnDctpvUXN0vlq3nsV/7NRx5p2qb1ufgFjniVdFW1bmBaf/XUzvlpXP9GG/+ZD19ib9//QiGIjPH
      GJfr1aauYowxRlVMKVUhU8JYMyIGNwAAVRRJtvG89yJSlvX93fzTp0+L9doyVSsQOQghTEbjq6ur
      oihwMPAI2MJQbDab5XJZlmU+HNhmvru7m8/ny/XKdn4Iwfb5cDg8m84mk0kIPQ+pXsf2lF+HO2HL
      2vRUkx132XHlnWKxqqr1ei0IRVFkWcbM6/W6rmvv/WQycc5VVcXMg8GgIyt7wpf2XtSfm1cr1176
      yGOD8CN19ks/m3b/bBCR9Xq9Wm3KspxNtSPQKaXlcvn7l8+r1co0VPasqGZZNplMbGCdc3Ycrtar
      9Xpdrtbr9XqxWGw2G+9cnufT6fTi4uL8/Nx7byqXuq43m83t7c3d3Z3hu2ZZlmVZURSXl5fj8biT
      vU4MxTPLoTjy5P0v+rW/Vk+dKygISIoEEDzl6qvkqsRlrL2vKaeATggRMSMfgstCcOBYBSSRcO6B
      vENPMRKwqKImTirKQmBGTA7OwLmQRRJDgkYzKKIcLRcd2RTYjqbW2XxvbPsdOUqtVPUJObK584Wj
      vcu9vuzZXnnRdL/iLbvy5ZPqu/6gmQORAoBH2QImNAxpszGq+Wqpqok5JSmrWGR5nudlWYY8K7io
      UkROIuI9ee9VgFk2VbybP/z+9ev9wwJE0VFUQNIiZBfns6Io6tlMRNg5UlEAo+aL9Wqz2ZwFDwBl
      Xf326bfb29tNXTkKpqFm5tl4UhRFjJG8m7qJcySWLN2QPBUAG3NtR0a7LbGzH5TA4iJ6h0HHbiuh
      qiYFBKhZ1lX9/f4BEWczRPIiWkcuqxgEBqyislqXZVkCuvE4Q08KQHAEtKHfhv7B81NWxqvLz3r7
      4b61ab25ufn+/S6lFHzuvQ8hENGmrL/f3v+f//3/7u/vq6rqTlPyDgDG4/Hbt29V8fLyMs89c/r+
      /e7bt2/332/X6/VyuVytVqjgvf/ll19Wy40KTiaT0WikIov56vvtt99++9fNzc18Pjc+oCiKs7Oz
      qqrev39PRNaGjvntcwAvGqXTnPuTjx+94fBLt0geO3hUVYFBEcV5opx85nyNklJcVSWQh8wpkhIS
      YEaucAFBU2KWFEjJh5Bn4KhUTRo9WB5j1hhrZodIRC44IlAiYGFQZmYABUIQBXWt82Iw30TQLtPd
      Y4Qb9/XF20FtBdZHSi+vxWHlh+O5+9TxauVgYF907p7482jbji6bPtt3+PizeIVW0b/vby6gSaRO
      cblZ393fmzNpXSfv/bAYDEbDGKOPtSReLpcK7L0fj4fD4TCEXE1FwxyTRBYCRIUkDAKEklgTaxQR
      BY8o3LTVVPPamKdkuVyu12slnE6nF+dX3ntE3Gw2y4d5VVXL5XI8Hg+LgaXxFrHw5o7Llo6/ths6
      Yt3ZVAkJW1cB6C2LRq/d2MoaklTX9XK5RMS8KIrBwDmX5zkzZ1lmbOZ6vd5sNiY3BDNCCPcNsIez
      8jqW8M+h+6pHMlafLh26UNfCqqo2m823b98+ffp0e3vvvX/39kOfbsYYy7L03g8Gg+FwaCxznaLJ
      Pf+/uW9rchzH1QRAUpLlS2ZVVk9Vz8SJOP//H+3Gvuzs9PTp6sqstJ22biSwD5BkWTdfMmfOYXRU
      OyXeRILABxAEt9vt8/Pzer1GxMPh8Ntvv/348SM/HJ1zq9VqtVoRoIgcj8c//vjDGKNcO8uy5+fn
      3//r9+fnn8aYp6cn7ZLO4D//+c84jtWO1/Pdnp+LHpGcDdT0n/O1aZrJ3wqbi1ZEgPqWZATdB8PY
      usKGioP3nFclIpIAEqHotpQQ10GyrJHIIllAQDFgAhkii8RigmEjoKZU56y1NiAZAaMX1nkWYeA6
      MLojY2rvBkYRQQY5I/ueWWCKA3bfzgjLFp/NjO3UWF3D/UdmdiLbTHMz3ZgSHj3dZZ44h4pOjc27
      OaQ5EeC9z/N8v997z1XwZVFFUVQUZVFVAIBEWZYBAKKkaWqMMcZVVcjzfPe2z/M8CAuiCLGgCAIw
      g1Qcsizb7XaRsYtFYo1BxMJXWVkoADfOFkVR5JWz8Wb9qKq09vt4PO6SRZ7nwJId8nyZqxHWe28A
      1RQDAGXhy7IEACJKEsMsIfiyLIuiqKqKiKIo0lWtbrxl6b33utEaQgghKHxTTb+qqre3t/3bQUSi
      OInjJFmm5JyJIhNFZQjH4/HnbpdlGZGx1sVxbA1B8Fp/a7ppa1a21R39GS4wJcPvSzNlp5bZfU2E
      EA6Hw/Pz89///vefP3/meZmmKZyjYG3x8fHx09Pnx8dHlaze+91u9+PHj6qqXl5evn79CgD7/X67
      3SLi09PTw8PDYrFwzhGgMv3tdrvb7RaLxXq9fn19/fHjx+vr63K5fHr6tFwudZ/j7e1tv98rTy+K
      YrFYgN6/zgJXRKSB8/XWPhy148HtBrTRyqXRHTsnMVvHGIaOrUFEBBiRDIpIMEAx2YWNAkvuRUGS
      NSYiICABYBGAICTGYgzGGAQOhBgTOmsQ0QCisx5BjCEi4yxZA4YEEA0aEiNUcFZVlQROIuuMjZyJ
      tKAIggjW5v6L6HKGrZ/k2SBNjfD8mJ8tupl8ox3r1nNFWzP9mVfpuqy8q5bN19/ybWjjm/eISVMI
      oaiqsiyr0itBiQgZY60FsUSkG5LMXFVVWZZvh+z1dXs45lUQAAoAHNQDBEWw8nzI8p+vOwSzqar1
      aqleiVVVhRAUg1dVxcyr1erbt28PDw+r1aosS+dcWZZpmu62W12ZeZ4nSQIAWZY5Moq1mTnP8+Px
      CABqyFOZ9Pb2ttvttJ4kSR4eHpbLpbLa4zHLsqzwFQCEEPI8B4DlcrlarRaLRZ7nu93u7e1NwXgc
      x0Ko1eqIb7dbNdEii4gsFosoiizAcsmKAVUuFkWh/W93AuEWhN6bmuu5//Ws6p18vNuQcvOXl5ef
      P396Xwu21lkQmtOD1tqHh4dv3759+fJF5073JJxzf/755+FwyLJMsbn3frVa/e3br09PT1qbQcrz
      fL1et94vZVnu9/vD4RC8PPzy8O3bt9VqpTL+eDz++PHj+/fvrdLW9hnPfWk+JM0DvfnM3ee1cZ+w
      q+edipzWLDMEg4CCIEQiFiA21hsufVF5XwYfOwM2Ms4Eg94gCQOCtRYIgIiZDTEBoQUAQCZAMI7Y
      MCKSNWJsIOAgDIhIDOw9F0VFIOhsZF1sjRUwyFavq4MzmX3Th3ffzpe9yM170GFUuxqt/z7L22i2
      GZVutP89JeaOdDo9pPKfWc/iE4JJ0xVSgcYCFQGEBVlwvVyuVqvlKg0hOENpmqaLRVmWWZ4fDofD
      4ZDnufc+CIOgEIKAoFQh5Hn+8+fPUJUoYAkWSayev8yAiGmaZlmm0ZN/+eWXx4eHx8dHAIic04fC
      bAEdmf1+zxXnh9wYc9wfheRLHGHwAFCW5fPzc+Ma4fb7/c+fP19eXg55VlWVc84593TMNpvN3/72
      t6IoDsfD77//nud5URQikuc5GbNcLn/99a/L5TKE8OeP59fXV8XvaA0jGGNeX1/jOHbOPT8/Pz8/
      Hw6H/X6flcVmuTLGxMZk2WqxWLZ48/fff0/TtKqqr1+/qtxqKawLQ7pT2MPv0FEwZSI2zim4R4dC
      puhmihpUzF+jkLZ5WlsWNLBC/Vmfnp6SJPFBiqIAQrIGCEWEAYJIFYJxzlq3Wq3bbckoit/eDm9v
      hxDeiqIMgbfb3ePj47dv3/727dc4jpW1GSRrbRRFaZp67+M4ttaqWUy9Fb3nECRJ3CJdRvEiihfr
      zWMUW+ecdpJF9PyfyPmNwxNf+rF60mjxE/dhQUQQYmYSJiQ01NIJiZ5X4G5JERFho4qfkBjChfXC
      h6rKfVVUXN/9jIjIFqG+SChyKGAJJQgJGEBEBCIRCeqmheABkUwQqYQrD4Uvi6oEAGttbCi2zhIg
      MAECC7JekzRpL76eDw6HpX3VBPzqZiYYYPYz6HoOdfVFIyaHHk3jVuyawif6PGP5ufKrpyTNRebe
      fWt7JdWhRe0VcRyTsVgY1YUduSiKFotFHMe1+diaJEmSJNGNyhAkywuzf6tXuB6YJURRQjPGucVi
      maZpkqSGrKj3NqIuTkEIISRJoiC3K1GJyJFRdtxiXmYufKX6gU5TfVeLiDrYqAFXRNQICwAK4rC5
      07aF8977NE0XiwWLVFV1PB6jKFLDrraon6nVtg7Ozrk4jr33y+UyTdMoigAgyzJrbZZlURSpu87b
      2xsALJdLaJApNP6L3UMuU3PZfzU9s7eymKl272BV7WSp7+CnT59Wq5WIbHdv9XXADd7U2VQ8rlod
      NGhUrSJ5niu9KR2mq3S5XC4Wi9bRSEAQMY5jbE4hAIDmUSOPzshqvV6tVtZa7RIZ0Dm9ctB6GLD9
      cTdugtmZ7Y5k1yo1UfDMjsG1QyEYAQE2gBYgjSJBEOSKQ17lAYIgAEGkJzbREAIKBh/oJNUIBQCR
      EAUBEBDJMxceyrIqqrJiARFnbGwoJps4E5EGAGACBgCDUonIwIXubuE3L0evGc/2bU8qN7+HpUa4
      +cX+vwdQT1U4/D0Fs9rHtommoMxFuXlRFFngyhgEsjFbVUeJKEnq9cA+gIghssZEhgDMarUi48rK
      v2x3NYdClMZ5U40hi8Vis9moCcU569XNHNHY2EUJi1cnB+dcZAg5gM4BMwIQgbWk6jMjMIJAzQ0V
      vIQQvEAZ2ARJElQDDhiKFslm/eCcy4p8u90GX1VV5b0nouC5Kj0gJYv06csvxpgsy/b7vRp8nHOb
      zSbLCmZ+enz6/PDZxfHxeAxehDGOFo8Pn/OstCb68vnzL19+IaKyzPO3N3WVs9YWRXU85kVRrVYU
      RQkAee/LslRdpAtve1zjDjB4PWX3KKOnGcxwmV5zwyIKzFWwCcLxeMzycgialHcfDoftdtuKbe/9
      y8vLjx8/iqJ4eHggoqIoiqL4/MuT+q02pmRhYQDQCdL9iRDCZrPZbDbb7fbn627/dkzTVH1dyNkk
      iZ6entbrtXExkfHeK0wVDjNMs9fni+N5MV2L0cAgAKI0cWupgz1F2EPjb6dUo9cxK4sHCEZIwFvE
      xBoGF4ClFD3P4b2vqiiJyCI4EzmDBAYFQYCQPAuAGEBGjegNXiQIV8xFJUVRVlXFECLrnHOxodhi
      ROjo5EfBCKCxQIBa3wSQPmq+YpQQoL6PbGR8sJuzbhkAWpQ9L56hwdf6L48sNO7bRrpvJ7o9bxAf
      7cbF1B23qTHsEfAZVJFOUl/vKrDu4CGiugM759TEbIxBjK0lY0wEYMAgYrZMkyQyzqIGU2vsCbFz
      izhZL5cPDw+b1SpNFsA+9zX7TuI4iqKyOoV8wY73d9sx/aGnCWtFCVGvoyVsj/kRAarZer1ex+ki
      hBC5uKjKcDzkeW7orGZrbbxIVqvVX//6V2PMdrttv9dau1wuV6tMRDabzXq9FsTj8ahfpArE8Xg0
      xnz+/Pnp6YmZs4N5weeiKHa7nXNOjTAhBN16VRamFmHF+11vue7HvhPRzMx3d67hFoY11D17YgCa
      aVJnRM8hz/PeJGJDEkVRfP/+Xf1SAMB7H0J4e3urqmq5XD48PCRJohJXwTU0ooKoPoXdnvbU+pfL
      5bdv34jo//32j91u9/Ly8v35hx4dWq3Sw+Hwn//5n3EcOzp5OtVlb/QjHv3qmXG+Iyn00Z8iAh2L
      XG0d6ohSo/GrAAEYBRgEBUnAISVEYi2ycPBl5cssD2XJcWQQrQ2RdY6YAAnRChi1sSh8AgrsPQOD
      5AV779l7FI4JI0OJo9goKhcLQsIny4/Q8DTWNbj1msGfRtPX1jBMowut22HEq2IFvn+pTtHVVP2j
      2o9toj7oqmAiULuH7kod84KZ9RRG5NxmvQ7Mx+ORQ22vdGQIMACr9qcrOYqiKC6lPs8PxpgkjtM0
      XS6XegyHiMrSl2VZ5QUZiuM4ieMQgjB6X2bZIYqs7mRqL0MIalc5FsfSFzY4ARABRvDCAQQFpQmB
      wggBxMVJFfi427+8vJS+8t577w955sjEyUIABRAIjbOLxWK1WunWqFpIoJYoJooSSwiAzhlriZlR
      AgE7g5Ygsi6JrC9NHLs4dsDCPo6iKM/z193eRvH+cDzmBTmbLFNytuJwLMrd2wFR0vXKRM4SIoTe
      tag6OzqJd5PFDB3MvJJZS85ZzlbZb/hpW4Oy7PYYPZybTSv2FfsyVMwMGQbgk1HS0uf1py9fvnz7
      9tUYk2VHgNojSMvW4UqgttsURdEeFGDmNE3/+te/rh8e9vt9UVXe+8A+L4osy55fXjeb1yhK7PrE
      a1iDUs0O18gqqmemY9uF/pOzGs6Z28Vlj4BtmKAQJIRAXG+qY0sWuvJFaaXLj4JuVRlBAIkIEa1B
      MkSFKQvvRYQr9swl+pxKXWKEaADZBzzxE2RgH9TfF1HAECWWnDWxNQ4hAjYCBIIMSKDB9HTjZpRz
      f6yWM6y2HrnxJrqLqy9pcLjOGreVocY8n+Yl1sci9y6WEpGTT0svk7pUK/Dk/b4oCgBQYtLnWW1x
      DoQSGUtEAkGYAVAkMHsR1shH0ihZBqlOgCh1bK8a+1fVMlqqQVMzZ1m23W6dc+1hSzVkI+Ixz96O
      h6qqJBFGYBFmsdYhoiHTrnkdlLIsD4fDbrd73W2VxahHin5L6yqg6E870Brxvfft9LSH+NvZah0N
      2wz6Q83ocRyrucYYo+A0XS7U01lH0lorcvJJb9kcTEvm66F6D3Ffmf+OnCdal7O3Q/UQzhdzy+vV
      SX+9XrdvjTGfHx4/f/682Wy898pr8jxvvU51iskYNVi9vLzo5rYqSdbaNE3/4z/+oyzrQ8ylL9WS
      vtvtttvter1eLRJ1Tu18whwCGuHmE7eazOtAU7UNU2NFUSWGQ5N0/6ZbFQIoGBcRggYCoAa2ERQm
      IYdI1hiixLjKB421UIL3la+gzMtQ82ESi3rPM7Yfwsx6tNChiQzG1sXWOIMOBVl5NyMiCqqvJ6MB
      6MVKnBvJ+edTvHF+DOdbGbHSTM/4rYJnRgX5WBnWbUvODZ6WEUQ9cJuVplxps9kcjsesyHUXy1rr
      nIVmi0BRkm4J4x9q7wAAGG5JREFUGgJE5ODVXlwVha8q771icwIMAN4bfXs8HrM4cmR8Wfmy6mrT
      NZMlfDseorfYRk4kHI/H4/H48vLiud4WM5FDa4yzviiDsIgEL5UNZfB5UZRVFUcRAFRVdTgctvtd
      VVWr1SZeLBAxz3MWT84GOF2d0VXniawxzpeBwJiGvgEAWPSC8y5P1x+IyD6EykdWIxAsRLZvb8eq
      CsagMWa92ljjdGcvjuPGIzNCNIg4tNy11fbYxPW2uetp4u5sPXrq9VZEWO+1VCIBYWzO2XovIs65
      L01qP42IVotUdT7NY609Ht/2+222WavOZAyRAV+Uh+P+j++/53mepulms/nx40ccx1/gL6vNJknT
      RI9NcFgsUhEpiqKsqqIsvYBBAvag2/NjS/cafjGUr5N8ZGIwL1nAEIAQdYdARNioyyDVzL4dNNCz
      3PqYpCYnQarvDTUISEjO2kASAMvCu+BzqrxUlQBD0Li2OostzRMAkaEQEmMiQmcoNhiRGACrpmQN
      hwcIiKKBrvWjePx2OJkmpNFxwLlsMpHrKofu7m8awUz9LjGe3o7W+YFGtuvTGSJptidPJ/uxsXET
      kTM2ts4aY5B8qLwuhbJU5+siz9gHa/B4fANgTiJErKqqZtZZVpa5+ErICAAaA+x9CWVujm/uEEdp
      5JzBoijKslDfbYtkrXXWOuecjY/Z2/OPn+rlfTgc8mP25/MP1RLIWQ3NUV86Hvzr61HDpBRF8fLy
      stvtNut1kiS6h6aVbDabKEnKsszygzrthLLSDTToo2OR+vSy8uva6ULVCOkEAIRG8VcOVZZlFEUi
      0kZ0ybIsTZPWCtyWanlf7d7ShIHuTVLTn2sJpZ0+OVcS308xwyc9Pt41pHT/7KSgz1qXHou0XC4/
      bR6enp7EB42hLyLtQQFjTJIky+Xy999/I4E0TlarlXr9cwi73e7v//cf//jtH4acanXqjZrlJVmb
      rlaqbBkk3TssiyyOHjTEiAHxyo9qHNrF6WdjPgLMGyvq3cN7cWoabl6bLqmOmSx6wq6uQXMiiZ6x
      Bxag5p6v2mERgAyqAGUWIEFLJIA2NoFNFDCILTkE4QAiAIRIRBYJEev74AAMQIxgIFgkQ0ACCCzA
      CGhAQ8XWWxoCitwQRGMbj2yb3zRQl/Jfuy6muG3v+X8LR/7wZAlQ8BRAWZ32DofD8W1vQNIoTuJY
      XX3LIjsSWGvXq1R8YOaX7WsZfBpSa63ncMizQ3b0zDZyxlee2RpjEQDBWCSCqir2+21kjSUosryq
      KksmiqxzJoQqiuxyuczznJzN8+KPP58BoCzLt219hAcRoyh6XD0iCwGmSfIcOMuy//1//lcSx8zs
      i5LFq/cLGbTOGMKirHa717iIQwi+KL33EsdlkRMCCGu8dXWQMYT1D4OKxpUBZfmx+q8SCeI45uA5
      eM2mZYs8++fxwBKKMl+v11Fk0zSJY/f29vbp08OnT5/Wm1UUu7qq7HA8vjEz8yfESGoM1oZoBw2h
      rk7HCKDRz2UEQZzxlC4/nUpTrPmmNLoAWofx7m8CZB8CV0iikZuQA4k4QhK2BhNnF0kUGUJDgdkQ
      nfw1UYgwid3jw/qfv/H3P/44Hg6Pj49xtEiShJm32+3r65YDfHp8eHz4vEzXSZy+Zq9//PFHVfnN
      42OyiPUD395225ef7MvYms0qja3hUBECCrCv9OadBs70rQSKNPtDduugdbLLOcrraQbNzDIiEta4
      l9CwUQkNwl7QEBGDCcwoYowBBGYvondTgO6FgoaMbpE7CAkxAKKxCMFIQsCALC6AiAgLGjzb59CL
      RgmEkKmzWyDAjMgAbaRyFW+1sV0A2i3R9+EJGV7zo03UUQ1HjPO9UT29OD3prCMwZ34z7VzA+NbR
      NZB/Sm97X+r69nTUHg1SVQ94ncdCx9Sl/r/qgn04HAjw8fFRka+GqC2zfPHwoNuYWZYVRbbf75El
      WaZVqE91CgQC0FOP1lpDDkQsAqEQsARm74ui0OsFothGzhljLBJG0TJlkc9Rlm2329fX1/1+fzwe
      i6Lw3i+iCBuf8bIsIbBFSiL7PT9sdzsQSZJkmSy6errCZDXUNFGfMIkjQ6RWezUrdbdbAUCPoujO
      vDHGh+rt7U1EFovF4+OjNBfBtLBUj4zq6KkzvrquV1WVJMl6vV4sFupgpxBelYyyLNXxbqCLX04f
      wpc/MA3xZheGn0xSJMIMTVjz2tDRYtFG0WlrUH//OI632+2PHz+iKIqjRRzHIpBl2WKxWK83v/76
      65cvXxaL5MuXL4fD4eXPny8vP5M0tc4AgN6lgCRpmq6Wi8g6QmGWZv9wLknLpD46tahwaEyDPq+v
      L9/olmVu4+SRCDIEQAIRBiJQ13NuoIC6GgKKALARQAiEZBpGGRAAUGqmoD3Rm32wvj8IBLsuK3pq
      X+PKdb5I/5iymH9kquObjwcx/h+S/hsXo+WOTFMrAzCjyHq9JqI4XtRn6KOsiBNEfHx8VB/hJIrz
      PBKEJIodmcNuXxwzX5RQhYgMRZEhS84658QHEYmci1wURZExRABRkiCi4EIjvQCA7owJkJ4RsoiO
      aBFF3Ll3InAVJ45QDEEUufV6/fj4CMAQOE3TVbq21q5TPaCU6J1IRHQ4HIwx6XKZpikhEoH6qCC6
      zWajTL8eDmv1MJRzjgzGSbTZbNRoo4vQOaf+1OrvrI46ehZJZ9EYo2eslJunaRrHsaJOtR7oh2gr
      vVXRJkQEPF2aMTpzF5/3uMDNpHEpNfxu0nSgE6oHfLr7DXEcq9mkG/us11tsPER//fUrs//+ncuy
      LIv9fr9Xd8/Hx4dv37798ssXHclPnz4dj8fSV9+/fz8c3yDUl9oQ0afPD3/5y1/U3tXlla1V6sNH
      5mKab7c3g1SbS1htVYgoZNSiEkIQCYhomriFAKDXe7D4Xm11u1yzeKh5t7ZCDR9o/hVBUZ+Vvt83
      CoDUl1D8Ozj4LWmMFOdY/3CxzNjZPiSNLs/ZNNl/6dhU9V/b/UN5XxzHALCqdz5j9QHQQ496NgQR
      kcUYs0oTQTSIQWS9XBGRRZumqa8YCNUMDgD1YRxjUxenSbxKl0mSKEADksVioXd6iQAi1o6Pzi0W
      i0+fPrXHtYmIxVdVFVm3Wq10ST+sN8bgL58/IWLsImOciCQu0kqstdZGeqreGBMnSRRFCKzGdGut
      MU5Df6i2AQDKaPS8uH74169f0zQty3K9Xqvg0V1itd2v12sAUJGgkViq0qupXXFl6xOtMmm1WmkU
      Kh3kEMKtMGOGxQ8B8kcZ0G/tDzZeK5vNRoertQXpQz3vo+TR4tOe4Uhd8r99+xbH8adPT1mWFXlV
      lqUG23l8fPz0qY6uJSIaSlfj3x7yrMxygPp4kXJzPSrRXbSiDKtrERgbqiF8/sBxGx06HahW+Ws1
      BGaWOkO3Pw2uPjnX9ff6zurvWu0kMJCAALCe/0QBaSxOIoLCQDgVV1NEblcsxyq5Jc3Mw40Wj5HF
      ct7QeGC1K3p41YZB9/k963TsKoWzW54RjbW0WBjlNe2lASBkkUIIrecJAli2wl7nPghbIudcmiy9
      9yIIiMZYMAQgegrfIkXOxdZF1hlbm/kEgYiQBGtzlThjrEFrMHJmtVy0Cjg15hFLYK11lgxKmiZR
      ZP1qDQBxE4UDhdrOO+eWy0VoNpQAIDJWTfD6JDKkqNmAAEBsjVkkuuNkyZgopvVqs0zrKI/GEFEa
      R0RUs4Y4crR5XK+U9YsPu91OXeLW63WyiI0l3VNVX35VAq6ZubvzvMd4dw/rb0oMuVIURY+bhzRZ
      tNwcAKyl9XppLaVpaq0B4Ob0HeuxZN1G1SqNQeXCKmKZQSGFys4kSYxFNRDHiXt4XC9Xi4dPGw28
      g4jOWudMrSFFllCEPcJJVa/1Kel9yvjXvZ+hj05Nf9yAQRgYBQT1Nj5ggNq+px5BjIEaZ1sRodaM
      jM1Hydmj2jaCgAKIXDNrBAAwnYCMzV5qe3cnsDq1jxIF95n8fbhhqtTUaI/b05tCTYW1dwrABfWh
      NyOIeHZAoC8Xp0z5I3Ve0+KVReZTt+wpTkuLAvTsvvI79UHEM85ek7U1RqiBUczO2CiKmrEgRtAz
      PS3WMM2OuboWSGBmRtILedXPBkG9XJsQ+C0fR0Q9QATNVUfa7chaZ4xEkTTh0a21KNRabJWhM54m
      zMApuLlaTrqrS9l0OzoKMLHTsTauuvZKQbpmKIoiz7M/f3z/448/iqLYbDatmzk0gVm0cu7elTHF
      kS9hkCEF9HXqf4sNYQa/KNt1zpE17e6ocnlVvxq+A9gcIBp+lG5s6OYnNDeL60S0YXOgmakoiqI4
      bg+gEgq1qeNoA80AtlT3b0jtnM5j55G3ynZNPYYhBD1yZaE2qXDL9xtbfzv7bQ29L205sZCAnO7O
      ZvWJ7PQHheZj3v+LlL/Raj+QpEcXy8yquQ8ezbf+zs/pAoIaKiGajmZXv0NEYEFC0tA7hCIQQuAQ
      mvytDx9omAhENEhIBk9RzohrMpK65+oOW0ebAhEmJOYgYnSNiYhBJnUsA2BhFpYQANEgEoGgAfWO
      V5s41ufXVEEMgRmCOvzVLE9jODIR1bG/hD1Sy0OFCFvSls72FHTkCgyYlG7xKUPpKu8ayQ8J0uVi
      vVmpAUctmyFwK4ca80tgFov9+gEZrtqgv/C8S5rnMvtjUss7un8OmZGqPQRIgKERY9Rwn5YHtQ4t
      MrChq4hVgxtifVbLex+C5tSCQYRFxBC4Zltbq6Lasn8K+4USQIAQA4r62A1THfxkYM2fH42Req4o
      0kOIoDvGInqNs2qt0lxzKiLeB7W6QO1fUK/WRufgkw7ebVxI8BQJsG27dpDt5mzxphBOodsJyfRR
      BDZa20WMchW3HXOIH9Y8ZPdD4DJcX23q0fBMb28esfP+dyu32EREaYx0TVea2eqiKkQUgXYpakEC
      tGSkxr8d12NCi8jEAKZ9CI1RVXmc2k+6naMmuGD7Z8tboeGYuqRreidSS05jCjdVVYlIfaewnO6R
      qpf3+RwQ1QcI2lakDQLTWWDtdLZWmraGbmhAIlJLbhRFnz9/7tpVuoc/mxoUm/f54DWTexNGGIUh
      H5W6VN79EA2rqRJxtPUuyXXJup369qGaF/Rhq6gpX2s9Z9RFXf2RdJrgpEKRiBCNrC4BQZFx7Cn9
      Dn94OqHpsSZ0rbUdaA/xAYAX0ChawmycFaLzy9um7bDqEl5fedG3jJ1ytW8QYNpWMWTlcCNlXsz/
      /vEfqX+W8/ZKzfxofl+2qwyfDBfFDeM2jczwz+cfo0XanZDTE11stdMs93J2O9eGTBn0o+893UUQ
      jIyII9cH8Ph3NvWMx047a+UKemgUE5qhy+FoQIfj16FgDgcAqIPVnMf1BYDWU+VUZ33UjHsjNoS6
      0NkiG/Z/dGld/t5BDfNeCvMoY9i3i0vx4mi3/UHEoY2ybbQdZBxg7bOakQGgpTFGQDA98sBGuo9O
      9xSZTX3pFB2OYj1QY3X7ZweFMaCGxmDmUgOBViGEkFgT2Xobn9m3NkaVlFxrJKQKUV0zhLbDoUEq
      o2NLAijUYwXXoM6pNBzSqRqmxvOacb41XSMwphZd17l5CFagM9EtKLy7n1NdVeeUr1+/9sM9f1S6
      o9+j+aeQ02jxK7nY3RM/XOHdGVJ4rnHMEbF2QOwwmvsa7aa2quEn3PpdvV5dU3aU83aJ9ZpuXBRF
      o08mZc/AseyjUlcyDfWP0fy31j9TdvQJM6viZpHEWgDdiJL2batkn4o3GvP5JyACSCPTTB1WCRhh
      9CqmGZz0nnRfPaOUf0cr75FJ3Up6hNGb1t7quKOtGftP13KgT+z8eh4B86TGCwQ47X2fdRdAVTnG
      OjhmC6/OGmh2Pk+oqj5u3cd3tTIwYi0a9G0g7UdFwQcy9E5nTkahLl8TkRp3j2EfgBotTkmym7px
      x3ddn3+KHOe7oQTdxfsypml1N+6gI8IRh0GuLvW/O85yCpnb6l7Q7PWdSvRCc3Qm8aM411yHexmA
      RGToFYh6xFMINPYGgLHIhCBCqNsGjZqCgAAIQKdNIDUIaM0EwOqY2VgMmQyqY1F3uOsRULP9YNam
      DGi3fvhU2evh4N1S4QMBVvdHywR66/FjpdeoFLHdTJdJDWGCJ433IwDY6cg4ODi+oZT3Hm4LPc44
      MV/dJu6W0qMLvp3FDh+5ureDyqe6pHr0zNvLU9nhcWcCH8arnaLLi3JF5LJX8hAFzyy26/ns6BjO
      gJ2ZJzcpMd3UHeHRkldWeBpSBTLNTrJaP0XOPIKkYwE4TbQeKwJkJpEAAtwe4gys/5f67ChAs3T0
      VNFwJqaE+k1svYd+unmGdDVvmbmmuV5tH8JkZvj1RdzzntSd6xM2n8z9QZpr3RIhdKh5BFf3U4vE
      m053CwidOMSUv+d1mA7x3MP0EuNpC7aRteF8ZJEEQGqfy3qgbxvKa+T5PLK4HhFcw8uuzz/C1j8U
      2o4Kztk83W2G2t9DRN2v75yUIeu5vsOjT8YL4iknNfJVsY7SFYBaUQCl3usRkXotyGkHlfm0sW8M
      EBE0zj8AAPqjY1LX79I/hJGxnsJuf2q74uA72vG9bzSuxB/XP78pzYOnNg2Z+JUFr88z1WKbum4C
      XeAoIpft5jO4ptfqsK8Ep6Nl3TxXcKJ7hMnoYF1kT3hFttGqetykHtHzqz67ManvqH+0Y6MsbMYE
      dFOaKXIPo+9M/UzZoXlxHIh1bHp94HmpS83vk1IIAzw42qWZmm+1j13LykfJYHB2URU0mKB5rhO0
      nkXWgjrUsjBoWEUBvf/zBJVEoAnpSQOry9nvQbNy1bq+ip5Hs92XptjX1GK5td2bBNId6RoR2EKW
      /m0Vo5Q0TF0WdZLS0pIFd/KQhhK/Bs6ICPfiErTbXBNnwDT/uQw4ya4LrFTPTYzfl9Lv2NTzHgPi
      zhOY4kqzTVykqh7v7uW/jyiH3bg7TcnUK5WJQaox3zV9O2U4m/kzCkHE9u7HtlfX4L56/2a+B/N9
      60ijqdFgwYFxTlcTdtaX6pRqBWl9zEE6QlFP6ut/7XEqRDHGsGbW7Yr6Mvbe7BAAMHAdAhrPLDDD
      zp/06EszNIO3LlrAhk1/OMe/gcCmH/4rePpUo6fNOQCYsbTAOV/4kB2D0fqvTFNYaaaSVp2+b5Km
      XnUHRIdSrdj6vLcX2ha5Tzfv0lmPAc0U//fQ00wHpl7NGEaGOxnn3yIAZ6x0CnlcHGrR6LJXZOtV
      WM/7++IqDif0yjQ2PlpbZ3k20qI2mLTnQpo1z8xkjZpnAEAaf9mT2bBjRWEQkPrf4Ve8cxxm0pXU
      ++FEPr92Ltn0JpWAj009+ukxmT437xqGeruUXZvaWQN4Ktxg8PHzdVNtdXs5iaaR2+wtEUPT0jXY
      6qY0LyS6GaZ493CHp5dnvsXen71ZmKlKRIY71eO6VFvkRtq7BozUa6MGw6eHo5mHdNmptv97agTq
      J0IDAK1eQ/3utdJ36hN6NdfIYKIPw1IzaY66zr5XW6zL6B8dSjDYsG8RjZlR30OEiPW5LQQgI4Y7
      AQ4ATquHQAQEkEiv2GlGuW+ZrbvUtI6IXR5/dvzv9k+G4bb5LenK/LM0dn8rt0LMj0rdz2k9U2/w
      N78VTfzPT3d/0UXSnC9ykyrwPy1dw8o1jerO8wj9jg7M13BNzXeM+QzlXD+5H7KgujpEt4mu+NeQ
      R/VNjbek4X7GEOR1e3Jlh3tNXF/2poaGpcZ0vvemO/r/r0sfdnro3/Y9F1HtLfVc3pW9pgN3lOqu
      uutRybC3t5aFWVvBDE+8fk+lbmXQyV5XLxo6xn5M+iYPezvzZB6jDf0Wpnp4E0cTuSrq1h1bOKMV
      drlMHU+pYxucquFK4/WteYbZerwVBsN+h7Ccb70nmabquUO+/ptZeTs+Qwq8jZt3y19EQx8I5D8c
      zM6v//vg1ZBbXYMi72DHw/qvLzuaWQY5pz5qprkZjoBXy+CLgza1+If5r2FMMw979NCzQM4Un2/i
      ypm6lapHx0eaVO/P88hZkZ49cGaaRKTxfbyZ/Ebz9CTorQN1a7qyt+9pd1TAX1n/vPSaX49tsnfT
      zU2v3pMuUNi9ldyaYabgUBIMVdQPb/0m6sTun3IZgl3JfEffvnM9DH9fxA3zby8W72XoYcbuPA73
      Qi726p2K1DWpZdn6Qx9q3LG28z0pOKpVTDGj4aSMWmCu7233zylxcis2v+gacE0l8/VcU/l72Mh9
      b1uZDR9iaZlZLf8KO/u/SGbc0fSQlEUmtel3DsX7v3qO4XbPhlzR+s1YbCz7sJKbGN87B+QONgSz
      YzhlPz17MqCNyZxXD3L3CFuXa9+6KmXMmNbvjABMbCde09WL/XkPJvgotvAeXNVN77enX8MxevX/
      fx+KLnc+jqIeAAAAAElFTkSuQmCC
    )
  )

  (text "Mount R121 if RMII needed\n" (at 53.34 86.36 0)
    (effects (font (size 1.5 1.5)) (justify left bottom))
    (uuid 08b6e76b-daf5-4b44-a5c3-2e8b32cf0c46)
  )
  (text "建议客户使用景略上述料号" (at 80.01 24.13 0)
    (effects (font (size 2 2) (thickness 0.4) bold) (justify left bottom))
    (uuid 2c6af7cb-4c1d-4506-816c-70e49c6e15e0)
  )
  (text "ECAT IO" (at 33.02 133.35 0)
    (effects (font (size 2 2) (thickness 0.4) bold) (justify left bottom))
    (uuid 8f852987-e79d-4825-882e-ca49c9082dc0)
  )
  (text "Mount R122 if RTL8201/YT8522\n" (at 124.46 91.44 0)
    (effects (font (size 1.5 1.5)) (justify left bottom))
    (uuid af1b2c72-8770-4f98-9475-8b403056c587)
  )
  (text "Mount C114/C115 if RTL8201/YT8522/YT8512\n" (at 139.7 52.07 0)
    (effects (font (size 1.5 1.5)) (justify left bottom))
    (uuid b5608daf-87d6-4799-a566-434be6b4dda8)
  )
  (text "PORTB Address is 01\nPORTB is ECAT OUT" (at 223.52 135.89 0)
    (effects (font (size 2 2) (thickness 0.4) bold) (justify left bottom))
    (uuid decd9c8f-d94f-4661-90a0-a39f75fe3581)
  )

  (label "ECAT_3.3V" (at 162.56 93.98 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 02dee18e-36f2-4580-bb2c-08c5651bf0ab)
  )
  (label "TX-" (at 214.63 74.93 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 05d89208-bc2e-41c2-bc45-c401e3e7de39)
  )
  (label "LED1" (at 128.27 99.06 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 1224804a-4be2-4611-bc13-66fc8356764c)
  )
  (label "LED0" (at 128.27 101.6 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 158359ae-e1cb-47b4-85f6-300ce429b1f7)
  )
  (label "RX+" (at 213.36 85.09 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 1a7d0c3a-512c-477a-85b9-0469e099f59e)
  )
  (label "ECAT_3.3V" (at 247.65 85.09 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 28540116-2f87-4f4c-9130-bebd4d8b872e)
  )
  (label "TX+" (at 214.63 72.39 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 2a605814-192d-4dfc-abb8-79b5bdbc62c8)
  )
  (label "LED0" (at 281.94 85.09 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 41f9cbda-74c0-4f16-bfe6-d39370390ccb)
  )
  (label "ECAT_3.3V" (at 135.89 48.26 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right bottom))
    (uuid 643a6d20-e855-4616-9d2c-7b9e71fc9eac)
  )
  (label "TD_P" (at 137.16 68.58 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid 7bec29cd-be1a-4c6a-b146-485d3d759196)
  )
  (label "ECAT_3.3V" (at 172.72 34.29 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid a726eb3e-be49-4641-a85c-1f1ed5f2d325)
  )
  (label "LED1" (at 248.92 74.93 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid b0303cbe-333e-47f5-94f3-78ce57b1609c)
  )
  (label "TD_N" (at 137.16 71.12 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid b1a73737-ce25-4566-b224-96d97315fc4f)
  )
  (label "RX-" (at 213.36 90.17 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid b407ef05-02f9-4d2b-a04b-6e9a05238a69)
  )
  (label "RD_N" (at 137.16 76.2 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid f6d15e5b-904e-41eb-9b9f-f5bbc8b79cda)
  )
  (label "RD_P" (at 137.16 73.66 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left bottom))
    (uuid fab9e85c-5c91-4cce-b5d6-10edd5ba0b00)
  )

  (hierarchical_label "PORTB_TXD3" (shape input) (at 67.31 63.5 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 0a2b2d47-debb-404d-b715-fda31f8c8d20)
  )
  (hierarchical_label "PORTB_RXD2" (shape input) (at 67.31 81.28 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 0ff95318-4228-418d-8c94-f2501bf4c387)
  )
  (hierarchical_label "ECAT_3.3V" (shape input) (at 162.56 34.29 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27) bold) (justify right))
    (uuid 13e56125-6f40-49b8-a4d7-208f28564b89)
  )
  (hierarchical_label "ECAT_IN2" (shape input) (at 69.85 149.86 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left))
    (uuid 1ee4734d-03c6-45fe-aa12-5b3be2988918)
  )
  (hierarchical_label "ECAT_IN1" (shape input) (at 69.85 147.32 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left))
    (uuid 2053ca53-492c-4023-9346-16b46e507959)
  )
  (hierarchical_label "PORTB_TXD2" (shape input) (at 67.31 60.96 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 2e0c9445-b6f3-457c-9554-ffb389bfde93)
  )
  (hierarchical_label "PORTB_MDIO" (shape input) (at 34.29 93.98 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 2f78a97d-ba17-4ef2-ac1c-72a09fded833)
  )
  (hierarchical_label "PORTB_RX_DV" (shape input) (at 67.31 88.9 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 36247c14-d096-481d-8ac1-73211fdbce72)
  )
  (hierarchical_label "PORTB_RXD3" (shape input) (at 67.31 83.82 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 3a4cde81-1ddb-4f91-be23-a1a1c55508e3)
  )
  (hierarchical_label "PORTB_RXD0" (shape input) (at 67.31 76.2 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 49eafd6a-648c-47ed-bbdc-927cc19d3141)
  )
  (hierarchical_label "ECAT_3.3V" (shape input) (at 139.7 48.26 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27) bold) (justify left))
    (uuid 4d7da83e-572a-436e-93e9-f1cc40cd4030)
  )
  (hierarchical_label "PORTB_RESET" (shape input) (at 160.02 104.14 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left))
    (uuid 6b1ffa82-1793-44e9-8e81-5dbe51bd2308)
  )
  (hierarchical_label "PORTB_RX­_ER" (shape input) (at 67.31 73.66 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 6b3be0cf-3bbf-4b6a-a713-611e9ad2d47f)
  )
  (hierarchical_label "PORTB_RXC" (shape input) (at 67.31 68.58 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 80184fe8-07b2-4cac-b223-1048c6154558)
  )
  (hierarchical_label "PORTB_RX_DV" (shape input) (at 67.31 71.12 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 842d82e3-be56-480b-9cab-7deb5c0bff91)
  )
  (hierarchical_label "PORTB_TX_EN" (shape input) (at 67.31 53.34 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid 91a85a4e-13e7-4751-8d3b-d064a8bc579b)
  )
  (hierarchical_label "PORTB_TXD0" (shape input) (at 67.31 55.88 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid a4e36c2f-e074-4e58-b7f0-4439709eac7f)
  )
  (hierarchical_label "PORTB_XI" (shape input) (at 50.8 101.6 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid c1af5b3b-d228-4266-a658-920977f785bf)
  )
  (hierarchical_label "PORTB_MDC" (shape input) (at 34.29 96.52 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid dc33f945-e06b-432c-aa33-f566702db3dd)
  )
  (hierarchical_label "PORTB_TXD1" (shape input) (at 67.31 58.42 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid deb4fe4e-b68f-42bf-ac6a-8db504a2119c)
  )
  (hierarchical_label "PORTB_LINK" (shape input) (at 132.08 99.06 0) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify left))
    (uuid e1d705dd-f65d-43ad-aea5-4a0e4644bcaf)
  )
  (hierarchical_label "PORTB_TXC" (shape input) (at 67.31 48.26 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid e9a54dd4-4ba5-4a87-9229-c7a432f5aa83)
  )
  (hierarchical_label "PORTB_RXD1" (shape input) (at 67.31 78.74 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid ec32984b-a7f3-4270-a8de-4711424b37d4)
  )
  (hierarchical_label "ECAT_OUT1" (shape input) (at 118.11 148.59 180) (fields_autoplaced)
    (effects (font (size 1.27 1.27)) (justify right))
    (uuid fe68421b-8fbb-416f-a9aa-d0caf384e54e)
  )

  (symbol (lib_id "14_HPM_Internet:JL1111-N032I") (at 104.14 76.2 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 07755b11-2795-4e8c-a0b5-c692a09bb4ef)
    (property "Reference" "U11" (at 105.41 40.64 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "JL1111-N032I" (at 105.41 43.18 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "06_HPM_LQFP:QFN-32-1EP_5x5mm_P0.5mm_EP3.1x3.1mm" (at 81.28 109.22 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Datasheet" "" (at 106.68 120.65 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "JL1111-N032I" (at 104.14 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "JLSEMI/景略" (at 104.14 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 104.14 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 6754560a-c83f-404e-a60b-189cacf1192b))
    (pin "10" (uuid c0063049-a76b-43af-a6fd-6031c593861f))
    (pin "11" (uuid b996d260-d9e1-45d9-b2e8-b0783cabc617))
    (pin "12" (uuid 715ca914-d755-41aa-ad9d-6601b8687456))
    (pin "13" (uuid 5302411e-6f9e-4117-b97b-8f45caaf786a))
    (pin "14" (uuid c0c4277e-d656-4e78-86ab-5ac47f72fd6d))
    (pin "15" (uuid eb9564c9-f62e-46e6-885f-6b986c38402a))
    (pin "16" (uuid 2bd28a40-8536-49b2-bd26-491fe3dc24bd))
    (pin "17" (uuid 6b0b94c0-a86b-445c-8159-b9a6bc17ae08))
    (pin "18" (uuid e7ce761e-7f54-41a1-9c9e-997c142aacf3))
    (pin "19" (uuid 99f4e93d-63b5-4172-91a8-7f922bcc8bbb))
    (pin "2" (uuid 0e07a859-41c2-4246-92a5-69f12722cd87))
    (pin "20" (uuid d0820f72-2aca-4256-af4e-202796628232))
    (pin "21" (uuid e0bb74d3-7c69-4ff4-93f0-9e1d96e2ec73))
    (pin "22" (uuid 843ef89a-c0c5-4107-922c-79f9d33e867b))
    (pin "23" (uuid f998a59e-2552-4a92-8598-32052cbff19a))
    (pin "24" (uuid d0b5f6f0-3c56-4e67-ab49-ae7d795e39de))
    (pin "25" (uuid 3fae15bd-47ac-4dab-b9ee-49d264d988f6))
    (pin "26" (uuid 07b59cf0-f297-483e-a50e-06a94d600ffa))
    (pin "27" (uuid 731b384e-41ec-457d-bfff-9e99cee823b5))
    (pin "28" (uuid 460dec9f-83f6-457c-9ebb-bcbfa9afb7f1))
    (pin "29" (uuid 0be45992-24d0-4df3-985d-3e89e32be9be))
    (pin "3" (uuid c3872c36-9daf-4313-86d5-18c758b3b556))
    (pin "30" (uuid 740462f2-c741-4c70-9706-4c09054b3ffa))
    (pin "31" (uuid 27e1dfb3-05dc-41af-8ea0-cb687009ddc0))
    (pin "32" (uuid a6b280ac-168e-489e-8f8f-25a620452f6c))
    (pin "33" (uuid e32604ae-a724-4d93-884e-651546c7c102))
    (pin "4" (uuid 2441362f-3c6b-4c01-8394-cc014d4dd9e5))
    (pin "5" (uuid a213158b-2d27-4cea-96f9-2b81ca911804))
    (pin "6" (uuid dd839330-e601-4d16-af03-835209b268a7))
    (pin "7" (uuid 60d7085b-c2ed-4c4d-b1ef-61e5e9273673))
    (pin "8" (uuid 797b3c8f-2543-4df1-b967-593399f619e3))
    (pin "9" (uuid cf4747fc-9e40-47ab-b88b-9f1858f6a2f6))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "U11") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "U13") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "U?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 184.15 119.38 0) (mirror x) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 0eddeb86-2da6-46f2-8f36-fc80503e1a67)
    (property "Reference" "#PWR?" (at 184.15 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 184.15 115.57 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 184.15 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 184.15 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 9bfd27c8-8705-44f8-98c8-74538e2df308))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "ETH_RMII"
        (path "/b88c389c-f5c6-4774-9a42-afd1d70be891"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0118") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0175") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0402") (at 77.47 110.49 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 10e56be6-395a-496a-bc85-92b227e6f116)
    (property "Reference" "R?" (at 77.47 106.68 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0Ω_0402" (at 77.47 114.3 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 83.82 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 77.47 110.49 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RC0402JR-070RL" (at 86.36 110.49 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YAGEO(国巨)" (at 88.9 110.49 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 77.47 110.49 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 10d70ec6-c26a-4884-88d3-0cb8fbeb6c65))
    (pin "2" (uuid aea6397f-8e86-4054-8977-9beba7a5502c))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R82") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R129") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 154.94 163.83 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 144ffb38-5676-4879-a332-ba0e47268699)
    (property "Reference" "#PWR?" (at 154.94 170.18 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 152.908 167.64 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "" (at 154.94 163.83 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 154.94 163.83 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 16534997-1fc1-4438-9961-eb91ce9f6637))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0119") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0285") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:1K_0402") (at 68.58 158.75 270) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 15439020-42d4-49b3-98c7-94c3f9bd25e8)
    (property "Reference" "R7" (at 67.31 166.37 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "1K" (at 67.31 156.21 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 66.04 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 68.58 158.75 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1001TCE" (at 60.96 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 63.5 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 68.58 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid fae32138-ff27-4971-9ca8-8444c84f1e4c))
    (pin "2" (uuid aa07cdf6-d2f8-4287-a85f-61f7980b3450))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "R7") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "R103") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R115") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 148.59 96.52 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 1b55c00d-3090-40e0-a3ad-64bdc8e6c580)
    (property "Reference" "#PWR?" (at 154.94 96.52 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 151.13 96.52 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "" (at 148.59 96.52 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 148.59 96.52 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid bf5fe061-80fe-410d-8709-fe28b5bf2752))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0111") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0168") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:+3.3V") (at 38.1 144.78 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 1f411e33-d4cf-4fba-a5bb-9000c0852441)
    (property "Reference" "#PWR027" (at 38.1 148.59 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "+3.3V" (at 38.1 140.97 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 38.1 144.78 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 38.1 144.78 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid cef1fbf1-1827-45b5-a04d-63b05571fb2c))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "#PWR027") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/b8432231-9443-4f8c-b065-03c77811eba6"
          (reference "#PWR?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0287") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR014") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "01-HPM-Peripheral:TestPoint-0.5mm") (at 80.01 91.44 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 20232acf-583d-4678-be3f-bcf4f481ceb8)
    (property "Reference" "T29" (at 81.28 93.98 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Value" "0.5mm" (at 74.93 92.71 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Footprint" "01_HPM_Peripheral:TestPoint_Pad_D0.5mm" (at 82.55 86.36 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 80.01 86.36 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 57d7f452-9ab1-4919-a853-1acb5beb02d0))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "T29") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/2dda6564-240e-411c-87a3-0164d71f620d"
          (reference "T?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "T?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/21a69ad3-d4bc-4ca6-8758-48254c4665b1"
          (reference "TP7") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "T30") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 128.27 63.5 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 293dc8a4-58bc-4368-93ff-edd902e48623)
    (property "Reference" "#PWR?" (at 128.27 69.85 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 127 67.31 0)
      (effects (font (size 1.27 1.27)) (justify left) hide)
    )
    (property "Footprint" "" (at 128.27 63.5 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 128.27 63.5 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 453b0737-8657-4e1c-9772-2e2482254bcd))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0109") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0166") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:330Ω_0402") (at 265.43 87.63 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 2c793403-8571-426c-8892-0359adab4c98)
    (property "Reference" "R71" (at 260.35 86.36 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "330Ω" (at 271.78 86.36 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 265.43 92.71 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 265.43 87.63 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF3300TCE" (at 265.43 95.25 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 265.43 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 265.43 87.63 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 93cfaea3-dc86-4aeb-b8af-519c7209be6d))
    (pin "2" (uuid 632d794c-7d63-45f3-b512-c5034fa1983b))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R71") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R118") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 172.72 119.38 0) (mirror x) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 2f1fd890-9018-44a8-8f86-1fd6609c94da)
    (property "Reference" "#PWR?" (at 172.72 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 172.72 115.57 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 172.72 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 172.72 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid f2da3e19-ce30-4ead-b77c-b968fbaf677d))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "ETH_RMII"
        (path "/b88c389c-f5c6-4774-9a42-afd1d70be891"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0117") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0174") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 77.47 114.3 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 366d4892-e865-4f0e-9aa9-0d355085f5c0)
    (property "Reference" "#PWR?" (at 77.47 120.65 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 75.438 118.11 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "" (at 77.47 114.3 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 77.47 114.3 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 634846b2-18d0-4649-9e30-3bff6fe15085))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0119") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0176") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:75Ω_0603") (at 219.71 97.79 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 39448ce2-ea1d-424e-bec2-d01cb6fe5e4f)
    (property "Reference" "R?" (at 219.71 93.98 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "75Ω_0603" (at 219.71 104.14 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 222.25 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 219.71 97.79 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF750JT5E" (at 227.33 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 224.79 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 219.71 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 116d9946-a0aa-4fe6-8073-ad673c4488b3))
    (pin "2" (uuid d89b1e96-9454-4aad-bf54-eeefc1187d1a))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R79") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R126") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 182.88 55.88 0) (mirror x) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 39aa4576-3c3a-49d4-8edd-c94c84bed3cf)
    (property "Reference" "#PWR?" (at 182.88 49.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 182.88 52.07 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 182.88 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 182.88 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid c99db105-b54a-4013-b6c2-325981b35760))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "ETH_RMII"
        (path "/b88c389c-f5c6-4774-9a42-afd1d70be891"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0107") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0164") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND3") (at 184.15 127 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 4145bd28-881b-4cd6-aa1c-3eb8b9e6e0cb)
    (property "Reference" "#PWR0169" (at 184.15 133.35 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND3" (at 184.15 132.08 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 184.15 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 184.15 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 466cffb5-5f5b-4a5d-a120-f042c9144458))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0169") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND3") (at 219.71 113.03 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 415fc746-5394-4333-b8d7-ae4a9405aa91)
    (property "Reference" "#PWR0162" (at 219.71 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND3" (at 219.71 118.11 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 219.71 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 219.71 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid bd50f728-5b07-4800-9357-4dfa437588c8))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0162") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "14_HPM_Internet:RJ45-B-1*1") (at 236.22 81.28 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 43b96a25-ce1c-4e1a-bc11-c4632b818766)
    (property "Reference" "P?" (at 237.8711 64.77 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "RJ45" (at 237.8711 67.31 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "11_HPM_Internet:RJ45-TH_B-1-1_led-update" (at 234.95 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 247.65 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RJ45-B-1*1" (at 234.95 102.87 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "BOOMELE(博穆精密)" (at 236.22 105.41 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 236.22 81.28 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "0" (uuid d6beeb14-d58c-4283-9b04-057d8b98e66d))
    (pin "0" (uuid d6beeb14-d58c-4283-9b04-057d8b98e66e))
    (pin "1" (uuid 23d6a933-daea-4a36-9dbd-dc6d7a440283))
    (pin "10" (uuid c91397f1-d764-4a62-8ffb-85460cfa7aac))
    (pin "11" (uuid 1878a32d-6c31-471c-b4ae-c7850f49e7e2))
    (pin "12" (uuid b82dffa8-29a8-43f4-a760-15e10e46db24))
    (pin "2" (uuid efa121d2-0864-4e70-8ec9-27eadcf0df7c))
    (pin "3" (uuid 41533882-0ee8-463e-9978-802537813230))
    (pin "4" (uuid 26a22abb-9714-4764-93d6-56765476f7b6))
    (pin "5" (uuid ccec73ff-ea63-45a0-84dc-e2f7bb01e72b))
    (pin "6" (uuid 636f0bc0-0e82-4afc-b2cc-0a76a47372ba))
    (pin "7" (uuid 133cb75d-6739-445c-9a44-dbdf8564f8ec))
    (pin "8" (uuid 992f0092-e3d4-4b1b-98d5-30964b0caaad))
    (pin "9" (uuid b53512e4-fbd1-421a-8e1c-847ecd0d2aa1))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "P?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "P1") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "P2") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "P?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "P?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "P?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "P?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "P?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "P?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0402") (at 54.61 101.6 0) (mirror y) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 470aca43-a336-4793-a8b1-37bf5a21852a)
    (property "Reference" "R?" (at 52.07 106.68 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0Ω_0402" (at 50.8 104.14 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 53.34 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 54.61 101.6 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RC0402JR-070RL" (at 54.61 110.49 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YAGEO(国巨)" (at 54.61 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 54.61 101.6 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid b0f15089-e445-4706-aa0d-9714e0583392))
    (pin "2" (uuid ff906df2-2067-4d2c-9b56-429db6913a1d))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R40") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R41") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:2.49K_0402") (at 139.7 96.52 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 55d7a991-d192-48fc-8718-13850a6ddab2)
    (property "Reference" "R?" (at 130.81 95.25 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "2.49K" (at 143.51 95.25 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 139.7 93.98 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 139.7 96.52 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RC0402FR-072K7L" (at 139.7 88.9 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YAGEO(国巨)" (at 139.7 91.44 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 139.7 96.52 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 56761663-f459-416f-ba1f-adce3d0d6b93))
    (pin "2" (uuid de66619c-0833-45de-8ef3-8407705d0547))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R76") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R123") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0402") (at 74.93 88.9 0) (mirror y) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 5f8c1c20-0699-4b58-a6eb-d15d492be7d7)
    (property "Reference" "R?" (at 67.31 87.63 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0Ω_0402" (at 78.74 87.63 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 73.66 95.25 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 74.93 88.9 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RC0402JR-070RL" (at 74.93 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YAGEO(国巨)" (at 74.93 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 74.93 88.9 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid d2ae31ed-4c75-4206-ae56-9dc8b9568a6a))
    (pin "2" (uuid c771bc41-d079-487e-abb2-c2856f5cefe6))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R121") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R119") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 63.5 109.22 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 604f1c5c-17ee-483f-adfa-f3c11de585b9)
    (property "Reference" "#PWR?" (at 63.5 115.57 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 61.468 113.03 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "" (at 63.5 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 63.5 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 3646a805-0a96-4085-be94-cd1804b8c25f))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0123") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0124") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:4.7K_0402") (at 265.43 85.09 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 620317d0-6946-4aea-abef-3268691ca2ee)
    (property "Reference" "R70" (at 260.35 83.82 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "4.7K" (at 270.51 83.82 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 265.43 87.63 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 265.43 85.09 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " 0402WGF4701TCE" (at 265.43 92.71 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 265.43 90.17 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 265.43 85.09 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 648a1aea-86b7-412a-a2ed-1f26ec21b028))
    (pin "2" (uuid cb6f8e1f-8ff1-4ed2-a767-b7927ffdb2b5))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R70") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R117") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND3") (at 236.22 100.33 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 625de6c4-5c35-44ff-b09e-27feb775a5dc)
    (property "Reference" "#PWR015" (at 236.22 106.68 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND3" (at 236.22 105.41 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 236.22 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 236.22 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 34c5c491-329d-4e2a-9b75-988f47ee401b))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR015") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:1nF,2kV_1206") (at 212.09 109.22 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 64e69540-04f6-495f-8dce-bc70eb06ef3e)
    (property "Reference" "C?" (at 207.01 106.68 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "1nF,2kV" (at 212.09 111.76 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_1206_3216Metric" (at 213.36 115.57 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 212.09 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "1206B102K202NT" (at 210.82 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 210.82 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 212.09 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 955d33bc-2e59-4bf1-b3f2-fcac6a7cb152))
    (pin "2" (uuid ace9704b-7876-475c-a0eb-8046549b2e56))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C74") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C122") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,50V_0402") (at 152.4 59.69 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 661ae364-eea0-4e91-bea1-0c71f4cb0a7d)
    (property "Reference" "C?" (at 157.48 57.15 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "0.1uF,50V" (at 162.56 62.23 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 148.59 52.07 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 152.4 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402B104K500NT" (at 149.86 49.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 151.13 54.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 152.4 59.69 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 1c65df8e-1bb9-4d4c-ad2a-7843bf3a40fe))
    (pin "2" (uuid 4a1b0e88-3305-4f76-92a4-6a1c1f81ca92))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C114") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C112") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 172.72 38.1 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 67a3c719-3fbe-485a-9742-9550de6eb599)
    (property "Reference" "C11" (at 172.72 35.56 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "0.1uF,16V" (at 172.72 40.64 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 175.26 52.07 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 172.72 38.1 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 173.99 54.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 172.72 49.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 172.72 38.1 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 5e39c4c4-5b2e-471e-b835-222190082160))
    (pin "2" (uuid 7bb1154e-cd4a-43ff-b933-4a068decec7c))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C11") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C66") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,50V_0402") (at 182.88 102.87 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 6e776316-9607-45f4-9217-52415b7c925b)
    (property "Reference" "C73" (at 186.69 101.6 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "0.1uF,50V" (at 186.69 104.14 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 186.69 110.49 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 182.88 102.87 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402B104K500NT" (at 185.42 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 184.15 107.95 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 182.88 102.87 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 4e4c434f-cbbb-4316-b411-2ffe26a6afb7))
    (pin "2" (uuid c07063e5-0736-4807-ba20-355a677fd0a2))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C73") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C121") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:1uF,10V_0402") (at 168.91 59.69 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 70005aba-0ee5-476f-ba49-1b82ebdba442)
    (property "Reference" "C113" (at 168.91 57.15 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "1uF,10V" (at 168.91 62.23 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 172.72 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 168.91 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " CL05A105KP5NNNC" (at 171.45 69.85 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 170.18 64.77 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 168.91 59.69 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid e2eff543-1c3e-4f3d-9a1d-a573009dee09))
    (pin "2" (uuid 008cc4ed-7695-46e6-87c0-7c568de24031))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C113") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C115") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "01-HPM-Peripheral:DM-02-V") (at 53.34 148.59 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 70a0f982-45fb-42e8-8367-68f3c137bbff)
    (property "Reference" "SW?" (at 49.53 143.51 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "拨码开关" (at 64.77 144.78 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "01_HPM_Peripheral:SW-SMD_DM-02-V" (at 53.34 155.575 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 53.34 144.78 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "DM-02-V" (at 53.34 139.7 0)
      (effects (font (size 0 0)) hide)
    )
    (property "Company" "圜达" (at 52.705 157.48 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 53.34 148.59 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 72848c0b-603b-4b51-b115-30bd92f76d70))
    (pin "2" (uuid 4cf16d59-f0f0-4325-9f2b-f0394c772c66))
    (pin "3" (uuid 49c9020f-ddc4-44af-9a1e-9385202c880a))
    (pin "4" (uuid 7f2310aa-b54e-4d61-b9c2-970bc743f33c))
    (instances
      (project "HPM6E00-PA00-PA31-JTAG-BOOT-LED-KEY"
        (path "/29ac3f40-2113-4dac-8d58-a13bca3aee97"
          (reference "SW?") (unit 1)
        )
      )
      (project "HPM6E00 SKT Board BGA289_BDIF REVA"
        (path "/a41b0905-ef56-48d9-b06d-4dc9518abdc7/4660a489-af31-41d2-86b5-fc0246e827ca/93cfbad6-56e7-43a8-afcb-a52eb13db8c0"
          (reference "SW?") (unit 1)
        )
      )
      (project "HPM5300-CON-JTAG"
        (path "/bac2711e-84a2-4344-ae08-8e581d112422"
          (reference "SW?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/64c6c979-a234-4d9b-ab9c-77c628dd08ef"
          (reference "SW?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/ede36aad-ac34-4d4f-8b81-cc1b3553ddbb"
          (reference "SW1") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "SW6") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "SW6") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP100 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/90f77b5a-179f-413e-aafd-05aa0b392bd1"
          (reference "SW?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:4.7K_0402") (at 264.16 74.93 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 8106df95-e865-4647-9c09-65e707fca02e)
    (property "Reference" "R64" (at 259.08 73.66 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "4.7K" (at 269.24 73.66 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 264.16 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 264.16 74.93 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " 0402WGF4701TCE" (at 264.16 82.55 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 264.16 80.01 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 264.16 74.93 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 8017acf6-e50a-42dc-ae9c-9fe5acf99c4c))
    (pin "2" (uuid fb9fe9ff-8157-4538-bcf5-55a5f19e687e))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R64") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R111") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:75Ω_0603") (at 212.09 97.79 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 82a2a552-3bdc-499a-8f6d-55b99fd374be)
    (property "Reference" "R?" (at 212.09 93.98 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "75Ω_0603" (at 201.93 104.14 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 214.63 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 212.09 97.79 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF750JT5E" (at 219.71 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 217.17 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 212.09 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 4222fefb-28ed-4877-ad1b-059e544c8122))
    (pin "2" (uuid bbd39787-6898-425d-827c-233266904dc6))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R78") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R125") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND3") (at 236.22 62.23 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid 9008ff4a-fb7e-4ff5-be90-e6f77d316c90)
    (property "Reference" "#PWR0165" (at 236.22 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND3" (at 236.22 58.42 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 236.22 62.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 236.22 62.23 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 9eceb2e8-49e2-4fed-9ac0-d0aca2b6d96b))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0165") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 68.58 170.18 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 95de1221-86c2-4903-ac89-1a5c20b6ae04)
    (property "Reference" "#PWR?" (at 68.58 176.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 66.548 173.99 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "" (at 68.58 170.18 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 68.58 170.18 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid be259593-70cd-4ab0-aac0-0b7dd44a8f0e))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0119") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0286") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:1K_0402") (at 129.54 148.59 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid 980de52e-a147-43fc-9837-bda830733939)
    (property "Reference" "R7" (at 121.92 147.32 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "1K" (at 132.08 147.32 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 129.54 146.05 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 129.54 148.59 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1001TCE" (at 129.54 140.97 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 129.54 143.51 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 129.54 148.59 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 3c23743e-5b21-4d83-8170-c3b86aa38109))
    (pin "2" (uuid 930dc175-ef57-485c-aa11-c3da4c826a27))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "R7") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "R102") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R110") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "power:GND") (at 182.88 106.68 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid a9847d80-d010-4284-91c6-8733d867f943)
    (property "Reference" "#PWR?" (at 182.88 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 182.88 110.49 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 182.88 106.68 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 182.88 106.68 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid a8cccb17-0ae4-4e34-8517-1d53ef43c9d7))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "ETH_RMII"
        (path "/b88c389c-f5c6-4774-9a42-afd1d70be891"
          (reference "#PWR?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0113") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0170") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "#PWR?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "#PWR?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 172.72 41.91 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid ad4c4920-a59e-4e90-b8b6-54ab0332fdd9)
    (property "Reference" "#PWR012" (at 172.72 48.26 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 172.72 45.72 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 172.72 41.91 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 172.72 41.91 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid aeb70141-151f-4890-860b-ee02219c33ca))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR012") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0106") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:0Ω_0402") (at 139.7 93.98 0) (mirror y) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid ae56410b-c8ba-46ff-94ea-be3c3d8d551a)
    (property "Reference" "R?" (at 132.08 92.71 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "0Ω_0402" (at 143.51 92.71 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 138.43 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 139.7 93.98 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "RC0402JR-070RL" (at 139.7 102.87 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YAGEO(国巨)" (at 139.7 105.41 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 139.7 93.98 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 8629e0c4-4d77-4159-a8e8-6a1f7ecd169a))
    (pin "2" (uuid f5daa8d3-be0f-4d87-8d98-38335b85e3ac))
    (instances
      (project "HPM5300-USB-OSC"
        (path "/4c7b0ad0-b5a1-4a84-9055-796c57236d5e"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R122") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R119") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/7bfa3519-297b-4088-a57e-f2603a098bb0"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7759ef03-346f-4a69-8dda-8d8259b23ea5"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/af515cf1-97e6-49b9-bd1b-45df0a97b82b"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM5300 SKT Board LQFP64 REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/f20b2654-0424-4c49-9857-f83b37957c4e"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND3") (at 172.72 127 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid ae74e6e7-9f08-4454-9a58-325b5686c20b)
    (property "Reference" "#PWR0171" (at 172.72 133.35 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND3" (at 172.72 132.08 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 172.72 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 172.72 127 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 71801275-7669-4b1e-b0b0-d9095dfcae7f))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0171") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:75Ω_0603") (at 207.01 97.79 270) (mirror x) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid b01afbf4-c73d-4268-8298-ad06d58394dd)
    (property "Reference" "R?" (at 210.82 93.98 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "75Ω_0603" (at 205.74 99.06 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 204.47 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 207.01 97.79 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF750JT5E" (at 199.39 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 201.93 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 207.01 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid e95f9760-cab4-4fc7-b2aa-72fc2a8b9181))
    (pin "2" (uuid 3657f474-d6b6-4655-b57b-61b8ec58b64d))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R77") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R124") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,50V_0402") (at 182.88 59.69 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid b88322fd-e0ed-40c3-bc46-97a6ad3f272b)
    (property "Reference" "C72" (at 186.69 58.42 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "0.1uF,50V" (at 186.69 60.96 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 186.69 67.31 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 182.88 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402B104K500NT" (at 185.42 69.85 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 184.15 64.77 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 182.88 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid d6b9bb07-afc1-41a9-a578-7f1dc0b3c921))
    (pin "2" (uuid 74d0ed3b-46fc-4ecf-804c-2a73dca018e7))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C72") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C120") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 185.42 38.1 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid c01b754c-3563-4b6b-86d4-2224f79dc7da)
    (property "Reference" "C12" (at 185.42 35.56 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "0.1uF,16V" (at 185.42 40.64 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 187.96 52.07 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 185.42 38.1 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 186.69 54.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 185.42 49.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 185.42 38.1 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 4761ee76-02a0-4f3a-a4ba-a8de4c3f37a8))
    (pin "2" (uuid df9f751a-6962-4231-be58-7d0a95c05229))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C12") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C66") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,50V_0402") (at 128.27 59.69 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid c128c132-21e6-462a-aefc-3bfee426a1f5)
    (property "Reference" "C?" (at 133.35 57.15 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "0.1uF,50V" (at 138.43 62.23 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 124.46 52.07 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 128.27 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402B104K500NT" (at 125.73 49.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 127 54.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 128.27 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 10111d83-8faf-471d-b8dd-f74086db86cf))
    (pin "2" (uuid 780ac95d-d936-4552-80f4-2c7ffac78f91))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6750EVK2 RevC.0822"
        (path "/70f9d60f-5c71-4a9a-a3d3-31c463e0aae0/7b745725-a8bb-43db-9d93-98e7228e076e/6bda32f1-18f8-46fe-936d-a15de0d0f535"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C70") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C118") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:1nF,2kV_1206") (at 172.72 123.19 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid c1c38799-9e86-4319-8f13-3bbf2fc01270)
    (property "Reference" "C?" (at 172.72 120.65 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "1nF,2kV" (at 180.34 125.73 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_1206_3216Metric" (at 173.99 129.54 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 172.72 123.19 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "1206B102K202NT" (at 171.45 133.35 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 171.45 135.89 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 172.72 123.19 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 04cd3682-0b25-491b-8959-346d8a2cf9ce))
    (pin "2" (uuid 429d4747-4cc2-45c9-b67a-cad3e60d316a))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C77") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C125") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:0.1uF,16V_0402") (at 63.5 105.41 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid c74ab12a-760b-4ba7-bc05-6e46463cae4e)
    (property "Reference" "C?" (at 63.5 102.87 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "62pF,50V" (at 63.5 107.95 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "03_HPM_Capacitance:C_0402_1005Metric" (at 66.04 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 63.5 105.41 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "CL05B104KO5NNNC" (at 64.77 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "SAMSUNG(三星)" (at 63.5 116.84 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "DNP" (at 63.5 105.41 0)
      (effects (font (size 1.27 1.27)))
    )
    (pin "1" (uuid 04a67e58-23f1-4ff2-a007-bcf57ab2e233))
    (pin "2" (uuid 53a47eb2-c5c1-410c-8712-e9bc8ebfce59))
    (instances
      (project "Quadrotor"
        (path "/667e29ad-c85d-4275-8d34-f753abe697a5"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM5300-POWER"
        (path "/8734e6f2-1a28-439c-b1cd-c359c29fe239"
          (reference "C?") (unit 1)
        )
      )
      (project "EncoderServo"
        (path "/87ce6d31-805d-4cce-9819-5ea00d9d0b32"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/2dda6564-240e-411c-87a3-0164d71f620d"
          (reference "C163") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C79") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C80") (unit 1)
        )
      )
      (project "HPM5300 EVK REVA"
        (path "/da9d8c97-5301-4179-9d57-0a9ed815b1de/f237d9fc-f580-4ea3-9608-ea1fa5e8032f/836064e3-8c95-41f3-ac54-70b3777422f7"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND") (at 274.32 77.47 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid c7e93108-9ffc-437b-a6ad-4f2c23fcf21c)
    (property "Reference" "#PWR0110" (at 280.67 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND" (at 278.13 77.47 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 274.32 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 274.32 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 7efb88e1-b2be-4720-9421-9da1ce0b17c4))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "#PWR0110") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0251") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:1K_0402") (at 66.04 158.75 270) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid c9e5ca0d-eb6c-49b6-a0ba-887c0ec95f0e)
    (property "Reference" "R7" (at 64.77 166.37 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "1K" (at 64.77 156.21 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 63.5 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 66.04 158.75 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF1001TCE" (at 58.42 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 60.96 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 66.04 158.75 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid f676abff-8c5f-401c-bf80-c8eb75a126b0))
    (pin "2" (uuid 000d3130-c90e-4c48-a850-d78769989ed4))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "R7") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "R102") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R114") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:10uF,10V_0603") (at 139.7 59.69 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid d44b7ca2-8078-4f8b-870f-9648f912c70b)
    (property "Reference" "C119" (at 139.7 57.15 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "10uF,10V" (at 139.7 62.23 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 139.7 71.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 139.7 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " CL10A106KP8NNNC" (at 139.7 68.58 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " SAMSUNG(三星) " (at 139.7 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 139.7 59.69 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid d150c55f-77e4-4dc4-ba43-55d785f0a78a))
    (pin "2" (uuid c864f204-59de-4386-90e1-c49e225d496d))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C119") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C69") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "01-HPM-Peripheral:LED_RED") (at 142.24 148.59 180) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid dd1e3fa6-7885-49af-b02d-09addad09c49)
    (property "Reference" "LED?" (at 137.16 147.32 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "LED_RED" (at 144.78 147.32 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "01_HPM_Peripheral:LED_0603" (at 142.24 137.16 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 142.24 154.051 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "NCD0603R1" (at 143.51 139.7 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "国星光电" (at 143.51 142.24 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 142.24 148.59 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid afb90afd-3746-42df-96e3-94222dc4e43b))
    (pin "2" (uuid efe7294e-12f4-4d23-b367-5dedca5c5ba5))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/b8432231-9443-4f8c-b065-03c77811eba6"
          (reference "LED?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/26258b01-d699-48f1-bf49-060b9aea75c9"
          (reference "LED1") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "LED4") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "LED8") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:33Ω_0402") (at 78.74 68.58 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid ddb8d3d3-233e-45f6-b96c-107630589c44)
    (property "Reference" "R?" (at 73.66 67.31 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "33Ω" (at 83.82 67.31 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 78.74 71.12 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 78.74 68.58 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF330JTCE" (at 78.74 76.2 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 78.74 73.66 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 78.74 68.58 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid b390bf1c-2366-451d-ba94-d9137a436820))
    (pin "2" (uuid 1ded6189-fe35-4057-ac7d-ffb185fc2592))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/2dda6564-240e-411c-87a3-0164d71f620d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/21a69ad3-d4bc-4ca6-8758-48254c4665b1"
          (reference "R140") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R85") (unit 1)
        )
      )
      (project "HPM6880_EVK_RevA"
        (path "/e92d7a75-e0f4-4ae1-b25f-e49fa1896fde/823d5e44-9968-4aa0-a43b-e6cff4a216f9/9e4b3c9c-9fdb-493d-9535-b7805f2c3983"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "00_HPM_power:GND3") (at 212.09 113.03 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid e5d81318-088c-4263-a533-a599b5765f1d)
    (property "Reference" "#PWR0163" (at 212.09 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Value" "GND3" (at 212.09 118.11 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "" (at 212.09 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 212.09 113.03 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 23a09350-7cb5-4454-9475-be52d9b496d4))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "#PWR0163") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:330Ω_0402") (at 264.16 77.47 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid e60d4b3d-c950-41a1-a725-18ca043b612d)
    (property "Reference" "R66" (at 259.08 76.2 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "330Ω" (at 270.51 76.2 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 264.16 82.55 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 264.16 77.47 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF3300TCE" (at 264.16 85.09 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 264.16 87.63 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 264.16 77.47 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 4d8f9e5e-1567-4ae2-9e94-d635904b5bca))
    (pin "2" (uuid e4188e20-e34c-413a-a902-42973b9fdf2c))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R66") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R113") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:1nF,2kV_1206") (at 184.15 123.19 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid e75228ec-4b86-416e-8f2a-33ff3bcf2abf)
    (property "Reference" "C?" (at 184.15 120.65 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "1nF,2kV" (at 191.77 125.73 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_1206_3216Metric" (at 185.42 129.54 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 184.15 123.19 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "1206B102K202NT" (at 182.88 133.35 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 182.88 135.89 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 184.15 123.19 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 8108a689-5bc8-4e14-99bf-73724f18181c))
    (pin "2" (uuid 0198696a-8338-4adc-8fd5-52f93e93a5f5))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C78") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C126") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:75Ω_0603") (at 224.79 97.79 90) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid ec5f7d03-c2ad-4af2-b58f-93a817a8693f)
    (property "Reference" "R?" (at 224.79 93.98 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Value" "75Ω_0603" (at 226.06 99.06 90)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 227.33 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 224.79 97.79 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0603WAF750JT5E" (at 232.41 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 229.87 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 224.79 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 70581b18-8d26-4a3f-be59-570667b49541))
    (pin "2" (uuid f77d8a27-f89f-4312-b8aa-6671549065d0))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "R?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R80") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R127") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "R?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "R?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:10uF,10V_0603") (at 201.93 38.1 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid ee7b462d-772b-42a5-adf6-e0a6ed8ad29c)
    (property "Reference" "C14" (at 201.93 35.56 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "10uF,10V" (at 201.93 40.64 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Footprint" "02_HPM_Resistor:R_0603_1608Metric" (at 201.93 49.53 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 201.93 38.1 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" " CL10A106KP8NNNC" (at 201.93 46.99 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" " SAMSUNG(三星) " (at 201.93 54.61 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 201.93 38.1 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 61395b8e-238e-428a-8cb4-b8e1cf014647))
    (pin "2" (uuid 2366cc68-584b-43de-bde6-3bc343ea0427))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C14") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C69") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "14_HPM_Internet:11FB-05NL") (at 195.58 81.28 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no) (fields_autoplaced)
    (uuid f454e347-bf15-418d-beb3-ab5315ba84a4)
    (property "Reference" "T?" (at 195.58 64.77 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "网口变压器11FB-05NL" (at 195.58 67.31 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "11_HPM_Internet:H1102_XFMR16_SM" (at 195.58 97.79 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "" (at 195.58 85.598 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "11FB-05NL" (at 195.58 102.87 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "YDS(元册科技)" (at 195.58 100.33 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 195.58 81.28 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid a0ff303b-db86-494c-8d81-44fada8f9abc))
    (pin "10" (uuid e63129a9-ac09-4def-b8f2-607beaabc97d))
    (pin "11" (uuid 2ec2b96b-f3c4-4c67-b3ec-1a32ca549489))
    (pin "12" (uuid daad7cec-f4e9-437a-a683-5888c194acf2))
    (pin "13" (uuid 40caadf0-e54d-409f-8f5d-041782772ca9))
    (pin "14" (uuid 827071ec-a14d-4423-8b62-f2c24b7d8a4b))
    (pin "15" (uuid 7039d0d8-b6bf-4086-aa9a-000eaad3792f))
    (pin "16" (uuid 1720ca10-e14b-4f2e-8401-0a85a2daae5d))
    (pin "2" (uuid 73a68b0b-6b61-4bee-b8c6-e09ec4339178))
    (pin "3" (uuid edc1deac-bdbf-41e0-804c-3ad486735e2d))
    (pin "4" (uuid 1cadb2c4-c369-4936-8f26-9aa725f971eb))
    (pin "5" (uuid 6fe1a408-def7-4d1d-a9f5-2bd2118bed88))
    (pin "6" (uuid 3631849b-5549-477d-ba54-42530d82f567))
    (pin "7" (uuid cd610121-b2cc-4082-af2c-17dcac4887a1))
    (pin "8" (uuid b589ba73-bbf4-4394-aa8f-7a8b58615b85))
    (pin "9" (uuid ce205041-247a-41bc-b332-525587d56539))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "T?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "T1") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "T2") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "T?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "T?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "T?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "T?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "T?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "T?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "03_HPM_Capacitance:1nF,2kV_1206") (at 219.71 109.22 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid f71b7dd7-9be4-4def-b13b-ff22d8cb4891)
    (property "Reference" "C?" (at 219.71 106.68 0)
      (effects (font (size 1.27 1.27)) (justify left))
    )
    (property "Value" "1nF,2kV" (at 227.33 111.76 0)
      (effects (font (size 1.27 1.27)) (justify right))
    )
    (property "Footprint" "03_HPM_Capacitance:C_1206_3216Metric" (at 220.98 115.57 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 219.71 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "1206B102K202NT" (at 218.44 119.38 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "FH(风华)" (at 218.44 121.92 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 219.71 109.22 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 62c2db72-07ee-456f-9a26-4feef1904ca6))
    (pin "2" (uuid 5b95d6a5-9565-480f-a82a-d7a847542483))
    (instances
      (project "05-HPM1200-ETHERCAT1"
        (path "/1c91b41e-71b4-46da-b5e6-8e37ea133e88"
          (reference "C?") (unit 1)
        )
      )
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "C75") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "C123") (unit 1)
        )
      )
      (project "HPM1200_ETHERNET_FPGA_VALIDATE_B"
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/9d956cca-5a88-4e63-aaa4-2f433b091d84/b0b683ed-6cbb-4757-8c82-76e1c44af5ff"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/bdf5085c-7078-44d2-b715-a6214417bf12/7982a21b-d3c3-4f64-b6cb-f95d582c33b7"
          (reference "C?") (unit 1)
        )
        (path "/c2b8bdef-34fb-4572-af82-9fe5b16d4a5e/0717604a-582c-46eb-8b56-a0a8aa58641c/86af9c24-e09f-4976-a3fb-8daf374f2041/fab42821-2ca7-49ed-9be6-6c6791314d92/3fd4df72-e201-4692-ab19-50018ddcb5e3"
          (reference "C?") (unit 1)
        )
      )
    )
  )

  (symbol (lib_id "02_HPM_Resistor:33Ω_0402") (at 78.74 48.26 0) (unit 1)
    (in_bom yes) (on_board yes) (dnp no)
    (uuid fc093b6b-40f9-4235-ac17-569f3c76cdb7)
    (property "Reference" "R?" (at 73.66 46.99 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Value" "33Ω" (at 83.82 46.99 0)
      (effects (font (size 1.27 1.27)))
    )
    (property "Footprint" "02_HPM_Resistor:R_0402_1005Metric" (at 78.74 50.8 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Datasheet" "~" (at 78.74 48.26 90)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Model" "0402WGF330JTCE" (at 78.74 55.88 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "Company" "UNI-ROYAL(厚声)" (at 78.74 53.34 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (property "ASSY_OPT" "" (at 78.74 48.26 0)
      (effects (font (size 1.27 1.27)) hide)
    )
    (pin "1" (uuid 9536c833-9350-42b4-9f54-826efef2f2bc))
    (pin "2" (uuid 8e434fea-24ee-4d56-9040-f21b48b259bd))
    (instances
      (project "HPM6E00EVKRevC"
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/00ec6331-320c-41ca-90b3-2a365d4e193d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/2dda6564-240e-411c-87a3-0164d71f620d"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/4a6d41ae-2d85-4466-b2fe-4fe5ff2a0505"
          (reference "R?") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/21a69ad3-d4bc-4ca6-8758-48254c4665b1"
          (reference "R140") (unit 1)
        )
        (path "/beb44ed8-7622-45cf-bbfb-b2d5b9d8c208/f1049d94-3709-48ef-97b5-91120e738f00/3a910f40-0a09-4108-80d6-1fa75b40b1af"
          (reference "R83") (unit 1)
        )
      )
      (project "HPM6880_EVK_RevA"
        (path "/e92d7a75-e0f4-4ae1-b25f-e49fa1896fde/823d5e44-9968-4aa0-a43b-e6cff4a216f9/9e4b3c9c-9fdb-493d-9535-b7805f2c3983"
          (reference "R?") (unit 1)
        )
      )
    )
  )
)
